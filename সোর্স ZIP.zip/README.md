# হাট হিসাব (Hat Hisab) v1.0.0

পেঁয়াজ হাটের কর্মচারীর জন্য অফলাইন-ফার্স্ট ব্যক্তিগত হিসাব অ্যাপ — সম্পূর্ণ বাংলা UI।

## ইনস্টল
1. APK ফোনে কপি করুন (`হাট-হিসাব-v1.0.0.apk` — সব ফোনে চলে; `arm64` ছোট সংস্করণ ২০১৬+ ফোনের জন্য)
2. ফোনে **সেটিংস → অ্যাপ → স্পেশাল অ্যাক্সেস → অজানা অ্যাপ ইনস্টল** অনুমতি দিন
3. APK-তে ট্যাপ করে ইনস্টল করুন — Android 7.0 (API 24) বা তার পরের যেকোনো ফোনে

## প্রথম ব্যবহার
- **অ্যাকাউন্ট ছাড়াই** শুরু করা যায় (অতিথি মোড) — সব ডেটা ফোনেই থাকে
- পরে Settings → অ্যাকাউন্ট খুললে পুরনো ডেটা স্বয়ংক্রিয়ভাবে সিঙ্ক হবে (ডেটা হারাবে না)
- Supabase sync: ইন্টারনেট পেলেই অটো-সিঙ্ক; ম্যানুয়াল সিঙ্ক Settings-এ

## মূল ফিচার
- **হাট সেশন** — মাল ক্রয় (কেজি × দর, weighted গড়), ছোতা/স্লিপ/মেমো, closing-এ টাকা গুনে পার্থক্য দেখা
- **Cash-in-Hand** — হাতে যত টাকা থাকার কথা, সব এন্ট্রির যোগফল (হিসাব মিলতে বাধ্য)
- **আম্মু ৳500** — এক ট্যাপে, streak সহ
- **DPS** — লক্ষ্য, অগ্রগতি, পরবর্তী কিস্তির রিমাইন্ডার
- **ধার** — ব্যক্তি-ভিত্তিক পাওনা/দেনা, partial ফেরত, overdue সতর্কতা
- **বাইক** — full-tank পদ্ধতিতে সঠিক km/L, ৳/কিমি, মাইলেজ কমলে চেকলিস্ট
- **টাকা গনক** — নোট গুনে ব্যালেন্সের সাথে মেলানো
- **ক্যালেন্ডার / রিপোর্ট / PDF-Export / CSV/JSON ব্যাকআপ**
- **PIN + Biometric লক, প্রাইভেসি মোড (৳•••), ডার্ক/লাইট থিম, বাংলা/English সংখ্যা**

## ডেভেলপার
```bash
flutter pub get
dart run build_runner build --delete-conflicting-outputs   # Drift codegen
flutter analyze   # 0 issue
flutter test      # 65 tests
flutter build apk --release          # fat APK
flutter build appbundle --release    # Play Store AAB
```

### Supabase
- URL/key: `lib/data/remote/supabase_client.dart` (ডিফল্ট prod; `--dart-define` দিয়ে বদলানো যায়)
- Migrations: `supabase/migrations/0001..0003` (টেবিল + RLS + index)
- Keystore: প্রজেক্টের বাইরে (vault-এ) রাখুন — পাসওয়ার্ড কোনো ফাইলে লেখা যাবে না (Audit 2026-10-29, C-1)

### টেক স্ট্যাক (docs/04_TRD locked)
Flutter 3.24.5 · Riverpod 2.5.1 · go_router 14.2.7 · Drift/SQLite · supabase_flutter 2.5.6 · fl_chart 0.69.0
