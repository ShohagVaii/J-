# হাট হিসাব — সম্পূর্ণ অডিট রিপোর্ট ও ফিক্স লগ
**তারিখ:** 2026-10-29 · **অডিট করা ভার্সন:** 1.2.0+4 · **ফিক্সড ভার্সন:** 1.2.1+5
**পদ্ধতি:** 3টি স্বতন্ত্র অডিট পাস (হিসাব/ডাটাবেস · Sync/Security · UI/Build) — মূল বাগগুলো in-memory Drift DB-তে probe test চালিয়ে runtime-এ যাচাই করা। তারপর `flutter analyze` (0 error) + পূর্ণ test suite: **39/39 passed** (আগের 26 + নতুন 13টি রিগ্রেশন টেস্ট, `test/repository_fix_test.dart`)।


> **⚠️ APK বিল্ডের অবস্থা (সৎ নোট):** এই পরিবেশে (Muse-এর VM) `flutter build apk` চালানো যায়নি — কোডের কারণে নয়। Gradle daemon-এর নেটওয়ার্ক সংযোগ VM-এর নিরাপত্তা-স্তরে ব্লক পেয়েছে ("Other TCP connections is turned off for this assistant") — ফলে AGP/dependency ডাউনলোড অসম্ভব ছিল। বিল্ডের আগের সব ধাপ সম্পন্ন ও যাচাইকৃত: `flutter analyze` 0 error, `flutter test` 39/39 passed। **APK পেতে:** Muse settings → Permissions → Direct network protocols → `other_tcp` কে Deny থেকে Ask করলেই পরের বার বিল্ড চলবে; অথবা নিজের মেশিনে এই ZIP খুলে `flutter build apk --release` চালালেই হবে (toolchain: Flutter 3.24.5 + JDK 17 + SDK 34)।

**চিহ্ন:** ✅ = এই রিলিজে ফিক্সড ও যাচাইকৃত · 🟡 = আংশিক ফিক্সড · 📋 = ওপেন (পরের রিলিজের কাজ, কারণসহ)

---

## সারসংক্ষেপ — সবচেয়ে গুরুতর সত্য

অ্যাপটি দেখতে সম্পূর্ণ হলেও **ডাটা লেখার মূল পথটাই ভাঙা ছিল**: `AppRepository`-র generic insert/update/soft-delete প্রতিবার runtime `TypeError` ছুড়ত। অর্থাৎ বেশিরভাগ সেভ/এডিট/ডিলিট আসলে ডাটাবেসে পৌঁছাতই না (বা error খেয়ে হারিয়ে যেত)। আগের 26টি টেস্ট পাস করত কারণ সেগুলো repository ব্যবহারই করত না — সরাসরি `db.into(...)` দিয়ে লিখত। এই রিলিজে সেই পথ পুরোপুরি নতুন করে লেখা হয়েছে এবং repository-level টেস্ট যোগ করা হয়েছে যাতে এটা আর কখনো চুপচাপ ভাঙতে না পারে।

---

## CRITICAL — ফিক্সড ✅

| # | সমস্যা | কোথায় | ফিক্স |
|---|---|---|---|
| C-1 | **সব repository লেখা TypeError** — `RawValuesInsertable<dynamic>` vs `Insertable<Wallet>` | `app_repository.dart` `_rv()` | Generic লেখা এখন custom SQL (`_customInsertRow/_customUpdateRow`) দিয়ে; insert/update/softDelete/restore/applyServerRow/importAll/migrate — সব পথ বদলানো |
| C-2 | **Wallet balance কোয়েরি ভাঙা** — `bike_maintenance.amount_paisa` বলে কোনো কলাম নেই (আসল নাম `cost_paisa`); পুরো balance query fail | `app_repository.dart` `watchWalletBalances()` | `SUM(cost_paisa)`; টেস্টে প্রমাণিত: opening ৳1,000 − মোবিল ৳450 = ৳550। **টেস্ট চালাতে গিয়ে আরও দুটি একই-জাতীয় ভুল ধরা পড়েছে:** wallet SQL-এর দুটি loan টার্মেও `loans.amount_paisa` ছিল — আসল কলাম `principal_paisa` (সেগুলোও ঠিক করা হয়েছে) |
| C-3 | **Guest→Account migration প্রথম টেবিলেই crash** — `profiles`-এ `userId` কলাম নেই, generic লুপ সেটাই খুঁজত | `migrateLocalDataToUser()` | profiles লুপ থেকে বাদ (আলাদা হ্যান্ডলিং আগেই ছিল); বাকি টেবিলে custom SQL |
| C-4 | **setSetting/setMeta দ্বিতীয়বার লিখলেই UNIQUE crash** — দ্বিতীয় sync conflict-এই অ্যাপ ভাঙত | `setSetting/setMeta` | `InsertMode.insertOrReplace` |
| SEC-1 | **Release keystore + পাসওয়ার্ড ZIP-এর ভেতরে দুই কপি**, পাসওয়ার্ড দুই README-তেও ছাপা | `android/app/*.keystore`, `keystore-backup/`, `keystore.properties`, README×2 | এই ZIP থেকে keystore/password সম্পূর্ণ সরানো; README scrub; `.gitignore`-এ `keystore.properties/*.keystore/*.jks/local.properties` যোগ। ⚠️ **কীটি compromised ধরে নিতে হবে** — নিচে "আপনার করণীয়" দেখুন |
| SEC-2 | **ইন-অ্যাপ আপডেট: APK ডাউনলোডে কোনো hash/signature যাচাই নেই** — manifest বদলাতে পারলেই সবার ফোনে যেকোনো APK | `update_service.dart` | manifest-এ `sha256` বাধ্যতামূলক (না থাকলে ডাউনলোডই হবে না), URL অবশ্যই https + নিজের Supabase হোস্ট, ডাউনলোডের পর SHA-256 মিলিয়ে তবেই `ready`; না মিললে ফাইল মুছে বাতিল। `canInstall()` অজানা অবস্থায় আর `true` ধরে না |
| UI-1 | **Daily Closing কখনোই সফল হতো না** — SQL-এ `?` ২টি, variable পাঠানো হতো ১টি | `daily_closing_screen.dart` | `scalar(sql, varCount)` — income কোয়েরিতে ২টি variable |
| UI-2 | **Dashboard "আজকের আয়" থেকে পার্সোনাল আয় বাদ** — Dart-এ `+` এর precedence `??`-এর চেয়ে বেশি: `hatIncome ?? (0 + personalIncome)` হয়ে যেত | `dashboard_screen.dart:137` | বন্ধনী ঠিক করা |

## HIGH — ফিক্সড ✅

| # | সমস্যা | ফিক্স |
|---|---|---|
| H-1 | একই দিন দুবার Daily Closing → ডুপ্লিকেট row → `getDailyClosing()` "Too many elements" crash | DB schema v4: `(user_id, txn_date)` unique index (onCreate + onUpgrade, পুরনো ডুপ্লিকেট থাকলে crash না করে index বাদ) |
| H-2 | ওডোমিটার কমে গেলে **ঋণাত্মক মাইলেজ** (−20 km/L) ও গড়ও বিষাক্ত হতো | `distance <= 0` হলে মাইলেজ null; গড়েও বাদ |
| H-3 | আংশিক তেল ভরায় অর্থহীন "আনুমানিক মাইলেজ" (100 km/L জাতীয়) — 05_Schema §3.16-এর বিরোধী | ফুল-ট্যাংক বেসলাইন থাকলে আংশিক এন্ট্রির মাইলেজ null (শুধু "আনুমানিক" পতাকা); কখনো ফুল না হলে জোড়া-ভিত্তিক আনুমানিক আগের মতো |
| H-4 | DPS `nextDueDate()` অতীতের তারিখ দিত (জমা পুরনো হলে) + জমা না থাকলে প্রথম কিস্তি বাদ যেত | দুই শাখাতেই roll-forward লুপ; `_firstDue()` দিয়ে সঠিক প্রথম কিস্তি |
| H-5 | Tally/Import অর্ধেক লিখে থামতে পারত (transaction ছাড়া) | `saveTallyWithItems` ও `importAll` এখন transaction-এ |
| H-6 | Category/Product rename সিঙ্ক-কিউতে যেত না — rename কখনো Supabase-এ পৌঁছাত না | প্রতিটি পথে `_enqueueRow()` যোগ |
| H-7 | Sync queue-তে একটি corrupt payload থাকলে **সব সিঙ্ক চিরদিন আটকে** যেত; delete ব্যর্থ হলে অসীম লুপ; queue-id/payload misalignment-এ ভুল রো done মার্ক হতো | per-item try/catch + attempts cap (delete-এও), `(qid, payload)` জোড়া হিসেবে বহন, লুপ গার্ড |
| H-8 | **App Lock কার্যত ছিলই না** — `/lock` রাউটে কেউ যেত না, re-lock ছিল না, ভুল PIN-এ কোনো সীমা ছিল না; biometric সফল হলেও ফলাফল ফেলে দেওয়া হতো | Router redirect গেট (PIN সেট + locked → `/lock`), onboarding ফ্ল্যাগ এখন সত্যিই পড়া হয়, background-এ 2 মিনিটের বেশি থাকলে re-lock, 5 বার ভুলে 30s cooldown, biometric সফল হলে navigation |
| H-9 | PIN হ্যাশ: এক রাউন্ড SHA-256 + DateTime-ভিত্তিক অনুমেয় salt; salt হারালে চিরস্থায়ী lockout | `Random.secure()` salt, 50,000-রাউন্ড iterated SHA-256 (v2); পুরনো হ্যাশ legacy পথে যাচাই হয়ে সফল হলে v2-তে আপগ্রেড; তৈরি salt এখন সংরক্ষণ হয় |
| H-10 | Notification ভুল সময়ে: timezone সেট না করায় 21:30-এর রিমাইন্ডার 03:30-তে; "প্রতিদিন" আসলে একবারই বাজত | `tz.setLocalLocation(Asia/Dhaka)` + `matchDateTimeComponents: DateTimeComponents.time` |
| H-11 | Excel/CSV এক্সপোর্ট সবসময় খালি (caller `const []` পাঠাত) | Reports এখন মাসের আসল income/expense সারি query করে পাঠায় |
| H-12 | Migration-এ আগের অ্যাকাউন্টের ডাটা নতুন অ্যাকাউন্টে উঠে যেত (cross-account leakage) | মাইগ্রেশনের কিউ এখন শুধু `newUid`-র সারির; import-এ `user_id` বর্তমান ব্যবহারকারীর করা হয় |

## MEDIUM — ফিক্সড ✅

- **M-1** `MoneyFmt.taka(-5000)` → `৳-৫০.০০` ছিল; এখন `-৳৫০.০০` (ভুলটা enshrine করা টেস্টও ঠিক করা হয়েছে)
- **M-2** `parseTakaToPaisa('abc')` → ৳0 হয়ে যেত; `'1.2.3'` → ৳1.20; এখন অবৈধ ইনপুটে `null`
- **M-3** লাইন টোটালে .5 পয়সা rounding floating-point-এ কমে যেত (100.5 → 100); epsilon-সহ ঠিক করা
- **M-4** update-এ nullable ফিল্ড মোছা যেত না → এখন `Value(null)` সত্যিই মোছে
- **M-5** profiles-এ `user_id` ঢোকানোর চেষ্টা → টেবিলে কলাম থাকলেই কেবল বসে
- **M-8** soft-deleted রেকর্ড single-getter দিয়ে ফিরে আসত → সব getter-এ `deletedAt.isNull()`
- **M-9** ০/ঋণাত্মক লোন-পরিশোধ পাস হতো → ব্লক; `loanRemainingPaisa`/`personNetBalancePaisa` helper যোগ
- **M-13** `epochMsToTimeBn()` — ডাকলেই TypeError (dead landmine) → মুছে ফেলা
- **SEC-M** পাসওয়ার্ড ফিল্ড খোলা টেক্সটে দেখাত → `AppTextField`-এ `obscureText` সাপোর্ট + Auth-তে প্রয়োগ
- **SEC-M2** Sync `start()` বারবার ডাকলে listener/timer ডুপ্লিকেট → single-flight গার্ড + subscription সংরক্ষণ/বাতিল
- **SEC-M4** Manifest: `allowBackup=false` যোগ, অপ্রয়োজনীয় `SCHEDULE_EXACT_ALARM` বাদ, FileProvider-এর পুরো-cache উন্মুক্ততা বন্ধ
- **UI-L1** সেশন পণ্যের dropdown-এ লিটারাল `$typed` দেখাত → ঠিক করা
- **UI-L2** হাট ফর্মে ডিফল্ট দিন: কমেন্ট "শুক্র" কিন্তু সিলেক্ট হতো বৃহস্পতিবার → `{5}` (শুক্র)
- **UI-M1** Search-এ বন্ধনী ভুলে soft-deleted হাট-আয় ফলাফলে আসত → ঠিক করা
- **M-14** প্রোফাইলে নাম সেভ হতো না — `saveProfileFields()` তার নিজের `displayName` প্যারামিটারটাই উপেক্ষা করত (নতুন রিগ্রেশন টেস্টে ধরা পড়েছে) → ঠিক করা

## যা যাচাই করে সঠিক পাওয়া গেছে (বদলানো হয়নি)
- Session expected-cash সূত্র হুবহু 05_Schema অনুযায়ী; wage সঠিকভাবে বাদ
- **ক্রয়-পরিশোধের ডাবল-ডেবিট ফাঁদ এড়ানো হয়েছে** — wallet balance-এ purchase paid নেই (ঠিক যেমনটা থাকার কথা)
- Full-tank মাইলেজের মূল সূত্র ও weighted গড় সঠিক ছিল
- Loan status derivation (settled > overdue > partial) সঠিক
- টাকা সর্বত্র integer paisa — `double` শুধু kg/litre/odometer-এ
- Theme-এর hex প্যালেট 03_UI-এর সাথে হুবহু মিলে
- কোনো `service_role` key কোডে নেই; PIN plaintext-এ সংরক্ষিত ছিল না

---

## 📋 ওপেন — এই রিলিজে করা হয়নি (সৎ তালিকা)

| # | বিষয় | কেন পেছালো / কী লাগবে |
|---|---|---|
| O-1 | **Sync conflict (amount) UI** — সার্ভার কপি `sync_meta`-তে জমা হয় কিন্তু পড়া/সমাধান করার স্ক্রিন নেই; push-এ version check নেই | Sync Detail স্ক্রিন + conditional upsert — আলাদা বড় কাজ, V1.3 |
| O-2 | **Logout-এর দুই পথ** (ডাটা রেখে/মুছে) ও অন্য অ্যাকাউন্টে লগইনের আগে সতর্কতা — 05_Schema §5 অনুযায়ী হয়নি | Auth ফ্লো পুনর্গঠন লাগবে |
| O-3 | **Hat Detail স্ক্রিন নেই** (`/hats/:id`) — হাটে ট্যাপ করলে সরাসরি নতুন সেশন খোলে | নতুন স্ক্রিন লাগবে |
| O-4 | Session Step-4-এ **Tally সংযোগ নেই**, Step-3-তে session-expense যোগের UI নেই, বড় difference-এ অতিরিক্ত confirm নেই, counted ফাঁকা রেখে close করা যায় (ঘাটতি ৳0 counted হিসেবে যায়) | Stepper-এর কাজ — গুরুত্বপূর্ণ, V1.3-এর প্রথমে |
| O-5 | **Dark theme-এ light token** — semantic রঙের dark variant সংজ্ঞায়িত কিন্তু ব্যবহার হয়নি (~180 জায়গায়); থিম/সংখ্যা-স্টাইল বদলের Settings UI নেই | Theme extension দিয়ে রিফ্যাক্টর লাগবে |
| O-6 | **পিয়াজ ব্যবসা (Trade) মডিউল README/PLAN-এ প্রতিশ্রুত কিন্তু কোডে নেই**; outer README অন্য (React) অ্যাপের — বিভ্রান্তিকর | সিদ্ধান্ত দরকার: মডিউল বানাবেন নাকি README থেকে প্রতিশ্রুতি তুলবেন |
| O-7 | Local DB-তে FK/CHECK constraint নেই; schema timestamps doc-এর epoch-ms-এর বদলে TEXT ISO | Drift migration সহ ধাপে ধাপে |
| O-8 | DPS/Loan/Hat-day/Bike-service reminder-গুলো schedule করাই হয় না (শুধু Daily Closing হয়); cold-start notification tap হারায় | Trigger অনুযায়ী একটা করে scheduling কোড + tap-routing লিখতে হবে — আলাদা ফিচার-কাজ, V1.3 |

---

## V1.3-তে এই ওপেন আইটেমগুলো করতে যা লাগবে (সারসংক্ষেপ)

- **শুধু কোডের কাজ, ব্যবহারকারীর কাছ থেকে কিছু লাগবে না:** O-2 (Logout-এর দুই পথ), O-3 (Hat Detail স্ক্রিন), O-5 (Dark theme রিফ্যাক্টর), O-8 (বাকি reminder scheduling + tap routing)।
- **ছোট একটা সিদ্ধান্ত লাগবে:** O-1 (conflict হলে ডিফল্ট আচরণ — প্রতিবার জিজ্ঞেস করা / লোকাল রাখা / নতুনটা রাখা), O-4 (কত টাকার বেশি difference হলে অতিরিক্ত confirm চাইবে — প্রস্তাবিত ডিফল্ট ৳200), O-8-এর reminder-এর সময় (প্রস্তাবিত ডিফল্ট দেওয়া যাবে)।
- **ব্যবহারকারীর বড় সিদ্ধান্ত লাগবে:** O-6 (Trade মডিউল আদৌ লাগবে কি না — লাগলে তার প্রয়োজনীয়তা)।
- **সতর্কতার কাজ:** O-7 (DB constraint + migration) — বিদ্যমান ডাটা অক্ষত রেখে schema v5 migration ও টেস্টসহ করতে হবে।
- **APK বিল্ড:** Muse settings-এ `other_tcp` = Ask করলে এই VM-এই বিল্ড সম্ভব; নইলে ব্যবহারকারীর নিজের মেশিনে বিল্ড করতে হবে। অন-ডিভাইস আচরণ (notification সত্যিই বাজে কি না, biometric) শুধু ফোনে ইনস্টল করেই যাচাই সম্ভব।

## উন্নতি ও নতুন ফিচারের প্রস্তাব (V1.3-এর জন্য)

1. **Hat Detail স্ক্রিন** (O-3-এর সঙ্গেই): হাটের ইতিহাস, মোট কেনাবেচা, গড় difference এক পর্দায়।
2. **Conflict সমাধান স্ক্রিন** (O-1): কোন এন্ট্রিতে কত টাকার গরমিল, দুই কপি পাশাপাশি দেখে বেছে নেওয়া।
3. **হাট-ব্যস্ততা স্কোর:** সেশনের লাইন-সংখ্যা ও মোট kg দেখে দিনের ব্যস্ততার ধারণা — মাসিক তুলনায় কাজে লাগবে।
4. **DPS অটো-রিমাইন্ডার চেইন:** কিস্তির আগের দিন সন্ধ্যা + কিস্তির দিন সকাল — দুই ধাপের reminder।
5. **মা-কে টাকা দেওয়ার streak:** পরপর কত হাটে ৳500 দেওয়া হয়েছে — ছোট্ট motivational হিসাব (ড্যাশবোর্ডে)।
6. **Session difference সতর্কতা:** বড় ঘাটতি/উদ্বৃত্তে লাল হাইলাইট + কারণ নোট লেখার ঘর।
7. **এক-ট্যাপ ব্যাকআপ:** Settings থেকে এক চাপে export ফাইল শেয়ার (WhatsApp/Drive)।
8. **Bike সার্ভিস পূর্বাভাস:** শেষ সার্ভিসের km থেকে পরের সার্ভিসের আনুমানিক তারিখ।

*(নোট: এই রিপোর্টের আগের কপিতে ফাইলের শেষাংশ — O-8-এর সারির বাকি অংশ ও এই প্রস্তাব-অংশ — কেটে গিয়েছিল; 2026-10-30-এ তা পূরণ করে দেওয়া হলো।)*

---

# V1.3 আপডেট — 30 October 2026 (সেশন-ফ্লো পুনর্গঠন + ৮ ফিচার)

সূত্র: ব্যবহারকারীর নিজের বর্ণিত হাট-ওয়ার্কফ্লো (`docs/07_Session_Workflow.md`) ও সিদ্ধান্তসমূহ (conflict = প্রতিবার জিজ্ঞাসা; Trade মডিউল লাগবে না)।

## হিসাবের নিয়ম সংশোধন (calc)
- **লাইন-মোট এখন পূর্ণ টাকায় নামিয়ে (floor)** — আগের নিয়মে 3407.50 আসত; ব্যবহারকারীর নিয়ম ৳3,407। নতুন টেস্টে তার নিজের উদাহরণটাই বসানো (৯৪ কেজি × ৳১৪৫০/মন = ৩৪০৭)।
- **পড়তা** এখন সরাসরি মোট ÷ মোট কেজি × ৪০ (per-kg গড়ে round-drift ছিল)।
- লাইন আইটেমে নতুন কলাম (schema v5): `gross_kg`, `deduction_kg`, `rate_paisa_per_maund`; সেশনে `difference_note`।
- Calculator-এর grouping বাগ (৳১০,০০০+ এ অঙ্ক এলোমেলো, যেমন ১২৩৪→"১,৪৩২") ও parseTakaToPaisa-র int64 overflow গার্ড ঠিক করা হয়েছে।

## সেশন UI (docs/07 অনুযায়ী)
- আইটেম ডায়ালগ নতুন করে: বিক্রেতার নাম প্রথমে ও বাধ্যতামূলক → বস্তা ধরে কেজি যোগ (+বস্তা বোতাম) → বাদ কেজি → নেট → মণ-দর → লাইভ মোট। পরিশোধ ফাঁকা = পুরো পরিশোধ (আগে উল্টোটা ছিল); বেশি দিলে সতর্কবার্তা; ডাবল-ট্যাপ গার্ড।
- **বাকি settle**: লিস্টে আইটেমে ট্যাপ = একই ডায়ালগে এডিট/settle (আগে কোনো পথ ছিল না)।
- **রানিং "হাতে অবশিষ্ট ক্যাশ"** বার কেনার স্ক্রিনের উপরে; টাইপ-ভিত্তিক মোট (দেশি ১/দেশী ২/সুখসাগর seed সহ)।
- **সেশন খরচের UI তৈরি** (আগে data-path-ই মৃত ছিল — closing-এ খরচ ধরত না, ভুয়া ঘাটতি দেখাত): ব্যবহারকারীর ৭টি ধরন seed + মুহূর্তে নতুন ধরন যোগ।
- **টালি (টাকা গণক) সেশনের সাথে যুক্ত**: Step-1 (শুরুর ক্যাশ) ও Step-4 (গোনা ক্যাশ) থেকে সরাসরি।
- Closing সুরক্ষা: গোনা ক্যাশ ছাড়া বন্ধ নয়; ৳২০০-র বেশি পার্থক্যে সতর্ক + কারণ লেখার ঘর (difference_note); ডাবল-ক্লোজে পারিশ্রমিক দ্বিগুণ ঢোকার পথ বন্ধ; ভুল টাকার লেখা নীরবে ৳০ হয়ে সেভ হওয়া বন্ধ।
- মালিকের নাম হাটের default থেকে prefill; opening/owner-cash দ্বিগুণ গোনার বিভ্রান্তি দূর করতে লেবেল ও হিন্ট।

## ৮টি ফিচার
1. **Hat Detail স্ক্রিন** (রাউট `/hats/:id`) + **ব্যস্ততা স্কোর** (গড় দিন = ৫০) + বড় difference হাইলাইট।
2. **Conflict-সমাধান স্ক্রিন** (সেটিংসে, গরমিল থাকলে এন্ট্রি দেখায়): লোকাল বনাম সার্ভার পাশাপাশি, টাকার ফিল্ড টাকায়; push-এর আগে **version-check** — সার্ভার এগিয়ে থাকলে overwrite না করে conflict জমা হয়; conflict কাউন্টারের over-count বাগও ঠিক।
3. **Hat Detail** — উপরে দ্রষ্টব্য।
4. **DPS রিমাইন্ডার চেইন**: প্রতি অ্যাকাউন্টে আলাদা নোটিফিকেশন ID (আগে একে অন্যকে overwrite করত); আগের দিন সন্ধ্যা ৭টা + কিস্তির দিন সকাল ৮টা (দৈনিক DPS-এ সন্ধ্যারটা বাদ)।
5. **আম্মুর streak** ড্যাশবোর্ডে (তারিখ-মিল ভিত্তিক; সীমাবদ্ধতা: পরদিন দিলে streak ভাঙে — sessionId-সংযোগ নেই)।
6. **পার্থক্য সতর্ক + কারণ** — উপরে দ্রষ্টব্য (threshold ৳২০০)।
7. **এক-ট্যাপ ব্যাকআপ**: সেটিংসের মূল তালিকা থেকে সরাসরি শেয়ার (আগে শুধু Backup স্ক্রিনে ছিল)।
8. **বাইক সার্ভিস পূর্বাভাস**: বাকি কিমি + দৈনিক গড় চলাচল থেকে আনুমানিক তারিখ; আগের দিন সকাল ৯টায় রিমাইন্ডার।

## যাচাই (verification)
- `flutter analyze` — **0 errors** (শুধু info-level lint)।
- `flutter test` — **50/50 passed** (আগের 39 + V1.3-র নতুন 11: floor-rounding/পড়তা/streak/busy-score/service-forecast)।
- **APK build এখনো হয়নি**: Gradle client↔daemon-এর localhost (Java) TCP সংযোগ Muse-এর নেটওয়ার্ক নীতিতে (other_tcp = Ask) আটকে যাচ্ছে — Python/curl চললেও Java connect ঝুলে থাকে, পরীক্ষা করে নিশ্চিত করা হয়েছে। সমাধান: Settings → Permissions → Direct network protocols → **other_tcp = Allow** করে দিলে build চালানো যাবে।
- Sync-এর নতুন কলামগুলো আপাতত push থেকে বাদ রাখা হয়েছে (`sync_payload.dart`-তে strip) — সার্ভারে `supabase_v13_columns.sql` চালানোর পর strip তুললেই sync চালু হবে; ততদিন sync আগের মতোই চলবে, আটকাবে না।
- **Supabase সার্ভার আপডেট সম্পন্ন (2026-10-30)**: Management API দিয়ে `supabase_v13_columns.sql` চালানো হয়েছে প্রজেক্ট `hat-hisab-prod`-এ; চারটি কলামই information_schema দিয়ে যাচাই করা। `sync_payload.dart` থেকে সাময়িক pushStrip এন্ট্রি দুটি তোলা হয়েছে — নতুন কলাম এখন সিঙ্ক হয়। পুনরায় যাচাই: analyze 0 errors, tests 50/50।

---

## V1.3.1 (2026-10-31) — ভিডিও-রিভিউ ফিক্স: সিঙ্ক + Hat Detail

ব্যবহারকারীর পাঠানো ১৯-মিনিটের স্ক্রিন-রেকর্ডিং দেখে ও লাইভ Supabase
ডাটা/স্কিমা যাচাই করে পাওয়া ও সারানো সমস্যা:

### S-1 (Critical, সিঙ্ক): সার্ভারে কলাম না থাকায় mother_payments আপলোড ব্যর্থ
- লোকাল অ্যাপ `mother_payments.payment_method` ও
  `dps_transactions.payment_method`/`txn_at` পাঠায়, কিন্তু সার্ভার
  টেবিলে এই কলামগুলো ছিল না → প্রতিটি upsert PGRST204-এ ফেল।
- প্রমাণ: ব্যবহারকারীর ভিডিওতে দেওয়া ৳৫০০ আম্মুর পেমেন্ট সার্ভারে
  ০টি (লাইভ query-তে যাচাই)। ৬ বার ব্যর্থ হলে কিউ-আইটেম নীরবে বাদ
  পড়ত — অন্য ফোনে লগইনে ডাটা হারাত।
- ফিক্স (সার্ভার, ইতিমধ্যে লাইভ): `supabase_v131_columns.sql` —
  ৩টি কলাম যোগ ও information_schema দিয়ে যাচাই। অ্যাপ আপডেট ছাড়াই
  পুরনো ভার্সনেও এই পেমেন্ট এখন সিঙ্ক হবে।

### S-2 (সিঙ্ক স্থিতিস্থাপকতা): একটা ব্যর্থতা = পুরো সিঙ্ক "সমস্যা"
- Pull এখন টেবিল-প্রতি isolated; ব্যর্থ টেবিলের নামসহ স্ট্যাটাস
  ("সিঙ্কে সমস্যা (hat_sessions)…"), আসল exception sync_meta-র
  `last_sync_error`-তে থাকে, Settings-এর সিঙ্ক টাইলে ট্যাপ করলে দেখা যায়।
- নেটওয়ার্ক-ঘটিত মোড়ানো এরর (ClientException ইত্যাদি) এখন offline
  হিসেবে গণ্য (আগে generic "সমস্যা" দেখাত — ভিডিওতে নেট বারবার
  ঝরছিল)। Retry backoff সর্বোচ্চ ৫ মিনিট (আগে ৩০)।
- পুরনো ভার্সনের নষ্ট pull-watermark থাকলে timestamp-এররে epoch-এ
  রিসেট করে self-heal।
- Bulk upsert-এর আগে payload key-set uniform করা হয় (মিশ্র-বয়সের
  কিউ-পেলোডে "All object keys must match" ব্যর্থতা ঠেকাতে)।
- `reenqueueOrphanPending()`: sync_status='pending' অথচ কিউতে নেই —
  এমন রো প্রতিটি সিঙ্কের শুরুতে আবার কিউতে ওঠে (S-1-এর মতো কারণে
  ঝরে পড়া ডাটার গ্যারান্টিড প্রত্যাবর্তন)।
- রিগ্রেশন টেস্ট: ব্যবহারকারীর আসল ২৯টি সার্ভার-রো replay করে pull
  যাচাই (`test/sync_repro_test.dart`) — সব প্রয়োগ হয়, throw নয়।

### H-1 (Hat Detail): বন্ধ সেশন "এখনো সেশন হয়নি" + সব হিসাব ০
- কারণ: `_hatDetailProvider` ছিল FutureProvider — হাট তৈরির পরপরই
  প্রথমবার খোলায় খালি ফল ক্যাশ হয়ে থাকে; সেশন বন্ধ করে ফিরলেও
  পুরনো ক্যাশই দেখাত (তালিকায় stream-based গণনা ঠিক ছিল)।
- ফিক্স: StreamProvider (watchSessions স্ট্রিমের ওপর লাইভ হিসাব)।

যাচাই: flutter analyze 0 errors · flutter test 51/51 passed ·
সার্ভার কলাম information_schema-তে নিশ্চিত।
