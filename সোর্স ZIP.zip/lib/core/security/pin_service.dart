import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';

/// PIN সিকিউরিটি — FIX H-2 (Audit 2026-10-29):
/// আগের salt ছিল DateTime-ভিত্তিক (অনুমেয়) আর হ্যাশ ছিল এক রাউন্ড SHA-256।
/// এখন: Random.secure() salt + 50,000 রাউন্ড iterated SHA-256 (v2 ফরম্যাট)।
/// পুরনো (v1) হ্যাশ যাচাইয়ে legacy পথ আছে — সফল হলে v2-তে আপগ্রেড হয়।
class PinService {
  PinService._();

  static const int _iterations = 50000;
  static const String v2Prefix = 'v2\$';

  static bool isV2(String stored) => stored.startsWith(v2Prefix);

  /// নতুন (v2) হ্যাশ — সংরক্ষিত মান 'v2\$<hex>' আকারে থাকে
  static String hashPin(String pin, String salt) {
    var bytes = utf8.encode('$salt:$pin:hat-hisab');
    var digest = sha256.convert(bytes);
    for (var i = 1; i < _iterations; i++) {
      digest = sha256.convert([...digest.bytes, ...utf8.encode(salt)]);
    }
    return '$v2Prefix${digest.toString()}';
  }

  /// পুরনো এক-রাউন্ড হ্যাশ (শুধু legacy যাচাই/আপগ্রেডের জন্য)
  static String legacyHashPin(String pin, String salt) {
    final bytes = utf8.encode('$salt:$pin:hat-hisab');
    return sha256.convert(bytes).toString();
  }

  static String newSalt() {
    final rnd = Random.secure();
    final bytes = List<int>.generate(16, (_) => rnd.nextInt(256));
    return bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
  }

  static bool isValidFormat(String pin) {
    return pin.length == 4 || pin.length == 6;
  }
}
