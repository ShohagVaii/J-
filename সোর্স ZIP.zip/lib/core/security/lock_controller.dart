import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:local_auth/local_auth.dart';

import '../utils/bangla_digits.dart';
import 'pin_service.dart';

/// লক নিয়ন্ত্রণ — PIN (SHA-256+salt) / biometric
class LockController extends ChangeNotifier {
  static final LockController instance = LockController._();
  LockController._();

  static const _storage = FlutterSecureStorage();
  static const _kPin = 'pin_hash';
  static const _kSalt = 'pin_salt';
  static const _kBiometric = 'biometric_enabled';
  static const _kFailCount = 'pin_fail_count';
  static const _kCooldownUntil = 'pin_cooldown_until';

  int _failCount = 0;
  int _cooldownUntilMs = 0;

  /// কুলডাউন বাকি থাকলে সেকেন্ড, নইলে 0
  int get cooldownRemainingSeconds {
    final left = _cooldownUntilMs - DateTime.now().millisecondsSinceEpoch;
    return left > 0 ? (left / 1000).ceil() : 0;
  }

  /// অ্যাপ background থেকে ফিরলে পুনরায় লক (02_AppFlow §3.3)
  void lock() {
    if (isPinSet && !_locked) {
      _locked = true;
      notifyListeners();
    }
  }

  bool get isPinSet => _pinHash != null;
  bool get biometricEnabled => _biometric;
  bool _locked = true;

  String? _pinHash;
  String? _salt;
  bool _biometric = false;

  bool get locked => _locked && isPinSet;

  Future<void> load() async {
    _pinHash = await _storage.read(key: _kPin);
    _salt = await _storage.read(key: _kSalt);
    if (_salt == null) {
      // FIX H-2b: তৈরি করা salt সংরক্ষণ না করলে hash থাকা অবস্থায়
      // PIN চিরদিনের জন্য যাচাই-অযোগ্য হয়ে যেত
      _salt = PinService.newSalt();
      await _storage.write(key: _kSalt, value: _salt);
    }
    _biometric = await _storage.read(key: _kBiometric) == '1';
    _failCount = int.tryParse(await _storage.read(key: _kFailCount) ?? '') ?? 0;
    _cooldownUntilMs = int.tryParse(await _storage.read(key: _kCooldownUntil) ?? '') ?? 0;
    notifyListeners();
  }

  Future<bool> setPin(String pin) async {
    if (!PinService.isValidFormat(pin)) return false;
    final salt = PinService.newSalt();
    await _storage.write(key: _kSalt, value: salt);
    await _storage.write(key: _kPin, value: PinService.hashPin(pin, salt));
    _pinHash = PinService.hashPin(pin, salt);
    notifyListeners();
    return true;
  }

  Future<bool> verifyPin(String pin) async {
    // FIX H-1b: ৫ বার ভুল → ৩০ সেকেন্ড কুলডাউন (02_AppFlow §3.3)
    if (cooldownRemainingSeconds > 0) return false;
    final stored = _pinHash;
    if (stored == null) return false;
    var ok = false;
    if (PinService.isV2(stored)) {
      ok = PinService.hashPin(pin, _salt ?? '') == stored;
    } else {
      // legacy v1 হ্যাশ — মিললে v2-তে আপগ্রেড করে সংরক্ষণ
      ok = PinService.legacyHashPin(pin, _salt ?? '') == stored;
      if (ok) {
        final upgraded = PinService.hashPin(pin, _salt ?? '');
        _pinHash = upgraded;
        await _storage.write(key: _kPin, value: upgraded);
      }
    }
    if (ok) {
      _locked = false;
      _failCount = 0;
      await _storage.write(key: _kFailCount, value: '0');
      notifyListeners();
      return true;
    }
    _failCount++;
    if (_failCount >= 5) {
      _cooldownUntilMs = DateTime.now().millisecondsSinceEpoch + 30000;
      await _storage.write(key: _kCooldownUntil, value: '$_cooldownUntilMs');
      _failCount = 0;
    }
    await _storage.write(key: _kFailCount, value: '$_failCount');
    return false;
  }

  Future<void> clearPin() async {
    await _storage.delete(key: _kPin);
    await _storage.delete(key: _kBiometric);
    _pinHash = null;
    _biometric = false;
    notifyListeners();
  }

  Future<void> setBiometric(bool enabled) async {
    _biometric = enabled;
    await _storage.write(key: _kBiometric, value: enabled ? '1' : '0');
    notifyListeners();
  }

  Future<bool> authenticateBiometric() async {
    try {
      final auth = LocalAuthentication();
      final ok = await auth.authenticate(
        localizedReason: 'হাট হিসাব খুলতে ফিঙ্গারপ্রিন্ট দিন',
        options: const AuthenticationOptions(biometricOnly: true, stickyAuth: true),
      );
      if (ok) {
        _locked = false;
        notifyListeners();
      }
      return ok;
    } catch (_) {
      return false;
    }
  }

  /// প্রথম ৪ সংখ্যা টেস্টের জন্য
  static bool looksLikePin(String v) => fromBanglaDigits(v).length >= 4;
}
