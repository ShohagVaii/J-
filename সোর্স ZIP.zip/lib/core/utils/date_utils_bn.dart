import 'bangla_digits.dart';

const List<String> bnMonths = [
  'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
  'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর',
];

const List<String> bnWeekdays = [
  'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার', 'রবিবার',
];

const List<String> bnWeekdaysShort = [
  'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র', 'শনি', 'রবি',
];

String _d(int n) => toBanglaDigits('$n');

String formatDateBn(String ymd) {
  final p = ymd.split('-');
  if (p.length != 3) return ymd;
  return '${_d(int.parse(p[2]))} ${bnMonths[int.parse(p[1]) - 1]} ${_d(int.parse(p[0]))}';
}

String formatDateShortBn(String ymd) {
  final p = ymd.split('-');
  if (p.length != 3) return ymd;
  return '${_d(int.parse(p[2]))} ${bnMonths[int.parse(p[1]) - 1]}';
}

String formatTimeBn(String hhmm) {
  final p = hhmm.split(':');
  if (p.length < 2) return hhmm;
  var h = int.parse(p[0]);
  final m = p[1];
  final ap = h < 12 ? 'AM' : 'PM';
  var h12 = h % 12;
  if (h12 == 0) h12 = 12;
  return '${_d(h12)}:${_d(int.parse(m))} $ap';
}

/// DateTime → 'YYYY-MM-DD'
String ymdOf(DateTime dt) =>
    '${dt.year.toString().padLeft(4, '0')}-${dt.month.toString().padLeft(2, '0')}-${dt.day.toString().padLeft(2, '0')}';

DateTime dateOf(String ymd) {
  final p = ymd.split('-').map(int.parse).toList();
  return DateTime(p[0], p[1], p[2]);
}

String weekdayNameBn(DateTime dt) => bnWeekdays[dt.weekday - 1];

/// "আজ", "গতকাল", "আগামীকাল", নাহলে ছোট তারিখ
String relativeDayBn(String ymd, {DateTime? now}) {
  final n = now ?? DateTime.now();
  final today = DateTime(n.year, n.month, n.day);
  final d = dateOf(ymd);
  final diff = d.difference(today).inDays;
  if (diff == 0) return 'আজ';
  if (diff == -1) return 'গতকাল';
  if (diff == 1) return 'আগামীকাল';
  return formatDateShortBn(ymd);
}

String monthNameBn(int month) => bnMonths[month - 1];

String monthYearBn(int year, int month) => '${bnMonths[month - 1]} ${_d(year)}';

String timeFromEpochBn(int epochMs) {
  final dt = DateTime.fromMillisecondsSinceEpoch(epochMs);
  var h = dt.hour;
  final ap = h < 12 ? 'AM' : 'PM';
  h = h % 12;
  if (h == 0) h = 12;
  return '${toBanglaDigits('$h')}:${toBanglaDigits(dt.minute.toString().padLeft(2, '0'))} $ap';
}

String dateTimeFromEpochBn(int epochMs) {
  final dt = DateTime.fromMillisecondsSinceEpoch(epochMs);
  return '${formatDateShortBn(ymdOf(dt))}, ${timeFromEpochBn(epochMs)}';
}

/// বাংলা-ডিজিট ইনপুট কন্ট্রোলারের জন্য: allowed chars
bool isAmountChar(String ch) =>
    '0123456789.০১২৩৪৫৬৭৮৯'.contains(ch) && ch.length == 1;
