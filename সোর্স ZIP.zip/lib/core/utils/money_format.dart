import 'bangla_digits.dart';

/// টাকা = integer paisa। সব ফরম্যাট এখানেই।
class MoneyFmt {
  MoneyFmt._();

  /// 123450 → "১,২৩৪.৫০" (বাংলা ডিজিটে, ভারতীয় গ্রুপিং ২,৫০,০০০)
  static String groupBangla(String digits) {
    final neg = digits.startsWith('-');
    var d = neg ? digits.substring(1) : digits;
    final dot = d.indexOf('.');
    String frac = '';
    if (dot >= 0) {
      frac = d.substring(dot);
      d = d.substring(0, dot);
    }
    final groups = <String>[];
    if (d.length > 3) {
      groups.add(d.substring(d.length - 3));
      d = d.substring(0, d.length - 3);
      while (d.length > 2) {
        groups.insert(0, d.substring(d.length - 2));
        d = d.substring(0, d.length - 2);
      }
    }
    if (d.isNotEmpty) groups.insert(0, d);
    return '${neg ? '-' : ''}${groups.join(',')}$frac';
  }

  /// paisa → "৳১,২৩৪.৫০"
  static String taka(int paisa, {bool withSign = false, bool bangla = true}) {
    // FIX M-1: চিহ্ন ৳-এর বাইরে ("-৳৫০.০০", "৳-৫০.০০" নয়)
    final dec = formatPaisaAsDecimal(paisa.abs());
    final grouped = groupBangla(dec);
    final body = bangla ? toBanglaDigits(grouped) : grouped;
    var s = '৳$body';
    if (paisa < 0) s = '-$s';
    if (withSign && paisa > 0) return '+$s';
    return s;
  }

  /// paisa → "১,২৩৪" (শুধু টাকা, পয়সা বাদ — বড় সারাংশে)
  static String takaShort(int paisa) {
    final takaAbs = paisa.abs() ~/ 100;
    final s = toBanglaDigits(groupBangla('$takaAbs'));
    return paisa < 0 ? '-৳$s' : '৳$s';
  }

  /// 12345678 paisa → "১.২৩ লক্ষ" / 2500000 → "২৫ হাজার"
  static String compact(int paisa) {
    final t = paisa.abs() / 100;
    String body;
    if (t >= 10000000) {
      body = '${(t / 10000000).toStringAsFixed(2)} কোটি';
    } else if (t >= 100000) {
      body = '${(t / 100000).toStringAsFixed(2)} লক্ষ';
    } else if (t >= 1000) {
      body = '${(t / 1000).toStringAsFixed(1)} হাজার';
    } else {
      body = t.toStringAsFixed(0);
    }
    final sign = paisa < 0 ? '-' : '';
    return '$sign৳${toBanglaDigits(body)}';
  }

  /// ওজন: 12.5 → "১২.৫ কেজি"
  static String kg(num kg, {String suffix = ' কেজি'}) {
    var s = kg.toStringAsFixed(3);
    s = s.replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
    return '${toBanglaDigits(s)}$suffix';
  }

  /// ".00" হলে বাদ — 1450.00 → 1450, 36.25 থাকবে
  static String _trim00(String dec) =>
      dec.endsWith('.00') ? dec.substring(0, dec.length - 3) : dec;

  /// দর: পয়সা/কেজি → "৳৩৬.২৫/কেজি"
  static String rate(int paisaPerKg) {
    final dec = _trim00(formatPaisaAsDecimal(paisaPerKg));
    return '৳${toBanglaDigits(groupBangla(dec))}/কেজি';
  }

  /// দর সরাসরি পয়সা/মণ থেকে → "৳১,৪৫০/মন" (V1.3: F-11 drift এড়াতে)
  static String rateMaundDirect(int paisaPerMaund) {
    final dec = _trim00(formatPaisaAsDecimal(paisaPerMaund));
    return '৳${toBanglaDigits(groupBangla(dec))}/মন';
  }

  /// দর: পয়সা/কেজি → মন প্রতি (১ মন = ৪০ কেজি) → "৳১,৪৫০/মন"
  static String rateMaund(int paisaPerKg) {
    final dec = _trim00(formatPaisaAsDecimal(paisaPerKg * 40));
    return '৳${toBanglaDigits(groupBangla(dec))}/মন';
  }
}
