/// বাংলা সংখ্যা রূপান্তর — একমাত্র বাস্তবায়ন (CLAUDE.md §ফর্মুল)
const String _bnDigits = '০১২৩৪৫৬৭৮৯';

String toBanglaDigits(String input) {
  final sb = StringBuffer();
  for (final code in input.runes) {
    final ch = String.fromCharCode(code);
    final idx = '0123456789'.indexOf(ch);
    sb.write(idx >= 0 ? _bnDigits[idx] : ch);
  }
  return sb.toString();
}

String fromBanglaDigits(String input) {
  final sb = StringBuffer();
  for (final code in input.runes) {
    final ch = String.fromCharCode(code);
    final idx = _bnDigits.indexOf(ch);
    sb.write(idx >= 0 ? '$idx' : ch);
  }
  return sb.toString();
}

/// "৳১২৩৪.৫০" → 123450 (পয়সা) — ব্যর্থ হলে null
int? parseTakaToPaisa(String raw) {
  final cleaned = fromBanglaDigits(raw)
      .replaceAll('৳', '')
      .replaceAll(',', '')
      .replaceAll(' ', '')
      .replaceAll('৳', '')
      .trim();
  if (cleaned.isEmpty) return null;
  // কঠোর যাচাই (FIX M-2): আবর্জনা লেখা নীরবে ৳০/ভুল টাকায় বদলাবে না
  if (!RegExp(r'^-?\d*(\.\d*)?$').hasMatch(cleaned)) return null;
  final parts = cleaned.split('.');
  if (parts.length > 2) return null;
  final neg = cleaned.startsWith('-');
  final intPart = parts[0].replaceFirst('-', '');
  if (intPart.isEmpty && (parts.length < 2 || parts[1].isEmpty)) return null;
  // FIX V1.3 (F-16): ১২ ডিজিটের বেশি টাকা মানলে ×100-এ int64 wrap হয়ে
  // ঋণাত্মক পয়সা হতে পারে — নিরাপদ সীমার বাইরে হলে প্রত্যাখ্যান।
  if (intPart.length > 12) return null;
  final taka = intPart.isEmpty ? 0 : int.tryParse(intPart);
  if (taka == null) return null;
  var paisa = 0;
  if (parts.length > 1) {
    if (parts[1].length > 2) return null; // পয়সার বেশি ঘর — প্রত্যাখ্যান
    final frac = parts[1].padRight(2, '0');
    final pv = int.tryParse(frac);
    if (pv == null) return null;
    paisa = pv;
  }
  final total = taka * 100 + paisa;
  return neg ? -total : total;
}

String formatPaisaAsDecimal(int paisa) {
  final sign = paisa < 0 ? '-' : '';
  final abs = paisa.abs();
  final taka = abs ~/ 100;
  final rem = abs % 100;
  return '$sign$taka.${rem.toString().padLeft(2, '0')}';
}
