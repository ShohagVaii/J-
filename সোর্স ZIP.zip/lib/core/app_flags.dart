/// স্টার্টআপ ফ্ল্যাগ — main() SharedPreferences থেকে সেট করে।
/// (আলাদা ফাইলে রাখা যাতে router ↔ onboarding circular import না হয়)
bool appOnboarded = true;
