/// Wallet ব্যালেন্সের ক্রেডিট/ডেবিট ম্যাপিং — 05_Schema §4 (অপরিবর্তনীয়)
///
/// Credit (+): income_hat (method≠baki), income_personal, loans(taken) principal,
///             loan_payments (given-এর ফেরত)।
/// Debit (−) : expenses, mother_payments, dps_transactions, loans(given) principal,
///             loan_payments (taken শোধ), fuel_logs, bike_maintenance।
/// ⚠️ hat_purchase_items-এর paid অংশ wallet_balances-এ যায় না (মালিকের ক্যাশ থেকে যায়)।
class LedgerEntry {
  final String walletId;
  final int amountPaisa; // স্বাক্ষরিত: + credit, − debit
  const LedgerEntry({required this.walletId, required this.amountPaisa});
}

int walletBalance({
  required int openingBalancePaisa,
  required List<LedgerEntry> entries,
}) {
  var bal = openingBalancePaisa;
  for (final e in entries) {
    bal += e.amountPaisa;
  }
  return bal;
}

/// প্রতি ওয়ালেটে একত্র করা
Map<String, int> balanceByWallet({
  required Map<String, int> openings,
  required List<LedgerEntry> entries,
}) {
  final out = Map<String, int>.from(openings);
  for (final e in entries) {
    out[e.walletId] = (out[e.walletId] ?? 0) + e.amountPaisa;
  }
  return out;
}

/// পেমেন্ট মেথড থেকে ওয়ালেট ভ্যালিডেশন: baki হলে wallet NULL
bool walletAllowedForMethod(String method, String? walletId) {
  if (method == 'baki') return walletId == null;
  return walletId != null;
}
