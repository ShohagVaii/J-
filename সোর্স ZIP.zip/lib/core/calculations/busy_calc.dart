/// হাট-ব্যস্ততা স্কোর (V1.3, ফিচার ৩) — derived হিসাব, কোনো স্কিমা বদল নেই।
/// ধারণা: কোনো সেশন তার হাটের গড় সেশনের তুলনায় কত ব্যস্ত ছিল —
/// গড় দিন = ৫০, দ্বিগুণ ব্যস্ত = ১০০। লাইন-সংখ্যা ও মোট কেজি দুটোই ধরা হয়।
class BusyScore {
  BusyScore._();

  /// তুলনার ভিত্তি না থাকলে (প্রথম সেশন/গড় ০) null — তখন স্কোর দেখানো হয় না।
  static int? score({
    required int lines,
    required double totalKg,
    required double avgLines,
    required double avgKg,
  }) {
    var parts = 0;
    var sum = 0.0;
    if (avgLines > 0) {
      sum += lines / avgLines;
      parts++;
    }
    if (avgKg > 0) {
      sum += totalKg / avgKg;
      parts++;
    }
    if (parts == 0) return null;
    final rel = sum / parts; // ১.০ = গড় দিন
    return (rel * 50).clamp(0, 100).round();
  }

  static String label(int score) {
    if (score >= 70) return 'খুব ব্যস্ত';
    if (score >= 45) return 'মাঝারি ব্যস্ত';
    return 'হালকা';
  }
}
