/// ফুল-ট্যাংক মাইলেজ সূত্র — 05_Schema §3.16 (একমাত্র বাস্তবায়ন)
class FuelEntryView {
  final String id;
  final String txnDate;
  final double odometerKm;
  final int amountPaisa;
  final double? litre;
  final int? pricePerLitrePaisa;
  final bool isFullTank;
  const FuelEntryView({
    required this.id,
    required this.txnDate,
    required this.odometerKm,
    required this.amountPaisa,
    this.litre,
    this.pricePerLitrePaisa,
    required this.isFullTank,
  });

  double get filledLitre {
    if (litre != null && litre! > 0) return litre!;
    if (pricePerLitrePaisa != null && pricePerLitrePaisa! > 0) {
      return amountPaisa / pricePerLitrePaisa!;
    }
    return 0;
  }
}

class MileageResult {
  final String entryId;
  final double? kmPerLitre; // null = হিসাব নেই
  final bool approximate; // আনুমানিক মোড (দুই ফুল-ট্যাংকের মাঝে ফুল নেই)
  const MileageResult({required this.entryId, this.kmPerLitre, required this.approximate});
}

/// entries: তারিখ অনুসারে পুরনো→নতুন ক্রমে
List<MileageResult> computeMileage(List<FuelEntryView> entries) {
  final results = <MileageResult>[];
  int? lastFullIdx;
  for (var i = 0; i < entries.length; i++) {
    final e = entries[i];
    if (e.isFullTank) {
      if (lastFullIdx == null) {
        results.add(MileageResult(entryId: e.id, kmPerLitre: null, approximate: false));
      } else {
        final prev = entries[lastFullIdx];
        final distance = e.odometerKm - prev.odometerKm;
        var consumed = 0.0;
        for (var j = lastFullIdx + 1; j <= i; j++) {
          consumed += entries[j].filledLitre;
        }
        // FIX H-2: ওডোমিটার কমে গেলে (distance <= 0) মাইলেজ হয় না
        final mpl = (consumed > 0 && distance > 0) ? distance / consumed : null;
        results.add(MileageResult(entryId: e.id, kmPerLitre: mpl, approximate: false));
      }
      lastFullIdx = i;
    } else {
      // FIX H-3 (05_Schema §3.16): ফুল-ট্যাংক বেসলাইন থাকলে আংশিক ভরায় মাইলেজ
      // মাপা যায় না (ট্যাংকে কত ছিল জানা নেই) → মান null, শুধু approximate পতাকা।
      // কখনোই ফুল না হয়ে থাকলে জোড়া-ভিত্তিক আনুমানিক (distance > 0 শর্তে)।
      if (lastFullIdx != null) {
        results.add(MileageResult(entryId: e.id, kmPerLitre: null, approximate: true));
      } else if (i > 0) {
        final prev = entries[i - 1];
        final distance = e.odometerKm - prev.odometerKm;
        final consumed = e.filledLitre;
        final mpl = (consumed > 0 && distance > 0) ? distance / consumed : null;
        results.add(
          MileageResult(entryId: e.id, kmPerLitre: mpl, approximate: true),
        );
      } else {
        results.add(MileageResult(entryId: e.id, kmPerLitre: null, approximate: true));
      }
    }
  }
  return results;
}

/// ওজন-গড়: Σdistance(বৈধ জোড়া) ÷ Σconsumed
double? averageMileage(List<FuelEntryView> entries) {
  double totalDistance = 0, totalConsumed = 0;
  int? lastFullIdx;
  for (var i = 0; i < entries.length; i++) {
    if (!entries[i].isFullTank) continue;
    if (lastFullIdx != null) {
      final distance = entries[i].odometerKm - entries[lastFullIdx].odometerKm;
      var consumed = 0.0;
      for (var j = lastFullIdx + 1; j <= i; j++) {
        consumed += entries[j].filledLitre;
      }
      if (consumed > 0 && distance > 0) {
        totalDistance += distance;
        totalConsumed += consumed;
      }
    }
    lastFullIdx = i;
  }
  if (totalConsumed <= 0) return null;
  return totalDistance / totalConsumed;
}

/// cost/km = মোট বাইক খরচ (fuel+maintenance) ÷ মোট km
double? costPerKm({
  required int totalCostPaisa,
  required double totalKm,
}) {
  if (totalKm <= 0) return null;
  return totalCostPaisa / totalKm;
}

/// বাইক সার্ভিস পূর্বাভাস (V1.3, ফিচার ৮)
class ServiceEstimate {
  final double remainingKm; // ঋণাত্মক = সময় পেরিয়ে গেছে
  final DateTime? estimatedDate; // দৈনিক গড় চলাচল জানা না থাকলে null
  const ServiceEstimate({required this.remainingKm, this.estimatedDate});
}

/// nextServiceKm পর্যন্ত কত বাকি ও আনুমানিক কোন তারিখে পৌঁছাবে।
/// ভিত্তি (nextServiceKm) না থাকলে null।
ServiceEstimate? estimateNextService({
  required double? nextServiceKm,
  required double currentOdometerKm,
  required double? avgKmPerDay,
  required DateTime today,
}) {
  if (nextServiceKm == null) return null;
  final remaining = nextServiceKm - currentOdometerKm;
  DateTime? date;
  if (avgKmPerDay != null && avgKmPerDay > 0) {
    final days = remaining <= 0 ? 0 : (remaining / avgKmPerDay).ceil();
    date = DateTime(today.year, today.month, today.day).add(Duration(days: days));
  }
  return ServiceEstimate(remainingKm: remaining, estimatedDate: date);
}

/// জ্বালানি ইতিহাস থেকে দৈনিক গড় চলাচল (কিমি/দিন)।
/// কমপক্ষে ২টি এন্ট্রি ও ৭ দিনের ব্যবধান না থাকলে null (অনুমান দুর্বল হবে)।
double? avgKmPerDayFromFuel(List<FuelEntryView> entries) {
  if (entries.length < 2) return null;
  final sorted = [...entries]..sort((a, b) => a.txnDate.compareTo(b.txnDate));
  final d1 = DateTime.tryParse(sorted.first.txnDate);
  final d2 = DateTime.tryParse(sorted.last.txnDate);
  if (d1 == null || d2 == null) return null;
  final days = d2.difference(d1).inDays;
  final dist = sorted.last.odometerKm - sorted.first.odometerKm;
  if (days < 7 || dist <= 0) return null;
  return dist / days;
}
