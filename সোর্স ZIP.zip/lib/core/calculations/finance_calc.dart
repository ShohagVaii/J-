// V1.4 FinTrack পোর্ট — বাজেট/গোলের খাঁটি হিসাব (FinTracks BudgetView-এর লজিক)
// টাকা সবসময় integer paisa।

/// 'YYYY-MM' মাস-কী
String monthKeyOf(DateTime dt) =>
    '${dt.year.toString().padLeft(4, '0')}-${dt.month.toString().padLeft(2, '0')}';

enum BudgetStatus { ok, warn, over, noLimit }

/// FinTracks-এর রঙ-লজিক: <80% সবুজ(ok), 80–100% হলুদ(warn), >100% লাল(over)
BudgetStatus budgetStatus({required int spentPaisa, required int limitPaisa}) {
  if (limitPaisa <= 0) return BudgetStatus.noLimit;
  final p = spentPaisa * 100 / limitPaisa;
  if (p > 100) return BudgetStatus.over;
  if (p >= 80) return BudgetStatus.warn;
  return BudgetStatus.ok;
}

/// খরচের শতাংশ (লিমিট 0 হলে: খরচ থাকলে 100, না থাকলে 0)
double budgetUsedPercent({required int spentPaisa, required int limitPaisa}) {
  if (limitPaisa <= 0) return spentPaisa > 0 ? 100 : 0;
  return spentPaisa * 100 / limitPaisa;
}

/// বাকি টাকা (ঋণাত্মক হবে না)
int budgetRemaining({required int spentPaisa, required int limitPaisa}) {
  final r = limitPaisa - spentPaisa;
  return r < 0 ? 0 : r;
}

/// গোলের অগ্রগতি % (0–100-এ সীমাবদ্ধ; টার্গেট 0 হলে 0)
double goalProgressPercent({required int currentPaisa, required int targetPaisa}) {
  if (targetPaisa <= 0) return 0;
  final p = currentPaisa * 100 / targetPaisa;
  if (p < 0) return 0;
  if (p > 100) return 100;
  return p;
}

bool goalReached({required int currentPaisa, required int targetPaisa}) =>
    targetPaisa > 0 && currentPaisa >= targetPaisa;

/// একটা খরচ-এন্ট্রি (ক্যাটাগরি নাম + পয়সা) — spentByCategory-র ইনপুট
class CategorySpend {
  final String category;
  final int amountPaisa;
  const CategorySpend({required this.category, required this.amountPaisa});
}

/// ক্যাটাগরি অনুযায়ী মোট খরচ (FinTracks getSpentForCategory-র সমতুল্য, সব ক্যাটাগরির জন্য)
Map<String, int> spentByCategory(List<CategorySpend> entries) {
  final out = <String, int>{};
  for (final e in entries) {
    out[e.category] = (out[e.category] ?? 0) + e.amountPaisa;
  }
  return out;
}

/// FinTracks PaymentMode (Cash/bKash/Nagad/Rocket/Bank/Card) → হাট হিসাবের
/// payment_method কী। বিদ্যমান মান: cash/bkash/nagad/bank (+baki শুধু পুরনো ফ্লোতে)।
const List<(String, String)> finPaymentModes = [
  ('cash', 'নগদ (Cash)'),
  ('bkash', 'বিকাশ'),
  ('nagad', 'নগদ (মোবাইল ব্যাংকিং)'),
  ('rocket', 'রকেট'),
  ('bank', 'ব্যাংক'),
  ('card', 'কার্ড'),
];

String paymentModeLabel(String key) {
  for (final m in finPaymentModes) {
    if (m.$1 == key) return m.$2;
  }
  return switch (key) {
    'baki' => 'বাকি',
    _ => key,
  };
}
