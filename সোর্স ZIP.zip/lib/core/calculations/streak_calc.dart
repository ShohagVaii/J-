/// আম্মুকে টাকা দেওয়ার ধারাবাহিকতা (V1.3, ফিচার ৫)।
/// সংজ্ঞা: বন্ধ সেশনগুলোর তারিখ (নতুন→পুরনো) ধরে পরপর কতটি হাটের দিনে
/// একই তারিখে মা-কে টাকার এন্ট্রি আছে। পেমেন্ট অন্য দিনে দিলে streak
/// ভাঙা দেখাবে — এটা তারিখ-মিল পদ্ধতির জানা সীমাবদ্ধতা (ডক রিপোর্টে উল্লেখ আছে)।
int motherStreak({
  required List<String> closedSessionDatesYmd,
  required Set<String> motherPaymentDatesYmd,
}) {
  final dates = closedSessionDatesYmd.toSet().toList()
    ..sort((a, b) => b.compareTo(a)); // নতুন আগে, দিনে একবার
  var streak = 0;
  for (final d in dates) {
    if (motherPaymentDatesYmd.contains(d)) {
      streak++;
    } else {
      break;
    }
  }
  return streak;
}
