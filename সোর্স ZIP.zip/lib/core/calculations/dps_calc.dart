/// DPS সূত্র — v1.1: দৈনিক/সাপ্তাহিক/মাসিক ফ্রিকোয়েন্সি সমর্থিত
class DpsFrequency {
  static const daily = 'daily';
  static const weekly = 'weekly';
  static const monthly = 'monthly';

  static String label(String f) {
    switch (f) {
      case daily:
        return 'দৈনিক';
      case weekly:
        return 'সাপ্তাহিক';
      default:
        return 'মাসিক';
    }
  }

  /// due_day অর্থ: monthly → ১–২৮ (তারিখ); weekly → 0=শনি..6=শুক্র (DateTime.weekday নয়!);
  /// আমরা weekday হিসেবে DateTime.weekday (1=সোম..7=রবি) ব্যবহার করব weekly-তে।
  static String dueDayLabel(String frequency, int dueDay) {
    if (frequency == weekly) {
      const names = ['', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার', 'রবিবার'];
      return dueDay >= 1 && dueDay <= 7 ? names[dueDay] : '';
    }
    if (frequency == daily) return 'প্রতিদিন';
    return 'প্রতি মাসের $dueDay তারিখ'.replaceAll('$dueDay', _bnNum(dueDay));
  }
}

String _bnNum(int n) {
  const d = '০১২৩৪৫৬৭৮৯';
  return '$n'.split('').map((c) => d[int.parse(c)]).join();
}

/// পরবর্তী কিস্তির তারিখ: lastDepositDate (YYYY-MM-DD) বা start_date থেকে
String? nextDueDate({
  required String frequency,
  required int dueDay,
  required String startDateYmd,
  String? lastDepositDateYmd,
  DateTime? today,
}) {
  final t = today ?? DateTime.now();
  final todayYmd =
      '${t.year.toString().padLeft(4, '0')}-${t.month.toString().padLeft(2, '0')}-${t.day.toString().padLeft(2, '0')}';

  String step(String fromYmd) {
    final p = fromYmd.split('-').map(int.parse).toList();
    var y = p[0], m = p[1], d = p[2];
    switch (frequency) {
      case DpsFrequency.daily:
        final dt = DateTime(y, m, d).add(const Duration(days: 1));
        return _ymd(dt);
      case DpsFrequency.weekly:
        // পরের বার dueDay-ওয়ালা বার (weekday: 1=সোম..7=রবি)
        var dt = DateTime(y, m, d).add(const Duration(days: 1));
        final target = dueDay.clamp(1, 7);
        while (dt.weekday != target) {
          dt = dt.add(const Duration(days: 1));
        }
        return _ymd(dt);
      default:
        // পরের মাসের dueDay (১–২৮ নিরাপদ)
        m += 1;
        if (m > 12) {
          m = 1;
          y += 1;
        }
        return _ymd(DateTime(y, m, dueDay.clamp(1, 28)));
    }
  }

  // FIX H-8: দুই শাখাতেই একই নিয়ম — পরবর্তী কিস্তি কখনো অতীতে হবে না,
  // এবং জমা না থাকলে প্রথম কিস্তি বাদ যাবে না।
  String nxt;
  if (lastDepositDateYmd != null) {
    nxt = step(lastDepositDateYmd);
  } else {
    nxt = _firstDue(frequency, dueDay, startDateYmd);
  }
  var guard = 0;
  while (nxt.compareTo(todayYmd) < 0 && guard < 600) {
    nxt = step(nxt);
    guard++;
  }
  return nxt;
}

/// জমা শুরুর আগের/সমান প্রথম কিস্তির তারিখ (start_date থেকে)
String _firstDue(String frequency, int dueDay, String startDateYmd) {
  final p = startDateYmd.split('-').map(int.parse).toList();
  final y = p[0], m = p[1], d = p[2];
  switch (frequency) {
    case DpsFrequency.daily:
      return startDateYmd;
    case DpsFrequency.weekly:
      var dt = DateTime(y, m, d);
      final target = dueDay.clamp(1, 7);
      while (dt.weekday != target) {
        dt = dt.add(const Duration(days: 1));
      }
      return _ymd(dt);
    default:
      final dd = dueDay.clamp(1, 28);
      var cand = DateTime(y, m, dd);
      if (cand.isBefore(DateTime(y, m, d))) {
        cand = DateTime(y, m + 1, dd);
      }
      return _ymd(cand);
  }
}

String _ymd(DateTime dt) =>
    '${dt.year.toString().padLeft(4, '0')}-${dt.month.toString().padLeft(2, '0')}-${dt.day.toString().padLeft(2, '0')}';

/// মোট জমা
int totalDeposited(List<int> amountsPaisa) =>
    amountsPaisa.fold(0, (a, b) => a + b);

/// প্রত্যাশিত জমা এ পর্যন্ত (streak/ট্র্যাকিং প্রগ্রেসের জন্য)
int expectedDepositsCount({
  required String frequency,
  required String startDateYmd,
  DateTime? today,
}) {
  final t = today ?? DateTime.now();
  final p = startDateYmd.split('-').map(int.parse).toList();
  final start = DateTime(p[0], p[1], p[2]);
  final days = t.difference(start).inDays;
  if (days < 0) return 0;
  switch (frequency) {
    case DpsFrequency.daily:
      return days + 1;
    case DpsFrequency.weekly:
      return (days ~/ 7) + 1;
    default:
      var months = (t.year - start.year) * 12 + (t.month - start.month);
      if (t.day < start.day) months -= 1;
      return months + 1;
  }
}

/// ধারাবাহিকতা (streak): সাম্প্রতিক কিস্তিগুলো কতটা নিয়মিত — সরল গণনা:
/// পরপর কতটি কিস্তির ব্যবধান প্রত্যাশিত ছন্দের মধ্যে (±১ দিন)
int streakCount({
  required String frequency,
  required List<String> depositDatesAsc,
}) {
  if (depositDatesAsc.length < 2) return depositDatesAsc.length;
  final gap = frequency == DpsFrequency.daily
      ? 1
      : frequency == DpsFrequency.weekly
          ? 7
          : 30;
  var streak = 1;
  for (var i = depositDatesAsc.length - 1; i > 0; i--) {
    final a = _date(depositDatesAsc[i]);
    final b = _date(depositDatesAsc[i - 1]);
    final diff = a.difference(b).inDays;
    if ((diff - gap).abs() <= 2) {
      streak++;
    } else {
      break;
    }
  }
  return streak;
}

DateTime _date(String ymd) {
  final p = ymd.split('-').map(int.parse).toList();
  return DateTime(p[0], p[1], p[2]);
}
