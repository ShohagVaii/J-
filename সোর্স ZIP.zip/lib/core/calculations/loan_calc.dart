/// ধারের স্টেটাস — 05_Schema §3.14 (সংরক্ষিত নয়, হিসাব করা)
class LoanStatus {
  static const ongoing = 'ongoing';
  static const partial = 'partial';
  static const settled = 'settled';
  static const overdue = 'overdue';
}

String loanStatusLabel(String status) {
  switch (status) {
    case LoanStatus.settled:
      return 'পরিশোধিত';
    case LoanStatus.partial:
      return 'আংশিক';
    case LoanStatus.overdue:
      return 'বকেয়া';
    default:
      return 'চলমান';
  }
}

/// status নির্ধারণ: paid=0→ongoing, 0<paid<principal→partial, paid≥principal→settled,
/// due_date < today AND paid<principal→overdue
String deriveLoanStatus({
  required int paidPaisa,
  required int principalPaisa,
  String? dueDateYmd,
  DateTime? today,
}) {
  if (paidPaisa >= principalPaisa && principalPaisa > 0) return LoanStatus.settled;
  if (dueDateYmd != null) {
    final t = today ?? DateTime.now();
    final todayYmd =
        '${t.year.toString().padLeft(4, '0')}-${t.month.toString().padLeft(2, '0')}-${t.day.toString().padLeft(2, '0')}';
    if (dueDateYmd.compareTo(todayYmd) < 0) return LoanStatus.overdue;
  }
  if (paidPaisa <= 0) return LoanStatus.ongoing;
  return LoanStatus.partial;
}

/// ওভারপে গার্ড: Σpayments ≤ principal
bool canAddLoanPayment({
  required int currentPaidPaisa,
  required int principalPaisa,
  required int newAmountPaisa,
}) {
  // FIX M-9: ০/ঋণাত্মক "পরিশোধ" গ্রহণযোগ্য নয়
  if (newAmountPaisa <= 0) return false;
  return currentPaidPaisa + newAmountPaisa <= principalPaisa;
}

/// একটি লোনের বাকি (পয়সা) — 05_Schema §3.13/§3.14
int loanRemainingPaisa({required int principalPaisa, required int paidPaisa}) {
  final r = principalPaisa - paidPaisa;
  return r < 0 ? 0 : r;
}

/// একজন ব্যক্তির নেট অবস্থান (পয়সা): ধনাত্মক = আমার পাওনা, ঋণাত্মক = আমার দেনা।
/// loans: প্রতিটি ম্যাপে type ('given'/'taken'), principalPaisa, paidPaisa থাকতে হবে।
int personNetBalancePaisa(List<({String type, int principalPaisa, int paidPaisa})> loans) {
  var net = 0;
  for (final l in loans) {
    final rem = loanRemainingPaisa(principalPaisa: l.principalPaisa, paidPaisa: l.paidPaisa);
    net += l.type == 'given' ? rem : -rem;
  }
  return net;
}
