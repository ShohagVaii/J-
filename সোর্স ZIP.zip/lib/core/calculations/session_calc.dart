/// হাট সেশন সূত্র — একমাত্র বাস্তবায়ন (05_Schema §3.4)
/// সব মান পয়সায় (integer paisa)।
class SessionCalc {
  SessionCalc._();

  /// ১ মন = ৪০ কেজি (স্থানীয় বাজার-প্রথা)
  static const double kgPerMaund = 40;

  /// FIX V1.3 (F-1, docs/07): লাইন-মোট সবসময় পূর্ণ টাকায় নামিয়ে আনা হয় —
  /// হাটে বিক্রেতাকে পয়সা-ভগ্নাংশ দেওয়া হয় না। এই ধ্রুবকটাই সেই নিয়মের
  /// একমাত্র সংজ্ঞা; বদলাতে হলে docs/07 আপডেট করে টেস্টসহ বদলাতে হবে।
  static const int moneyRoundingUnitPaisa = 100; // ১ টাকা

  /// বড় difference সতর্কতার threshold (docs/07 ফিচার ৬): এর বেশি হলে
  /// closing-এর সময় অতিরিক্ত confirm + কারণ নোট চাওয়া হয়।
  static const int differenceAlertThresholdPaisa = 20000; // ৳২০০

  /// মন-দর (পয়সা/মন) → কেজি-দর (পয়সা/কেজি)
  static int paisaPerKgFromMaund(int paisaPerMaund) =>
      (paisaPerMaund / kgPerMaund).round();

  /// কেজি-দর → মন-দর
  static int paisaPerMaundFromKg(int paisaPerKg) =>
      (paisaPerKg * kgPerMaund).round();

  /// মন-দর দিয়ে লাইন মোট: (kg × rate ÷ ৪০), তারপর পূর্ণ টাকায় নামিয়ে।
  /// ব্যবহারকারীর নিজের উদাহরণ (docs/07): ৯৪ কেজি × ৳১৪৫০/মন
  /// → 1450÷40×94 = ৩৪০৭.৫০ → ৳৩,৪০৭ (340700 পয়সা)।
  /// আগের নিয়ম (পয়সায় round) প্রতিটি লাইনে ভুতুড়ে বাকি রেখে দিত (F-1)।
  static int lineTotalMaund({required double kg, required int ratePaisaPerMaund}) {
    final rawPaisa = kg * ratePaisaPerMaund / kgPerMaund;
    return (rawPaisa / moneyRoundingUnitPaisa).floor() * moneyRoundingUnitPaisa;
  }

  /// Expected = Opening + মালিকের ক্যাশ − ক্রয় পরিশোধ − সেশন খরচ
  ///            − ছোতা − স্লিপ − মেমো − মালিককে ফেরত
  /// (পারিশ্রমিক/wage এই সূত্রে নেই — সেটি মালিকের ক্যাশ থেকে নিজের পাওনা)
  static int expectedCash({
    required int openingCashPaisa,
    required int ownerCashReceivedPaisa,
    required int purchasePaidPaisa,
    required int sessionExpensePaisa,
    required int chotaPaisa,
    required int slipChargePaisa,
    required int memoChargePaisa,
    required int returnedToOwnerPaisa,
  }) {
    return openingCashPaisa +
        ownerCashReceivedPaisa -
        purchasePaidPaisa -
        sessionExpensePaisa -
        chotaPaisa -
        slipChargePaisa -
        memoChargePaisa -
        returnedToOwnerPaisa;
  }

  /// difference = counted − expected (প্লাস = বাড়তি, মাইনাস = ঘাটতি)
  static int difference({required int countedPaisa, required int expectedPaisa}) =>
      countedPaisa - expectedPaisa;

  /// লাইন আইটেমের মোট: round(kg × rate_paisa)
  static int lineTotal({required double kg, required int ratePaisaPerKg}) =>
      // FIX M-3: binary floating point-এ 100.5 পয়সা 100.4999… হয়ে round
      // কমে যেত; kg-এর সর্বোচ্চ ৩ দশমিক ঘর থাকায় 1e-6 epsilon নিরাপদ
      (kg * ratePaisaPerKg + 1e-6).round();

  /// ওজন-গড় দর (পয়সা/কেজি): Σtotal ÷ Σkg — kg=0 হলে 0
  static int weightedAvgRate({
    required double totalKg,
    required int totalPaisa,
  }) {
    if (totalKg <= 0) return 0;
    return (totalPaisa / totalKg).round();
  }

  /// FIX V1.3: পড়তা সরাসরি প্রতি-মণ হিসাবে (docs/07):
  /// পড়তা = মোট মূল্য ÷ মোট কেজি × ৪০ (পয়সা/মণ)।
  /// আগে per-kg গড়ে round করে ×৪০ করায় প্রদর্শিত পড়তায় ~৪০ পয়সা
  /// পর্যন্ত drift হতো; এখন এক ধাপেই হিসাব।
  static int weightedAvgRateMaundPaisa({
    required double totalKg,
    required int totalPaisa,
  }) {
    if (totalKg <= 0) return 0;
    return (totalPaisa * kgPerMaund / totalKg).round();
  }
}

/// সেশন লাইন-আইটেমের হালকা ভিউ
class PurchaseLine {
  final String productName;
  final double kg;
  final int ratePaisaPerKg;
  final int paidPaisa;
  const PurchaseLine({
    required this.productName,
    required this.kg,
    required this.ratePaisaPerKg,
    required this.paidPaisa,
  });
  int get totalPaisa => SessionCalc.lineTotal(kg: kg, ratePaisaPerKg: ratePaisaPerKg);
  int get duePaisa => totalPaisa - paidPaisa;
}
