/// মাসিক/দৈনিক সারাংশ হিসাব
class SummaryBucket {
  int hatIncomePaisa = 0;
  int personalIncomePaisa = 0;
  int expensePaisa = 0;
  int motherPaisa = 0;
  int dpsPaisa = 0;
  int loanGivenPaisa = 0; // ধার দেওয়া (বের হয়ে গেছে)
  int loanTakenPaisa = 0; // ধার নেওয়া (ঢুকেছে)
  int loanRepaidInPaisa = 0; // given-এর ফেরত
  int loanRepaidOutPaisa = 0; // taken শোধ
  int bikeFuelPaisa = 0;
  int bikeMaintenancePaisa = 0;

  int get totalIncomePaisa => hatIncomePaisa + personalIncomePaisa;
  int get totalExpensePaisa => expensePaisa + motherPaisa + dpsPaisa + bikeFuelPaisa + bikeMaintenancePaisa;
  int get netPaisa => totalIncomePaisa - totalExpensePaisa;
  int get bikeTotalPaisa => bikeFuelPaisa + bikeMaintenancePaisa;
}

class CategorySlice {
  final String name;
  final int amountPaisa;
  const CategorySlice({required this.name, required this.amountPaisa});
}

/// দিন-ভিত্তিক বার (চার্টের জন্য)
class DayBar {
  final String ymd;
  final int incomePaisa;
  final int expensePaisa;
  const DayBar({required this.ymd, required this.incomePaisa, required this.expensePaisa});
}
