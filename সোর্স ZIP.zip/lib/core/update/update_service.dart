import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../../data/remote/supabase_client.dart';
import '../calculations/update_version.dart';

/// অ্যাপ-ইন আপডেট সিস্টেম (v1.1):
/// অ্যাপ শুরুতে ব্যাকগ্রাউন্ডে চেক → নতুন ভার্সন পেলে ব্যাকগ্রাউন্ডেই ডাউনলোড →
/// প্রস্তুত হলে পপআপ → ইউজার পারমিশন (unknown sources) → ইনস্টল।
class UpdateManifest {
  final String versionName;
  final int versionCode;
  final String url;
  final String notes;

  /// FIX C-2: ডাউনলোড করা APK-এর প্রত্যাশিত SHA-256 (hex)। manifest-এ
  /// না থাকলে আপডেট ডাউনলোডই হবে না — যাচাই ছাড়া ইনস্টল ঝুঁকিপূর্ণ।
  final String sha256;
  const UpdateManifest({
    required this.versionName,
    required this.versionCode,
    required this.url,
    required this.notes,
    this.sha256 = '',
  });

  factory UpdateManifest.fromJson(Map<String, dynamic> j) => UpdateManifest(
        versionName: '${j['versionName'] ?? j['version'] ?? ''}',
        versionCode: int.tryParse('${j['versionCode'] ?? 0}') ?? 0,
        url: '${j['url'] ?? ''}',
        notes: '${j['notes'] ?? ''}',
        sha256: '${j['sha256'] ?? ''}'.trim().toLowerCase(),
      );
}

enum UpdatePhase { idle, checking, upToDate, available, downloading, ready, error }

class UpdateState {
  final UpdatePhase phase;
  final double progress; // 0..1
  final UpdateManifest? manifest;
  final String? filePath;
  final String? error;
  final String currentVersion;
  final int currentVersionCode;
  const UpdateState({
    this.phase = UpdatePhase.idle,
    this.progress = 0,
    this.manifest,
    this.filePath,
    this.error,
    this.currentVersion = '',
    this.currentVersionCode = 0,
  });

  bool get isNewerAvailable =>
      manifest != null &&
      // versionName-ভিত্তিক তুলনা (split-APK-র buildNumber স্কিম যাই হোক,
      // যেমন arm64 = code×1000+2 — কোড-তুলনায় বিভ্রান্তি হয়)
      (compareVersions(manifest!.versionName, currentVersion) > 0 ||
          (manifest!.versionCode > currentVersionCode &&
              manifest!.versionCode >= 1000 &&
              currentVersionCode >= 1000));
}

class UpdateService extends ChangeNotifier {
  UpdateService._();
  static final UpdateService instance = UpdateService._();

  static const MethodChannel _channel = MethodChannel('hat_hisab/updater');

  static String get manifestUrl {
    const custom = String.fromEnvironment('UPDATE_MANIFEST_URL');
    if (custom.isNotEmpty) return custom;
    return '${Supa.defaultUrl}/storage/v1/object/public/updates/version.json';
  }

  UpdateState state = const UpdateState();
  bool _popupShownThisSession = false;
  bool _autoFlowStarted = false;
  void Function(UpdateState ready)? onReadyToInstall;

  Future<void> loadCurrentVersion() async {
    try {
      final info = await PackageInfo.fromPlatform();
      final code = int.tryParse(info.buildNumber) ?? 1;
      // নতুন ভার্সন ইনস্টল হয়ে ফিরে এসেছে? পুরনো 'প্রস্তুত' স্টেট ঝাড়িয়ে দিই
      var phase = state.phase;
      var filePath = state.filePath;
      final m = state.manifest;
      if (m != null && compareVersions(m.versionName, info.version) <= 0) {
        phase = UpdatePhase.upToDate;
        filePath = null;
      }
      state = UpdateState(
        phase: phase,
        progress: state.progress,
        manifest: m,
        filePath: filePath,
        error: state.error,
        currentVersion: info.version,
        currentVersionCode: code,
      );
      notifyListeners();
    } catch (_) {}
  }

  Future<UpdateManifest?> fetchManifest() async {
    try {
      final uri = Uri.parse('$manifestUrl?cb=${DateTime.now().millisecondsSinceEpoch}');
      final resp = await http.get(uri).timeout(const Duration(seconds: 12));
      if (resp.statusCode != 200) return null;
      return UpdateManifest.fromJson(
        Map<String, dynamic>.from(jsonDecode(resp.body) as Map),
      );
    } catch (_) {
      return null;
    }
  }

  /// অ্যাপ শুরুতে নীরব চেক + আপডেট থাকলে ব্যাকগ্রাউন্ড ডাউনলোড
  Future<void> backgroundCheck() async {
    if (_autoFlowStarted) return;
    _autoFlowStarted = true;
    try {
      await loadCurrentVersion();
      state = UpdateState(
        phase: UpdatePhase.checking,
        currentVersion: state.currentVersion,
        currentVersionCode: state.currentVersionCode,
      );
      notifyListeners();
      final m = await fetchManifest();
      if (m == null) {
        state = UpdateState(
          phase: UpdatePhase.idle,
          currentVersion: state.currentVersion,
          currentVersionCode: state.currentVersionCode,
          error: 'আপডেট সার্ভারে পৌঁছানো যায়নি',
        );
        notifyListeners();
        return;
      }
      // ভার্সন-নাম-ভিত্তিক তুলনা — split-APK-র কোড-স্কিম (2003/3003…) বিভ্রান্তি করে
      if (compareVersions(m.versionName, state.currentVersion) <= 0) {
        // পুরনো ডাউনলোড-স্টেট থাকলে পরিষ্কার — "আবার আপডেট প্রস্তুত" দেখাবে না
        state = UpdateState(
          phase: UpdatePhase.upToDate,
          manifest: m,
          currentVersion: state.currentVersion,
          currentVersionCode: state.currentVersionCode,
        );
        notifyListeners();
        return;
      }
      state = UpdateState(
        phase: UpdatePhase.available,
        manifest: m,
        currentVersion: state.currentVersion,
        currentVersionCode: state.currentVersionCode,
      );
      notifyListeners();
      await download(m);
    } catch (_) {
      state = UpdateState(
        phase: UpdatePhase.error,
        error: 'আপডেট চেক ব্যর্থ',
        currentVersion: state.currentVersion,
        currentVersionCode: state.currentVersionCode,
      );
      notifyListeners();
    }
  }

  /// সেটিংস থেকে ম্যানুয়াল চেক (পপআপ আবার দেখানো যাবে)
  Future<void> manualCheck() async {
    _autoFlowStarted = false;
    _popupShownThisSession = true; // ম্যানুয়াল চেকে পপআপ দরকার নেই, সেটিংসেই দেখা যায়
    await backgroundCheck();
  }

  Future<String> _updatesDir() async {
    final dir = await getExternalStorageDirectory();
    final upd = Directory('${dir!.path}/updates');
    if (!await upd.exists()) await upd.create(recursive: true);
    return upd.path;
  }

  Future<void> download(UpdateManifest m) async {
    // FIX C-2: URL অবশ্যই https ও আমাদের Supabase হোস্টের হতে হবে,
    // এবং manifest-এ sha256 থাকতেই হবে
    final uri = Uri.tryParse(m.url);
    final expectedHost = Uri.tryParse(Supa.defaultUrl)?.host ?? '';
    if (uri == null ||
        uri.scheme != 'https' ||
        (expectedHost.isNotEmpty && uri.host != expectedHost) ||
        m.sha256.length != 64) {
      state = UpdateState(
        phase: UpdatePhase.error,
        error: 'আপডেটের তথ্য যাচাই করা যায়নি (sha256/host) — আপডেট বন্ধ রাখা হয়েছে',
        manifest: m,
        currentVersion: state.currentVersion,
        currentVersionCode: state.currentVersionCode,
      );
      notifyListeners();
      return;
    }
    try {
      state = UpdateState(
        phase: UpdatePhase.downloading,
        progress: 0,
        manifest: m,
        currentVersion: state.currentVersion,
        currentVersionCode: state.currentVersionCode,
      );
      notifyListeners();
      final dir = await _updatesDir();
      final file = File('$dir/hat-hisab-${m.versionName}.apk');
      final client = http.Client();
      final req = http.Request('GET', Uri.parse(m.url));
      final resp = await client.send(req).timeout(const Duration(seconds: 30));
      if (resp.statusCode != 200) throw Exception('download ${resp.statusCode}');
      final total = resp.contentLength ?? 0;
      final sink = file.openWrite();
      var received = 0;
      await for (final chunk in resp.stream) {
        received += chunk.length;
        sink.add(chunk);
        if (total > 0) {
          final p = received / total;
          if ((p - state.progress).abs() > 0.02) {
            state = UpdateState(
              phase: UpdatePhase.downloading,
              progress: p,
              manifest: m,
              currentVersion: state.currentVersion,
              currentVersionCode: state.currentVersionCode,
            );
            notifyListeners();
          }
        }
      }
      await sink.flush();
      await sink.close();
      client.close();
      // FIX C-2: ইনস্টলের আগে SHA-256 মিলিয়ে দেখা — না মিললে ফাইল মুছে বাতিল
      final digest = await sha256.bind(file.openRead()).first;
      if (digest.toString() != m.sha256) {
        try { await file.delete(); } catch (_) {}
        throw Exception('sha256 mismatch');
      }
      state = UpdateState(
        phase: UpdatePhase.ready,
        progress: 1,
        manifest: m,
        filePath: file.path,
        currentVersion: state.currentVersion,
        currentVersionCode: state.currentVersionCode,
      );
      notifyListeners();
      if (!_popupShownThisSession) {
        _popupShownThisSession = true;
        onReadyToInstall?.call(state);
      }
    } catch (_) {
      state = UpdateState(
        phase: UpdatePhase.error,
        error: 'ডাউনলোড ব্যর্থ — আবার চেষ্টা করুন',
        manifest: m,
        currentVersion: state.currentVersion,
        currentVersionCode: state.currentVersionCode,
      );
      notifyListeners();
    }
  }

  Future<bool> canInstall() async {
    try {
      return await _channel.invokeMethod('canInstall') as bool;
    } catch (_) {
      // FIX M-7: অজানা অবস্থায় true ধরা যাবে না
      return false;
    }
  }

  Future<void> openPermissionSettings() async {
    try {
      await _channel.invokeMethod('openPermissionSettings');
    } catch (_) {}
  }

  Future<bool> installApk(String path) async {
    try {
      final ok = await _channel.invokeMethod('installApk', {'path': path});
      return ok == true;
    } catch (_) {
      return false;
    }
  }

  /// পপআপ/সেটিংস থেকে: প্রস্তুত হলে পারমিশন চেক করে ইনস্টলার খোলে
  Future<void> installNow() async {
    final path = state.filePath;
    if (path == null) return;
    if (!await canInstall()) {
      await openPermissionSettings();
      return;
    }
    await installApk(path);
  }
}
