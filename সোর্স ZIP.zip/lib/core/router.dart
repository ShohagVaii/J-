import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import 'app_flags.dart';
import 'security/lock_controller.dart';
import 'widgets/floating_calculator.dart';
import '../features/auth/auth_screen.dart';
import '../features/bike/bike_screens.dart';
import '../features/calendar/calendar_screen.dart';
import '../features/dashboard/dashboard_screen.dart';
import '../features/daily_closing/daily_closing_screen.dart';
import '../features/dps/dps_screens.dart';
import '../features/expenses/expenses_screens.dart';
import '../features/finance/finance_screens.dart';
import '../features/hats/hat_detail_screen.dart';
import '../features/hats/hats_screens.dart';
import '../features/hats/session_screens.dart';
import '../features/income/income_screens.dart';
import '../features/lock/lock_screen.dart';
import '../features/loans/loans_screens.dart';
import '../features/more/more_screen.dart';
import '../features/mother/mother_screen.dart';
import '../features/onboarding/onboarding_screen.dart';
import '../features/recycle/recycle_bin_screen.dart';
import '../features/reports/reports_screen.dart';
import '../features/search/search_screen.dart';
import '../features/settings/conflict_screen.dart';
import '../features/settings/settings_screens.dart';
import '../features/shell/home_shell.dart';
import '../features/tally/tally_screen.dart';
import '../features/tools/age_calculator_screen.dart';
import '../features/tools/rate_calculator_screen.dart';

final rootNavigatorKey = GlobalKey<NavigatorState>();
final shellNavigatorKey = GlobalKey<NavigatorState>();

final goRouterProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    navigatorKey: rootNavigatorKey,
    // U-3: modal route উঠলে ভাসমান ক্যালকুলেটর বাটন লুকানোর observer
    observers: [floatingCalcObserver],
    initialLocation: '/',
    // FIX H-1/C-3: PIN সেট থাকলে লক গেট — আগে /lock ও /onboarding
    // declared থাকলেও কোনোদিন সেখানে যাওয়া হতো না।
    refreshListenable: LockController.instance,
    redirect: (context, state) {
      final lc = LockController.instance;
      final loc = state.matchedLocation;
      if (lc.isPinSet && lc.locked && loc != '/lock') return '/lock';
      if ((!lc.isPinSet || !lc.locked) && loc == '/lock') return '/';
      if (!appOnboarded && loc != '/onboarding') return '/onboarding';
      if (appOnboarded && loc == '/onboarding') return '/';
      return null;
    },
    routes: [
      GoRoute(
        path: '/onboarding',
        builder: (c, s) => const OnboardingScreen(),
      ),
      GoRoute(path: '/lock', builder: (c, s) => const LockScreen()),
      GoRoute(path: '/auth', builder: (c, s) => const AuthScreen()),
      StatefulShellRoute.indexedStack(
        builder: (c, s, shell) => HomeShell(shell: shell),
        branches: [
          StatefulShellBranch(observers: [floatingCalcObserver], routes: [
            GoRoute(path: '/', builder: (c, s) => const DashboardScreen()),
          ]),
          StatefulShellBranch(observers: [floatingCalcObserver], routes: [
            GoRoute(
              path: '/hats',
              builder: (c, s) => const HatsScreen(),
              routes: [
                // F-15 (v1.4.1): ফর্ম root navigator-এ — shell-এর ট্যাব বার/FAB ফর্মে থাকবে না
                GoRoute(
                  path: 'new',
                  parentNavigatorKey: rootNavigatorKey,
                  builder: (c, s) => const HatFormScreen(),
                ),
                // V1.3 (ফিচার ১): হাটের বিস্তারিত
                GoRoute(path: ':id', builder: (c, s) => HatDetailScreen(hatId: s.pathParameters['id']!)),
                GoRoute(
                  path: ':id/edit',
                  parentNavigatorKey: rootNavigatorKey,
                  builder: (c, s) => HatFormScreen(hatId: s.pathParameters['id']),
                ),
              ],
            ),
          ]),
          StatefulShellBranch(observers: [floatingCalcObserver], routes: [
            GoRoute(path: '/expenses', builder: (c, s) => const ExpensesScreen()),
          ]),
          // V1.4 FinTrack মার্জ: ফাইন্যান্স শাখা (ব্রাঞ্চ ইনডেক্স 3)
          StatefulShellBranch(observers: [floatingCalcObserver], routes: [
            GoRoute(path: '/finance', builder: (c, s) => const FinanceScreen()),
          ]),
          StatefulShellBranch(observers: [floatingCalcObserver], routes: [
            GoRoute(path: '/more', builder: (c, s) => const MoreScreen()),
          ]),
        ],
      ),
      // হাট সেশন (৪-ধাপ স্টেপার)
      GoRoute(
        path: '/sessions/new',
        builder: (c, s) => SessionStepperScreen(initialHatId: s.uri.queryParameters['hatId']),
      ),
      GoRoute(
        path: '/sessions/:id',
        builder: (c, s) => SessionStepperScreen(sessionId: s.pathParameters['id']),
      ),
      // আয়
      GoRoute(
        path: '/income',
        builder: (c, s) => IncomeListScreen(initialTab: s.uri.queryParameters['type']),
      ),
      GoRoute(
        path: '/income/new',
        builder: (c, s) => IncomeFormScreen(
          type: s.uri.queryParameters['type'] == 'personal' ? IncomeType.personal : IncomeType.hat,
          prefillAmountPaisa: s.uri.queryParameters['amount'],
          prefillNote: s.uri.queryParameters['note'],
        ),
      ),
      GoRoute(
        path: '/income/:id/edit',
        builder: (c, s) => IncomeFormScreen(
          type: s.uri.queryParameters['type'] == 'personal' ? IncomeType.personal : IncomeType.hat,
          editId: s.pathParameters['id'],
        ),
      ),
      // খরচ
      GoRoute(
        path: '/expenses/new',
        builder: (c, s) => const ExpenseFormScreen(),
      ),
      GoRoute(
        path: '/expenses/:id/edit',
        builder: (c, s) => ExpenseFormScreen(editId: s.pathParameters['id']),
      ),
      // ফাইন্যান্স: দ্রুত আয়/খরচ যোগ (V1.4)
      GoRoute(
        path: '/finance/add',
        builder: (c, s) => FinanceQuickAddScreen(
          type: s.uri.queryParameters['type'] == 'expense' ? 'expense' : 'income',
        ),
      ),
      // আম্মু
      GoRoute(path: '/mother', builder: (c, s) => const MotherScreen()),
      // DPS
      GoRoute(path: '/dps', builder: (c, s) => const DpsScreen()),
      GoRoute(
        path: '/dps/new',
        builder: (c, s) => const DpsFormScreen(),
      ),
      GoRoute(
        path: '/dps/:id',
        builder: (c, s) => DpsDetailScreen(accountId: s.pathParameters['id']!),
      ),
      GoRoute(
        path: '/dps/:id/edit',
        builder: (c, s) => DpsFormScreen(editId: s.pathParameters['id']),
      ),
      // ধার
      GoRoute(path: '/loans', builder: (c, s) => const LoansScreen()),
      GoRoute(
        path: '/loans/person/:id',
        builder: (c, s) => LoanPersonScreen(personId: s.pathParameters['id']!),
      ),
      GoRoute(
        path: '/loans/new',
        builder: (c, s) => LoansFormScreen(personId: s.uri.queryParameters['personId']),
      ),
      // বাইক
      GoRoute(path: '/bike', builder: (c, s) => const BikeScreen()),
      GoRoute(path: '/bike/fuel/new', builder: (c, s) => const FuelFormScreen()),
      GoRoute(path: '/bike/fuel/:id/edit', builder: (c, s) => FuelFormScreen(editId: s.pathParameters['id'])),
      GoRoute(path: '/bike/maintenance/new', builder: (c, s) => const MaintenanceFormScreen()),
      GoRoute(
          path: '/bike/maintenance/:id/edit',
          builder: (c, s) => MaintenanceFormScreen(editId: s.pathParameters['id'])),
      // টুল/ভিউ
      GoRoute(path: '/tally', builder: (c, s) => const TallyScreen()),
      GoRoute(
        path: '/tally/:sessionId',
        builder: (c, s) => TallyScreen(sessionId: s.pathParameters['sessionId']),
      ),
      GoRoute(path: '/calendar', builder: (c, s) => const CalendarScreen()),
      // V1.5 টুলস: দর-পড়তা ও বয়স ক্যালকুলেটর (root navigator — top-level রুট)
      GoRoute(path: '/tools/rate', builder: (c, s) => const RateCalculatorScreen()),
      GoRoute(path: '/tools/age', builder: (c, s) => const AgeCalculatorScreen()),
      GoRoute(path: '/reports', builder: (c, s) => const ReportsScreen()),
      GoRoute(path: '/daily-closing', builder: (c, s) => const DailyClosingScreen()),
      GoRoute(path: '/search', builder: (c, s) => const SearchScreen()),
      GoRoute(path: '/recycle-bin', builder: (c, s) => const RecycleBinScreen()),
      // সেটিংস
      GoRoute(path: '/settings', builder: (c, s) => const SettingsScreen()),
      GoRoute(path: '/settings/categories', builder: (c, s) => const CategoriesScreen()),
      GoRoute(path: '/settings/wallets', builder: (c, s) => const WalletsScreen()),
      GoRoute(path: '/settings/security', builder: (c, s) => const SecurityScreen()),
      GoRoute(path: '/settings/backup', builder: (c, s) => const BackupScreen()),
      GoRoute(path: '/settings/conflicts', builder: (c, s) => const ConflictScreen()),
    ],
  );
});
