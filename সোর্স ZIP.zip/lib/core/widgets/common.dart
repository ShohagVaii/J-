import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../providers/app_providers.dart';
import '../sync/sync_engine.dart';
import '../theme/app_colors.dart';
import 'money_text.dart';
export 'money_text.dart';
export 'amount_input.dart';
export 'info_banner.dart' show StatCard;

/// সেকশন হেডার
class SectionHeader extends StatelessWidget {
  final String title;
  final Widget? trailing;
  const SectionHeader({super.key, required this.title, this.trailing});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 18, 4, 8),
      child: Row(
        children: [
          Expanded(
            child: Text(
              title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.titleMedium,
            ),
          ),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}

/// খালি অবস্থা
class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final String? actionLabel;
  final VoidCallback? onAction;
  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    this.subtitle,
    this.actionLabel,
    this.onAction,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 56, color: AppColors.onSurfaceVariant),
            const SizedBox(height: 12),
            Text(title, textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.titleMedium),
            if (subtitle != null) ...[
              const SizedBox(height: 6),
              Text(
                subtitle!,
                textAlign: TextAlign.center,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
            if (actionLabel != null) ...[
              const SizedBox(height: 16),
              FilledButton(onPressed: onAction, child: Text(actionLabel!)),
            ],
          ],
        ),
      ),
    );
  }
}

/// সিঙ্ক ব্যাজ (টপ রাইট)
class SyncBadge extends ConsumerWidget {
  const SyncBadge({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final engine = ref.watch(syncStatusProvider);
    final state = engine.status;
    final (icon, color) = switch (state.state) {
      SyncState.syncing => (Icons.cloud_sync_outlined, AppColors.info),
      SyncState.synced => (Icons.cloud_done_outlined, AppColors.income),
      SyncState.pending => (Icons.cloud_upload_outlined, AppColors.secondary),
      SyncState.offline => (Icons.cloud_off_outlined, AppColors.onSurfaceVariant),
      SyncState.error => (Icons.cloud_off_outlined, AppColors.expense),
      _ => (Icons.cloud_outlined, AppColors.onSurfaceVariant),
    };
    return IconButton(
      icon: Icon(icon, color: color, size: 22),
      tooltip: state.message,
      onPressed: () => _showDetail(context, state.message),
    );
  }

  void _showDetail(BuildContext context, String message) {
    showModalBottomSheet(
      context: context,
      useRootNavigator: true, // F-06: shell-এর center FAB-এর নিচে যাবে
      builder: (c) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('সিঙ্ক', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(child: Text(message)),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () {
                      syncEngine.runSync();
                      Navigator.pop(context);
                    },
                    child: const Text('এখনই সিঙ্ক করুন'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: FilledButton(
                    onPressed: () {
                      Navigator.pop(context);
                      context.push('/settings');
                    },
                    child: const Text('সেটিংস'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// এন্ট্রি টাইল (তালিকার সাধারণ সারি)
class EntryTile extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String title;
  final String? subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  final Widget? trailingSub;
  const EntryTile({
    super.key,
    required this.icon,
    required this.title,
    this.iconColor = AppColors.primary,
    this.subtitle,
    this.trailing,
    this.onTap,
    this.onLongPress,
    this.trailingSub,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        onTap: onTap,
        onLongPress: onLongPress,
        leading: CircleAvatar(
          backgroundColor: iconColor.withAlpha(30),
          child: Icon(icon, color: iconColor, size: 20),
        ),
        title: Text(
          title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        subtitle: subtitle == null
            ? null
            : Text(
                subtitle!,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
        trailing: trailing ?? trailingSub,
      ),
    );
  }
}

/// টাকার সারি ট্রেইলিং
class AmountTrailing extends StatelessWidget {
  final int paisa;
  final Color color;
  final double fontSize;
  const AmountTrailing(this.paisa, {super.key, required this.color, this.fontSize = 15});

  @override
  Widget build(BuildContext context) {
    return MoneyText(paisa, color: color, fontSize: fontSize, fontWeight: FontWeight.w700);
  }
}


/// F-14 (v1.4.1): floating স্ন্যাকবার — নিচের অ্যাকশন বোতাম/FAB-এর
/// ওপরে না বসে তার উপরে ভাসে, যাতে স্ন্যাকবার থাকা অবস্থায়ও
/// বোতাম চাপা যায়। shell-ভুক্ত স্ক্রিনে [bottomMargin] 96 রাখুন;
/// পূর্ণ-স্ক্রিন ফর্মে ছোট মার্জিন (যেমন 24) দিন।
void showFloatingSnackBar(
  BuildContext context,
  String message, {
  Color? backgroundColor,
  double bottomMargin = 96,
}) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(message),
      behavior: SnackBarBehavior.floating,
      margin: EdgeInsets.fromLTRB(16, 0, 16, bottomMargin),
      backgroundColor: backgroundColor,
    ),
  );
}

/// সাধারণ নিশ্চিতকরণ ডায়ালগ
Future<bool> confirmDialog(BuildContext context, String title, String body) async {
  final ok = await showDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      title: Text(title),
      content: Text(body),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('বাতিল')),
        FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('হ্যাঁ')),
      ],
    ),
  );
  return ok ?? false;
}
