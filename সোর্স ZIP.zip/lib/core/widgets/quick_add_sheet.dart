import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../theme/app_colors.dart';
import '../utils/bangla_digits.dart';
import 'calculator_sheet.dart';

/// ＋ দ্রুত এন্ট্রি শিট (v1.1 ফিক্স ৯):
/// "আয়" একটাই বাটন — ভেতরে ঢুকলে হাট আয় / পার্সোনাল আয় আলাদা করে বাছাই।
class QuickAddSheet extends StatelessWidget {
  const QuickAddSheet({super.key});

  static void show(BuildContext context) {
    showModalBottomSheet(
      context: context,
      // F-06: root navigator — শিট shell-এর center FAB-এর নিচে থাকবে,
      // ওপরে ভাসবে না; U-13: ছোট স্ক্রিনেও পুরো গ্রিড দেখা যাবে
      useRootNavigator: true,
      isScrollControlled: true,
      builder: (_) => const QuickAddSheet(),
    );
  }

  void _go(BuildContext context, String route) {
    Navigator.pop(context);
    context.push(route);
  }

  @override
  Widget build(BuildContext context) {
    final items = <_QuickItem>[
      _QuickItem(
        icon: Icons.trending_up,
        color: AppColors.income,
        label: 'আয়',
        onTap: () => _pickIncome(context),
      ),
      _QuickItem(
        icon: Icons.receipt_long,
        color: AppColors.expense,
        label: 'খরচ',
        onTap: () => _go(context, '/expenses/new'),
      ),
      _QuickItem(
        icon: Icons.favorite,
        color: AppColors.mother,
        label: 'আম্মুকে ৳৫০০',
        onTap: () => _go(context, '/mother?add=50000'),
      ),
      _QuickItem(
        icon: Icons.savings,
        color: AppColors.savings,
        label: 'DPS জমা',
        onTap: () => _go(context, '/dps'),
      ),
      _QuickItem(
        icon: Icons.handshake_outlined,
        color: AppColors.loan,
        label: 'ধার',
        onTap: () => _go(context, '/loans/new'),
      ),
      _QuickItem(
        icon: Icons.local_gas_station_outlined,
        color: AppColors.bike,
        label: 'তেল ভরা',
        onTap: () => _go(context, '/bike/fuel/new'),
      ),
      _QuickItem(
        icon: Icons.storefront,
        color: AppColors.primary,
        label: 'হাট সেশন',
        onTap: () => _go(context, '/sessions/new'),
      ),
      _QuickItem(
        icon: Icons.balance_outlined,
        color: AppColors.info,
        label: 'টাকা গণক',
        onTap: () {
          Navigator.pop(context);
          CalculatorSheet.show(context);
        },
      ),
    ];
    return SafeArea(
      // U-13: খুব ছোট স্ক্রিনে শিটের উচ্চতা ছাড়ালে স্ক্রল ফলব্যাক
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 4, bottom: 12),
                child: Text('দ্রুত এন্ট্রি', style: Theme.of(context).textTheme.titleLarge),
              ),
              GridView.count(
                crossAxisCount: 4,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                // F-10: আগের 0.82-তে টাইল ছোট হয়ে লেবেলের নিচ কাটত —
                // লম্বা সেল (0.75) + বড় line-height-এ ক্লিপ বন্ধ
                childAspectRatio: 0.75,
                children: [
                  for (final it in items)
                    _QuickTile(item: it),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _pickIncome(BuildContext context) {
    // এক বাটন → ভেতরে দুই অপশন (ইউজারের নির্দেশ)
    showModalBottomSheet(
      context: context,
      useRootNavigator: true, // F-06
      builder: (c) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('কোন আয়?', style: Theme.of(c).textTheme.titleMedium),
              const SizedBox(height: 12),
              ListTile(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: const BorderSide(color: AppColors.outline),
                ),
                leading: const Icon(Icons.storefront, color: AppColors.primary),
                title: const Text('হাট আয়'),
                subtitle: const Text('হাটের পারিশ্রমিক / কমিশন'),
                onTap: () {
                  Navigator.pop(c);
                  Navigator.pop(context);
                  context.push('/income/new?type=hat');
                },
              ),
              const SizedBox(height: 8),
              ListTile(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: const BorderSide(color: AppColors.outline),
                ),
                leading: const Icon(Icons.person, color: AppColors.savings),
                title: const Text('পার্সোনাল আয়'),
                subtitle: const Text('অন্য কোনো আয়'),
                onTap: () {
                  Navigator.pop(c);
                  Navigator.pop(context);
                  context.push('/income/new?type=personal');
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _QuickItem {
  final IconData icon;
  final Color color;
  final String label;
  final VoidCallback onTap;
  const _QuickItem({required this.icon, required this.color, required this.label, required this.onTap});
}

class _QuickTile extends StatelessWidget {
  final _QuickItem item;
  const _QuickTile({required this.item});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: item.onTap,
      borderRadius: BorderRadius.circular(14),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: item.color.withAlpha(28),
              shape: BoxShape.circle,
            ),
            child: Icon(item.icon, color: item.color, size: 22),
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 2),
            child: Text(
              item.label,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              // F-10: বাংলা হরফের নিচের অংশ কাটা রোধে height 1.35
              style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 12, height: 1.35),
            ),
          ),
        ],
      ),
    );
  }
}

String bnDigitsOf(String s) => toBanglaDigits(s);
