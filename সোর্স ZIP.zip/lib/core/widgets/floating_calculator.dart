import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../theme/app_colors.dart';
import 'calculator_dialog.dart';

/// U-3/F-06 (v1.4.1): কোনো modal route (ডায়ালগ/বটম-শিট) সক্রিয় থাকলে
/// ভাসমান ক্যালকুলেটর বাটন লুকিয়ে রাখার পর্যবেক্ষক। router.dart-তে
/// GoRouter ও প্রতিটি shell branch-এ এই একই observer নিবন্ধিত —
/// যেকোনো navigator-এ popup route উঠলেই [modalActive] true হয়।
class FloatingCalcRouteObserver extends RouteObserver<ModalRoute<dynamic>> {
  final ValueNotifier<bool> modalActive = ValueNotifier<bool>(false);
  int _popupDepth = 0;

  bool _isPopup(Route<dynamic>? route) =>
      route is ModalRoute && route is! PageRoute;

  void _sync() => modalActive.value = _popupDepth > 0;

  @override
  void didPush(Route<dynamic> route, Route<dynamic>? previousRoute) {
    super.didPush(route, previousRoute);
    if (_isPopup(route)) {
      _popupDepth++;
      _sync();
    }
  }

  @override
  void didPop(Route<dynamic> route, Route<dynamic>? previousRoute) {
    super.didPop(route, previousRoute);
    if (_isPopup(route) && _popupDepth > 0) {
      _popupDepth--;
      _sync();
    }
  }

  @override
  void didRemove(Route<dynamic> route, Route<dynamic>? previousRoute) {
    super.didRemove(route, previousRoute);
    if (_isPopup(route) && _popupDepth > 0) {
      _popupDepth--;
      _sync();
    }
  }

  @override
  void didReplace({Route<dynamic>? newRoute, Route<dynamic>? oldRoute}) {
    super.didReplace(newRoute: newRoute, oldRoute: oldRoute);
    if (_isPopup(oldRoute) && _popupDepth > 0) _popupDepth--;
    if (_isPopup(newRoute)) _popupDepth++;
    _sync();
  }
}

/// একক instance — router.dart ও বাটন দুজনেই এটাই ব্যবহার করে
final FloatingCalcRouteObserver floatingCalcObserver = FloatingCalcRouteObserver();

/// ভাসমান ট্রান্সপারেন্ট ক্যালকুলেটর বাটন (v1.1):
/// • সব স্ক্রিনের উপরে থাকে
/// • টেনে যেকোনো দিকে সরানো যায় (পজিশন মনে থাকে)
/// • ট্যাপে গ্লাস ক্যালকুলেটর ডায়ালগ খোলে (v1.5.0)
class FloatingCalculatorButton extends StatefulWidget {
  final Widget child;
  const FloatingCalculatorButton({super.key, required this.child});

  @override
  State<FloatingCalculatorButton> createState() => _FloatingCalculatorButtonState();
}

class _FloatingCalculatorButtonState extends State<FloatingCalculatorButton> {
  static const String _kX = 'fab_calc_x';
  static const String _kY = 'fab_calc_y';

  Offset _pos = const Offset(-1, -1); // -1 = ডিফল্ট (ডান-নিচ)
  bool _loaded = false;
  double _screenW = 0, _screenH = 0;
  static const double _size = 52;

  @override
  void initState() {
    super.initState();
    _loadPos();
  }

  Future<void> _loadPos() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _pos = Offset(prefs.getDouble(_kX) ?? -1, prefs.getDouble(_kY) ?? -1);
      _loaded = true;
    });
  }

  Future<void> _savePos(Offset o) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_kX, o.dx);
    await prefs.setDouble(_kY, o.dy);
  }

  void _openCalculator() {
    // v1.5.0 (ব্যবহারকারীর নকশা): বাবলে ট্যাপে টাকা-গণক শিট নয় —
    // ট্রান্সপারেন্ট গ্লাস ক্যালকুলেটর ডায়ালগ খোলে। টাকা গণক
    // ডায়ালগের হেডারের লিংক থেকে আগের মতোই পাওয়া যায়।
    showCalculatorDialog(null);
  }

  @override
  Widget build(BuildContext context) {
    final media = MediaQuery.of(context);
    _screenW = media.size.width;
    _screenH = media.size.height;
    final pos = _loaded
        ? _resolveDefault()
        : const Offset(-1000, -1000); // লোড হওয়ার আগে লুকানো
    return Stack(
      children: [
        widget.child,
        // U-3: ডায়ালগ/শিট খোলা থাকলে বাটন লুকানো — নইলে modal-এর ওপরে
        // ভেসে ট্যাপ আটকাত ও ভুল ট্যাপে ক্যালকুলেটর খুলে যেত
        ValueListenableBuilder<bool>(
          valueListenable: floatingCalcObserver.modalActive,
          builder: (context, modalOnTop, _) {
            if (modalOnTop) return const SizedBox.shrink();
            return Positioned(
          left: pos.dx,
          top: pos.dy,
          child: GestureDetector(
            onTap: _openCalculator,
            onPanUpdate: (d) {
              setState(() {
                var nx = _pos.dx + d.delta.dx;
                var ny = _pos.dy + d.delta.dy;
                nx = nx.clamp(4.0, _screenW - _size - 4);
                ny = ny.clamp(media.padding.top + 4, _screenH - _size - media.padding.bottom - 4);
                _pos = Offset(nx, ny);
              });
            },
            onPanEnd: (_) => _savePos(_pos),
            child: Material(
              color: Colors.transparent,
              child: Tooltip(
                message: 'ক্যালকুলেটর — টেনে সরানো যায়',
                child: Container(
                  width: _size,
                  height: _size,
                  decoration: BoxDecoration(
                    color: AppColors.primary.withAlpha(120), // ট্রান্সপারেন্ট
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white.withAlpha(150), width: 1.4),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withAlpha(45),
                        blurRadius: 8,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.calculate_outlined,
                    color: Colors.white,
                    size: 27,
                  ),
                ),
              ),
            ),
          ),
            );
          },
        ),
      ],
    );
  }

  Offset _resolveDefault() {
    if (_pos.dx >= 0 && _pos.dy >= 0) {
      // পুরনো পজিশন স্ক্রিনের বাইরে হলে ডিফল্ট
      if (_pos.dx <= _screenW - _size && _pos.dy <= _screenH - _size) return _pos;
    }
    return Offset(_screenW - _size - 16, _screenH * 0.62);
  }
}
