import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../utils/bangla_digits.dart';
import '../utils/date_utils_bn.dart';

/// F-08 (v1.4.1): টাইপ করা ল্যাটিন ডিজিট সঙ্গে সঙ্গে বাংলা ডিজিট হয়ে
/// দেখাবে। রূপান্তর ১:১ (একই দৈর্ঘ্য) বলে কার্সর/সিলেকশন নড়ে না;
/// parse-এর সময় [parseTakaToPaisa] দুটো ডিজিটই সামলায়।
class BanglaDigitFormatter extends TextInputFormatter {
  const BanglaDigitFormatter();

  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    final converted = toBanglaDigits(newValue.text);
    if (converted == newValue.text) return newValue;
    return TextEditingValue(
      text: converted,
      selection: newValue.selection,
      composing: newValue.composing,
    );
  }
}

/// টাকার ইনপুট — শুধু ম্যানুয়াল ইনপুট বক্স (v1.1: কোনো প্লাস/মাইনাস বাটন নেই)
/// বাংলা ও ইংরেজি ডিজিট দুটোই চলে; ফলাফল পয়সায়।
class AmountInput extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final String? hint;
  final String? suffixText;
  final bool integerOnly;
  final ValueChanged<int?>? onChangedPaisa;
  final String? Function(String?)? validator;
  final bool autofocus;

  const AmountInput({
    super.key,
    required this.controller,
    required this.label,
    this.hint,
    this.suffixText,
    this.integerOnly = false,
    this.onChangedPaisa,
    this.validator,
    this.autofocus = false,
  });

  static int? readPaisa(TextEditingController c) => parseTakaToPaisa(c.text);

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      autofocus: autofocus,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      inputFormatters: [
        FilteringTextInputFormatter.allow(RegExp(r'[0-9০-৯.,]')),
        const BanglaDigitFormatter(), // F-08: ডিসপ্লে বাংলা ডিজিটে
      ],
      autovalidateMode: AutovalidateMode.onUserInteraction,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint ?? (integerOnly ? '০' : '০.০০'),
        suffixText: suffixText ?? '৳',
        border: const OutlineInputBorder(),
      ),
      style: TextStyle(
        fontFamily: 'HindSiliguri',
        fontSize: 16,
        color: Theme.of(context).colorScheme.onSurface,
      ),
      onChanged: (v) => onChangedPaisa?.call(parseTakaToPaisa(v)),
      validator: validator ??
          (v) {
            if (v == null || parseTakaToPaisa(v) == null) return null;
            final paisa = parseTakaToPaisa(v)!;
            if (paisa <= 0) return 'শূন্যের বেশি দিন';
            return null;
          },
    );
  }
}

/// সাধারণ টেক্সট ইনপুট
class AppTextField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final String? hint;
  final int maxLines;
  final bool readOnly;
  final VoidCallback? onTap;
  final String? Function(String?)? validator;
  final Widget? suffix;
  final bool obscureText;
  const AppTextField({
    super.key,
    required this.controller,
    required this.label,
    this.hint,
    this.maxLines = 1,
    this.readOnly = false,
    this.onTap,
    this.validator,
    this.suffix,
    this.obscureText = false, // FIX C-4: পাসওয়ার্ড/গোপন ইনপুটের জন্য
  });

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      maxLines: obscureText ? 1 : maxLines,
      obscureText: obscureText,
      readOnly: readOnly,
      onTap: onTap,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      validator: validator,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        border: const OutlineInputBorder(),
        suffixIcon: suffix,
      ),
      style: TextStyle(
        fontFamily: 'HindSiliguri',
        fontSize: 15,
        color: Theme.of(context).colorScheme.onSurface,
      ),
    );
  }
}

/// তারিখ বাছাই ফিল্ড (read-only, ট্যাপে পিকার)
/// F-08 (v1.4.1): [controller]-তে আগের মতোই 'YYYY-MM-DD' (ISO) থাকে —
/// সব ফর্ম ও সেভ-লজিক সেটাই পড়ে; কিন্তু ব্যবহারকারী দেখেন বাংলা তারিখ
/// ("১ নভেম্বর ২০২৬") — ডিসপ্লের জন্য আলাদা কন্ট্রোলার।
class DateField extends StatefulWidget {
  final TextEditingController controller; // 'YYYY-MM-DD'
  final String label;
  const DateField({super.key, required this.controller, required this.label});

  @override
  State<DateField> createState() => _DateFieldState();
}

class _DateFieldState extends State<DateField> {
  late final TextEditingController _display;

  @override
  void initState() {
    super.initState();
    _display = TextEditingController(text: _displayText(widget.controller.text));
    // এডিট ফ্লোতে ফর্ম বাইরে থেকে ISO কন্ট্রোলারে তারিখ বসালে
    // (async লোডের পর) ডিসপ্লেও সঙ্গে সঙ্গে মিলিয়ে নেওয়া
    widget.controller.addListener(_syncFromIso);
  }

  void _syncFromIso() {
    final shown = _displayText(widget.controller.text);
    if (shown != _display.text) _display.text = shown;
  }

  @override
  void dispose() {
    widget.controller.removeListener(_syncFromIso);
    _display.dispose();
    super.dispose();
  }

  static String _displayText(String iso) {
    final s = iso.trim();
    if (s.isEmpty || _parse(s) == null) return s.isEmpty ? '' : s;
    return formatDateBn(s);
  }

  static String _isoOf(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    return AppTextField(
      controller: _display,
      label: widget.label,
      hint: 'তারিখ বাছুন',
      readOnly: true,
      suffix: const Icon(Icons.calendar_month_outlined, size: 20),
      onTap: () async {
        final initial = _parse(widget.controller.text);
        final picked = await showDatePicker(
          context: context,
          initialDate: initial ?? DateTime.now(),
          firstDate: DateTime(2020),
          lastDate: DateTime(2100),
        );
        if (picked != null) {
          final iso = _isoOf(picked);
          widget.controller.text = iso;
          _display.text = _displayText(iso);
        }
      },
    );
  }

  static DateTime? _parse(String s) {
    final p = s.split('-').map(int.tryParse).toList();
    if (p.length != 3 || p[0] == null || p[1] == null || p[2] == null) return null;
    return DateTime(p[0]!, p[1]!, p[2]!);
  }
}
