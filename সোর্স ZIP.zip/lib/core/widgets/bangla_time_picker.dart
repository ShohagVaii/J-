import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../utils/bangla_digits.dart';
import '../theme/app_colors.dart';

/// বাংলা ডিজিটের সুন্দর টাইম-পিকার (Material-এর ইংরেজি ঘড়ির বদলে)
/// দুটি চাকা: ঘণ্টা (০–২৩) ও মিনিট (০–৫৯)
Future<TimeOfDay?> showBanglaTimePicker({
  required BuildContext context,
  required TimeOfDay initial,
}) {
  return showDialog<TimeOfDay>(
    context: context,
    builder: (c) => _BanglaTimePickerDialog(initial: initial),
  );
}

class _BanglaTimePickerDialog extends StatefulWidget {
  final TimeOfDay initial;
  const _BanglaTimePickerDialog({required this.initial});

  @override
  State<_BanglaTimePickerDialog> createState() => _BanglaTimePickerDialogState();
}

class _BanglaTimePickerDialogState extends State<_BanglaTimePickerDialog> {
  late int _hour = widget.initial.hour;
  late int _minute = widget.initial.minute;

  static const double _extent = 46;

  String _label(int v, int digits) =>
      toBanglaDigits(v.toString().padLeft(digits, '0'));

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Theme.of(context).colorScheme.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 20, 18, 14),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('সময় বাছুন', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 6),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                _wheel(
                  count: 24,
                  initial: _hour,
                  label: (i) => _label(i, 2),
                  onChanged: (v) => setState(() => _hour = v),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: Text(':',
                      style: Theme.of(context)
                          .textTheme
                          .headlineMedium
                          ?.copyWith(color: AppColors.primary)),
                ),
                _wheel(
                  count: 60,
                  initial: _minute,
                  label: (i) => _label(i, 2),
                  onChanged: (v) => setState(() => _minute = v),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Center(
              child: Text(
                'প্রতিদিন এই সময়ে রিমাইন্ডার আসবে',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ),
            const SizedBox(height: 14),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('বাতিল'),
                ),
                const SizedBox(width: 8),
                FilledButton(
                  onPressed: () => Navigator.pop(
                      context, TimeOfDay(hour: _hour, minute: _minute)),
                  child: const Text('ঠিক আছে'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _wheel({
    required int count,
    required int initial,
    required String Function(int) label,
    required ValueChanged<int> onChanged,
  }) {
    return SizedBox(
      width: 92,
      height: 220,
      child: ListWheelScrollView.useDelegate(
        controller: FixedExtentScrollController(initialItem: initial),
        itemExtent: _extent,
        perspective: 0.0035,
        diameterRatio: 1.6,
        physics: const FixedExtentScrollPhysics(),
        onSelectedItemChanged: (i) {
          HapticFeedback.selectionClick();
          onChanged(i);
        },
        childDelegate: ListWheelChildBuilderDelegate(
          childCount: count,
          builder: (c, i) {
            final selected = i == initial;
            return Container(
              alignment: Alignment.center,
              margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
              decoration: BoxDecoration(
                color: selected
                    ? AppColors.primary.withAlpha(35)
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(12),
                border: selected
                    ? Border.all(color: AppColors.primary, width: 1.2)
                    : null,
              ),
              child: Text(
                label(i),
                style: TextStyle(
                  fontFamily: 'HindSiliguri',
                  fontSize: selected ? 24 : 20,
                  fontWeight: selected ? FontWeight.w700 : FontWeight.w400,
                  color: selected
                      ? AppColors.primary
                      : Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
