import 'package:flutter/material.dart';

import '../theme/app_colors.dart';
import '../utils/bangla_digits.dart';
import '../utils/money_format.dart';
import 'money_text.dart';

/// ইনফো ব্যানার — লম্বা লেখা সুন্দরভাবে মোড়ানো (v1.1 ফিক্স: টেক্সট ভাঙা)
class InfoBanner extends StatelessWidget {
  final String message;
  final IconData icon;
  final Color color;
  final Color background;
  final Widget? action;
  final VoidCallback? onTap;
  const InfoBanner({
    super.key,
    required this.message,
    required this.icon,
    required this.color,
    required this.background,
    this.action,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withAlpha(60)),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Icon(icon, size: 18, color: color),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                message,
                softWrap: true,
                style: TextStyle(
                  fontFamily: 'HindSiliguri',
                  fontSize: 13,
                  height: 1.35,
                  color: color,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            if (action != null) action!,
          ],
        ),
      ),
    );
  }
}

/// স্ট্যাট কার্ড (লেবেল + টাকা) — স্থির লেআউট, ভাঙবে না
class StatCard extends StatelessWidget {
  final String label;
  final int paisa;
  final Color color;
  final IconData? icon;
  final bool compact;
  const StatCard({
    super.key,
    required this.label,
    required this.paisa,
    required this.color,
    this.icon,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Theme.of(context).cardTheme.color,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.outline.withAlpha(120)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              if (icon != null) ...[
                Icon(icon, size: 15, color: color),
                const SizedBox(width: 5),
              ],
              Expanded(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontFamily: 'HindSiliguri',
                    fontSize: 12.5,
                    color: AppColors.onSurfaceVariant,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Align(
            alignment: Alignment.centerLeft,
            child: MoneyText(
              paisa,
              color: color,
              fontSize: 16,
              fontWeight: FontWeight.w700,
              compact: compact,
            ),
          ),
        ],
      ),
    );
  }
}

/// সংখ্যা প্রদর্শন সহায়ক
String bn(int n) => toBanglaDigits('$n');
String bnMoney(int paisa) => MoneyFmt.taka(paisa);
