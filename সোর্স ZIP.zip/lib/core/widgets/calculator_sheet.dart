import 'package:flutter/material.dart';

import '../../core/router.dart';
import 'package:flutter/services.dart';

import '../theme/app_colors.dart';
import '../utils/bangla_digits.dart';
import '../utils/money_format.dart';
import 'amount_input.dart';

/// টাকা গণক (v1.1): প্লাস/মাইনাস বাটন নেই — শুধু ম্যানুয়াল ইনপুট বক্স।
/// দাম(৳/কেজি) × ওজন(কেজি) = মোট; ইচ্ছা করলে ২য় মোট যোগ করে সার্বিক দেখা যায়।
class CalculatorSheet extends StatefulWidget {
  /// "ফর্মে ব্যবহার করুন" চাপলে মোট পয়সা এখানে ফেরত যাবে
  final ValueChanged<int>? onUseResult;
  const CalculatorSheet({super.key, this.onUseResult});

  static Future<void> show(BuildContext? context, {ValueChanged<int>? onUseResult}) {
    // MaterialApp.builder-এর কনটেক্সটের উপরে Navigator নেই → রুট-নেভিগেটর ব্যবহার
    BuildContext? navCtx =
        (context != null && context.findAncestorStateOfType<NavigatorState>() != null)
            ? context
            : rootNavigatorKey.currentContext;
    if (navCtx == null) return Future<void>.value();
    return showModalBottomSheet(
      context: navCtx,
      isScrollControlled: true,
      useRootNavigator: true,
      backgroundColor: Colors.transparent,
      builder: (sheetCtx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(sheetCtx).viewInsets.bottom),
        child: Container(
          margin: const EdgeInsets.all(14),
          // U-9: দ্বৈত প্যাডিং বাদ — ভেতরের এক স্তরের প্যাডিংই থাকল
          decoration: BoxDecoration(
            color: Theme.of(sheetCtx).colorScheme.surface.withAlpha(235),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white.withAlpha(40)),
          ),
          child: CalculatorSheet(onUseResult: onUseResult),
        ),
      ),
    );
  }

  @override
  State<CalculatorSheet> createState() => _CalculatorSheetState();
}

class _CalculatorSheetState extends State<CalculatorSheet> {
  final _rate = TextEditingController();
  final _kg = TextEditingController();
  final _rate2 = TextEditingController();
  final _kg2 = TextEditingController();
  int? _total1;
  int? _total2;
  bool _useSecond = false;

  @override
  void dispose() {
    _rate.dispose();
    _kg.dispose();
    _rate2.dispose();
    _kg2.dispose();
    super.dispose();
  }

  void _recalc() {
    setState(() {
      final rate = parseTakaToPaisa(_rate.text);
      final kg = double.tryParse(fromBanglaDigits(_kg.text).replaceAll(',', '')) ?? 0;
      _total1 = (rate != null && kg > 0) ? (rate * kg).round() : null;

      final rate2 = parseTakaToPaisa(_rate2.text);
      final kg2 = double.tryParse(fromBanglaDigits(_kg2.text).replaceAll(',', '')) ?? 0;
      _total2 = (rate2 != null && kg2 > 0) ? (rate2 * kg2).round() : null;
    });
  }

  int? get _grand {
    if (_useSecond) {
      if (_total1 == null && _total2 == null) return null;
      return (_total1 ?? 0) + (_total2 ?? 0);
    }
    return _total1;
  }

  String _fmt(int? paisa) {
    if (paisa == null) return '—';
    return toBanglaDigits(_decimalFromPaisa(paisa));
  }

  String _decimalFromPaisa(int paisa) {
    final taka = paisa ~/ 100;
    final rem = paisa % 100;
    final intPart = _group('$taka');
    return rem == 0 ? intPart : '$intPart.${rem.toString().padLeft(2, '0')}';
  }

  // FIX V1.3 (F-10): আগের হাতে-লেখা _group অঙ্ক এলোমেলো করে দিত
  // (যেমন '1234' → '1,432')। এখন যাচাইকৃত MoneyFmt.groupBangla ব্যবহার হয়।
  String _group(String d) => MoneyFmt.groupBangla(d);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      // U-1: স্ক্রলযোগ্য — কীবোর্ড + দ্বিতীয় হিসাব খুললে ছোট স্ক্রিনে
      // Column overflow হতো; এখন শিটের ভেতরেই স্ক্রল হবে
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
          child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('টাকা গণক', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 4),
            Text(
              'দাম আর ওজন লিখুন — মোট নিজে থেকেই হিসাব হবে',
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: 14),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: AmountInput(
                    controller: _rate,
                    label: 'দাম',
                    suffixText: '৳/কেজি',
                    autofocus: true,
                    onChangedPaisa: (_) => _recalc(),
                  ),
                ),
                const SizedBox(width: 5),
                const Padding(
                  padding: EdgeInsets.only(top: 14),
                  child: Text('×', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                ),
                const SizedBox(width: 5),
                Expanded(
                  child: TextFormField(
                    controller: _kg,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9০-৯.]')), const BanglaDigitFormatter()],
                    decoration: const InputDecoration(
                      labelText: 'ওজন',
                      suffixText: 'কেজি',
                      border: OutlineInputBorder(),
                    ),
                    style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 16),
                    onChanged: (_) => _recalc(),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.primaryLight,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('মোট', style: TextStyle(color: AppColors.primary, fontSize: 13)),
                  const SizedBox(height: 2),
                  Text(
                    '৳${_fmt(_grand)}',
                    style: const TextStyle(
                      fontFamily: 'Inter',
                      fontWeight: FontWeight.w700,
                      fontSize: 24,
                      color: AppColors.primary,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            TextButton.icon(
              onPressed: () => setState(() => _useSecond = !_useSecond),
              icon: Icon(_useSecond ? Icons.remove_circle_outline : Icons.add_circle_outline, size: 18),
              label: Text(_useSecond ? 'দ্বিতীয় হিসাব বাদ দিন' : 'আরেকটা হিসাব যোগ করুন'),
            ),
            if (_useSecond) ...[
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: AmountInput(
                      controller: _rate2,
                      label: 'দাম ২',
                      suffixText: '৳/কেজি',
                      onChangedPaisa: (_) => _recalc(),
                    ),
                  ),
                  const SizedBox(width: 5),
                  const Padding(
                    padding: EdgeInsets.only(top: 14),
                    child: Text('×', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                  ),
                  const SizedBox(width: 5),
                  Expanded(
                    child: TextFormField(
                      controller: _kg2,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9০-৯.]')), const BanglaDigitFormatter()],
                      decoration: const InputDecoration(
                        labelText: 'ওজন ২',
                        suffixText: 'কেজি',
                        border: OutlineInputBorder(),
                      ),
                      style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 16),
                      onChanged: (_) => _recalc(),
                    ),
                  ),
                ],
              ),
            ],
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: _grand == null
                        ? null
                        : () {
                            Clipboard.setData(ClipboardData(text: _decimalFromPaisa(_grand!)));
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('কপি হয়েছে ✓')),
                            );
                          },
                    child: const Text('কপি করুন'),
                  ),
                ),
                if (widget.onUseResult != null) ...[
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton(
                      onPressed: _grand == null
                          ? null
                          : () {
                              widget.onUseResult!(_grand!);
                              Navigator.pop(context);
                            },
                      child: const Text('ফর্মে ব্যবহার করুন'),
                    ),
                  ),
                ],
              ],
            ),
          ],
          ),
        ),
      ),
    );
  }
}
