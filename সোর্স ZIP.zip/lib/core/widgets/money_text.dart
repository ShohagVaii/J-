import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../theme/app_colors.dart';
import '../utils/bangla_digits.dart';
import '../utils/money_format.dart';

/// প্রাইভেসি আই: টাকা লুকানো
final privacyProvider = StateProvider<bool>((ref) => false);

class MoneyText extends ConsumerWidget {
  final int paisa;
  final Color? color;
  final double fontSize;
  final FontWeight fontWeight;
  final bool signed;
  final bool compact;
  const MoneyText(
    this.paisa, {
    super.key,
    this.color,
    this.fontSize = 14,
    this.fontWeight = FontWeight.w600,
    this.signed = false,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final hidden = ref.watch(privacyProvider);
    if (hidden) {
      return Text(
        '৳ ${toBanglaDigits('••••')}',
        style: TextStyle(
          fontFamily: 'HindSiliguri',
          fontSize: fontSize,
          fontWeight: fontWeight,
          color: color ?? AppColors.onSurface,
        ),
      );
    }
    final text = compact
        ? MoneyFmt.compact(paisa)
        : MoneyFmt.taka(paisa, withSign: signed);
    return Text(
      text,
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      style: TextStyle(
        fontFamily: 'HindSiliguri',
        fontSize: fontSize,
        fontWeight: fontWeight,
        color: color ?? AppColors.onSurface,
      ),
    );
  }
}
