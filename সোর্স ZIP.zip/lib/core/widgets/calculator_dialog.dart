import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../router.dart';
import '../theme/app_colors.dart';
import '../utils/bangla_digits.dart';
import '../utils/money_format.dart';
import 'calculator_sheet.dart';

/// সাধারণ ক্যালকুলেটর (v1.5.0) — ব্যবহারকারীর নকশা অনুযায়ী:
/// ভাসমান বাবলে ট্যাপ করলে সিস্টেম-কীবোর্ডওয়ালা বটম-শিট নয়, বরং
/// ক্লাসিক ক্যালকুলেটর পপআপ আসবে — উপরে ডিসপ্লে, নিচে কীপ্যাড
/// (৭৮৯÷ / ৪৫৬× / ১২৩− / .০±+ / =), CLEAR · CANCEL · OK —
/// আর পুরোটা ট্রান্সপারেন্ট/গ্লাস স্টাইলে: পেছনের পেজ হালকা ঝাপসা
/// হয়ে faint দেখা যাবে।
///
/// হেডারের "টাকা গণক →" লিংকে পুরনো দাম×ওজন শিটটা আগের মতোই পাওয়া
/// যাবে — কোনো ফিচার হারায়নি।
Future<void> showCalculatorDialog(BuildContext? context) {
  // FloatingCalculatorButton MaterialApp.builder-এর কনটেক্সটে থাকে —
  // সেখানে Navigator নেই, তাই CalculatorSheet.show-এর মতোই
  // রুট-নেভিগেটরের কনটেক্সটে ফলব্যাক।
  BuildContext? navCtx =
      (context != null && context.findAncestorStateOfType<NavigatorState>() != null)
          ? context
          : rootNavigatorKey.currentContext;
  if (navCtx == null) return Future<void>.value();
  return showGeneralDialog<void>(
    context: navCtx,
    useRootNavigator: true,
    barrierDismissible: true,
    barrierLabel: 'ক্যালকুলেটর',
    barrierColor: Colors.black.withAlpha(115), // ~45% কালো আবছা আবরণ
    transitionDuration: const Duration(milliseconds: 180),
    pageBuilder: (ctx, animation, secondaryAnimation) {
      return Stack(
        children: [
          // ঝাপসা আবরণ — পেছনের পেজ faint দেখা যায়; ট্যাপে বন্ধ
          Positioned.fill(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => Navigator.of(ctx).pop(),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 6, sigmaY: 6),
                child: const SizedBox.expand(),
              ),
            ),
          ),
          SafeArea(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 380),
                  child: const _CalculatorPanel(),
                ),
              ),
            ),
          ),
        ],
      );
    },
    transitionBuilder: (ctx, animation, secondaryAnimation, child) {
      final curved = CurvedAnimation(parent: animation, curve: Curves.easeOutCubic);
      return FadeTransition(
        opacity: curved,
        child: ScaleTransition(
          scale: Tween<double>(begin: 0.96, end: 1).animate(curved),
          child: child,
        ),
      );
    },
  );
}

class _CalculatorPanel extends StatefulWidget {
  const _CalculatorPanel();

  @override
  State<_CalculatorPanel> createState() => _CalculatorPanelState();
}

class _CalculatorPanelState extends State<_CalculatorPanel> {
  /// বর্তমান এন্ট্রি (ল্যাটিন ডিজিটে রাখা হয়; দেখানোর সময় বাংলায়)
  String _entry = '';

  /// জমে থাকা মান ও অপেক্ষমাণ অপারেটর ('+', '-', '*', '/')
  double? _acc;
  String? _op;

  /// '=' চাপার পর সম্পূর্ণ প্রকাশটা ("১২ + ৩ =") ডিসপ্লের উপরে থাকে
  String? _doneExpr;
  bool _evaluated = false;
  bool _error = false;

  // ---------- হিসাবের লজিক ----------

  void _reset() {
    _entry = '';
    _acc = null;
    _op = null;
    _doneExpr = null;
    _evaluated = false;
    _error = false;
  }

  double? _apply(double a, String op, double b) {
    switch (op) {
      case '+':
        return a + b;
      case '-':
        return a - b;
      case '*':
        return a * b;
      case '/':
        if (b == 0) return null; // শূন্য দিয়ে ভাগ — ত্রুটি
        return a / b;
    }
    return null;
  }

  /// ত্রুটি-অবস্থায় ঢোকা (call-site setState-এর ভেতরে ডাকতে হবে)
  void _enterError() {
    _error = true;
    _entry = '';
    _op = null;
    _doneExpr = 'শূন্য দিয়ে ভাগ করা যায় না';
  }

  void _digit(String d) {
    setState(() {
      if (_error) _reset();
      if (_evaluated) {
        _reset();
      }
      final digits = _entry.replaceAll('-', '').replaceAll('.', '');
      if (digits.length >= 12) return;
      if (_entry == '0') {
        _entry = d;
      } else if (_entry == '-0') {
        _entry = '-$d';
      } else {
        _entry += d;
      }
    });
  }

  void _dot() {
    setState(() {
      if (_error) _reset();
      if (_evaluated) _reset();
      if (_entry.contains('.')) return;
      if (_entry.isEmpty) {
        _entry = '0.';
      } else if (_entry == '-') {
        _entry = '-0.';
      } else {
        _entry += '.';
      }
    });
  }

  void _negate() {
    setState(() {
      if (_error) return;
      if (_entry.isNotEmpty) {
        _entry = _entry.startsWith('-') ? _entry.substring(1) : '-$_entry';
      } else if (_evaluated && _acc != null) {
        _acc = -_acc!;
      }
    });
  }

  void _backspace() {
    setState(() {
      if (_error) {
        _reset();
        return;
      }
      if (_evaluated) return;
      if (_entry.isNotEmpty) {
        _entry = _entry.substring(0, _entry.length - 1);
        if (_entry == '-') _entry = '';
      } else if (_op != null && _acc != null) {
        // অপারেটর মুছলে আগের মান আবার এন্ট্রিতে ফেরে
        _entry = _plain(_acc!);
        _acc = null;
        _op = null;
      }
    });
  }

  void _setOp(String op) {
    if (_error) return;
    setState(() {
      if (_entry.isNotEmpty) {
        final v = double.tryParse(_entry);
        if (v == null) return;
        if (_acc != null && _op != null) {
          final r = _apply(_acc!, _op!, v);
          if (r == null) {
            _enterError();
            return;
          }
          _acc = r;
        } else {
          _acc = v;
        }
        _entry = '';
      }
      _acc ??= 0;
      _op = op;
      _evaluated = false;
      _doneExpr = null;
    });
  }

  void _equals() {
    if (_error || _acc == null || _op == null) return;
    final v = _entry.isEmpty ? _acc! : (double.tryParse(_entry) ?? _acc!);
    final r = _apply(_acc!, _op!, v);
    if (r == null) {
      setState(_enterError);
      return;
    }
    setState(() {
      _doneExpr = '${_fmt(_acc!)} ${_sym(_op!)} ${_fmt(v)} =';
      _acc = r;
      _entry = '';
      _op = null;
      _evaluated = true;
    });
  }

  void _clear() => setState(_reset);

  // ---------- ফরম্যাট ----------

  static String _sym(String op) => switch (op) {
        '+' => '+',
        '-' => '−',
        '*' => '×',
        '/' => '÷',
        _ => op,
      };

  /// double → গ্রুপ করা ল্যাটিন স্ট্রিং (দশমিকের অপ্রয়োজনীয় ০ ছাড়া)
  static String _plain(double v) {
    if (v == v.roundToDouble() && v.abs() < 1e13) return '${v.round()}';
    var s = v.toStringAsFixed(6);
    if (s.contains('.')) {
      s = s.replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
    }
    return s;
  }

  /// দেখানোর জন্য: ভারতীয় গ্রুপিং + বাংলা ডিজিট
  static String _fmt(double v) => toBanglaDigits(MoneyFmt.groupBangla(_plain(v)));

  static String _fmtEntry(String entry) {
    if (entry.isEmpty) return '';
    final neg = entry.startsWith('-');
    final body = neg ? entry.substring(1) : entry;
    final dot = body.indexOf('.');
    final intPart = dot >= 0 ? body.substring(0, dot) : body;
    final frac = dot >= 0 ? body.substring(dot) : '';
    final grouped = MoneyFmt.groupBangla(intPart.isEmpty ? '0' : intPart);
    return toBanglaDigits('${neg ? '-' : ''}$grouped$frac');
  }

  String get _display {
    if (_error) return 'ত্রুটি';
    if (_entry.isNotEmpty) return _fmtEntry(_entry);
    if (_acc != null) return _fmt(_acc!);
    return toBanglaDigits('0');
  }

  String get _exprLine {
    if (_doneExpr != null) return _doneExpr!;
    if (_acc != null && _op != null) {
      final tail = _entry.isNotEmpty ? ' ${_fmtEntry(_entry)}' : '';
      return '${_fmt(_acc!)} ${_sym(_op!)}$tail';
    }
    return '';
  }

  /// OK চাপলে কপি হওয়া মান (ল্যাটিন, গ্রুপিং ছাড়া — ফর্মে বসানোর মতো)
  String get _resultPlain {
    if (_entry.isNotEmpty) return _entry;
    if (_acc != null) return _plain(_acc!);
    return '0';
  }

  // ---------- অ্যাকশন ----------

  void _onOk() {
    final messenger = ScaffoldMessenger.of(context);
    final text = _resultPlain;
    Clipboard.setData(ClipboardData(text: text));
    Navigator.of(context).pop();
    messenger.showSnackBar(
      SnackBar(
        content: Text('কপি হয়েছে: ${toBanglaDigits(text)}'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _openTakaGonok() {
    Navigator.of(context).pop();
    CalculatorSheet.show(null);
  }

  // ---------- UI ----------

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final onSurface = scheme.onSurface;
    return Material(
      color: Colors.transparent,
      child: Container(
        decoration: BoxDecoration(
          // গ্লাস প্যানেল: সারফেস রঙ ~৮৮% অস্বচ্ছ — পেছনের ঝাপসা
          // পেজের আভা হালকা ভেসে ওঠে
          color: scheme.surface.withAlpha(224),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: (isDark ? Colors.white : AppColors.primary).withAlpha(46),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withAlpha(70),
              blurRadius: 28,
              offset: const Offset(0, 12),
            ),
          ],
        ),
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 10),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // হেডার: শিরোনাম + টাকা গণকে যাওয়ার লিংক
            Row(
              children: [
                Icon(Icons.calculate_outlined, size: 19, color: scheme.primary),
                const SizedBox(width: 7),
                Text(
                  'ক্যালকুলেটর',
                  style: TextStyle(
                    fontFamily: 'HindSiliguri',
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: onSurface,
                  ),
                ),
                const Spacer(),
                TextButton(
                  onPressed: _openTakaGonok,
                  style: TextButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    minimumSize: Size.zero,
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                  child: const Text(
                    'টাকা গণক →',
                    style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 13.5),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            // ডিসপ্লে
            Container(
              decoration: BoxDecoration(
                color: onSurface.withAlpha(isDark ? 16 : 10),
                borderRadius: BorderRadius.circular(14),
              ),
              padding: const EdgeInsets.fromLTRB(14, 10, 6, 12),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: 18,
                          child: Text(
                            _exprLine,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontFamily: 'HindSiliguri',
                              fontSize: 13,
                              color: _error ? AppColors.error : scheme.onSurfaceVariant,
                            ),
                          ),
                        ),
                        const SizedBox(height: 2),
                        FittedBox(
                          fit: BoxFit.scaleDown,
                          alignment: Alignment.centerLeft,
                          child: Text(
                            _display,
                            maxLines: 1,
                            style: TextStyle(
                              fontFamily: 'HindSiliguri',
                              fontSize: 32,
                              fontWeight: FontWeight.w700,
                              color: _error ? AppColors.error : onSurface,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: _backspace,
                    icon: const Icon(Icons.backspace_outlined, size: 21),
                    color: scheme.onSurfaceVariant,
                    tooltip: 'একটা করে মুছুন',
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            // কীপ্যাড: বামে ৪×৩ সংখ্যা, ডানে অপারেটর কলাম (÷ × − + =)
            SizedBox(
              height: 268,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(
                    flex: 3,
                    child: Column(
                      children: [
                        _keyRow([
                          _digitKey('7'),
                          _digitKey('8'),
                          _digitKey('9'),
                        ]),
                        _keyRow([
                          _digitKey('4'),
                          _digitKey('5'),
                          _digitKey('6'),
                        ]),
                        _keyRow([
                          _digitKey('1'),
                          _digitKey('2'),
                          _digitKey('3'),
                        ]),
                        _keyRow([
                          _Key(
                            label: '.',
                            onTap: _dot,
                            bg: _keyBg(context),
                            fg: onSurface,
                          ),
                          _digitKey('0'),
                          _Key(
                            label: '±',
                            onTap: _negate,
                            bg: _keyBg(context),
                            fg: onSurface,
                          ),
                        ]),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    flex: 1,
                    child: Column(
                      children: [
                        _opKey('÷', () => _setOp('/')),
                        _opKey('×', () => _setOp('*')),
                        _opKey('−', () => _setOp('-')),
                        _opKey('+', () => _setOp('+')),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: _Key(
                              label: '=',
                              onTap: _equals,
                              bg: scheme.primary,
                              fg: Colors.white,
                              fontSize: 24,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 6),
            // অ্যাকশন সারি
            Row(
              children: [
                TextButton(
                  onPressed: _clear,
                  child: const Text(
                    'CLEAR',
                    style: TextStyle(fontFamily: 'HindSiliguri', letterSpacing: 0.4),
                  ),
                ),
                const Spacer(),
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text(
                    'CANCEL',
                    style: TextStyle(fontFamily: 'HindSiliguri', letterSpacing: 0.4),
                  ),
                ),
                const SizedBox(width: 4),
                TextButton(
                  onPressed: _onOk,
                  child: Text(
                    'OK',
                    style: TextStyle(
                      fontFamily: 'HindSiliguri',
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.4,
                      color: scheme.primary,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Color _keyBg(BuildContext context) =>
      Theme.of(context).colorScheme.onSurface.withAlpha(18);

  Color _opBg(BuildContext context) =>
      Theme.of(context).colorScheme.primary.withAlpha(42);

  Widget _keyRow(List<Widget> keys) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.only(top: 8),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            for (var i = 0; i < keys.length; i++) ...[
              if (i > 0) const SizedBox(width: 8),
              Expanded(child: keys[i]),
            ],
          ],
        ),
      ),
    );
  }

  Widget _digitKey(String d) {
    return _Key(
      label: toBanglaDigits(d),
      onTap: () => _digit(d),
      bg: _keyBg(context),
      fg: Theme.of(context).colorScheme.onSurface,
    );
  }

  Widget _opKey(String label, VoidCallback onTap) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.only(top: 8),
        child: _Key(
          label: label,
          onTap: onTap,
          bg: _opBg(context),
          fg: Theme.of(context).colorScheme.primary,
          fontSize: 23,
        ),
      ),
    );
  }
}

/// একটা কীপ্যাড বোতাম — গ্লাস ঘরানার, চাপে ripple
class _Key extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final Color bg;
  final Color fg;
  final double fontSize;
  const _Key({
    required this.label,
    required this.onTap,
    required this.bg,
    required this.fg,
    this.fontSize = 22,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: bg,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              fontFamily: 'HindSiliguri',
              fontSize: fontSize,
              fontWeight: FontWeight.w600,
              color: fg,
            ),
          ),
        ),
      ),
    );
  }
}
