import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/local/app_database.dart';
import '../../data/local/dao/app_repository.dart';
import '../../data/local/dao/finance_repository.dart';
import '../../data/remote/supabase_client.dart';
import '../sync/sync_engine.dart';
import '../update/update_service.dart';

/// গ্লোবাল ইনস্ট্যান্স — অ্যাপ বুটে সেট হয়
AppDatabase? _dbInstance;
AppRepository? _repoInstance;
FinanceRepository? _finRepoInstance;
SyncEngine? _engineInstance;

void bootstrapServices(AppDatabase db) {
  _dbInstance = db;
  _repoInstance = AppRepository(db);
  _finRepoInstance = FinanceRepository(db);
  _engineInstance = SyncEngine(_repoInstance!);
}

AppDatabase get dbRef => _dbInstance!;
AppRepository get repo => _repoInstance!;
FinanceRepository get finRepo => _finRepoInstance!;
SyncEngine get syncEngine => _engineInstance!;
UpdateService get updateService => UpdateService.instance;

/// লগইন স্টেট — auth পরিবর্তনে শুনুন
class AuthStateNotifier extends ChangeNotifier {
  bool _loggedIn = Supa.isLoggedIn;
  String? _uid = Supa.currentUserId;

  bool get loggedIn => _loggedIn;
  String? get uid => _uid;

  void refresh() {
    _loggedIn = Supa.isLoggedIn;
    _uid = Supa.currentUserId;
    notifyListeners();
  }
}

final authStateProvider = ChangeNotifierProvider<AuthStateNotifier>((ref) {
  return AuthStateNotifier();
});

/// V1.5.0 (Agent E): লোকাল ডাটা বদলের গ্লোবাল revision কাউন্টার।
/// AppRepository.onLocalChange প্রতিটা insert/update/delete-এ fire হয়;
/// main.dart-এর composition root-এ সেটা চেইন করে (সিঙ্ক-ট্রিগার আগের
/// মতোই রেখে) এই notifier-ও bump করা হয়। যেসব হিসাব-provider stream
/// নয় (FutureProvider), তারা এটা watch করলেই যেকোনো আয়-ব্যয় যোগের
/// পর সঙ্গে সঙ্গে আবার হিসাব হয় — অ্যাপ রিস্টার্ট করা লাগে না।
class DataRevision extends ChangeNotifier {
  DataRevision._();
  static final DataRevision instance = DataRevision._();

  int _value = 0;
  int get value => _value;

  void bump() {
    _value++;
    notifyListeners();
  }
}

final dataRevisionProvider = ChangeNotifierProvider<DataRevision>((ref) {
  return DataRevision.instance;
});

final syncStatusProvider = ChangeNotifierProvider<SyncEngine>((ref) {
  ref.watch(authStateProvider); // V1.4.1: uid বদলালে নতুন uid দিয়ে স্ট্রিম (F-02 প্যাটার্ন)
  return syncEngine;
});

final updateProvider = ChangeNotifierProvider<UpdateService>((ref) {
  ref.watch(authStateProvider); // V1.4.1: uid বদলালে নতুন uid দিয়ে স্ট্রিম (F-02 প্যাটার্ন)
  return updateService;
});

/// ওয়ালেট তালিকা
final walletsProvider = StreamProvider.autoDispose((ref) { ref.watch(authStateProvider); return repo.watchWallets(); });
final categoriesProvider = StreamProvider.autoDispose((ref) { ref.watch(authStateProvider); return repo.watchCategories(); });
final expenseHeadsProvider = StreamProvider.autoDispose((ref) { ref.watch(authStateProvider); return repo.watchCategoriesScoped('expense'); });
final incomeHeadsProvider = StreamProvider.autoDispose((ref) { ref.watch(authStateProvider); return repo.watchCategoriesScoped('income'); });
final productsProvider = StreamProvider.autoDispose((ref) { ref.watch(authStateProvider); return repo.watchProducts(); });
final profileProvider = StreamProvider.autoDispose((ref) { ref.watch(authStateProvider); return repo.watchProfile(); });
final pendingSyncProvider = StreamProvider.autoDispose((ref) { ref.watch(authStateProvider); return repo.watchPendingCount(); });
