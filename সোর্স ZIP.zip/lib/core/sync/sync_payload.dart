import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:drift/drift.dart';

/// সিঙ্ক পেলোড হেল্পার — লোকাল Drift স্কিমা ↔ সার্ভার Postgres স্কিমার সেতু
/// • sync_status/GENERATED কলাম বাদ
/// • টেবিল-ভেদে কলাম-নাম/টাইপের পার্থক্য ম্যাপ করে (v1.2 সিঙ্ক-ফিক্স)
class SyncPayload {
  SyncPayload._();

  /// সার্ভারে GENERATED কলাম — পেলোডে যাবে না
  static const Map<String, List<String>> generatedCols = {
    'hat_purchase_items': ['due_paisa', 'line_total_paisa'],
    'cash_tally_items': ['line_total_paisa'],
  };

  /// পুশের সময় বাদ যাবে (সার্ভারে কলাম নেই)
  static const Map<String, Set<String>> pushStrip = {
    'profiles': {'user_id'}, // সার্ভারে profiles-এ user_id নেই (id-ই uid)
    'income_personal': {'payment_method'},
    'dps_accounts': {'note'},
    // V1.3-এর নতুন কলাম (gross_kg, deduction_kg, rate_paisa_per_maund,
    // difference_note) সার্ভারে যোগ হয়েছে 2026-10-30 (Management API দিয়ে
    // supabase_v13_columns.sql চালিয়ে যাচাই করা) — তাই strip তোলা হলো,
    // কলামগুলো এখন সিঙ্ক হয়।
  };

  /// পুশে নাম বদলে যাবে (লোকাল → সার্ভার)
  static const Map<String, Map<String, String>> pushRename = {};

  /// পুলে বাদ যাবে (লোকালে কলাম নেই — serverRowValues নিজেই ফিল্টার করে)

  static Map<String, dynamic> of(Insertable<dynamic> row, {String? table}) {
    final cols = row.toColumns(false);
    final out = <String, dynamic>{};
    cols.forEach((key, expr) {
      if (expr is Variable) {
        out[key] = expr.value;
      }
    });
    out.remove('sync_status');
    if (table != null) {
      for (final g in generatedCols[table] ?? const <String>[]) {
        out.remove(g);
      }
      for (final s in pushStrip[table] ?? const <String>{}) {
        out.remove(s);
      }
      if (table == 'hats') {
        // লোকাল TEXT '[]' → সার্ভার smallint[]
        out['hat_days'] = decodeHatDays(out['hat_days']);
      }
      if (table == 'daily_closings') {
        // লোকাল epoch-ms → সার্ভার timestamptz ISO
        out['closed_at'] = closedAtToIso(out['closed_at']);
      }
    }
    return out;
  }

  /// সার্ভার JSON → কলাম-নাম ধরে টাইপ-কোয়ার্স করা মানের ম্যাপ
  static Map<String, Object?> serverRowValues(TableInfo table, Map<String, dynamic> json) {
    final name = table.entityName;
    final src = Map<String, dynamic>.from(json);
    if (name == 'hats') {
      src['hat_days'] = encodeHatDays(src['hat_days']);
    }
    if (name == 'daily_closings') {
      src['closed_at'] = isoToClosedAtMs(src['closed_at']);
    }
    final raw = <String, Object?>{};
    for (final c in table.$columns) {
      if (c.name == 'sync_status') continue;
      if (!src.containsKey(c.name)) continue;
      raw[c.name] = coerce(c, src[c.name]);
    }
    return raw;
  }

  /// লোকাল '["6"]'/’[]' → [6] (সার্ভার smallint[])
  static List<int> decodeHatDays(Object? v) {
    if (v == null) return const <int>[];
    if (v is List) return v.map((e) => int.tryParse('$e') ?? 0).toList();
    final s = '$v';
    try {
      final parsed = jsonDecode(s.isEmpty ? '[]' : s);
      if (parsed is List) return parsed.map((e) => int.tryParse('$e') ?? 0).toList();
    } catch (_) {}
    return const <int>[];
  }

  /// সার্ভার smallint[]/null → লোকাল TEXT JSON
  static String encodeHatDays(Object? v) {
    if (v == null) return '[]';
    if (v is String) return v.isEmpty ? '[]' : v;
    if (v is List) return jsonEncode(v.map((e) => int.tryParse('$e') ?? 0).toList());
    return '[]';
  }

  /// লোকাল epoch-ms (int) → ISO timestamptz; 0/null → null
  static String? closedAtToIso(Object? v) {
    if (v == null) return null;
    final ms = v is int ? v : int.tryParse('$v');
    if (ms == null || ms <= 0) return null;
    return DateTime.fromMillisecondsSinceEpoch(ms, isUtc: true)
        .toIso8601String();
  }

  /// সার্ভার timestamptz ISO → লোকাল epoch-ms; null/'0' → 0
  static int isoToClosedAtMs(Object? v) {
    if (v == null) return 0;
    if (v is int) return v;
    final s = '$v';
    if (s.isEmpty || s == '0') return 0;
    return DateTime.tryParse(s)?.millisecondsSinceEpoch ?? 0;
  }

  /// V1.5.0: deterministic seed id — UUIDv5-স্টাইল (SHA-256 ভিত্তিক)।
  /// '<scope>|<table>|<naturalKey>' থেকে তৈরি হয় বলে একই scope-এ প্রতিটা
  /// ইনস্টল/ডিভাইসে seed row-র id হুবহু একই হয় — সিডিং waves অনুযায়ী
  /// সার্ভারে ডুপ্লিকেট জমে না (v1.4.x-এর ডুপ্লিকেশনের মূল কারণ ছিল
  /// প্রতিবার নতুন random id)।
  static String deterministicSeedId(String scope, String table, String naturalKey) {
    final bytes = sha256.convert(utf8.encode('$scope|$table|$naturalKey')).bytes;
    final b = List<int>.from(bytes.take(16));
    b[6] = (b[6] & 0x0f) | 0x50; // version 5
    b[8] = (b[8] & 0x3f) | 0x80; // RFC 4122 variant
    final hex = b.map((e) => e.toRadixString(16).padLeft(2, '0')).join();
    return '${hex.substring(0, 8)}-${hex.substring(8, 12)}-'
        '${hex.substring(12, 16)}-${hex.substring(16, 20)}-${hex.substring(20)}';
  }

  static Object? coerce(GeneratedColumn c, Object? v) {
    if (v == null) return null;
    switch (c.type) {
      case DriftSqlType.bool:
        if (v is bool) return v;
        if (v is num) return v != 0;
        return '$v' == 'true' || '$v' == '1';
      case DriftSqlType.int:
      case DriftSqlType.bigInt:
        if (v is num) return v.round();
        return int.tryParse('$v');
      case DriftSqlType.double:
        if (v is num) return v.toDouble();
        return double.tryParse('$v');
      default:
        return v is String ? v : v.toString();
    }
  }
}

/// V1.5.0: normalized content-তুলনা — push-এর version reconciliation (B) ও
/// pull-এর pending/equal-version তুলনা (applyServerRow) দুটোই এটা ব্যবহার
/// করে। v1.4.x-এ raw string তুলনায় শুধু timestamp-ফরম্যাটের তফাতে
/// ("…30.310011Z" বনাম "…30.310011+00:00", trailing-zero fraction) ভুয়া
/// conflict তৈরি হতো এবং profiles-এর version-check চিরদিন আটকে থাকত।
///
/// নিয়ম (রক্ষণশীল — এর বাইরে যেকোনো string-পার্থক্য = আসল পার্থক্য):
/// • তুলনা হয় লোকাল payload-র key-গুলোর উপর (payload-তে যা push হবে);
///   সার্ভারে key না থাকা = null ধরা হয়। এতে pushStrip/generated কলাম
///   (সার্ভার-only বা payload-only) ভুয়া পার্থক্য তৈরি করে না।
/// • ignore: 'version', 'sync_status' (তুলনার বিষয়ই নয়) ও 'updated_at'
///   (শুধু ছোঁয়ার সময় — আগের _contentDiffers-ও এটা বাদ দিত; রাখলে
///   server row পরে touch হলেই adopt অসম্ভব হয়ে যেত)।
/// • ISO-8601 datetime string (যাতে 'T' আছে) → instant হিসেবে তুলনা
///   (DateTime.parse — Z ও +00:00 দুটোই পড়ে; millisecondsSinceEpoch)।
///   date-only string ('YYYY-MM-DD') plain string হিসেবেই তুলনা হয়।
/// • সংখ্যা: মান দিয়ে (int 4 == double 4.0)। bool ↔ 0/1 ম্যাপ হয়।
/// • null আর missing key সমান; null আর খালি list-ও সমান ধরা হয়
///   (hat_days-এর পুরনো সার্ভার row-তে null থাকতে পারে)।
/// • user_id: case-insensitive string তুলনা।
class SyncCompare {
  SyncCompare._();

  static const Set<String> defaultIgnore = {'version', 'sync_status', 'updated_at'};

  /// [server] = সার্ভার row (PostgREST JSON), [localPayload] =
  /// SyncPayload.of দিয়ে বানানো লোকাল payload। true = content সমান।
  static bool rowsEqual(
    Map<String, dynamic> server,
    Map<String, dynamic> localPayload, {
    Set<String> ignore = defaultIgnore,
  }) {
    for (final k in localPayload.keys) {
      if (ignore.contains(k)) continue;
      if (!valuesEqual(server[k], localPayload[k], key: k)) return false;
    }
    return true;
  }

  static bool valuesEqual(Object? a, Object? b, {String? key}) {
    if (a == null && b == null) return true;
    // null বনাম খালি list — সমান (উপরে দেখুন)
    if (a == null && b is List) return b.isEmpty;
    if (b == null && a is List) return a.isEmpty;
    if (a == null || b == null) return false;
    if (key == 'user_id' && a is String && b is String) {
      return a.toLowerCase() == b.toLowerCase();
    }
    if (a is num && b is num) return a == b; // Dart-এ num == মান-ভিত্তিক
    if (a is bool && b is num) return a == (b != 0);
    if (b is bool && a is num) return b == (a != 0);
    if (a is String && b is String) {
      final ia = _tryInstantMs(a);
      final ib = _tryInstantMs(b);
      if (ia != null && ib != null) return ia == ib;
      return a == b;
    }
    if (a is List && b is List) {
      if (a.length != b.length) return false;
      for (var i = 0; i < a.length; i++) {
        if (!valuesEqual(a[i], b[i])) return false;
      }
      return true;
    }
    return a == b;
  }

  /// পূর্ণ ISO datetime হলে epoch-ms, নাহলে null। date-only বা সাধারণ
  /// string-এ null ফেরত আসে → caller plain string তুলনায় যায়।
  static int? _tryInstantMs(String s) {
    if (!s.contains('T')) return null;
    return DateTime.tryParse(s)?.millisecondsSinceEpoch;
  }
}
