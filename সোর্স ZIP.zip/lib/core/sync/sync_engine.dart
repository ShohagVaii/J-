import 'dart:async';
import 'dart:convert';
import 'dart:io' show SocketException;

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';

import '../../data/local/dao/app_repository.dart';
import '../../data/remote/supabase_client.dart';
import 'sync_payload.dart';

/// সিঙ্ক ইঞ্জিন — কখনোই থ্রো করে না, UI-তে বন্ধুত্বপূর্ণ স্টেট দেয় (v1.1 ফিক্স ৪)
enum SyncState { idle, syncing, synced, pending, offline, error }

class SyncStatus {
  final SyncState state;
  final String message;
  final int pendingCount;
  const SyncStatus(this.state, this.message, {this.pendingCount = 0});
}

class SyncEngine extends ChangeNotifier {
  SyncEngine(this._repo);
  final AppRepository _repo;

  SyncStatus _status = const SyncStatus(SyncState.idle, 'সিঙ্ক প্রস্তুত');
  SyncStatus get status => _status;

  /// V1.3.1: সর্বশেষ সিঙ্ক-ব্যর্থতার আসল বিবরণ (টেবিল + exception) —
  /// Settings-এ ট্যাপ করলে দেখা যায়; meta-তেও থাকে (last_sync_error)।
  String? lastErrorDetail;

  void _set(SyncState state, String message, {int pendingCount = 0}) {
    _status = SyncStatus(state, message, pendingCount: pendingCount);
    notifyListeners();
  }

  Timer? _retryTimer;
  Timer? _periodic;
  bool _running = false;
  int _errorStreak = 0;
  bool _offline = false;
  bool _started = false;
  StreamSubscription<List<ConnectivityResult>>? _connSub;

  void start() {
    // FIX M-2: start() বারবার ডাকলেও (login/auth event) listener/timer
    // ডুপ্লিকেট হবে না
    if (_started) {
      scheduleSoon();
      return;
    }
    _started = true;
    _repo.onLocalChange = () => scheduleSoon();
    _connSub = Connectivity().onConnectivityChanged.listen((results) {
      final off = results.isEmpty ||
          (results.length == 1 && results.first == ConnectivityResult.none);
      _offline = off;
      if (!off) scheduleSoon();
    });
    _periodic = Timer.periodic(const Duration(minutes: 4), (_) => scheduleSoon());
    scheduleSoon();
  }

  @override
  void dispose() {
    _retryTimer?.cancel();
    _periodic?.cancel();
    _connSub?.cancel();
    _started = false;
    super.dispose();
  }

  /// ছোট ডিলেতে একবারই চলবে (ডিবাউন্স)
  void scheduleSoon() {
    if (_running) return;
    Future.delayed(const Duration(milliseconds: 1200), () {
      if (!_running) runSync();
    });
  }

  Future<void> runSync({bool force = false}) async {
    if (_running) return;
    if (!Supa.isLoggedIn) {
      _set(SyncState.idle, 'অতিথি মোড — সিঙ্ক বন্ধ');
      return;
    }
    if (_offline && !force) {
      final pending = await _safePendingCount();
      _set(SyncState.offline, 'অফলাইন — ডাটা ফোনে সেভ হচ্ছে', pendingCount: pending);
      return;
    }
    _running = true;
    try {
      _set(SyncState.syncing, 'সিঙ্ক হচ্ছে…', pendingCount: await _safePendingCount());
      // V1.3.1: কিউ থেকে ঝরে পড়া pending রো আগে ফেরত আনা হয়
      try {
        await _repo.reenqueueOrphanPending();
      } catch (_) {}
      // V1.4.1 (G-09): push ব্যর্থতাও এখন টেবিলের নামসহ আলাদা তালিকায়
      // আসে (আগে _push() throw করলে পুরো runSync generic catch-এ যেত) —
      // pull failures-এর সঙ্গে মর্জ করে একই last_sync_error-এ রাখা হয়।
      final pushFailures = await _push();
      final pullFailures = await _pullIsolated();
      final failures = [...pushFailures, ...pullFailures];
      final pending = await _safePendingCount();
      if (failures.isEmpty) {
        _errorStreak = 0;
        lastErrorDetail = null;
        await _repo.setMeta('last_sync_error', '');
        _set(SyncState.synced, 'সব সিঙ্ক সম্পন্ন', pendingCount: pending);
      } else {
        // V1.3.1: একটা টেবিল ব্যর্থ হলেও বাকিগুলো সিঙ্ক হয়েছে —
        // কোন টেবিলে আটকেছে সেটা নামসহ জানানো হয় (আগে পুরো সিঙ্কই
        // "সমস্যা" দেখাত, কারণ জানা যেত না)।
        _errorStreak++;
        _scheduleRetry();
        final first = failures.first;
        lastErrorDetail = failures
            .map((f) => '${f.table}: ${f.error}')
            .join('\n');
        await _repo.setMeta('last_sync_error', lastErrorDetail!);
        _set(SyncState.error,
            'সিঙ্কে সমস্যা (${first.table}) — নিজে থেকেই আবার চেষ্টা করবে',
            pendingCount: pending);
        if (kDebugMode) debugPrint('sync failures: $lastErrorDetail');
      }
    } catch (e) {
      if (_isNetworkError(e)) {
        // V1.3.1: http ক্লায়েন্টের মোড়ানো নেটওয়ার্ক-এররও অফলাইন —
        // আগে এগুলো generic catch-এ পড়ে "সিঙ্কে সমস্যা" দেখাত।
        _offline = true;
        _scheduleRetry();
        _set(SyncState.offline, 'অফলাইন — ইন্টারনেট এলে আবার সিঙ্ক হবে',
            pendingCount: await _safePendingCount());
      } else {
        _errorStreak++;
        _scheduleRetry();
        lastErrorDetail = '$e';
        await _repo.setMeta('last_sync_error', '$e');
        _set(SyncState.error, 'সিঙ্কে সমস্যা — নিজে থেকেই আবার চেষ্টা করবে',
            pendingCount: await _safePendingCount());
        if (kDebugMode) debugPrint('sync error: $e');
      }
    } finally {
      _running = false;
    }
  }

  bool _isNetworkError(Object e) {
    if (e is SocketException || e is TimeoutException) return true;
    final s = '$e';
    return s.contains('SocketException') ||
        s.contains('ClientException') ||
        s.contains('Failed host lookup') ||
        s.contains('Connection closed') ||
        s.contains('Connection reset') ||
        s.contains('Network is unreachable') ||
        s.contains('timed out');
  }

  void _scheduleRetry() {
    _retryTimer?.cancel();
    // V1.3.1: সর্বোচ্চ বিরতি ৫ মিনিট (আগে ৩০ মিনিট পর্যন্ত যেত — নেট
    // ফিরলেও ব্যানার অনেকক্ষণ থেকে যেত)।
    final delays = [60, 180, 300, 300];
    final idx = _errorStreak - 1 < 0 ? 0 : (_errorStreak - 1 >= delays.length ? delays.length - 1 : _errorStreak - 1);
    _retryTimer = Timer(Duration(seconds: delays[idx]), () => runSync());
  }

  Future<int> _safePendingCount() async {
    try {
      return await _repo.pendingCount();
    } catch (_) {
      return 0;
    }
  }

  /// V1.4.1: push ব্যর্থতার তালিকা ফেরত দেয় (টেবিলের নামসহ) — runSync
  /// এটাকে pull failures-এর সঙ্গে মর্জ করে last_sync_error-এ রাখে।
  ///
  /// ★ V1.5.0 (A): payload আর queue-র জমে থাকা payloadJson থেকে নয় —
  /// প্রতিটা item-এর বর্তমান লোকাল row থেকে নতুন করে বানানো হয়।
  /// পুরনো payloadJson stale হতো (migration/reassign-এর আগের user_id
  /// থেকে যেত → RLS upsert reject করত: "categories: upsert failed")।
  /// row মুছে গিয়ে থাকলে item বাদ; row অন্য অ্যাকাউন্টের partition-এর
  /// হলে item বাদ (ডাটা ফোনেই থাকে, ওই partition-এরই অংশ)।
  Future<List<({String table, Object error})>> _push() async {
    final failures = <({String table, Object error})>[];
    final failedTables = <String>{};
    void noteFailure(String table, Object error) {
      if (failedTables.add(table)) {
        failures.add((table: table, error: error));
      }
    }

    const maxAttempts = 6; // এর বেশি ব্যর্থ রো কিউ আটকে রাখবে না (ডাটা ফোনে থাকে)
    var loops = 0;
    while (true) {
      if (++loops > 60) return failures; // FIX H-5b: অসীম লুপের বিরুদ্ধে নিরাপত্তা
      final batch = await _repo.pendingBatch(limit: 100);
      if (batch.isEmpty) return failures;
      // এই রাউন্ডে queue থেকে কিছু সরল কিনা — না সরলে একই batch বারবার ঘোরে না
      var removedAny = false;
      // FIX H-5: queue id ও payload জোড়া হিসেবে রাখা হয় — আগে parallel
      // list ধরে হিসাব করায় ভুল রো done/error মার্ক হয়ে যেত
      final byTable = <String, List<({int qid, Map<String, dynamic> payload})>>{};
      for (final q in batch) {
        if (q.operation == 'delete') {
          try {
            await Supa.client.from(q.targetTable).delete().eq('id', q.rowId);
            await _repo.removeQueueIds([q.id]);
            removedAny = true;
          } catch (_) {
            noteFailure(q.targetTable, 'delete failed');
            // FIX H-5: delete-এরও attempts cap (আগে অসীম retry লুপ হতো)
            if (q.attempts + 1 >= maxAttempts) {
              await _repo.removeQueueIds([q.id]);
              removedAny = true;
            } else {
              await _repo.markQueueError(q.id, q.attempts + 1, 'delete failed');
            }
          }
          continue;
        }
        // (A) payload rebuild — বর্তমান লোকাল row থেকে
        Map<String, dynamic>? payload;
        try {
          payload = await _repo.getLocalRowJson(q.targetTable, q.rowId);
        } catch (_) {
          // অজানা টেবিল/ভাঙা row — cap পর্যন্ত retry, তারপর বাদ
          if (q.attempts + 1 >= maxAttempts) {
            await _repo.removeQueueIds([q.id]);
            removedAny = true;
          } else {
            await _repo.markQueueError(q.id, q.attempts + 1, 'row load failed');
          }
          continue;
        }
        if (payload == null) {
          // row আর লোকালে নেই (purge/wipe হয়ে গেছে) — item-এর কাজ শেষ
          await _repo.removeQueueIds([q.id]);
          removedAny = true;
          continue;
        }
        final curUid = Supa.currentUserId;
        if (q.targetTable == 'profiles') {
          // profiles-এর scope হলো row id নিজেই (id = uid; payload-এ
          // user_id থাকে না)। গেস্ট ('local') বা অন্য অ্যাকাউন্টের
          // প্রোফাইল এই অ্যাকাউন্টে পাঠানো হবে না — item বাদ।
          if (q.rowId != curUid) {
            await _repo.removeQueueIds([q.id]);
            removedAny = true;
            continue;
          }
        } else {
          final pUid = payload['user_id'];
          if (pUid != null && pUid != 'local' && pUid != curUid) {
            // অন্য অ্যাকাউন্টের লোকাল partition-এর row — এই অ্যাকাউন্টের
            // নামে যাবে না (docs/08 §6.3); item বাদ, ডাটা ফোনে থাকে।
            await _repo.removeQueueIds([q.id]);
            removedAny = true;
            continue;
          }
          // 'local'/নিজের uid — এখনকার uid জোর করে বসানো হয়, যাতে
          // migration-আগের stale user_id RLS-এ আটকায় না।
          payload['user_id'] = curUid;
        }
        byTable.putIfAbsent(q.targetTable, () => []).add((qid: q.id, payload: payload));
      }

      // অভিভাবক-টেবিল আগে (FK অর্ডার): profiles → wallets → hats → sessions → …
      const order = AppRepository.userTables;
      final entries = byTable.keys.toList()
        ..sort((a, b) {
          final ia = !order.contains(a) ? 999 : order.indexOf(a);
          final ib = !order.contains(b) ? 999 : order.indexOf(b);
          return ia.compareTo(ib);
        });

      final processedIds = <int>[];
      for (final table in entries) {
        // ★ V1.5.0 (B): version reconciliation — fail-closed check-এর
        // বদলে: সার্ভার এগিয়ে + content সমান → adopt (নীরব সাফল্য);
        // content আলাদা → conflict; বাকি সব → push।
        final rec = await _reconcile(table, byTable[table]!);
        if (rec.fetchFailed) {
          // সার্ভার যাচাই হয়নি (নেটওয়ার্ক) — item queue-তেই থাকে,
          // পরের রানে আবার চেষ্টা হবে; অন্য টেবিল থামে না।
          noteFailure(table, 'সার্ভার যাচাই হয়নি — আবার চেষ্টা হবে');
          continue;
        }
        if (rec.progress) removedAny = true;
        final pairs = rec.push;
        if (pairs.isEmpty) continue;
        // V1.3.1: PostgREST-এর বাল্ক upsert-এ সব রো-তে একই key-set লাগে
        // ("All object keys must match") — পুরনো অ্যাপ-ভার্সনের কিউ-পেলোডে
        // নতুন কলাম না থাকলে পুরো ব্যাচ ফেল করত। key-এর union নিয়ে
        // অনুপস্থিতগুলো null বসিয়ে দেওয়া হয়।
        final allKeys = <String>{};
        for (final e in pairs) {
          allKeys.addAll(e.payload.keys);
        }
        final rows = pairs.map((e) {
          final m = Map<String, dynamic>.from(e.payload);
          for (final k in allKeys) {
            m.putIfAbsent(k, () => null);
          }
          return m;
        }).toList();
        try {
          await Supa.client.from(table).upsert(rows);
          processedIds.addAll(pairs.map((e) => e.qid));
        } catch (_) {
          // ব্যাচ গেল না — একটা একটা করে; কেউ বারবার ফেললে ক্যাপে বাদ
          var anyRowFailed = false;
          for (final pair in pairs) {
            try {
              await Supa.client.from(table).upsert(pair.payload);
              processedIds.add(pair.qid);
            } catch (_) {
              anyRowFailed = true;
              final q = batch.firstWhere((e) => e.id == pair.qid);
              if (q.attempts + 1 >= maxAttempts) {
                await _repo.removeQueueIds([pair.qid]);
                removedAny = true;
              } else {
                await _repo.markQueueError(pair.qid, q.attempts + 1, 'upsert failed');
              }
            }
          }
          if (anyRowFailed) noteFailure(table, 'upsert failed');
        }
      }
      if (processedIds.isNotEmpty) {
        await _repo.removeQueueIds(processedIds);
        removedAny = true;
      }
      if (!removedAny) return failures; // কোনো অগ্রগতি নেই — একই batch ঘোরে না
      if (batch.length < 100) return failures;
    }
  }

  /// V1.3.1: টেবিল-প্রতি আলাদা pull — একটা টেবিল ব্যর্থ হলে বাকিগুলো
  /// থামে না; ব্যর্থ টেবিলের watermark এগোয় না (পরের রানে আবার আসবে)।
  /// V1.4.1: row-প্রতি isolation — একটা row ফেল করলে ব্যর্থতা রেকর্ড হয়
  /// (টেবিল + row id + সংক্ষিপ্ত error), অন্য টেবিলের pull চলতে থাকে।
  Future<List<({String table, Object error})>> _pullIsolated() async {
    final failures = <({String table, Object error})>[];
    for (final table in AppRepository.userTables) {
      try {
        await _pullTable(table);
      } catch (e) {
        if (e is _PullRowFailure) {
          // row-এর এরর — watermark reset-এ লাভ নেই, সরাসরি রেকর্ড
          failures.add((table: table, error: e));
        } else if (_isBadWatermarkError(e)) {
          // পুরনো অ্যাপ-ভার্সনের লেখা নষ্ট watermark (timestamp ফরম্যাট
          // মেলে না) — epoch-এ রিসেট করে একবারই আবার চেষ্টা।
          try {
            await _repo.setMeta('pull:$table', '1970-01-01T00:00:00.000Z');
            await _pullTable(table);
            continue;
          } catch (e2) {
            failures.add((table: table, error: e2));
          }
        } else {
          failures.add((table: table, error: e));
        }
      }
    }
    if (failures.isEmpty) {
      await _repo.setMeta('last_synced_at', DateTime.now().toUtc().toIso8601String());
    }
    return failures;
  }

  /// এরর-স্ট্রিং সংক্ষিপ্ত করা — last_sync_error যেন এক row-এর বিশাল
  /// stack/message-এ ভরে না যায়।
  static String _shortError(Object e) {
    final s = '$e'.replaceAll('\n', ' ');
    return s.length > 220 ? '${s.substring(0, 220)}…' : s;
  }

  bool _isBadWatermarkError(Object e) {
    final s = '$e';
    return s.contains('invalid input syntax for type timestamp') ||
        s.contains('22007');
  }

  Future<void> _pullTable(String table) async {
    final watermark = await _repo.getMeta('pull:$table') ?? '1970-01-01T00:00:00.000Z';
    var last = watermark;
    while (true) {
      final rows = await Supa.client
          .from(table)
          .select()
          .gt('updated_at', last)
          .order('updated_at')
          .limit(500);
      if (rows.isEmpty) break;
      for (final r in rows) {
        final json = Map<String, dynamic>.from(r as Map);
        // V1.4.1: প্রতি row আলাদা try/catch — একটা row ফেল করলে ওই
        // row-তেই থামা হয়, watermark তার আগ পর্যন্তই এগোয় (সফল row
        // গুলো বাদ যায় না, ব্যর্থ row পরের রানে আবার আসবে)।
        try {
          await _repo.applyServerRow(table, json);
        } catch (e) {
          await _repo.setMeta('pull:$table', last);
          throw _PullRowFailure(table, '${json['id']}', e);
        }
        final ua = json['updated_at'] as String?;
        if (ua != null && ua.compareTo(last) > 0) last = ua;
      }
      if ((rows as List).length < 500) break;
    }
    await _repo.setMeta('pull:$table', last);
  }

  /// সার্ভারে লগইন-ইউজারের টেবিলে প্রথমবার প্রোফাইল নিশ্চিত
  Future<void> ensureProfileOnServer() async {
    final uid = Supa.currentUserId;
    if (uid == null) return;
    await _repo.applyServerRow('profiles', {
      'id': uid,
      'user_id': uid,
      'display_name': '',
      'number_style': 'bn',
      'theme_mode': 'system',
      'daily_closing_time': '21:30',
      'default_mother_amount_paisa': 50000,
      'created_at': DateTime.now().toUtc().toIso8601String(),
      'updated_at': DateTime.now().toUtc().toIso8601String(),
      'version': 1,
    });
  }

  /// ★ V1.5.0 (B): version reconciliation — v1.4.1-এর fail-closed
  /// _versionCheck-এর বদলি। সার্ভার row একবারে এনে প্রতিটা item-এর জন্য:
  /// • সার্ভারে row নেই → push
  /// • server version ≤ local version → push (স্বাভাবিক পথ — লোকাল
  ///   edit-এই version বাড়ে; resolveConflictKeepLocal-ও এই পথের উপর
  ///   নির্ভর করে, version = server+1 বসিয়ে push করে)
  /// • server version > local version → normalized content তুলনা
  ///   (SyncCompare): সমান হলে **adopt** — লোকাল version সার্ভারেরটায়
  ///   বসে, sync_status='synced', queue item বাদ; এটা নীরব সাফল্য,
  ///   failure হিসেবে রিপোর্ট হয় না (profiles version-divergence-এর
  ///   স্থায়ী block এভাবেই ভাঙে — content আসলে একই ছিল, শুধু
  ///   timestamp-ফরম্যাট আলাদা ছিল)। আলাদা হলে conflict জমে, item বাদ
  ///   — অন্য টেবিল/row থামে না।
  /// • সার্ভার fetch-ই ব্যর্থ হলে [fetchFailed] — item queue-তে থাকে।
  Future<({
    List<({int qid, Map<String, dynamic> payload})> push,
    bool progress,
    bool fetchFailed,
  })> _reconcile(
      String table, List<({int qid, Map<String, dynamic> payload})> pairs) async {
    final ids = pairs.map((e) => '${e.payload['id']}').toList();
    final List<dynamic> serverRows;
    try {
      serverRows =
          await Supa.client.from(table).select().inFilter('id', ids) as List<dynamic>;
    } catch (_) {
      return (
        push: <({int qid, Map<String, dynamic> payload})>[],
        progress: false,
        fetchFailed: true,
      );
    }
    final serverById = <String, Map<String, dynamic>>{};
    for (final r in serverRows) {
      final m = Map<String, dynamic>.from(r as Map);
      serverById['${m['id']}'] = m;
    }
    final push = <({int qid, Map<String, dynamic> payload})>[];
    var progress = false;
    for (final pair in pairs) {
      final id = '${pair.payload['id']}';
      final server = serverById[id];
      if (server == null) {
        push.add(pair);
        continue;
      }
      final sv = (server['version'] as num?)?.toInt();
      final lv = (pair.payload['version'] as num?)?.toInt();
      if (sv == null || lv == null || sv <= lv) {
        push.add(pair);
        continue;
      }
      // sv > lv — সার্ভার এগিয়ে: content সমান কিনা-ই এখন একমাত্র প্রশ্ন
      if (SyncCompare.rowsEqual(server, pair.payload)) {
        await _repo.adoptServerVersion(table, id, sv);
        await _repo.clearConflict(table, id);
        await _repo.removeQueueIds([pair.qid]);
      } else {
        await _repo.incrementConflict(table, id, jsonEncode(server));
        await _repo.removeQueueIds([pair.qid]);
      }
      progress = true;
    }
    return (push: push, progress: progress, fetchFailed: false);
  }
}

/// V1.4.1: pull-এ নির্দিষ্ট একটা row প্রয়োগে ব্যর্থতা — কোন টেবিলের
/// কোন row, সেটাসহ উপরে ওঠে (watermark ওই row-এর আগেই থেমে থাকে)।
class _PullRowFailure implements Exception {
  final String table;
  final String rowId;
  final Object error;
  const _PullRowFailure(this.table, this.rowId, this.error);

  @override
  String toString() => 'row $rowId: ${SyncEngine._shortError(error)}';
}
