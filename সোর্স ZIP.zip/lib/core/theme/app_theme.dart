import 'package:flutter/material.dart';
import 'app_colors.dart';

class AppTypography {
  AppTypography._();
  static const String fontFamily = 'HindSiliguri';
  static const String numberFamily = 'Inter';

  static TextTheme build(Color onSurface, Color onSurfaceVariant) {
    return TextTheme(
      displaySmall: TextStyle(fontFamily: fontFamily, fontWeight: FontWeight.w700, fontSize: 34, color: onSurface),
      headlineMedium: TextStyle(fontFamily: fontFamily, fontWeight: FontWeight.w700, fontSize: 26, color: onSurface),
      headlineSmall: TextStyle(fontFamily: fontFamily, fontWeight: FontWeight.w600, fontSize: 22, color: onSurface),
      titleLarge: TextStyle(fontFamily: fontFamily, fontWeight: FontWeight.w600, fontSize: 19, color: onSurface),
      titleMedium: TextStyle(fontFamily: fontFamily, fontWeight: FontWeight.w600, fontSize: 16, color: onSurface),
      titleSmall: TextStyle(fontFamily: fontFamily, fontWeight: FontWeight.w500, fontSize: 14, color: onSurface),
      bodyLarge: TextStyle(fontFamily: fontFamily, fontWeight: FontWeight.w400, fontSize: 16, color: onSurface),
      bodyMedium: TextStyle(fontFamily: fontFamily, fontWeight: FontWeight.w400, fontSize: 14, color: onSurface),
      bodySmall: TextStyle(fontFamily: fontFamily, fontWeight: FontWeight.w400, fontSize: 12, color: onSurfaceVariant),
      labelLarge: TextStyle(fontFamily: fontFamily, fontWeight: FontWeight.w600, fontSize: 15, color: onSurface),
      labelMedium: TextStyle(fontFamily: fontFamily, fontWeight: FontWeight.w500, fontSize: 13, color: onSurface),
      labelSmall: TextStyle(fontFamily: fontFamily, fontWeight: FontWeight.w500, fontSize: 11, color: onSurfaceVariant),
    );
  }
}

class AppTheme {
  AppTheme._();

  static ThemeData light() {
    final scheme = ColorScheme.fromSeed(
      seedColor: AppColors.primary,
      primary: AppColors.primary,
      secondary: AppColors.secondary,
      error: AppColors.error,
      surface: AppColors.surface,
    );
    return _base(scheme, AppColors.background, AppColors.surface, AppColors.onSurface,
        AppColors.onSurfaceVariant, AppColors.outline, AppColors.primaryLight,
        AppColors.primaryDark, AppColors.errorLight);
  }

  static ThemeData dark() {
    final scheme = ColorScheme.fromSeed(
      seedColor: AppColors.dPrimary,
      brightness: Brightness.dark,
      primary: AppColors.dPrimary,
      secondary: AppColors.dSecondary,
      error: AppColors.dError,
      surface: AppColors.dSurface,
    );
    return _base(scheme, AppColors.dBackground, AppColors.dSurface, AppColors.dOnSurface,
        AppColors.dOnSurfaceVariant, AppColors.dOutline, AppColors.dPrimaryLight,
        AppColors.dPrimaryDark, AppColors.dErrorLight);
  }

  static ThemeData _base(
    ColorScheme scheme,
    Color background,
    Color surface,
    Color onSurface,
    Color onSurfaceVariant,
    Color outline,
    Color primaryLight,
    Color primaryDark,
    Color errorLight,
  ) {
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: background,
      textTheme: AppTypography.build(onSurface, onSurfaceVariant),
      appBarTheme: AppBarTheme(
        backgroundColor: background,
        foregroundColor: onSurface,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: AppTypography.build(onSurface, onSurfaceVariant).titleLarge,
      ),
      cardTheme: CardTheme(
        color: surface,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: BorderSide(color: outline, width: 1),
        ),
        margin: EdgeInsets.zero,
      ),
      textSelectionTheme: TextSelectionThemeData(
        cursorColor: scheme.primary,
        selectionColor: scheme.primary.withAlpha(70),
        selectionHandleColor: scheme.primary,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: scheme.surfaceContainerHighest.withAlpha(80),
        labelStyle: TextStyle(color: onSurfaceVariant, fontFamily: AppTypography.fontFamily),
        floatingLabelStyle: TextStyle(
            color: scheme.primary, fontFamily: AppTypography.fontFamily, fontWeight: FontWeight.w600),
        hintStyle: TextStyle(
            color: onSurfaceVariant.withAlpha(150), fontFamily: AppTypography.fontFamily),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: outline),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: outline),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: scheme.primary, width: 1.6),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: scheme.primary,
          foregroundColor: Colors.white,
          minimumSize: const Size(0, 48),
          textStyle: const TextStyle(fontFamily: AppTypography.fontFamily, fontWeight: FontWeight.w600, fontSize: 15),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: scheme.primary,
          minimumSize: const Size(0, 48),
          side: BorderSide(color: scheme.primary),
          textStyle: const TextStyle(fontFamily: AppTypography.fontFamily, fontWeight: FontWeight.w600, fontSize: 15),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: scheme.primary,
          textStyle: const TextStyle(fontFamily: AppTypography.fontFamily, fontWeight: FontWeight.w600),
        ),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: primaryLight,
        labelStyle: TextStyle(color: scheme.primary, fontFamily: AppTypography.fontFamily),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        side: BorderSide.none,
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: const Color(0xFF26302A),
        contentTextStyle: const TextStyle(fontFamily: AppTypography.fontFamily, color: Colors.white, fontSize: 14),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
      bottomSheetTheme: const BottomSheetThemeData(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        showDragHandle: true,
      ),
      dividerTheme: DividerThemeData(color: outline, thickness: 1),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: surface,
        indicatorColor: primaryLight,
        labelTextStyle: WidgetStatePropertyAll(TextStyle(
            fontFamily: AppTypography.fontFamily, fontSize: 12, fontWeight: FontWeight.w600, color: onSurface)),
      ),
      dialogTheme: DialogTheme(
        backgroundColor: surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        titleTextStyle: AppTypography.build(onSurface, onSurfaceVariant).titleMedium,
      ),
      listTileTheme: ListTileThemeData(
        titleTextStyle: AppTypography.build(onSurface, onSurfaceVariant).titleSmall,
        subtitleTextStyle: AppTypography.build(onSurface, onSurfaceVariant).bodySmall,
      ),
    );
  }
}
