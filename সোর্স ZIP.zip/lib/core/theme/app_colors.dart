import 'package:flutter/material.dart';

/// 03_UI_Spec §2 — হুবহু টোকেন
class AppColors {
  AppColors._();

  static const Color primary = Color(0xFF1B7A43);
  static const Color primaryDark = Color(0xFF145C32);
  static const Color primaryLight = Color(0xFFE3F2E8);
  static const Color secondary = Color(0xFFF2A93B);
  static const Color secondaryLight = Color(0xFFFDF0DC);
  static const Color background = Color(0xFFF7F8F5);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color surfaceVariant = Color(0xFFEEF1EC);
  static const Color onSurface = Color(0xFF1A1F1C);
  static const Color onSurfaceVariant = Color(0xFF5C6660);
  static const Color outline = Color(0xFFD8DED9);
  static const Color error = Color(0xFFC62828);
  static const Color errorLight = Color(0xFFFDECEA);

  // Dark
  static const Color dPrimary = Color(0xFF3FB96F);
  static const Color dPrimaryDark = Color(0xFF2E9457);
  static const Color dPrimaryLight = Color(0xFF14301F);
  static const Color dSecondary = Color(0xFFF5B84F);
  static const Color dSecondaryLight = Color(0xFF3A2E14);
  static const Color dBackground = Color(0xFF101512);
  static const Color dSurface = Color(0xFF1A201C);
  static const Color dSurfaceVariant = Color(0xFF242B26);
  static const Color dOnSurface = Color(0xFFE8EDE9);
  static const Color dOnSurfaceVariant = Color(0xFF9AA69E);
  static const Color dOutline = Color(0xFF333B35);
  static const Color dError = Color(0xFFEF5350);
  static const Color dErrorLight = Color(0xFF3A1717);

  // Money color language (§2.3)
  static const Color income = primary;
  static const Color dIncome = dPrimary;
  static const Color expense = error;
  static const Color dExpense = dError;
  static const Color savings = Color(0xFF1565C0);
  static const Color dSavings = Color(0xFF64B5F6);
  static const Color mother = Color(0xFFC2185B);
  static const Color dMother = Color(0xFFF06292);
  static const Color loan = Color(0xFF6A1B9A);
  static const Color dLoan = Color(0xFFBA68C8);
  static const Color bike = Color(0xFF4527A0);
  static const Color dBike = Color(0xFF9575CD);
  static const Color warning = Color(0xFFE65100);
  static const Color dWarning = Color(0xFFFFB74D);
  static const Color info = Color(0xFF0277BD);
  static const Color dInfo = Color(0xFF4FC3F7);

  static const List<Color> hatPalette = [
    Color(0xFF1B7A43), Color(0xFFF2A93B), Color(0xFF1565C0), Color(0xFFC2185B),
    Color(0xFF6A1B9A), Color(0xFF00838F), Color(0xFFE65100), Color(0xFF78909C),
  ];
}
