import '../../data/local/app_database.dart';
import '../calculations/dps_calc.dart';
import '../calculations/mileage_calc.dart';
import '../providers/app_providers.dart';
import 'notification_service.dart';

/// V1.3 (ফিচার ৪ + O-8 আংশিক): DPS কিস্তির রিমাইন্ডার চেইন ও বাইক
/// সার্ভিস রিমাইন্ডার — অ্যাপ চালুতে এবং DPS জমা বদলালে পুনঃশিডিউল হয়।
///
/// DPS নোটিফিকেশন ID: প্রতি অ্যাকাউন্টে স্থিতিশীল জোড়া (base, base+1) —
/// আগের কাঠামোতে ধরন-প্রতি একটা ID ছিল, ফলে একাধিক DPS অ্যাকাউন্ট
/// একে অপরের রিমাইন্ডার মুছে দিত।
class ReminderScheduler {
  ReminderScheduler._();

  static int _dpsBaseId(String accountId) =>
      1000 + (accountId.hashCode.abs() % 8000) * 2;

  /// সব active DPS অ্যাকাউন্টের চেইন + বাইক সার্ভিস রিমাইন্ডার শিডিউল করে।
  /// ব্যর্থ হলে নীরবে ছেড়ে দেয় (রিমাইন্ডার কখনো অ্যাপ চালু আটকাবে না)।
  static Future<void> scheduleAll() async {
    try {
      await _scheduleDpsChains();
      await _scheduleBikeService();
    } catch (_) {}
  }

  static Future<void> _scheduleDpsChains() async {
    final svc = NotificationService.instance;
    final accounts = await repo.watchDpsAccounts().first;
    for (final a in accounts) {
      final base = _dpsBaseId(a.id);
      await svc.cancel(base);
      await svc.cancel(base + 1);
      if (a.status != 'active') continue;
      final txs = await repo.watchDpsTx(a.id).first;
      String? lastDeposit;
      for (final t in txs) {
        if (lastDeposit == null || t.txnDate.compareTo(lastDeposit) > 0) {
          lastDeposit = t.txnDate;
        }
      }
      final due = nextDueDate(
        frequency: a.frequency,
        dueDay: a.dueDay,
        startDateYmd: a.startDate,
        lastDepositDateYmd: lastDeposit,
      );
      if (due == null) continue;
      final p = due.split('-').map(int.parse).toList();
      final dueDate = DateTime(p[0], p[1], p[2]);
      final name = a.institutionName;
      // কিস্তির দিন সকাল ৮টা (সব ফ্রিকোয়েন্সিতে)
      await svc.scheduleAt(
        id: base + 1,
        when: DateTime(dueDate.year, dueDate.month, dueDate.day, 8),
        title: 'DPS কিস্তির দিন',
        body: '$name — আজ কিস্তি দেওয়ার দিন।',
        route: '/dps/${a.id}',
      );
      // আগের দিন সন্ধ্যা ৭টা — দৈনিক DPS-এ প্রতিদিনই আসত বলে শুধু সাপ্তাহিক/মাসিকে
      if (a.frequency != DpsFrequency.daily) {
        final eve = dueDate.subtract(const Duration(days: 1));
        await svc.scheduleAt(
          id: base,
          when: DateTime(eve.year, eve.month, eve.day, 19),
          title: 'আগামীকাল DPS কিস্তি',
          body: '$name — আগামীকাল কিস্তির দিন, টাকা গুছিয়ে রাখুন।',
          route: '/dps/${a.id}',
        );
      }
    }
  }

  static Future<void> _scheduleBikeService() async {
    final svc = NotificationService.instance;
    await svc.cancel(NotificationService.idBikeService);
    final fuel = await repo.watchFuelLogs().first;
    final maint = await repo.watchMaintenance().first;
    final estimate = bikeServiceEstimate(fuelLogs: fuel, maintenances: maint);
    final date = estimate?.estimatedDate;
    if (estimate == null || date == null) return;
    final when = date.subtract(const Duration(days: 1));
    await svc.scheduleAt(
      id: NotificationService.idBikeService,
      when: DateTime(when.year, when.month, when.day, 9),
      title: 'বাইক সার্ভিসের সময় হচ্ছে',
      body: 'আনুমানিক ${estimate.remainingKm.toStringAsFixed(0)} কিমি বাকি — সার্ভিসের তারিখ কাছাকাছি।',
      route: '/bike',
    );
  }
}

/// বাইক সার্ভিস পূর্বাভাসের ডাটা-সংযোগ অংশ (V1.3, ফিচার ৮):
/// BikeScreen ও ReminderScheduler দুজনেই এটা ব্যবহার করে।
/// ভিত্তি: সর্বশেষ মেইনটেন্যান্স যার nextServiceKm আছে; না থাকলে সর্বশেষ
/// 'service' এন্ট্রির ওডোমিটার + ডিফল্ট interval।
ServiceEstimate? bikeServiceEstimate({
  required List<FuelLog> fuelLogs,
  required List<BikeMaintenanceData> maintenances,
  DateTime? today,
}) {
  const defaultIntervalKm = 2000.0;
  double? currentOdo;
  for (final f in fuelLogs) {
    if (currentOdo == null || f.odometerKm > currentOdo) currentOdo = f.odometerKm;
  }
  for (final m in maintenances) {
    final o = m.odometerKm;
    if (o != null && (currentOdo == null || o > currentOdo)) currentOdo = o;
  }
  if (currentOdo == null) return null;

  final sorted = [...maintenances]..sort((a, b) => b.txnDate.compareTo(a.txnDate));
  double? nextKm;
  for (final m in sorted) {
    if (m.nextServiceKm != null) {
      nextKm = m.nextServiceKm;
      break;
    }
  }
  if (nextKm == null) {
    for (final m in sorted) {
      if (m.type == 'service' && m.odometerKm != null) {
        nextKm = m.odometerKm! + defaultIntervalKm;
        break;
      }
    }
  }
  if (nextKm == null) return null;

  final views = fuelLogs
      .map((f) => FuelEntryView(
            id: f.id,
            txnDate: f.txnDate,
            odometerKm: f.odometerKm,
            amountPaisa: f.amountPaisa,
            litre: f.litre,
            pricePerLitrePaisa: f.pricePerLitrePaisa,
            isFullTank: f.isFullTank,
          ))
      .toList();
  return estimateNextService(
    nextServiceKm: nextKm,
    currentOdometerKm: currentOdo,
    avgKmPerDay: avgKmPerDayFromFuel(views),
    today: today ?? DateTime.now(),
  );
}
