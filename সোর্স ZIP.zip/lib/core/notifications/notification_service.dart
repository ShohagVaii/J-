import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

/// লোকাল নোটিফিকেশন — 02_AppFlow §6-এর ৬টি ট্রিগার
class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  bool _ready = false;

  static const String channelId = 'hat_hisab_reminders';
  static const String channelName = 'হাট হিসাব রিমাইন্ডার';

  static const int idDpsDue = 1;
  static const int idLoanDue = 2;
  static const int idDailyClosing = 3;
  static const int idHatDay = 4;
  static const int idBikeService = 5;
  static const int idWeeklyBackup = 6;

  Future<void> init() async {
    if (_ready) return;
    tzdata.initializeTimeZones();
    // FIX H-4: setLocalLocation কখনো ডাকা হতো না — tz.local UTC থেকে গিয়ে
    // 21:30-এর রিমাইন্ডার ভোর 03:30-তে বাজত। অ্যাপটি বাংলাদেশ-কেন্দ্রিক,
    // তাই লোকাল জোন Asia/Dhaka-তে নির্ধারিত।
    tz.setLocalLocation(tz.getLocation('Asia/Dhaka'));
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: android);
    await _plugin.initialize(
      settings,
      onDidReceiveNotificationResponse: _onTap,
    );
    _ready = true;
    await requestPermission();
  }

  Future<void> requestPermission() async {
    final android = _plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    await android?.requestNotificationsPermission();
  }

  void Function(String route)? onTapRoute;

  void _onTap(NotificationResponse resp) {
    final route = resp.payload;
    if (route != null && route.isNotEmpty) {
      onTapRoute?.call(route);
    }
  }

  Future<void> showNow({required int id, required String title, required String body, String? route}) async {
    if (!_ready) return;
    const android = AndroidNotificationDetails(
      channelId,
      channelName,
      importance: Importance.high,
      priority: Priority.high,
    );
    await _plugin.show(id, title, body,
        const NotificationDetails(android: android), payload: route);
  }

  /// প্রতিদিন নির্দিষ্ট সময়ে (HH:mm) রিমাইন্ডার
  Future<void> scheduleDaily({
    required int id,
    required int hour,
    required int minute,
    required String title,
    required String body,
    String? route,
  }) async {
    if (!_ready) return;
    final now = tz.TZDateTime.now(tz.local);
    var scheduled = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute);
    if (scheduled.isBefore(now)) {
      scheduled = scheduled.add(const Duration(days: 1));
    }
    const android = AndroidNotificationDetails(channelId, channelName,
        importance: Importance.high, priority: Priority.high);
    await _plugin.zonedSchedule(id, title, body, scheduled,
        const NotificationDetails(android: android),
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        // FIX H-4b: এটি ছাড়া "প্রতিদিনের" রিমাইন্ডার একবারই বাজত
        matchDateTimeComponents: DateTimeComponents.time,
        payload: route,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime);
  }

  Future<void> scheduleAt({
    required int id,
    required DateTime when,
    required String title,
    required String body,
    String? route,
  }) async {
    if (!_ready) return;
    final scheduled = tz.TZDateTime.from(when, tz.local);
    if (scheduled.isBefore(tz.TZDateTime.now(tz.local))) return;
    const android = AndroidNotificationDetails(channelId, channelName,
        importance: Importance.high, priority: Priority.high);
    await _plugin.zonedSchedule(id, title, body, scheduled,
        const NotificationDetails(android: android),
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        payload: route,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime);
  }

  Future<void> cancel(int id) => _plugin.cancel(id);
}
