// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'app_database.dart';

// ignore_for_file: type=lint
class $ProfilesTable extends Profiles with TableInfo<$ProfilesTable, Profile> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProfilesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<String> createdAt = GeneratedColumn<String>(
      'created_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<String> updatedAt = GeneratedColumn<String>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _deletedAtMeta =
      const VerificationMeta('deletedAt');
  @override
  late final GeneratedColumn<String> deletedAt = GeneratedColumn<String>(
      'deleted_at', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _versionMeta =
      const VerificationMeta('version');
  @override
  late final GeneratedColumn<int> version = GeneratedColumn<int>(
      'version', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('pending'));
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _displayNameMeta =
      const VerificationMeta('displayName');
  @override
  late final GeneratedColumn<String> displayName = GeneratedColumn<String>(
      'display_name', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _phoneMeta = const VerificationMeta('phone');
  @override
  late final GeneratedColumn<String> phone = GeneratedColumn<String>(
      'phone', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _defaultMotherAmountPaisaMeta =
      const VerificationMeta('defaultMotherAmountPaisa');
  @override
  late final GeneratedColumn<int> defaultMotherAmountPaisa =
      GeneratedColumn<int>('default_mother_amount_paisa', aliasedName, false,
          type: DriftSqlType.int,
          requiredDuringInsert: false,
          defaultValue: const Constant(50000));
  static const VerificationMeta _numberStyleMeta =
      const VerificationMeta('numberStyle');
  @override
  late final GeneratedColumn<String> numberStyle = GeneratedColumn<String>(
      'number_style', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('bn'));
  static const VerificationMeta _themeModeMeta =
      const VerificationMeta('themeMode');
  @override
  late final GeneratedColumn<String> themeMode = GeneratedColumn<String>(
      'theme_mode', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('system'));
  static const VerificationMeta _dailyClosingTimeMeta =
      const VerificationMeta('dailyClosingTime');
  @override
  late final GeneratedColumn<String> dailyClosingTime = GeneratedColumn<String>(
      'daily_closing_time', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('21:30'));
  @override
  List<GeneratedColumn> get $columns => [
        createdAt,
        updatedAt,
        deletedAt,
        version,
        syncStatus,
        id,
        displayName,
        phone,
        defaultMotherAmountPaisa,
        numberStyle,
        themeMode,
        dailyClosingTime
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'profiles';
  @override
  VerificationContext validateIntegrity(Insertable<Profile> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    if (data.containsKey('deleted_at')) {
      context.handle(_deletedAtMeta,
          deletedAt.isAcceptableOrUnknown(data['deleted_at']!, _deletedAtMeta));
    }
    if (data.containsKey('version')) {
      context.handle(_versionMeta,
          version.isAcceptableOrUnknown(data['version']!, _versionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('display_name')) {
      context.handle(
          _displayNameMeta,
          displayName.isAcceptableOrUnknown(
              data['display_name']!, _displayNameMeta));
    }
    if (data.containsKey('phone')) {
      context.handle(
          _phoneMeta, phone.isAcceptableOrUnknown(data['phone']!, _phoneMeta));
    }
    if (data.containsKey('default_mother_amount_paisa')) {
      context.handle(
          _defaultMotherAmountPaisaMeta,
          defaultMotherAmountPaisa.isAcceptableOrUnknown(
              data['default_mother_amount_paisa']!,
              _defaultMotherAmountPaisaMeta));
    }
    if (data.containsKey('number_style')) {
      context.handle(
          _numberStyleMeta,
          numberStyle.isAcceptableOrUnknown(
              data['number_style']!, _numberStyleMeta));
    }
    if (data.containsKey('theme_mode')) {
      context.handle(_themeModeMeta,
          themeMode.isAcceptableOrUnknown(data['theme_mode']!, _themeModeMeta));
    }
    if (data.containsKey('daily_closing_time')) {
      context.handle(
          _dailyClosingTimeMeta,
          dailyClosingTime.isAcceptableOrUnknown(
              data['daily_closing_time']!, _dailyClosingTimeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Profile map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Profile(
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}updated_at'])!,
      deletedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}deleted_at']),
      version: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}version'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      displayName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}display_name'])!,
      phone: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}phone']),
      defaultMotherAmountPaisa: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}default_mother_amount_paisa'])!,
      numberStyle: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}number_style'])!,
      themeMode: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}theme_mode'])!,
      dailyClosingTime: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}daily_closing_time'])!,
    );
  }

  @override
  $ProfilesTable createAlias(String alias) {
    return $ProfilesTable(attachedDatabase, alias);
  }
}

class Profile extends DataClass implements Insertable<Profile> {
  final String createdAt;
  final String updatedAt;
  final String? deletedAt;
  final int version;
  final String syncStatus;
  final String id;
  final String displayName;
  final String? phone;
  final int defaultMotherAmountPaisa;
  final String numberStyle;
  final String themeMode;
  final String dailyClosingTime;
  const Profile(
      {required this.createdAt,
      required this.updatedAt,
      this.deletedAt,
      required this.version,
      required this.syncStatus,
      required this.id,
      required this.displayName,
      this.phone,
      required this.defaultMotherAmountPaisa,
      required this.numberStyle,
      required this.themeMode,
      required this.dailyClosingTime});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['created_at'] = Variable<String>(createdAt);
    map['updated_at'] = Variable<String>(updatedAt);
    if (!nullToAbsent || deletedAt != null) {
      map['deleted_at'] = Variable<String>(deletedAt);
    }
    map['version'] = Variable<int>(version);
    map['sync_status'] = Variable<String>(syncStatus);
    map['id'] = Variable<String>(id);
    map['display_name'] = Variable<String>(displayName);
    if (!nullToAbsent || phone != null) {
      map['phone'] = Variable<String>(phone);
    }
    map['default_mother_amount_paisa'] =
        Variable<int>(defaultMotherAmountPaisa);
    map['number_style'] = Variable<String>(numberStyle);
    map['theme_mode'] = Variable<String>(themeMode);
    map['daily_closing_time'] = Variable<String>(dailyClosingTime);
    return map;
  }

  ProfilesCompanion toCompanion(bool nullToAbsent) {
    return ProfilesCompanion(
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      deletedAt: deletedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(deletedAt),
      version: Value(version),
      syncStatus: Value(syncStatus),
      id: Value(id),
      displayName: Value(displayName),
      phone:
          phone == null && nullToAbsent ? const Value.absent() : Value(phone),
      defaultMotherAmountPaisa: Value(defaultMotherAmountPaisa),
      numberStyle: Value(numberStyle),
      themeMode: Value(themeMode),
      dailyClosingTime: Value(dailyClosingTime),
    );
  }

  factory Profile.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Profile(
      createdAt: serializer.fromJson<String>(json['createdAt']),
      updatedAt: serializer.fromJson<String>(json['updatedAt']),
      deletedAt: serializer.fromJson<String?>(json['deletedAt']),
      version: serializer.fromJson<int>(json['version']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      id: serializer.fromJson<String>(json['id']),
      displayName: serializer.fromJson<String>(json['displayName']),
      phone: serializer.fromJson<String?>(json['phone']),
      defaultMotherAmountPaisa:
          serializer.fromJson<int>(json['defaultMotherAmountPaisa']),
      numberStyle: serializer.fromJson<String>(json['numberStyle']),
      themeMode: serializer.fromJson<String>(json['themeMode']),
      dailyClosingTime: serializer.fromJson<String>(json['dailyClosingTime']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'createdAt': serializer.toJson<String>(createdAt),
      'updatedAt': serializer.toJson<String>(updatedAt),
      'deletedAt': serializer.toJson<String?>(deletedAt),
      'version': serializer.toJson<int>(version),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'id': serializer.toJson<String>(id),
      'displayName': serializer.toJson<String>(displayName),
      'phone': serializer.toJson<String?>(phone),
      'defaultMotherAmountPaisa':
          serializer.toJson<int>(defaultMotherAmountPaisa),
      'numberStyle': serializer.toJson<String>(numberStyle),
      'themeMode': serializer.toJson<String>(themeMode),
      'dailyClosingTime': serializer.toJson<String>(dailyClosingTime),
    };
  }

  Profile copyWith(
          {String? createdAt,
          String? updatedAt,
          Value<String?> deletedAt = const Value.absent(),
          int? version,
          String? syncStatus,
          String? id,
          String? displayName,
          Value<String?> phone = const Value.absent(),
          int? defaultMotherAmountPaisa,
          String? numberStyle,
          String? themeMode,
          String? dailyClosingTime}) =>
      Profile(
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: deletedAt.present ? deletedAt.value : this.deletedAt,
        version: version ?? this.version,
        syncStatus: syncStatus ?? this.syncStatus,
        id: id ?? this.id,
        displayName: displayName ?? this.displayName,
        phone: phone.present ? phone.value : this.phone,
        defaultMotherAmountPaisa:
            defaultMotherAmountPaisa ?? this.defaultMotherAmountPaisa,
        numberStyle: numberStyle ?? this.numberStyle,
        themeMode: themeMode ?? this.themeMode,
        dailyClosingTime: dailyClosingTime ?? this.dailyClosingTime,
      );
  Profile copyWithCompanion(ProfilesCompanion data) {
    return Profile(
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      deletedAt: data.deletedAt.present ? data.deletedAt.value : this.deletedAt,
      version: data.version.present ? data.version.value : this.version,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      id: data.id.present ? data.id.value : this.id,
      displayName:
          data.displayName.present ? data.displayName.value : this.displayName,
      phone: data.phone.present ? data.phone.value : this.phone,
      defaultMotherAmountPaisa: data.defaultMotherAmountPaisa.present
          ? data.defaultMotherAmountPaisa.value
          : this.defaultMotherAmountPaisa,
      numberStyle:
          data.numberStyle.present ? data.numberStyle.value : this.numberStyle,
      themeMode: data.themeMode.present ? data.themeMode.value : this.themeMode,
      dailyClosingTime: data.dailyClosingTime.present
          ? data.dailyClosingTime.value
          : this.dailyClosingTime,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Profile(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('displayName: $displayName, ')
          ..write('phone: $phone, ')
          ..write('defaultMotherAmountPaisa: $defaultMotherAmountPaisa, ')
          ..write('numberStyle: $numberStyle, ')
          ..write('themeMode: $themeMode, ')
          ..write('dailyClosingTime: $dailyClosingTime')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      createdAt,
      updatedAt,
      deletedAt,
      version,
      syncStatus,
      id,
      displayName,
      phone,
      defaultMotherAmountPaisa,
      numberStyle,
      themeMode,
      dailyClosingTime);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Profile &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.deletedAt == this.deletedAt &&
          other.version == this.version &&
          other.syncStatus == this.syncStatus &&
          other.id == this.id &&
          other.displayName == this.displayName &&
          other.phone == this.phone &&
          other.defaultMotherAmountPaisa == this.defaultMotherAmountPaisa &&
          other.numberStyle == this.numberStyle &&
          other.themeMode == this.themeMode &&
          other.dailyClosingTime == this.dailyClosingTime);
}

class ProfilesCompanion extends UpdateCompanion<Profile> {
  final Value<String> createdAt;
  final Value<String> updatedAt;
  final Value<String?> deletedAt;
  final Value<int> version;
  final Value<String> syncStatus;
  final Value<String> id;
  final Value<String> displayName;
  final Value<String?> phone;
  final Value<int> defaultMotherAmountPaisa;
  final Value<String> numberStyle;
  final Value<String> themeMode;
  final Value<String> dailyClosingTime;
  final Value<int> rowid;
  const ProfilesCompanion({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.id = const Value.absent(),
    this.displayName = const Value.absent(),
    this.phone = const Value.absent(),
    this.defaultMotherAmountPaisa = const Value.absent(),
    this.numberStyle = const Value.absent(),
    this.themeMode = const Value.absent(),
    this.dailyClosingTime = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  ProfilesCompanion.insert({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    required String id,
    this.displayName = const Value.absent(),
    this.phone = const Value.absent(),
    this.defaultMotherAmountPaisa = const Value.absent(),
    this.numberStyle = const Value.absent(),
    this.themeMode = const Value.absent(),
    this.dailyClosingTime = const Value.absent(),
    this.rowid = const Value.absent(),
  }) : id = Value(id);
  static Insertable<Profile> custom({
    Expression<String>? createdAt,
    Expression<String>? updatedAt,
    Expression<String>? deletedAt,
    Expression<int>? version,
    Expression<String>? syncStatus,
    Expression<String>? id,
    Expression<String>? displayName,
    Expression<String>? phone,
    Expression<int>? defaultMotherAmountPaisa,
    Expression<String>? numberStyle,
    Expression<String>? themeMode,
    Expression<String>? dailyClosingTime,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (deletedAt != null) 'deleted_at': deletedAt,
      if (version != null) 'version': version,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (id != null) 'id': id,
      if (displayName != null) 'display_name': displayName,
      if (phone != null) 'phone': phone,
      if (defaultMotherAmountPaisa != null)
        'default_mother_amount_paisa': defaultMotherAmountPaisa,
      if (numberStyle != null) 'number_style': numberStyle,
      if (themeMode != null) 'theme_mode': themeMode,
      if (dailyClosingTime != null) 'daily_closing_time': dailyClosingTime,
      if (rowid != null) 'rowid': rowid,
    });
  }

  ProfilesCompanion copyWith(
      {Value<String>? createdAt,
      Value<String>? updatedAt,
      Value<String?>? deletedAt,
      Value<int>? version,
      Value<String>? syncStatus,
      Value<String>? id,
      Value<String>? displayName,
      Value<String?>? phone,
      Value<int>? defaultMotherAmountPaisa,
      Value<String>? numberStyle,
      Value<String>? themeMode,
      Value<String>? dailyClosingTime,
      Value<int>? rowid}) {
    return ProfilesCompanion(
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      version: version ?? this.version,
      syncStatus: syncStatus ?? this.syncStatus,
      id: id ?? this.id,
      displayName: displayName ?? this.displayName,
      phone: phone ?? this.phone,
      defaultMotherAmountPaisa:
          defaultMotherAmountPaisa ?? this.defaultMotherAmountPaisa,
      numberStyle: numberStyle ?? this.numberStyle,
      themeMode: themeMode ?? this.themeMode,
      dailyClosingTime: dailyClosingTime ?? this.dailyClosingTime,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (createdAt.present) {
      map['created_at'] = Variable<String>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<String>(updatedAt.value);
    }
    if (deletedAt.present) {
      map['deleted_at'] = Variable<String>(deletedAt.value);
    }
    if (version.present) {
      map['version'] = Variable<int>(version.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (displayName.present) {
      map['display_name'] = Variable<String>(displayName.value);
    }
    if (phone.present) {
      map['phone'] = Variable<String>(phone.value);
    }
    if (defaultMotherAmountPaisa.present) {
      map['default_mother_amount_paisa'] =
          Variable<int>(defaultMotherAmountPaisa.value);
    }
    if (numberStyle.present) {
      map['number_style'] = Variable<String>(numberStyle.value);
    }
    if (themeMode.present) {
      map['theme_mode'] = Variable<String>(themeMode.value);
    }
    if (dailyClosingTime.present) {
      map['daily_closing_time'] = Variable<String>(dailyClosingTime.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProfilesCompanion(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('displayName: $displayName, ')
          ..write('phone: $phone, ')
          ..write('defaultMotherAmountPaisa: $defaultMotherAmountPaisa, ')
          ..write('numberStyle: $numberStyle, ')
          ..write('themeMode: $themeMode, ')
          ..write('dailyClosingTime: $dailyClosingTime, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $WalletsTable extends Wallets with TableInfo<$WalletsTable, Wallet> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $WalletsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<String> createdAt = GeneratedColumn<String>(
      'created_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<String> updatedAt = GeneratedColumn<String>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _deletedAtMeta =
      const VerificationMeta('deletedAt');
  @override
  late final GeneratedColumn<String> deletedAt = GeneratedColumn<String>(
      'deleted_at', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _versionMeta =
      const VerificationMeta('version');
  @override
  late final GeneratedColumn<int> version = GeneratedColumn<int>(
      'version', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('pending'));
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<String> userId = GeneratedColumn<String>(
      'user_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _typeMeta = const VerificationMeta('type');
  @override
  late final GeneratedColumn<String> type = GeneratedColumn<String>(
      'type', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('cash'));
  static const VerificationMeta _openingBalancePaisaMeta =
      const VerificationMeta('openingBalancePaisa');
  @override
  late final GeneratedColumn<int> openingBalancePaisa = GeneratedColumn<int>(
      'opening_balance_paisa', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _isArchivedMeta =
      const VerificationMeta('isArchived');
  @override
  late final GeneratedColumn<bool> isArchived = GeneratedColumn<bool>(
      'is_archived', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_archived" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns => [
        createdAt,
        updatedAt,
        deletedAt,
        version,
        syncStatus,
        id,
        userId,
        name,
        type,
        openingBalancePaisa,
        isArchived
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'wallets';
  @override
  VerificationContext validateIntegrity(Insertable<Wallet> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    if (data.containsKey('deleted_at')) {
      context.handle(_deletedAtMeta,
          deletedAt.isAcceptableOrUnknown(data['deleted_at']!, _deletedAtMeta));
    }
    if (data.containsKey('version')) {
      context.handle(_versionMeta,
          version.isAcceptableOrUnknown(data['version']!, _versionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('user_id')) {
      context.handle(_userIdMeta,
          userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta));
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    } else if (isInserting) {
      context.missing(_nameMeta);
    }
    if (data.containsKey('type')) {
      context.handle(
          _typeMeta, type.isAcceptableOrUnknown(data['type']!, _typeMeta));
    }
    if (data.containsKey('opening_balance_paisa')) {
      context.handle(
          _openingBalancePaisaMeta,
          openingBalancePaisa.isAcceptableOrUnknown(
              data['opening_balance_paisa']!, _openingBalancePaisaMeta));
    }
    if (data.containsKey('is_archived')) {
      context.handle(
          _isArchivedMeta,
          isArchived.isAcceptableOrUnknown(
              data['is_archived']!, _isArchivedMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Wallet map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Wallet(
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}updated_at'])!,
      deletedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}deleted_at']),
      version: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}version'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      userId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}user_id'])!,
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name'])!,
      type: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}type'])!,
      openingBalancePaisa: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}opening_balance_paisa'])!,
      isArchived: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_archived'])!,
    );
  }

  @override
  $WalletsTable createAlias(String alias) {
    return $WalletsTable(attachedDatabase, alias);
  }
}

class Wallet extends DataClass implements Insertable<Wallet> {
  final String createdAt;
  final String updatedAt;
  final String? deletedAt;
  final int version;
  final String syncStatus;
  final String id;
  final String userId;
  final String name;
  final String type;
  final int openingBalancePaisa;
  final bool isArchived;
  const Wallet(
      {required this.createdAt,
      required this.updatedAt,
      this.deletedAt,
      required this.version,
      required this.syncStatus,
      required this.id,
      required this.userId,
      required this.name,
      required this.type,
      required this.openingBalancePaisa,
      required this.isArchived});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['created_at'] = Variable<String>(createdAt);
    map['updated_at'] = Variable<String>(updatedAt);
    if (!nullToAbsent || deletedAt != null) {
      map['deleted_at'] = Variable<String>(deletedAt);
    }
    map['version'] = Variable<int>(version);
    map['sync_status'] = Variable<String>(syncStatus);
    map['id'] = Variable<String>(id);
    map['user_id'] = Variable<String>(userId);
    map['name'] = Variable<String>(name);
    map['type'] = Variable<String>(type);
    map['opening_balance_paisa'] = Variable<int>(openingBalancePaisa);
    map['is_archived'] = Variable<bool>(isArchived);
    return map;
  }

  WalletsCompanion toCompanion(bool nullToAbsent) {
    return WalletsCompanion(
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      deletedAt: deletedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(deletedAt),
      version: Value(version),
      syncStatus: Value(syncStatus),
      id: Value(id),
      userId: Value(userId),
      name: Value(name),
      type: Value(type),
      openingBalancePaisa: Value(openingBalancePaisa),
      isArchived: Value(isArchived),
    );
  }

  factory Wallet.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Wallet(
      createdAt: serializer.fromJson<String>(json['createdAt']),
      updatedAt: serializer.fromJson<String>(json['updatedAt']),
      deletedAt: serializer.fromJson<String?>(json['deletedAt']),
      version: serializer.fromJson<int>(json['version']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      id: serializer.fromJson<String>(json['id']),
      userId: serializer.fromJson<String>(json['userId']),
      name: serializer.fromJson<String>(json['name']),
      type: serializer.fromJson<String>(json['type']),
      openingBalancePaisa:
          serializer.fromJson<int>(json['openingBalancePaisa']),
      isArchived: serializer.fromJson<bool>(json['isArchived']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'createdAt': serializer.toJson<String>(createdAt),
      'updatedAt': serializer.toJson<String>(updatedAt),
      'deletedAt': serializer.toJson<String?>(deletedAt),
      'version': serializer.toJson<int>(version),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'id': serializer.toJson<String>(id),
      'userId': serializer.toJson<String>(userId),
      'name': serializer.toJson<String>(name),
      'type': serializer.toJson<String>(type),
      'openingBalancePaisa': serializer.toJson<int>(openingBalancePaisa),
      'isArchived': serializer.toJson<bool>(isArchived),
    };
  }

  Wallet copyWith(
          {String? createdAt,
          String? updatedAt,
          Value<String?> deletedAt = const Value.absent(),
          int? version,
          String? syncStatus,
          String? id,
          String? userId,
          String? name,
          String? type,
          int? openingBalancePaisa,
          bool? isArchived}) =>
      Wallet(
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: deletedAt.present ? deletedAt.value : this.deletedAt,
        version: version ?? this.version,
        syncStatus: syncStatus ?? this.syncStatus,
        id: id ?? this.id,
        userId: userId ?? this.userId,
        name: name ?? this.name,
        type: type ?? this.type,
        openingBalancePaisa: openingBalancePaisa ?? this.openingBalancePaisa,
        isArchived: isArchived ?? this.isArchived,
      );
  Wallet copyWithCompanion(WalletsCompanion data) {
    return Wallet(
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      deletedAt: data.deletedAt.present ? data.deletedAt.value : this.deletedAt,
      version: data.version.present ? data.version.value : this.version,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      id: data.id.present ? data.id.value : this.id,
      userId: data.userId.present ? data.userId.value : this.userId,
      name: data.name.present ? data.name.value : this.name,
      type: data.type.present ? data.type.value : this.type,
      openingBalancePaisa: data.openingBalancePaisa.present
          ? data.openingBalancePaisa.value
          : this.openingBalancePaisa,
      isArchived:
          data.isArchived.present ? data.isArchived.value : this.isArchived,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Wallet(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('name: $name, ')
          ..write('type: $type, ')
          ..write('openingBalancePaisa: $openingBalancePaisa, ')
          ..write('isArchived: $isArchived')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(createdAt, updatedAt, deletedAt, version,
      syncStatus, id, userId, name, type, openingBalancePaisa, isArchived);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Wallet &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.deletedAt == this.deletedAt &&
          other.version == this.version &&
          other.syncStatus == this.syncStatus &&
          other.id == this.id &&
          other.userId == this.userId &&
          other.name == this.name &&
          other.type == this.type &&
          other.openingBalancePaisa == this.openingBalancePaisa &&
          other.isArchived == this.isArchived);
}

class WalletsCompanion extends UpdateCompanion<Wallet> {
  final Value<String> createdAt;
  final Value<String> updatedAt;
  final Value<String?> deletedAt;
  final Value<int> version;
  final Value<String> syncStatus;
  final Value<String> id;
  final Value<String> userId;
  final Value<String> name;
  final Value<String> type;
  final Value<int> openingBalancePaisa;
  final Value<bool> isArchived;
  final Value<int> rowid;
  const WalletsCompanion({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.id = const Value.absent(),
    this.userId = const Value.absent(),
    this.name = const Value.absent(),
    this.type = const Value.absent(),
    this.openingBalancePaisa = const Value.absent(),
    this.isArchived = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  WalletsCompanion.insert({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    required String id,
    required String userId,
    required String name,
    this.type = const Value.absent(),
    this.openingBalancePaisa = const Value.absent(),
    this.isArchived = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        userId = Value(userId),
        name = Value(name);
  static Insertable<Wallet> custom({
    Expression<String>? createdAt,
    Expression<String>? updatedAt,
    Expression<String>? deletedAt,
    Expression<int>? version,
    Expression<String>? syncStatus,
    Expression<String>? id,
    Expression<String>? userId,
    Expression<String>? name,
    Expression<String>? type,
    Expression<int>? openingBalancePaisa,
    Expression<bool>? isArchived,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (deletedAt != null) 'deleted_at': deletedAt,
      if (version != null) 'version': version,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (id != null) 'id': id,
      if (userId != null) 'user_id': userId,
      if (name != null) 'name': name,
      if (type != null) 'type': type,
      if (openingBalancePaisa != null)
        'opening_balance_paisa': openingBalancePaisa,
      if (isArchived != null) 'is_archived': isArchived,
      if (rowid != null) 'rowid': rowid,
    });
  }

  WalletsCompanion copyWith(
      {Value<String>? createdAt,
      Value<String>? updatedAt,
      Value<String?>? deletedAt,
      Value<int>? version,
      Value<String>? syncStatus,
      Value<String>? id,
      Value<String>? userId,
      Value<String>? name,
      Value<String>? type,
      Value<int>? openingBalancePaisa,
      Value<bool>? isArchived,
      Value<int>? rowid}) {
    return WalletsCompanion(
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      version: version ?? this.version,
      syncStatus: syncStatus ?? this.syncStatus,
      id: id ?? this.id,
      userId: userId ?? this.userId,
      name: name ?? this.name,
      type: type ?? this.type,
      openingBalancePaisa: openingBalancePaisa ?? this.openingBalancePaisa,
      isArchived: isArchived ?? this.isArchived,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (createdAt.present) {
      map['created_at'] = Variable<String>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<String>(updatedAt.value);
    }
    if (deletedAt.present) {
      map['deleted_at'] = Variable<String>(deletedAt.value);
    }
    if (version.present) {
      map['version'] = Variable<int>(version.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<String>(userId.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (type.present) {
      map['type'] = Variable<String>(type.value);
    }
    if (openingBalancePaisa.present) {
      map['opening_balance_paisa'] = Variable<int>(openingBalancePaisa.value);
    }
    if (isArchived.present) {
      map['is_archived'] = Variable<bool>(isArchived.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('WalletsCompanion(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('name: $name, ')
          ..write('type: $type, ')
          ..write('openingBalancePaisa: $openingBalancePaisa, ')
          ..write('isArchived: $isArchived, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $HatsTable extends Hats with TableInfo<$HatsTable, Hat> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $HatsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<String> createdAt = GeneratedColumn<String>(
      'created_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<String> updatedAt = GeneratedColumn<String>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _deletedAtMeta =
      const VerificationMeta('deletedAt');
  @override
  late final GeneratedColumn<String> deletedAt = GeneratedColumn<String>(
      'deleted_at', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _versionMeta =
      const VerificationMeta('version');
  @override
  late final GeneratedColumn<int> version = GeneratedColumn<int>(
      'version', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('pending'));
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<String> userId = GeneratedColumn<String>(
      'user_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _locationMeta =
      const VerificationMeta('location');
  @override
  late final GeneratedColumn<String> location = GeneratedColumn<String>(
      'location', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _hatDaysMeta =
      const VerificationMeta('hatDays');
  @override
  late final GeneratedColumn<String> hatDays = GeneratedColumn<String>(
      'hat_days', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('[]'));
  static const VerificationMeta _colorHexMeta =
      const VerificationMeta('colorHex');
  @override
  late final GeneratedColumn<String> colorHex = GeneratedColumn<String>(
      'color_hex', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('#1B7A43'));
  static const VerificationMeta _iconMeta = const VerificationMeta('icon');
  @override
  late final GeneratedColumn<String> icon = GeneratedColumn<String>(
      'icon', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('storefront'));
  static const VerificationMeta _defaultOwnerNameMeta =
      const VerificationMeta('defaultOwnerName');
  @override
  late final GeneratedColumn<String> defaultOwnerName = GeneratedColumn<String>(
      'default_owner_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _isArchivedMeta =
      const VerificationMeta('isArchived');
  @override
  late final GeneratedColumn<bool> isArchived = GeneratedColumn<bool>(
      'is_archived', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_archived" IN (0, 1))'),
      defaultValue: const Constant(false));
  @override
  List<GeneratedColumn> get $columns => [
        createdAt,
        updatedAt,
        deletedAt,
        version,
        syncStatus,
        id,
        userId,
        name,
        location,
        hatDays,
        colorHex,
        icon,
        defaultOwnerName,
        isArchived
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'hats';
  @override
  VerificationContext validateIntegrity(Insertable<Hat> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    if (data.containsKey('deleted_at')) {
      context.handle(_deletedAtMeta,
          deletedAt.isAcceptableOrUnknown(data['deleted_at']!, _deletedAtMeta));
    }
    if (data.containsKey('version')) {
      context.handle(_versionMeta,
          version.isAcceptableOrUnknown(data['version']!, _versionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('user_id')) {
      context.handle(_userIdMeta,
          userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta));
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    } else if (isInserting) {
      context.missing(_nameMeta);
    }
    if (data.containsKey('location')) {
      context.handle(_locationMeta,
          location.isAcceptableOrUnknown(data['location']!, _locationMeta));
    }
    if (data.containsKey('hat_days')) {
      context.handle(_hatDaysMeta,
          hatDays.isAcceptableOrUnknown(data['hat_days']!, _hatDaysMeta));
    }
    if (data.containsKey('color_hex')) {
      context.handle(_colorHexMeta,
          colorHex.isAcceptableOrUnknown(data['color_hex']!, _colorHexMeta));
    }
    if (data.containsKey('icon')) {
      context.handle(
          _iconMeta, icon.isAcceptableOrUnknown(data['icon']!, _iconMeta));
    }
    if (data.containsKey('default_owner_name')) {
      context.handle(
          _defaultOwnerNameMeta,
          defaultOwnerName.isAcceptableOrUnknown(
              data['default_owner_name']!, _defaultOwnerNameMeta));
    }
    if (data.containsKey('is_archived')) {
      context.handle(
          _isArchivedMeta,
          isArchived.isAcceptableOrUnknown(
              data['is_archived']!, _isArchivedMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Hat map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Hat(
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}updated_at'])!,
      deletedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}deleted_at']),
      version: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}version'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      userId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}user_id'])!,
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name'])!,
      location: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}location']),
      hatDays: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}hat_days'])!,
      colorHex: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}color_hex'])!,
      icon: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}icon'])!,
      defaultOwnerName: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}default_owner_name']),
      isArchived: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_archived'])!,
    );
  }

  @override
  $HatsTable createAlias(String alias) {
    return $HatsTable(attachedDatabase, alias);
  }
}

class Hat extends DataClass implements Insertable<Hat> {
  final String createdAt;
  final String updatedAt;
  final String? deletedAt;
  final int version;
  final String syncStatus;
  final String id;
  final String userId;
  final String name;
  final String? location;
  final String hatDays;
  final String colorHex;
  final String icon;
  final String? defaultOwnerName;
  final bool isArchived;
  const Hat(
      {required this.createdAt,
      required this.updatedAt,
      this.deletedAt,
      required this.version,
      required this.syncStatus,
      required this.id,
      required this.userId,
      required this.name,
      this.location,
      required this.hatDays,
      required this.colorHex,
      required this.icon,
      this.defaultOwnerName,
      required this.isArchived});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['created_at'] = Variable<String>(createdAt);
    map['updated_at'] = Variable<String>(updatedAt);
    if (!nullToAbsent || deletedAt != null) {
      map['deleted_at'] = Variable<String>(deletedAt);
    }
    map['version'] = Variable<int>(version);
    map['sync_status'] = Variable<String>(syncStatus);
    map['id'] = Variable<String>(id);
    map['user_id'] = Variable<String>(userId);
    map['name'] = Variable<String>(name);
    if (!nullToAbsent || location != null) {
      map['location'] = Variable<String>(location);
    }
    map['hat_days'] = Variable<String>(hatDays);
    map['color_hex'] = Variable<String>(colorHex);
    map['icon'] = Variable<String>(icon);
    if (!nullToAbsent || defaultOwnerName != null) {
      map['default_owner_name'] = Variable<String>(defaultOwnerName);
    }
    map['is_archived'] = Variable<bool>(isArchived);
    return map;
  }

  HatsCompanion toCompanion(bool nullToAbsent) {
    return HatsCompanion(
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      deletedAt: deletedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(deletedAt),
      version: Value(version),
      syncStatus: Value(syncStatus),
      id: Value(id),
      userId: Value(userId),
      name: Value(name),
      location: location == null && nullToAbsent
          ? const Value.absent()
          : Value(location),
      hatDays: Value(hatDays),
      colorHex: Value(colorHex),
      icon: Value(icon),
      defaultOwnerName: defaultOwnerName == null && nullToAbsent
          ? const Value.absent()
          : Value(defaultOwnerName),
      isArchived: Value(isArchived),
    );
  }

  factory Hat.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Hat(
      createdAt: serializer.fromJson<String>(json['createdAt']),
      updatedAt: serializer.fromJson<String>(json['updatedAt']),
      deletedAt: serializer.fromJson<String?>(json['deletedAt']),
      version: serializer.fromJson<int>(json['version']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      id: serializer.fromJson<String>(json['id']),
      userId: serializer.fromJson<String>(json['userId']),
      name: serializer.fromJson<String>(json['name']),
      location: serializer.fromJson<String?>(json['location']),
      hatDays: serializer.fromJson<String>(json['hatDays']),
      colorHex: serializer.fromJson<String>(json['colorHex']),
      icon: serializer.fromJson<String>(json['icon']),
      defaultOwnerName: serializer.fromJson<String?>(json['defaultOwnerName']),
      isArchived: serializer.fromJson<bool>(json['isArchived']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'createdAt': serializer.toJson<String>(createdAt),
      'updatedAt': serializer.toJson<String>(updatedAt),
      'deletedAt': serializer.toJson<String?>(deletedAt),
      'version': serializer.toJson<int>(version),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'id': serializer.toJson<String>(id),
      'userId': serializer.toJson<String>(userId),
      'name': serializer.toJson<String>(name),
      'location': serializer.toJson<String?>(location),
      'hatDays': serializer.toJson<String>(hatDays),
      'colorHex': serializer.toJson<String>(colorHex),
      'icon': serializer.toJson<String>(icon),
      'defaultOwnerName': serializer.toJson<String?>(defaultOwnerName),
      'isArchived': serializer.toJson<bool>(isArchived),
    };
  }

  Hat copyWith(
          {String? createdAt,
          String? updatedAt,
          Value<String?> deletedAt = const Value.absent(),
          int? version,
          String? syncStatus,
          String? id,
          String? userId,
          String? name,
          Value<String?> location = const Value.absent(),
          String? hatDays,
          String? colorHex,
          String? icon,
          Value<String?> defaultOwnerName = const Value.absent(),
          bool? isArchived}) =>
      Hat(
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: deletedAt.present ? deletedAt.value : this.deletedAt,
        version: version ?? this.version,
        syncStatus: syncStatus ?? this.syncStatus,
        id: id ?? this.id,
        userId: userId ?? this.userId,
        name: name ?? this.name,
        location: location.present ? location.value : this.location,
        hatDays: hatDays ?? this.hatDays,
        colorHex: colorHex ?? this.colorHex,
        icon: icon ?? this.icon,
        defaultOwnerName: defaultOwnerName.present
            ? defaultOwnerName.value
            : this.defaultOwnerName,
        isArchived: isArchived ?? this.isArchived,
      );
  Hat copyWithCompanion(HatsCompanion data) {
    return Hat(
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      deletedAt: data.deletedAt.present ? data.deletedAt.value : this.deletedAt,
      version: data.version.present ? data.version.value : this.version,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      id: data.id.present ? data.id.value : this.id,
      userId: data.userId.present ? data.userId.value : this.userId,
      name: data.name.present ? data.name.value : this.name,
      location: data.location.present ? data.location.value : this.location,
      hatDays: data.hatDays.present ? data.hatDays.value : this.hatDays,
      colorHex: data.colorHex.present ? data.colorHex.value : this.colorHex,
      icon: data.icon.present ? data.icon.value : this.icon,
      defaultOwnerName: data.defaultOwnerName.present
          ? data.defaultOwnerName.value
          : this.defaultOwnerName,
      isArchived:
          data.isArchived.present ? data.isArchived.value : this.isArchived,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Hat(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('name: $name, ')
          ..write('location: $location, ')
          ..write('hatDays: $hatDays, ')
          ..write('colorHex: $colorHex, ')
          ..write('icon: $icon, ')
          ..write('defaultOwnerName: $defaultOwnerName, ')
          ..write('isArchived: $isArchived')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      createdAt,
      updatedAt,
      deletedAt,
      version,
      syncStatus,
      id,
      userId,
      name,
      location,
      hatDays,
      colorHex,
      icon,
      defaultOwnerName,
      isArchived);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Hat &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.deletedAt == this.deletedAt &&
          other.version == this.version &&
          other.syncStatus == this.syncStatus &&
          other.id == this.id &&
          other.userId == this.userId &&
          other.name == this.name &&
          other.location == this.location &&
          other.hatDays == this.hatDays &&
          other.colorHex == this.colorHex &&
          other.icon == this.icon &&
          other.defaultOwnerName == this.defaultOwnerName &&
          other.isArchived == this.isArchived);
}

class HatsCompanion extends UpdateCompanion<Hat> {
  final Value<String> createdAt;
  final Value<String> updatedAt;
  final Value<String?> deletedAt;
  final Value<int> version;
  final Value<String> syncStatus;
  final Value<String> id;
  final Value<String> userId;
  final Value<String> name;
  final Value<String?> location;
  final Value<String> hatDays;
  final Value<String> colorHex;
  final Value<String> icon;
  final Value<String?> defaultOwnerName;
  final Value<bool> isArchived;
  final Value<int> rowid;
  const HatsCompanion({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.id = const Value.absent(),
    this.userId = const Value.absent(),
    this.name = const Value.absent(),
    this.location = const Value.absent(),
    this.hatDays = const Value.absent(),
    this.colorHex = const Value.absent(),
    this.icon = const Value.absent(),
    this.defaultOwnerName = const Value.absent(),
    this.isArchived = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  HatsCompanion.insert({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    required String id,
    required String userId,
    required String name,
    this.location = const Value.absent(),
    this.hatDays = const Value.absent(),
    this.colorHex = const Value.absent(),
    this.icon = const Value.absent(),
    this.defaultOwnerName = const Value.absent(),
    this.isArchived = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        userId = Value(userId),
        name = Value(name);
  static Insertable<Hat> custom({
    Expression<String>? createdAt,
    Expression<String>? updatedAt,
    Expression<String>? deletedAt,
    Expression<int>? version,
    Expression<String>? syncStatus,
    Expression<String>? id,
    Expression<String>? userId,
    Expression<String>? name,
    Expression<String>? location,
    Expression<String>? hatDays,
    Expression<String>? colorHex,
    Expression<String>? icon,
    Expression<String>? defaultOwnerName,
    Expression<bool>? isArchived,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (deletedAt != null) 'deleted_at': deletedAt,
      if (version != null) 'version': version,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (id != null) 'id': id,
      if (userId != null) 'user_id': userId,
      if (name != null) 'name': name,
      if (location != null) 'location': location,
      if (hatDays != null) 'hat_days': hatDays,
      if (colorHex != null) 'color_hex': colorHex,
      if (icon != null) 'icon': icon,
      if (defaultOwnerName != null) 'default_owner_name': defaultOwnerName,
      if (isArchived != null) 'is_archived': isArchived,
      if (rowid != null) 'rowid': rowid,
    });
  }

  HatsCompanion copyWith(
      {Value<String>? createdAt,
      Value<String>? updatedAt,
      Value<String?>? deletedAt,
      Value<int>? version,
      Value<String>? syncStatus,
      Value<String>? id,
      Value<String>? userId,
      Value<String>? name,
      Value<String?>? location,
      Value<String>? hatDays,
      Value<String>? colorHex,
      Value<String>? icon,
      Value<String?>? defaultOwnerName,
      Value<bool>? isArchived,
      Value<int>? rowid}) {
    return HatsCompanion(
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      version: version ?? this.version,
      syncStatus: syncStatus ?? this.syncStatus,
      id: id ?? this.id,
      userId: userId ?? this.userId,
      name: name ?? this.name,
      location: location ?? this.location,
      hatDays: hatDays ?? this.hatDays,
      colorHex: colorHex ?? this.colorHex,
      icon: icon ?? this.icon,
      defaultOwnerName: defaultOwnerName ?? this.defaultOwnerName,
      isArchived: isArchived ?? this.isArchived,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (createdAt.present) {
      map['created_at'] = Variable<String>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<String>(updatedAt.value);
    }
    if (deletedAt.present) {
      map['deleted_at'] = Variable<String>(deletedAt.value);
    }
    if (version.present) {
      map['version'] = Variable<int>(version.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<String>(userId.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (location.present) {
      map['location'] = Variable<String>(location.value);
    }
    if (hatDays.present) {
      map['hat_days'] = Variable<String>(hatDays.value);
    }
    if (colorHex.present) {
      map['color_hex'] = Variable<String>(colorHex.value);
    }
    if (icon.present) {
      map['icon'] = Variable<String>(icon.value);
    }
    if (defaultOwnerName.present) {
      map['default_owner_name'] = Variable<String>(defaultOwnerName.value);
    }
    if (isArchived.present) {
      map['is_archived'] = Variable<bool>(isArchived.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('HatsCompanion(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('name: $name, ')
          ..write('location: $location, ')
          ..write('hatDays: $hatDays, ')
          ..write('colorHex: $colorHex, ')
          ..write('icon: $icon, ')
          ..write('defaultOwnerName: $defaultOwnerName, ')
          ..write('isArchived: $isArchived, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $HatSessionsTable extends HatSessions
    with TableInfo<$HatSessionsTable, HatSession> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $HatSessionsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<String> createdAt = GeneratedColumn<String>(
      'created_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<String> updatedAt = GeneratedColumn<String>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _deletedAtMeta =
      const VerificationMeta('deletedAt');
  @override
  late final GeneratedColumn<String> deletedAt = GeneratedColumn<String>(
      'deleted_at', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _versionMeta =
      const VerificationMeta('version');
  @override
  late final GeneratedColumn<int> version = GeneratedColumn<int>(
      'version', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('pending'));
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<String> userId = GeneratedColumn<String>(
      'user_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _hatIdMeta = const VerificationMeta('hatId');
  @override
  late final GeneratedColumn<String> hatId = GeneratedColumn<String>(
      'hat_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _txnDateMeta =
      const VerificationMeta('txnDate');
  @override
  late final GeneratedColumn<String> txnDate = GeneratedColumn<String>(
      'txn_date', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _ownerNameMeta =
      const VerificationMeta('ownerName');
  @override
  late final GeneratedColumn<String> ownerName = GeneratedColumn<String>(
      'owner_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _statusMeta = const VerificationMeta('status');
  @override
  late final GeneratedColumn<String> status = GeneratedColumn<String>(
      'status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('draft'));
  static const VerificationMeta _openingCashPaisaMeta =
      const VerificationMeta('openingCashPaisa');
  @override
  late final GeneratedColumn<int> openingCashPaisa = GeneratedColumn<int>(
      'opening_cash_paisa', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _ownerCashReceivedPaisaMeta =
      const VerificationMeta('ownerCashReceivedPaisa');
  @override
  late final GeneratedColumn<int> ownerCashReceivedPaisa = GeneratedColumn<int>(
      'owner_cash_received_paisa', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _wagePaisaMeta =
      const VerificationMeta('wagePaisa');
  @override
  late final GeneratedColumn<int> wagePaisa = GeneratedColumn<int>(
      'wage_paisa', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _chotaPaisaMeta =
      const VerificationMeta('chotaPaisa');
  @override
  late final GeneratedColumn<int> chotaPaisa = GeneratedColumn<int>(
      'chota_paisa', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _slipChargePaisaMeta =
      const VerificationMeta('slipChargePaisa');
  @override
  late final GeneratedColumn<int> slipChargePaisa = GeneratedColumn<int>(
      'slip_charge_paisa', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _memoChargePaisaMeta =
      const VerificationMeta('memoChargePaisa');
  @override
  late final GeneratedColumn<int> memoChargePaisa = GeneratedColumn<int>(
      'memo_charge_paisa', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _returnedToOwnerPaisaMeta =
      const VerificationMeta('returnedToOwnerPaisa');
  @override
  late final GeneratedColumn<int> returnedToOwnerPaisa = GeneratedColumn<int>(
      'returned_to_owner_paisa', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _countedCashPaisaMeta =
      const VerificationMeta('countedCashPaisa');
  @override
  late final GeneratedColumn<int> countedCashPaisa = GeneratedColumn<int>(
      'counted_cash_paisa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _expectedCashPaisaMeta =
      const VerificationMeta('expectedCashPaisa');
  @override
  late final GeneratedColumn<int> expectedCashPaisa = GeneratedColumn<int>(
      'expected_cash_paisa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _cashDifferencePaisaMeta =
      const VerificationMeta('cashDifferencePaisa');
  @override
  late final GeneratedColumn<int> cashDifferencePaisa = GeneratedColumn<int>(
      'cash_difference_paisa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _residualHolderMeta =
      const VerificationMeta('residualHolder');
  @override
  late final GeneratedColumn<String> residualHolder = GeneratedColumn<String>(
      'residual_holder', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _walletIdMeta =
      const VerificationMeta('walletId');
  @override
  late final GeneratedColumn<String> walletId = GeneratedColumn<String>(
      'wallet_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _noteMeta = const VerificationMeta('note');
  @override
  late final GeneratedColumn<String> note = GeneratedColumn<String>(
      'note', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _differenceNoteMeta =
      const VerificationMeta('differenceNote');
  @override
  late final GeneratedColumn<String> differenceNote = GeneratedColumn<String>(
      'difference_note', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        createdAt,
        updatedAt,
        deletedAt,
        version,
        syncStatus,
        id,
        userId,
        hatId,
        txnDate,
        ownerName,
        status,
        openingCashPaisa,
        ownerCashReceivedPaisa,
        wagePaisa,
        chotaPaisa,
        slipChargePaisa,
        memoChargePaisa,
        returnedToOwnerPaisa,
        countedCashPaisa,
        expectedCashPaisa,
        cashDifferencePaisa,
        residualHolder,
        walletId,
        note,
        differenceNote
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'hat_sessions';
  @override
  VerificationContext validateIntegrity(Insertable<HatSession> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    if (data.containsKey('deleted_at')) {
      context.handle(_deletedAtMeta,
          deletedAt.isAcceptableOrUnknown(data['deleted_at']!, _deletedAtMeta));
    }
    if (data.containsKey('version')) {
      context.handle(_versionMeta,
          version.isAcceptableOrUnknown(data['version']!, _versionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('user_id')) {
      context.handle(_userIdMeta,
          userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta));
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('hat_id')) {
      context.handle(
          _hatIdMeta, hatId.isAcceptableOrUnknown(data['hat_id']!, _hatIdMeta));
    } else if (isInserting) {
      context.missing(_hatIdMeta);
    }
    if (data.containsKey('txn_date')) {
      context.handle(_txnDateMeta,
          txnDate.isAcceptableOrUnknown(data['txn_date']!, _txnDateMeta));
    } else if (isInserting) {
      context.missing(_txnDateMeta);
    }
    if (data.containsKey('owner_name')) {
      context.handle(_ownerNameMeta,
          ownerName.isAcceptableOrUnknown(data['owner_name']!, _ownerNameMeta));
    }
    if (data.containsKey('status')) {
      context.handle(_statusMeta,
          status.isAcceptableOrUnknown(data['status']!, _statusMeta));
    }
    if (data.containsKey('opening_cash_paisa')) {
      context.handle(
          _openingCashPaisaMeta,
          openingCashPaisa.isAcceptableOrUnknown(
              data['opening_cash_paisa']!, _openingCashPaisaMeta));
    }
    if (data.containsKey('owner_cash_received_paisa')) {
      context.handle(
          _ownerCashReceivedPaisaMeta,
          ownerCashReceivedPaisa.isAcceptableOrUnknown(
              data['owner_cash_received_paisa']!, _ownerCashReceivedPaisaMeta));
    }
    if (data.containsKey('wage_paisa')) {
      context.handle(_wagePaisaMeta,
          wagePaisa.isAcceptableOrUnknown(data['wage_paisa']!, _wagePaisaMeta));
    }
    if (data.containsKey('chota_paisa')) {
      context.handle(
          _chotaPaisaMeta,
          chotaPaisa.isAcceptableOrUnknown(
              data['chota_paisa']!, _chotaPaisaMeta));
    }
    if (data.containsKey('slip_charge_paisa')) {
      context.handle(
          _slipChargePaisaMeta,
          slipChargePaisa.isAcceptableOrUnknown(
              data['slip_charge_paisa']!, _slipChargePaisaMeta));
    }
    if (data.containsKey('memo_charge_paisa')) {
      context.handle(
          _memoChargePaisaMeta,
          memoChargePaisa.isAcceptableOrUnknown(
              data['memo_charge_paisa']!, _memoChargePaisaMeta));
    }
    if (data.containsKey('returned_to_owner_paisa')) {
      context.handle(
          _returnedToOwnerPaisaMeta,
          returnedToOwnerPaisa.isAcceptableOrUnknown(
              data['returned_to_owner_paisa']!, _returnedToOwnerPaisaMeta));
    }
    if (data.containsKey('counted_cash_paisa')) {
      context.handle(
          _countedCashPaisaMeta,
          countedCashPaisa.isAcceptableOrUnknown(
              data['counted_cash_paisa']!, _countedCashPaisaMeta));
    }
    if (data.containsKey('expected_cash_paisa')) {
      context.handle(
          _expectedCashPaisaMeta,
          expectedCashPaisa.isAcceptableOrUnknown(
              data['expected_cash_paisa']!, _expectedCashPaisaMeta));
    }
    if (data.containsKey('cash_difference_paisa')) {
      context.handle(
          _cashDifferencePaisaMeta,
          cashDifferencePaisa.isAcceptableOrUnknown(
              data['cash_difference_paisa']!, _cashDifferencePaisaMeta));
    }
    if (data.containsKey('residual_holder')) {
      context.handle(
          _residualHolderMeta,
          residualHolder.isAcceptableOrUnknown(
              data['residual_holder']!, _residualHolderMeta));
    }
    if (data.containsKey('wallet_id')) {
      context.handle(_walletIdMeta,
          walletId.isAcceptableOrUnknown(data['wallet_id']!, _walletIdMeta));
    }
    if (data.containsKey('note')) {
      context.handle(
          _noteMeta, note.isAcceptableOrUnknown(data['note']!, _noteMeta));
    }
    if (data.containsKey('difference_note')) {
      context.handle(
          _differenceNoteMeta,
          differenceNote.isAcceptableOrUnknown(
              data['difference_note']!, _differenceNoteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  HatSession map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return HatSession(
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}updated_at'])!,
      deletedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}deleted_at']),
      version: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}version'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      userId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}user_id'])!,
      hatId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}hat_id'])!,
      txnDate: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}txn_date'])!,
      ownerName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}owner_name']),
      status: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}status'])!,
      openingCashPaisa: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}opening_cash_paisa'])!,
      ownerCashReceivedPaisa: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}owner_cash_received_paisa'])!,
      wagePaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}wage_paisa'])!,
      chotaPaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}chota_paisa'])!,
      slipChargePaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}slip_charge_paisa'])!,
      memoChargePaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}memo_charge_paisa'])!,
      returnedToOwnerPaisa: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}returned_to_owner_paisa'])!,
      countedCashPaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}counted_cash_paisa']),
      expectedCashPaisa: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}expected_cash_paisa']),
      cashDifferencePaisa: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}cash_difference_paisa']),
      residualHolder: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}residual_holder']),
      walletId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}wallet_id']),
      note: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}note']),
      differenceNote: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}difference_note']),
    );
  }

  @override
  $HatSessionsTable createAlias(String alias) {
    return $HatSessionsTable(attachedDatabase, alias);
  }
}

class HatSession extends DataClass implements Insertable<HatSession> {
  final String createdAt;
  final String updatedAt;
  final String? deletedAt;
  final int version;
  final String syncStatus;
  final String id;
  final String userId;
  final String hatId;
  final String txnDate;
  final String? ownerName;
  final String status;
  final int openingCashPaisa;
  final int ownerCashReceivedPaisa;
  final int wagePaisa;
  final int chotaPaisa;
  final int slipChargePaisa;
  final int memoChargePaisa;
  final int returnedToOwnerPaisa;
  final int? countedCashPaisa;
  final int? expectedCashPaisa;
  final int? cashDifferencePaisa;
  final String? residualHolder;
  final String? walletId;
  final String? note;
  final String? differenceNote;
  const HatSession(
      {required this.createdAt,
      required this.updatedAt,
      this.deletedAt,
      required this.version,
      required this.syncStatus,
      required this.id,
      required this.userId,
      required this.hatId,
      required this.txnDate,
      this.ownerName,
      required this.status,
      required this.openingCashPaisa,
      required this.ownerCashReceivedPaisa,
      required this.wagePaisa,
      required this.chotaPaisa,
      required this.slipChargePaisa,
      required this.memoChargePaisa,
      required this.returnedToOwnerPaisa,
      this.countedCashPaisa,
      this.expectedCashPaisa,
      this.cashDifferencePaisa,
      this.residualHolder,
      this.walletId,
      this.note,
      this.differenceNote});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['created_at'] = Variable<String>(createdAt);
    map['updated_at'] = Variable<String>(updatedAt);
    if (!nullToAbsent || deletedAt != null) {
      map['deleted_at'] = Variable<String>(deletedAt);
    }
    map['version'] = Variable<int>(version);
    map['sync_status'] = Variable<String>(syncStatus);
    map['id'] = Variable<String>(id);
    map['user_id'] = Variable<String>(userId);
    map['hat_id'] = Variable<String>(hatId);
    map['txn_date'] = Variable<String>(txnDate);
    if (!nullToAbsent || ownerName != null) {
      map['owner_name'] = Variable<String>(ownerName);
    }
    map['status'] = Variable<String>(status);
    map['opening_cash_paisa'] = Variable<int>(openingCashPaisa);
    map['owner_cash_received_paisa'] = Variable<int>(ownerCashReceivedPaisa);
    map['wage_paisa'] = Variable<int>(wagePaisa);
    map['chota_paisa'] = Variable<int>(chotaPaisa);
    map['slip_charge_paisa'] = Variable<int>(slipChargePaisa);
    map['memo_charge_paisa'] = Variable<int>(memoChargePaisa);
    map['returned_to_owner_paisa'] = Variable<int>(returnedToOwnerPaisa);
    if (!nullToAbsent || countedCashPaisa != null) {
      map['counted_cash_paisa'] = Variable<int>(countedCashPaisa);
    }
    if (!nullToAbsent || expectedCashPaisa != null) {
      map['expected_cash_paisa'] = Variable<int>(expectedCashPaisa);
    }
    if (!nullToAbsent || cashDifferencePaisa != null) {
      map['cash_difference_paisa'] = Variable<int>(cashDifferencePaisa);
    }
    if (!nullToAbsent || residualHolder != null) {
      map['residual_holder'] = Variable<String>(residualHolder);
    }
    if (!nullToAbsent || walletId != null) {
      map['wallet_id'] = Variable<String>(walletId);
    }
    if (!nullToAbsent || note != null) {
      map['note'] = Variable<String>(note);
    }
    if (!nullToAbsent || differenceNote != null) {
      map['difference_note'] = Variable<String>(differenceNote);
    }
    return map;
  }

  HatSessionsCompanion toCompanion(bool nullToAbsent) {
    return HatSessionsCompanion(
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      deletedAt: deletedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(deletedAt),
      version: Value(version),
      syncStatus: Value(syncStatus),
      id: Value(id),
      userId: Value(userId),
      hatId: Value(hatId),
      txnDate: Value(txnDate),
      ownerName: ownerName == null && nullToAbsent
          ? const Value.absent()
          : Value(ownerName),
      status: Value(status),
      openingCashPaisa: Value(openingCashPaisa),
      ownerCashReceivedPaisa: Value(ownerCashReceivedPaisa),
      wagePaisa: Value(wagePaisa),
      chotaPaisa: Value(chotaPaisa),
      slipChargePaisa: Value(slipChargePaisa),
      memoChargePaisa: Value(memoChargePaisa),
      returnedToOwnerPaisa: Value(returnedToOwnerPaisa),
      countedCashPaisa: countedCashPaisa == null && nullToAbsent
          ? const Value.absent()
          : Value(countedCashPaisa),
      expectedCashPaisa: expectedCashPaisa == null && nullToAbsent
          ? const Value.absent()
          : Value(expectedCashPaisa),
      cashDifferencePaisa: cashDifferencePaisa == null && nullToAbsent
          ? const Value.absent()
          : Value(cashDifferencePaisa),
      residualHolder: residualHolder == null && nullToAbsent
          ? const Value.absent()
          : Value(residualHolder),
      walletId: walletId == null && nullToAbsent
          ? const Value.absent()
          : Value(walletId),
      note: note == null && nullToAbsent ? const Value.absent() : Value(note),
      differenceNote: differenceNote == null && nullToAbsent
          ? const Value.absent()
          : Value(differenceNote),
    );
  }

  factory HatSession.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return HatSession(
      createdAt: serializer.fromJson<String>(json['createdAt']),
      updatedAt: serializer.fromJson<String>(json['updatedAt']),
      deletedAt: serializer.fromJson<String?>(json['deletedAt']),
      version: serializer.fromJson<int>(json['version']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      id: serializer.fromJson<String>(json['id']),
      userId: serializer.fromJson<String>(json['userId']),
      hatId: serializer.fromJson<String>(json['hatId']),
      txnDate: serializer.fromJson<String>(json['txnDate']),
      ownerName: serializer.fromJson<String?>(json['ownerName']),
      status: serializer.fromJson<String>(json['status']),
      openingCashPaisa: serializer.fromJson<int>(json['openingCashPaisa']),
      ownerCashReceivedPaisa:
          serializer.fromJson<int>(json['ownerCashReceivedPaisa']),
      wagePaisa: serializer.fromJson<int>(json['wagePaisa']),
      chotaPaisa: serializer.fromJson<int>(json['chotaPaisa']),
      slipChargePaisa: serializer.fromJson<int>(json['slipChargePaisa']),
      memoChargePaisa: serializer.fromJson<int>(json['memoChargePaisa']),
      returnedToOwnerPaisa:
          serializer.fromJson<int>(json['returnedToOwnerPaisa']),
      countedCashPaisa: serializer.fromJson<int?>(json['countedCashPaisa']),
      expectedCashPaisa: serializer.fromJson<int?>(json['expectedCashPaisa']),
      cashDifferencePaisa:
          serializer.fromJson<int?>(json['cashDifferencePaisa']),
      residualHolder: serializer.fromJson<String?>(json['residualHolder']),
      walletId: serializer.fromJson<String?>(json['walletId']),
      note: serializer.fromJson<String?>(json['note']),
      differenceNote: serializer.fromJson<String?>(json['differenceNote']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'createdAt': serializer.toJson<String>(createdAt),
      'updatedAt': serializer.toJson<String>(updatedAt),
      'deletedAt': serializer.toJson<String?>(deletedAt),
      'version': serializer.toJson<int>(version),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'id': serializer.toJson<String>(id),
      'userId': serializer.toJson<String>(userId),
      'hatId': serializer.toJson<String>(hatId),
      'txnDate': serializer.toJson<String>(txnDate),
      'ownerName': serializer.toJson<String?>(ownerName),
      'status': serializer.toJson<String>(status),
      'openingCashPaisa': serializer.toJson<int>(openingCashPaisa),
      'ownerCashReceivedPaisa': serializer.toJson<int>(ownerCashReceivedPaisa),
      'wagePaisa': serializer.toJson<int>(wagePaisa),
      'chotaPaisa': serializer.toJson<int>(chotaPaisa),
      'slipChargePaisa': serializer.toJson<int>(slipChargePaisa),
      'memoChargePaisa': serializer.toJson<int>(memoChargePaisa),
      'returnedToOwnerPaisa': serializer.toJson<int>(returnedToOwnerPaisa),
      'countedCashPaisa': serializer.toJson<int?>(countedCashPaisa),
      'expectedCashPaisa': serializer.toJson<int?>(expectedCashPaisa),
      'cashDifferencePaisa': serializer.toJson<int?>(cashDifferencePaisa),
      'residualHolder': serializer.toJson<String?>(residualHolder),
      'walletId': serializer.toJson<String?>(walletId),
      'note': serializer.toJson<String?>(note),
      'differenceNote': serializer.toJson<String?>(differenceNote),
    };
  }

  HatSession copyWith(
          {String? createdAt,
          String? updatedAt,
          Value<String?> deletedAt = const Value.absent(),
          int? version,
          String? syncStatus,
          String? id,
          String? userId,
          String? hatId,
          String? txnDate,
          Value<String?> ownerName = const Value.absent(),
          String? status,
          int? openingCashPaisa,
          int? ownerCashReceivedPaisa,
          int? wagePaisa,
          int? chotaPaisa,
          int? slipChargePaisa,
          int? memoChargePaisa,
          int? returnedToOwnerPaisa,
          Value<int?> countedCashPaisa = const Value.absent(),
          Value<int?> expectedCashPaisa = const Value.absent(),
          Value<int?> cashDifferencePaisa = const Value.absent(),
          Value<String?> residualHolder = const Value.absent(),
          Value<String?> walletId = const Value.absent(),
          Value<String?> note = const Value.absent(),
          Value<String?> differenceNote = const Value.absent()}) =>
      HatSession(
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: deletedAt.present ? deletedAt.value : this.deletedAt,
        version: version ?? this.version,
        syncStatus: syncStatus ?? this.syncStatus,
        id: id ?? this.id,
        userId: userId ?? this.userId,
        hatId: hatId ?? this.hatId,
        txnDate: txnDate ?? this.txnDate,
        ownerName: ownerName.present ? ownerName.value : this.ownerName,
        status: status ?? this.status,
        openingCashPaisa: openingCashPaisa ?? this.openingCashPaisa,
        ownerCashReceivedPaisa:
            ownerCashReceivedPaisa ?? this.ownerCashReceivedPaisa,
        wagePaisa: wagePaisa ?? this.wagePaisa,
        chotaPaisa: chotaPaisa ?? this.chotaPaisa,
        slipChargePaisa: slipChargePaisa ?? this.slipChargePaisa,
        memoChargePaisa: memoChargePaisa ?? this.memoChargePaisa,
        returnedToOwnerPaisa: returnedToOwnerPaisa ?? this.returnedToOwnerPaisa,
        countedCashPaisa: countedCashPaisa.present
            ? countedCashPaisa.value
            : this.countedCashPaisa,
        expectedCashPaisa: expectedCashPaisa.present
            ? expectedCashPaisa.value
            : this.expectedCashPaisa,
        cashDifferencePaisa: cashDifferencePaisa.present
            ? cashDifferencePaisa.value
            : this.cashDifferencePaisa,
        residualHolder:
            residualHolder.present ? residualHolder.value : this.residualHolder,
        walletId: walletId.present ? walletId.value : this.walletId,
        note: note.present ? note.value : this.note,
        differenceNote:
            differenceNote.present ? differenceNote.value : this.differenceNote,
      );
  HatSession copyWithCompanion(HatSessionsCompanion data) {
    return HatSession(
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      deletedAt: data.deletedAt.present ? data.deletedAt.value : this.deletedAt,
      version: data.version.present ? data.version.value : this.version,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      id: data.id.present ? data.id.value : this.id,
      userId: data.userId.present ? data.userId.value : this.userId,
      hatId: data.hatId.present ? data.hatId.value : this.hatId,
      txnDate: data.txnDate.present ? data.txnDate.value : this.txnDate,
      ownerName: data.ownerName.present ? data.ownerName.value : this.ownerName,
      status: data.status.present ? data.status.value : this.status,
      openingCashPaisa: data.openingCashPaisa.present
          ? data.openingCashPaisa.value
          : this.openingCashPaisa,
      ownerCashReceivedPaisa: data.ownerCashReceivedPaisa.present
          ? data.ownerCashReceivedPaisa.value
          : this.ownerCashReceivedPaisa,
      wagePaisa: data.wagePaisa.present ? data.wagePaisa.value : this.wagePaisa,
      chotaPaisa:
          data.chotaPaisa.present ? data.chotaPaisa.value : this.chotaPaisa,
      slipChargePaisa: data.slipChargePaisa.present
          ? data.slipChargePaisa.value
          : this.slipChargePaisa,
      memoChargePaisa: data.memoChargePaisa.present
          ? data.memoChargePaisa.value
          : this.memoChargePaisa,
      returnedToOwnerPaisa: data.returnedToOwnerPaisa.present
          ? data.returnedToOwnerPaisa.value
          : this.returnedToOwnerPaisa,
      countedCashPaisa: data.countedCashPaisa.present
          ? data.countedCashPaisa.value
          : this.countedCashPaisa,
      expectedCashPaisa: data.expectedCashPaisa.present
          ? data.expectedCashPaisa.value
          : this.expectedCashPaisa,
      cashDifferencePaisa: data.cashDifferencePaisa.present
          ? data.cashDifferencePaisa.value
          : this.cashDifferencePaisa,
      residualHolder: data.residualHolder.present
          ? data.residualHolder.value
          : this.residualHolder,
      walletId: data.walletId.present ? data.walletId.value : this.walletId,
      note: data.note.present ? data.note.value : this.note,
      differenceNote: data.differenceNote.present
          ? data.differenceNote.value
          : this.differenceNote,
    );
  }

  @override
  String toString() {
    return (StringBuffer('HatSession(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('hatId: $hatId, ')
          ..write('txnDate: $txnDate, ')
          ..write('ownerName: $ownerName, ')
          ..write('status: $status, ')
          ..write('openingCashPaisa: $openingCashPaisa, ')
          ..write('ownerCashReceivedPaisa: $ownerCashReceivedPaisa, ')
          ..write('wagePaisa: $wagePaisa, ')
          ..write('chotaPaisa: $chotaPaisa, ')
          ..write('slipChargePaisa: $slipChargePaisa, ')
          ..write('memoChargePaisa: $memoChargePaisa, ')
          ..write('returnedToOwnerPaisa: $returnedToOwnerPaisa, ')
          ..write('countedCashPaisa: $countedCashPaisa, ')
          ..write('expectedCashPaisa: $expectedCashPaisa, ')
          ..write('cashDifferencePaisa: $cashDifferencePaisa, ')
          ..write('residualHolder: $residualHolder, ')
          ..write('walletId: $walletId, ')
          ..write('note: $note, ')
          ..write('differenceNote: $differenceNote')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        createdAt,
        updatedAt,
        deletedAt,
        version,
        syncStatus,
        id,
        userId,
        hatId,
        txnDate,
        ownerName,
        status,
        openingCashPaisa,
        ownerCashReceivedPaisa,
        wagePaisa,
        chotaPaisa,
        slipChargePaisa,
        memoChargePaisa,
        returnedToOwnerPaisa,
        countedCashPaisa,
        expectedCashPaisa,
        cashDifferencePaisa,
        residualHolder,
        walletId,
        note,
        differenceNote
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is HatSession &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.deletedAt == this.deletedAt &&
          other.version == this.version &&
          other.syncStatus == this.syncStatus &&
          other.id == this.id &&
          other.userId == this.userId &&
          other.hatId == this.hatId &&
          other.txnDate == this.txnDate &&
          other.ownerName == this.ownerName &&
          other.status == this.status &&
          other.openingCashPaisa == this.openingCashPaisa &&
          other.ownerCashReceivedPaisa == this.ownerCashReceivedPaisa &&
          other.wagePaisa == this.wagePaisa &&
          other.chotaPaisa == this.chotaPaisa &&
          other.slipChargePaisa == this.slipChargePaisa &&
          other.memoChargePaisa == this.memoChargePaisa &&
          other.returnedToOwnerPaisa == this.returnedToOwnerPaisa &&
          other.countedCashPaisa == this.countedCashPaisa &&
          other.expectedCashPaisa == this.expectedCashPaisa &&
          other.cashDifferencePaisa == this.cashDifferencePaisa &&
          other.residualHolder == this.residualHolder &&
          other.walletId == this.walletId &&
          other.note == this.note &&
          other.differenceNote == this.differenceNote);
}

class HatSessionsCompanion extends UpdateCompanion<HatSession> {
  final Value<String> createdAt;
  final Value<String> updatedAt;
  final Value<String?> deletedAt;
  final Value<int> version;
  final Value<String> syncStatus;
  final Value<String> id;
  final Value<String> userId;
  final Value<String> hatId;
  final Value<String> txnDate;
  final Value<String?> ownerName;
  final Value<String> status;
  final Value<int> openingCashPaisa;
  final Value<int> ownerCashReceivedPaisa;
  final Value<int> wagePaisa;
  final Value<int> chotaPaisa;
  final Value<int> slipChargePaisa;
  final Value<int> memoChargePaisa;
  final Value<int> returnedToOwnerPaisa;
  final Value<int?> countedCashPaisa;
  final Value<int?> expectedCashPaisa;
  final Value<int?> cashDifferencePaisa;
  final Value<String?> residualHolder;
  final Value<String?> walletId;
  final Value<String?> note;
  final Value<String?> differenceNote;
  final Value<int> rowid;
  const HatSessionsCompanion({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.id = const Value.absent(),
    this.userId = const Value.absent(),
    this.hatId = const Value.absent(),
    this.txnDate = const Value.absent(),
    this.ownerName = const Value.absent(),
    this.status = const Value.absent(),
    this.openingCashPaisa = const Value.absent(),
    this.ownerCashReceivedPaisa = const Value.absent(),
    this.wagePaisa = const Value.absent(),
    this.chotaPaisa = const Value.absent(),
    this.slipChargePaisa = const Value.absent(),
    this.memoChargePaisa = const Value.absent(),
    this.returnedToOwnerPaisa = const Value.absent(),
    this.countedCashPaisa = const Value.absent(),
    this.expectedCashPaisa = const Value.absent(),
    this.cashDifferencePaisa = const Value.absent(),
    this.residualHolder = const Value.absent(),
    this.walletId = const Value.absent(),
    this.note = const Value.absent(),
    this.differenceNote = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  HatSessionsCompanion.insert({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    required String id,
    required String userId,
    required String hatId,
    required String txnDate,
    this.ownerName = const Value.absent(),
    this.status = const Value.absent(),
    this.openingCashPaisa = const Value.absent(),
    this.ownerCashReceivedPaisa = const Value.absent(),
    this.wagePaisa = const Value.absent(),
    this.chotaPaisa = const Value.absent(),
    this.slipChargePaisa = const Value.absent(),
    this.memoChargePaisa = const Value.absent(),
    this.returnedToOwnerPaisa = const Value.absent(),
    this.countedCashPaisa = const Value.absent(),
    this.expectedCashPaisa = const Value.absent(),
    this.cashDifferencePaisa = const Value.absent(),
    this.residualHolder = const Value.absent(),
    this.walletId = const Value.absent(),
    this.note = const Value.absent(),
    this.differenceNote = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        userId = Value(userId),
        hatId = Value(hatId),
        txnDate = Value(txnDate);
  static Insertable<HatSession> custom({
    Expression<String>? createdAt,
    Expression<String>? updatedAt,
    Expression<String>? deletedAt,
    Expression<int>? version,
    Expression<String>? syncStatus,
    Expression<String>? id,
    Expression<String>? userId,
    Expression<String>? hatId,
    Expression<String>? txnDate,
    Expression<String>? ownerName,
    Expression<String>? status,
    Expression<int>? openingCashPaisa,
    Expression<int>? ownerCashReceivedPaisa,
    Expression<int>? wagePaisa,
    Expression<int>? chotaPaisa,
    Expression<int>? slipChargePaisa,
    Expression<int>? memoChargePaisa,
    Expression<int>? returnedToOwnerPaisa,
    Expression<int>? countedCashPaisa,
    Expression<int>? expectedCashPaisa,
    Expression<int>? cashDifferencePaisa,
    Expression<String>? residualHolder,
    Expression<String>? walletId,
    Expression<String>? note,
    Expression<String>? differenceNote,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (deletedAt != null) 'deleted_at': deletedAt,
      if (version != null) 'version': version,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (id != null) 'id': id,
      if (userId != null) 'user_id': userId,
      if (hatId != null) 'hat_id': hatId,
      if (txnDate != null) 'txn_date': txnDate,
      if (ownerName != null) 'owner_name': ownerName,
      if (status != null) 'status': status,
      if (openingCashPaisa != null) 'opening_cash_paisa': openingCashPaisa,
      if (ownerCashReceivedPaisa != null)
        'owner_cash_received_paisa': ownerCashReceivedPaisa,
      if (wagePaisa != null) 'wage_paisa': wagePaisa,
      if (chotaPaisa != null) 'chota_paisa': chotaPaisa,
      if (slipChargePaisa != null) 'slip_charge_paisa': slipChargePaisa,
      if (memoChargePaisa != null) 'memo_charge_paisa': memoChargePaisa,
      if (returnedToOwnerPaisa != null)
        'returned_to_owner_paisa': returnedToOwnerPaisa,
      if (countedCashPaisa != null) 'counted_cash_paisa': countedCashPaisa,
      if (expectedCashPaisa != null) 'expected_cash_paisa': expectedCashPaisa,
      if (cashDifferencePaisa != null)
        'cash_difference_paisa': cashDifferencePaisa,
      if (residualHolder != null) 'residual_holder': residualHolder,
      if (walletId != null) 'wallet_id': walletId,
      if (note != null) 'note': note,
      if (differenceNote != null) 'difference_note': differenceNote,
      if (rowid != null) 'rowid': rowid,
    });
  }

  HatSessionsCompanion copyWith(
      {Value<String>? createdAt,
      Value<String>? updatedAt,
      Value<String?>? deletedAt,
      Value<int>? version,
      Value<String>? syncStatus,
      Value<String>? id,
      Value<String>? userId,
      Value<String>? hatId,
      Value<String>? txnDate,
      Value<String?>? ownerName,
      Value<String>? status,
      Value<int>? openingCashPaisa,
      Value<int>? ownerCashReceivedPaisa,
      Value<int>? wagePaisa,
      Value<int>? chotaPaisa,
      Value<int>? slipChargePaisa,
      Value<int>? memoChargePaisa,
      Value<int>? returnedToOwnerPaisa,
      Value<int?>? countedCashPaisa,
      Value<int?>? expectedCashPaisa,
      Value<int?>? cashDifferencePaisa,
      Value<String?>? residualHolder,
      Value<String?>? walletId,
      Value<String?>? note,
      Value<String?>? differenceNote,
      Value<int>? rowid}) {
    return HatSessionsCompanion(
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      version: version ?? this.version,
      syncStatus: syncStatus ?? this.syncStatus,
      id: id ?? this.id,
      userId: userId ?? this.userId,
      hatId: hatId ?? this.hatId,
      txnDate: txnDate ?? this.txnDate,
      ownerName: ownerName ?? this.ownerName,
      status: status ?? this.status,
      openingCashPaisa: openingCashPaisa ?? this.openingCashPaisa,
      ownerCashReceivedPaisa:
          ownerCashReceivedPaisa ?? this.ownerCashReceivedPaisa,
      wagePaisa: wagePaisa ?? this.wagePaisa,
      chotaPaisa: chotaPaisa ?? this.chotaPaisa,
      slipChargePaisa: slipChargePaisa ?? this.slipChargePaisa,
      memoChargePaisa: memoChargePaisa ?? this.memoChargePaisa,
      returnedToOwnerPaisa: returnedToOwnerPaisa ?? this.returnedToOwnerPaisa,
      countedCashPaisa: countedCashPaisa ?? this.countedCashPaisa,
      expectedCashPaisa: expectedCashPaisa ?? this.expectedCashPaisa,
      cashDifferencePaisa: cashDifferencePaisa ?? this.cashDifferencePaisa,
      residualHolder: residualHolder ?? this.residualHolder,
      walletId: walletId ?? this.walletId,
      note: note ?? this.note,
      differenceNote: differenceNote ?? this.differenceNote,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (createdAt.present) {
      map['created_at'] = Variable<String>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<String>(updatedAt.value);
    }
    if (deletedAt.present) {
      map['deleted_at'] = Variable<String>(deletedAt.value);
    }
    if (version.present) {
      map['version'] = Variable<int>(version.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<String>(userId.value);
    }
    if (hatId.present) {
      map['hat_id'] = Variable<String>(hatId.value);
    }
    if (txnDate.present) {
      map['txn_date'] = Variable<String>(txnDate.value);
    }
    if (ownerName.present) {
      map['owner_name'] = Variable<String>(ownerName.value);
    }
    if (status.present) {
      map['status'] = Variable<String>(status.value);
    }
    if (openingCashPaisa.present) {
      map['opening_cash_paisa'] = Variable<int>(openingCashPaisa.value);
    }
    if (ownerCashReceivedPaisa.present) {
      map['owner_cash_received_paisa'] =
          Variable<int>(ownerCashReceivedPaisa.value);
    }
    if (wagePaisa.present) {
      map['wage_paisa'] = Variable<int>(wagePaisa.value);
    }
    if (chotaPaisa.present) {
      map['chota_paisa'] = Variable<int>(chotaPaisa.value);
    }
    if (slipChargePaisa.present) {
      map['slip_charge_paisa'] = Variable<int>(slipChargePaisa.value);
    }
    if (memoChargePaisa.present) {
      map['memo_charge_paisa'] = Variable<int>(memoChargePaisa.value);
    }
    if (returnedToOwnerPaisa.present) {
      map['returned_to_owner_paisa'] =
          Variable<int>(returnedToOwnerPaisa.value);
    }
    if (countedCashPaisa.present) {
      map['counted_cash_paisa'] = Variable<int>(countedCashPaisa.value);
    }
    if (expectedCashPaisa.present) {
      map['expected_cash_paisa'] = Variable<int>(expectedCashPaisa.value);
    }
    if (cashDifferencePaisa.present) {
      map['cash_difference_paisa'] = Variable<int>(cashDifferencePaisa.value);
    }
    if (residualHolder.present) {
      map['residual_holder'] = Variable<String>(residualHolder.value);
    }
    if (walletId.present) {
      map['wallet_id'] = Variable<String>(walletId.value);
    }
    if (note.present) {
      map['note'] = Variable<String>(note.value);
    }
    if (differenceNote.present) {
      map['difference_note'] = Variable<String>(differenceNote.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('HatSessionsCompanion(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('hatId: $hatId, ')
          ..write('txnDate: $txnDate, ')
          ..write('ownerName: $ownerName, ')
          ..write('status: $status, ')
          ..write('openingCashPaisa: $openingCashPaisa, ')
          ..write('ownerCashReceivedPaisa: $ownerCashReceivedPaisa, ')
          ..write('wagePaisa: $wagePaisa, ')
          ..write('chotaPaisa: $chotaPaisa, ')
          ..write('slipChargePaisa: $slipChargePaisa, ')
          ..write('memoChargePaisa: $memoChargePaisa, ')
          ..write('returnedToOwnerPaisa: $returnedToOwnerPaisa, ')
          ..write('countedCashPaisa: $countedCashPaisa, ')
          ..write('expectedCashPaisa: $expectedCashPaisa, ')
          ..write('cashDifferencePaisa: $cashDifferencePaisa, ')
          ..write('residualHolder: $residualHolder, ')
          ..write('walletId: $walletId, ')
          ..write('note: $note, ')
          ..write('differenceNote: $differenceNote, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $HatPurchaseItemsTable extends HatPurchaseItems
    with TableInfo<$HatPurchaseItemsTable, HatPurchaseItem> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $HatPurchaseItemsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<String> createdAt = GeneratedColumn<String>(
      'created_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<String> updatedAt = GeneratedColumn<String>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _deletedAtMeta =
      const VerificationMeta('deletedAt');
  @override
  late final GeneratedColumn<String> deletedAt = GeneratedColumn<String>(
      'deleted_at', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _versionMeta =
      const VerificationMeta('version');
  @override
  late final GeneratedColumn<int> version = GeneratedColumn<int>(
      'version', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('pending'));
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<String> userId = GeneratedColumn<String>(
      'user_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _sessionIdMeta =
      const VerificationMeta('sessionId');
  @override
  late final GeneratedColumn<String> sessionId = GeneratedColumn<String>(
      'session_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _productNameMeta =
      const VerificationMeta('productName');
  @override
  late final GeneratedColumn<String> productName = GeneratedColumn<String>(
      'product_name', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('পেঁয়াজ'));
  static const VerificationMeta _kgMeta = const VerificationMeta('kg');
  @override
  late final GeneratedColumn<double> kg = GeneratedColumn<double>(
      'kg', aliasedName, false,
      type: DriftSqlType.double, requiredDuringInsert: true);
  static const VerificationMeta _grossKgMeta =
      const VerificationMeta('grossKg');
  @override
  late final GeneratedColumn<double> grossKg = GeneratedColumn<double>(
      'gross_kg', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _deductionKgMeta =
      const VerificationMeta('deductionKg');
  @override
  late final GeneratedColumn<double> deductionKg = GeneratedColumn<double>(
      'deduction_kg', aliasedName, false,
      type: DriftSqlType.double,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _ratePaisaPerKgMeta =
      const VerificationMeta('ratePaisaPerKg');
  @override
  late final GeneratedColumn<int> ratePaisaPerKg = GeneratedColumn<int>(
      'rate_paisa_per_kg', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _ratePaisaPerMaundMeta =
      const VerificationMeta('ratePaisaPerMaund');
  @override
  late final GeneratedColumn<int> ratePaisaPerMaund = GeneratedColumn<int>(
      'rate_paisa_per_maund', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _totalPaisaMeta =
      const VerificationMeta('totalPaisa');
  @override
  late final GeneratedColumn<int> totalPaisa = GeneratedColumn<int>(
      'total_paisa', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _sellerNameMeta =
      const VerificationMeta('sellerName');
  @override
  late final GeneratedColumn<String> sellerName = GeneratedColumn<String>(
      'seller_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _paidPaisaMeta =
      const VerificationMeta('paidPaisa');
  @override
  late final GeneratedColumn<int> paidPaisa = GeneratedColumn<int>(
      'paid_paisa', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _noteMeta = const VerificationMeta('note');
  @override
  late final GeneratedColumn<String> note = GeneratedColumn<String>(
      'note', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        createdAt,
        updatedAt,
        deletedAt,
        version,
        syncStatus,
        id,
        userId,
        sessionId,
        productName,
        kg,
        grossKg,
        deductionKg,
        ratePaisaPerKg,
        ratePaisaPerMaund,
        totalPaisa,
        sellerName,
        paidPaisa,
        note
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'hat_purchase_items';
  @override
  VerificationContext validateIntegrity(Insertable<HatPurchaseItem> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    if (data.containsKey('deleted_at')) {
      context.handle(_deletedAtMeta,
          deletedAt.isAcceptableOrUnknown(data['deleted_at']!, _deletedAtMeta));
    }
    if (data.containsKey('version')) {
      context.handle(_versionMeta,
          version.isAcceptableOrUnknown(data['version']!, _versionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('user_id')) {
      context.handle(_userIdMeta,
          userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta));
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('session_id')) {
      context.handle(_sessionIdMeta,
          sessionId.isAcceptableOrUnknown(data['session_id']!, _sessionIdMeta));
    } else if (isInserting) {
      context.missing(_sessionIdMeta);
    }
    if (data.containsKey('product_name')) {
      context.handle(
          _productNameMeta,
          productName.isAcceptableOrUnknown(
              data['product_name']!, _productNameMeta));
    }
    if (data.containsKey('kg')) {
      context.handle(_kgMeta, kg.isAcceptableOrUnknown(data['kg']!, _kgMeta));
    } else if (isInserting) {
      context.missing(_kgMeta);
    }
    if (data.containsKey('gross_kg')) {
      context.handle(_grossKgMeta,
          grossKg.isAcceptableOrUnknown(data['gross_kg']!, _grossKgMeta));
    }
    if (data.containsKey('deduction_kg')) {
      context.handle(
          _deductionKgMeta,
          deductionKg.isAcceptableOrUnknown(
              data['deduction_kg']!, _deductionKgMeta));
    }
    if (data.containsKey('rate_paisa_per_kg')) {
      context.handle(
          _ratePaisaPerKgMeta,
          ratePaisaPerKg.isAcceptableOrUnknown(
              data['rate_paisa_per_kg']!, _ratePaisaPerKgMeta));
    } else if (isInserting) {
      context.missing(_ratePaisaPerKgMeta);
    }
    if (data.containsKey('rate_paisa_per_maund')) {
      context.handle(
          _ratePaisaPerMaundMeta,
          ratePaisaPerMaund.isAcceptableOrUnknown(
              data['rate_paisa_per_maund']!, _ratePaisaPerMaundMeta));
    }
    if (data.containsKey('total_paisa')) {
      context.handle(
          _totalPaisaMeta,
          totalPaisa.isAcceptableOrUnknown(
              data['total_paisa']!, _totalPaisaMeta));
    } else if (isInserting) {
      context.missing(_totalPaisaMeta);
    }
    if (data.containsKey('seller_name')) {
      context.handle(
          _sellerNameMeta,
          sellerName.isAcceptableOrUnknown(
              data['seller_name']!, _sellerNameMeta));
    }
    if (data.containsKey('paid_paisa')) {
      context.handle(_paidPaisaMeta,
          paidPaisa.isAcceptableOrUnknown(data['paid_paisa']!, _paidPaisaMeta));
    }
    if (data.containsKey('note')) {
      context.handle(
          _noteMeta, note.isAcceptableOrUnknown(data['note']!, _noteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  HatPurchaseItem map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return HatPurchaseItem(
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}updated_at'])!,
      deletedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}deleted_at']),
      version: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}version'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      userId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}user_id'])!,
      sessionId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}session_id'])!,
      productName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}product_name'])!,
      kg: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}kg'])!,
      grossKg: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}gross_kg']),
      deductionKg: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}deduction_kg'])!,
      ratePaisaPerKg: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}rate_paisa_per_kg'])!,
      ratePaisaPerMaund: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}rate_paisa_per_maund']),
      totalPaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}total_paisa'])!,
      sellerName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}seller_name']),
      paidPaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}paid_paisa'])!,
      note: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}note']),
    );
  }

  @override
  $HatPurchaseItemsTable createAlias(String alias) {
    return $HatPurchaseItemsTable(attachedDatabase, alias);
  }
}

class HatPurchaseItem extends DataClass implements Insertable<HatPurchaseItem> {
  final String createdAt;
  final String updatedAt;
  final String? deletedAt;
  final int version;
  final String syncStatus;
  final String id;
  final String userId;
  final String sessionId;
  final String productName;
  final double kg;
  final double? grossKg;
  final double deductionKg;
  final int ratePaisaPerKg;
  final int? ratePaisaPerMaund;
  final int totalPaisa;
  final String? sellerName;
  final int paidPaisa;
  final String? note;
  const HatPurchaseItem(
      {required this.createdAt,
      required this.updatedAt,
      this.deletedAt,
      required this.version,
      required this.syncStatus,
      required this.id,
      required this.userId,
      required this.sessionId,
      required this.productName,
      required this.kg,
      this.grossKg,
      required this.deductionKg,
      required this.ratePaisaPerKg,
      this.ratePaisaPerMaund,
      required this.totalPaisa,
      this.sellerName,
      required this.paidPaisa,
      this.note});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['created_at'] = Variable<String>(createdAt);
    map['updated_at'] = Variable<String>(updatedAt);
    if (!nullToAbsent || deletedAt != null) {
      map['deleted_at'] = Variable<String>(deletedAt);
    }
    map['version'] = Variable<int>(version);
    map['sync_status'] = Variable<String>(syncStatus);
    map['id'] = Variable<String>(id);
    map['user_id'] = Variable<String>(userId);
    map['session_id'] = Variable<String>(sessionId);
    map['product_name'] = Variable<String>(productName);
    map['kg'] = Variable<double>(kg);
    if (!nullToAbsent || grossKg != null) {
      map['gross_kg'] = Variable<double>(grossKg);
    }
    map['deduction_kg'] = Variable<double>(deductionKg);
    map['rate_paisa_per_kg'] = Variable<int>(ratePaisaPerKg);
    if (!nullToAbsent || ratePaisaPerMaund != null) {
      map['rate_paisa_per_maund'] = Variable<int>(ratePaisaPerMaund);
    }
    map['total_paisa'] = Variable<int>(totalPaisa);
    if (!nullToAbsent || sellerName != null) {
      map['seller_name'] = Variable<String>(sellerName);
    }
    map['paid_paisa'] = Variable<int>(paidPaisa);
    if (!nullToAbsent || note != null) {
      map['note'] = Variable<String>(note);
    }
    return map;
  }

  HatPurchaseItemsCompanion toCompanion(bool nullToAbsent) {
    return HatPurchaseItemsCompanion(
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      deletedAt: deletedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(deletedAt),
      version: Value(version),
      syncStatus: Value(syncStatus),
      id: Value(id),
      userId: Value(userId),
      sessionId: Value(sessionId),
      productName: Value(productName),
      kg: Value(kg),
      grossKg: grossKg == null && nullToAbsent
          ? const Value.absent()
          : Value(grossKg),
      deductionKg: Value(deductionKg),
      ratePaisaPerKg: Value(ratePaisaPerKg),
      ratePaisaPerMaund: ratePaisaPerMaund == null && nullToAbsent
          ? const Value.absent()
          : Value(ratePaisaPerMaund),
      totalPaisa: Value(totalPaisa),
      sellerName: sellerName == null && nullToAbsent
          ? const Value.absent()
          : Value(sellerName),
      paidPaisa: Value(paidPaisa),
      note: note == null && nullToAbsent ? const Value.absent() : Value(note),
    );
  }

  factory HatPurchaseItem.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return HatPurchaseItem(
      createdAt: serializer.fromJson<String>(json['createdAt']),
      updatedAt: serializer.fromJson<String>(json['updatedAt']),
      deletedAt: serializer.fromJson<String?>(json['deletedAt']),
      version: serializer.fromJson<int>(json['version']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      id: serializer.fromJson<String>(json['id']),
      userId: serializer.fromJson<String>(json['userId']),
      sessionId: serializer.fromJson<String>(json['sessionId']),
      productName: serializer.fromJson<String>(json['productName']),
      kg: serializer.fromJson<double>(json['kg']),
      grossKg: serializer.fromJson<double?>(json['grossKg']),
      deductionKg: serializer.fromJson<double>(json['deductionKg']),
      ratePaisaPerKg: serializer.fromJson<int>(json['ratePaisaPerKg']),
      ratePaisaPerMaund: serializer.fromJson<int?>(json['ratePaisaPerMaund']),
      totalPaisa: serializer.fromJson<int>(json['totalPaisa']),
      sellerName: serializer.fromJson<String?>(json['sellerName']),
      paidPaisa: serializer.fromJson<int>(json['paidPaisa']),
      note: serializer.fromJson<String?>(json['note']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'createdAt': serializer.toJson<String>(createdAt),
      'updatedAt': serializer.toJson<String>(updatedAt),
      'deletedAt': serializer.toJson<String?>(deletedAt),
      'version': serializer.toJson<int>(version),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'id': serializer.toJson<String>(id),
      'userId': serializer.toJson<String>(userId),
      'sessionId': serializer.toJson<String>(sessionId),
      'productName': serializer.toJson<String>(productName),
      'kg': serializer.toJson<double>(kg),
      'grossKg': serializer.toJson<double?>(grossKg),
      'deductionKg': serializer.toJson<double>(deductionKg),
      'ratePaisaPerKg': serializer.toJson<int>(ratePaisaPerKg),
      'ratePaisaPerMaund': serializer.toJson<int?>(ratePaisaPerMaund),
      'totalPaisa': serializer.toJson<int>(totalPaisa),
      'sellerName': serializer.toJson<String?>(sellerName),
      'paidPaisa': serializer.toJson<int>(paidPaisa),
      'note': serializer.toJson<String?>(note),
    };
  }

  HatPurchaseItem copyWith(
          {String? createdAt,
          String? updatedAt,
          Value<String?> deletedAt = const Value.absent(),
          int? version,
          String? syncStatus,
          String? id,
          String? userId,
          String? sessionId,
          String? productName,
          double? kg,
          Value<double?> grossKg = const Value.absent(),
          double? deductionKg,
          int? ratePaisaPerKg,
          Value<int?> ratePaisaPerMaund = const Value.absent(),
          int? totalPaisa,
          Value<String?> sellerName = const Value.absent(),
          int? paidPaisa,
          Value<String?> note = const Value.absent()}) =>
      HatPurchaseItem(
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: deletedAt.present ? deletedAt.value : this.deletedAt,
        version: version ?? this.version,
        syncStatus: syncStatus ?? this.syncStatus,
        id: id ?? this.id,
        userId: userId ?? this.userId,
        sessionId: sessionId ?? this.sessionId,
        productName: productName ?? this.productName,
        kg: kg ?? this.kg,
        grossKg: grossKg.present ? grossKg.value : this.grossKg,
        deductionKg: deductionKg ?? this.deductionKg,
        ratePaisaPerKg: ratePaisaPerKg ?? this.ratePaisaPerKg,
        ratePaisaPerMaund: ratePaisaPerMaund.present
            ? ratePaisaPerMaund.value
            : this.ratePaisaPerMaund,
        totalPaisa: totalPaisa ?? this.totalPaisa,
        sellerName: sellerName.present ? sellerName.value : this.sellerName,
        paidPaisa: paidPaisa ?? this.paidPaisa,
        note: note.present ? note.value : this.note,
      );
  HatPurchaseItem copyWithCompanion(HatPurchaseItemsCompanion data) {
    return HatPurchaseItem(
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      deletedAt: data.deletedAt.present ? data.deletedAt.value : this.deletedAt,
      version: data.version.present ? data.version.value : this.version,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      id: data.id.present ? data.id.value : this.id,
      userId: data.userId.present ? data.userId.value : this.userId,
      sessionId: data.sessionId.present ? data.sessionId.value : this.sessionId,
      productName:
          data.productName.present ? data.productName.value : this.productName,
      kg: data.kg.present ? data.kg.value : this.kg,
      grossKg: data.grossKg.present ? data.grossKg.value : this.grossKg,
      deductionKg:
          data.deductionKg.present ? data.deductionKg.value : this.deductionKg,
      ratePaisaPerKg: data.ratePaisaPerKg.present
          ? data.ratePaisaPerKg.value
          : this.ratePaisaPerKg,
      ratePaisaPerMaund: data.ratePaisaPerMaund.present
          ? data.ratePaisaPerMaund.value
          : this.ratePaisaPerMaund,
      totalPaisa:
          data.totalPaisa.present ? data.totalPaisa.value : this.totalPaisa,
      sellerName:
          data.sellerName.present ? data.sellerName.value : this.sellerName,
      paidPaisa: data.paidPaisa.present ? data.paidPaisa.value : this.paidPaisa,
      note: data.note.present ? data.note.value : this.note,
    );
  }

  @override
  String toString() {
    return (StringBuffer('HatPurchaseItem(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('sessionId: $sessionId, ')
          ..write('productName: $productName, ')
          ..write('kg: $kg, ')
          ..write('grossKg: $grossKg, ')
          ..write('deductionKg: $deductionKg, ')
          ..write('ratePaisaPerKg: $ratePaisaPerKg, ')
          ..write('ratePaisaPerMaund: $ratePaisaPerMaund, ')
          ..write('totalPaisa: $totalPaisa, ')
          ..write('sellerName: $sellerName, ')
          ..write('paidPaisa: $paidPaisa, ')
          ..write('note: $note')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      createdAt,
      updatedAt,
      deletedAt,
      version,
      syncStatus,
      id,
      userId,
      sessionId,
      productName,
      kg,
      grossKg,
      deductionKg,
      ratePaisaPerKg,
      ratePaisaPerMaund,
      totalPaisa,
      sellerName,
      paidPaisa,
      note);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is HatPurchaseItem &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.deletedAt == this.deletedAt &&
          other.version == this.version &&
          other.syncStatus == this.syncStatus &&
          other.id == this.id &&
          other.userId == this.userId &&
          other.sessionId == this.sessionId &&
          other.productName == this.productName &&
          other.kg == this.kg &&
          other.grossKg == this.grossKg &&
          other.deductionKg == this.deductionKg &&
          other.ratePaisaPerKg == this.ratePaisaPerKg &&
          other.ratePaisaPerMaund == this.ratePaisaPerMaund &&
          other.totalPaisa == this.totalPaisa &&
          other.sellerName == this.sellerName &&
          other.paidPaisa == this.paidPaisa &&
          other.note == this.note);
}

class HatPurchaseItemsCompanion extends UpdateCompanion<HatPurchaseItem> {
  final Value<String> createdAt;
  final Value<String> updatedAt;
  final Value<String?> deletedAt;
  final Value<int> version;
  final Value<String> syncStatus;
  final Value<String> id;
  final Value<String> userId;
  final Value<String> sessionId;
  final Value<String> productName;
  final Value<double> kg;
  final Value<double?> grossKg;
  final Value<double> deductionKg;
  final Value<int> ratePaisaPerKg;
  final Value<int?> ratePaisaPerMaund;
  final Value<int> totalPaisa;
  final Value<String?> sellerName;
  final Value<int> paidPaisa;
  final Value<String?> note;
  final Value<int> rowid;
  const HatPurchaseItemsCompanion({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.id = const Value.absent(),
    this.userId = const Value.absent(),
    this.sessionId = const Value.absent(),
    this.productName = const Value.absent(),
    this.kg = const Value.absent(),
    this.grossKg = const Value.absent(),
    this.deductionKg = const Value.absent(),
    this.ratePaisaPerKg = const Value.absent(),
    this.ratePaisaPerMaund = const Value.absent(),
    this.totalPaisa = const Value.absent(),
    this.sellerName = const Value.absent(),
    this.paidPaisa = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  HatPurchaseItemsCompanion.insert({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    required String id,
    required String userId,
    required String sessionId,
    this.productName = const Value.absent(),
    required double kg,
    this.grossKg = const Value.absent(),
    this.deductionKg = const Value.absent(),
    required int ratePaisaPerKg,
    this.ratePaisaPerMaund = const Value.absent(),
    required int totalPaisa,
    this.sellerName = const Value.absent(),
    this.paidPaisa = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        userId = Value(userId),
        sessionId = Value(sessionId),
        kg = Value(kg),
        ratePaisaPerKg = Value(ratePaisaPerKg),
        totalPaisa = Value(totalPaisa);
  static Insertable<HatPurchaseItem> custom({
    Expression<String>? createdAt,
    Expression<String>? updatedAt,
    Expression<String>? deletedAt,
    Expression<int>? version,
    Expression<String>? syncStatus,
    Expression<String>? id,
    Expression<String>? userId,
    Expression<String>? sessionId,
    Expression<String>? productName,
    Expression<double>? kg,
    Expression<double>? grossKg,
    Expression<double>? deductionKg,
    Expression<int>? ratePaisaPerKg,
    Expression<int>? ratePaisaPerMaund,
    Expression<int>? totalPaisa,
    Expression<String>? sellerName,
    Expression<int>? paidPaisa,
    Expression<String>? note,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (deletedAt != null) 'deleted_at': deletedAt,
      if (version != null) 'version': version,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (id != null) 'id': id,
      if (userId != null) 'user_id': userId,
      if (sessionId != null) 'session_id': sessionId,
      if (productName != null) 'product_name': productName,
      if (kg != null) 'kg': kg,
      if (grossKg != null) 'gross_kg': grossKg,
      if (deductionKg != null) 'deduction_kg': deductionKg,
      if (ratePaisaPerKg != null) 'rate_paisa_per_kg': ratePaisaPerKg,
      if (ratePaisaPerMaund != null) 'rate_paisa_per_maund': ratePaisaPerMaund,
      if (totalPaisa != null) 'total_paisa': totalPaisa,
      if (sellerName != null) 'seller_name': sellerName,
      if (paidPaisa != null) 'paid_paisa': paidPaisa,
      if (note != null) 'note': note,
      if (rowid != null) 'rowid': rowid,
    });
  }

  HatPurchaseItemsCompanion copyWith(
      {Value<String>? createdAt,
      Value<String>? updatedAt,
      Value<String?>? deletedAt,
      Value<int>? version,
      Value<String>? syncStatus,
      Value<String>? id,
      Value<String>? userId,
      Value<String>? sessionId,
      Value<String>? productName,
      Value<double>? kg,
      Value<double?>? grossKg,
      Value<double>? deductionKg,
      Value<int>? ratePaisaPerKg,
      Value<int?>? ratePaisaPerMaund,
      Value<int>? totalPaisa,
      Value<String?>? sellerName,
      Value<int>? paidPaisa,
      Value<String?>? note,
      Value<int>? rowid}) {
    return HatPurchaseItemsCompanion(
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      version: version ?? this.version,
      syncStatus: syncStatus ?? this.syncStatus,
      id: id ?? this.id,
      userId: userId ?? this.userId,
      sessionId: sessionId ?? this.sessionId,
      productName: productName ?? this.productName,
      kg: kg ?? this.kg,
      grossKg: grossKg ?? this.grossKg,
      deductionKg: deductionKg ?? this.deductionKg,
      ratePaisaPerKg: ratePaisaPerKg ?? this.ratePaisaPerKg,
      ratePaisaPerMaund: ratePaisaPerMaund ?? this.ratePaisaPerMaund,
      totalPaisa: totalPaisa ?? this.totalPaisa,
      sellerName: sellerName ?? this.sellerName,
      paidPaisa: paidPaisa ?? this.paidPaisa,
      note: note ?? this.note,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (createdAt.present) {
      map['created_at'] = Variable<String>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<String>(updatedAt.value);
    }
    if (deletedAt.present) {
      map['deleted_at'] = Variable<String>(deletedAt.value);
    }
    if (version.present) {
      map['version'] = Variable<int>(version.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<String>(userId.value);
    }
    if (sessionId.present) {
      map['session_id'] = Variable<String>(sessionId.value);
    }
    if (productName.present) {
      map['product_name'] = Variable<String>(productName.value);
    }
    if (kg.present) {
      map['kg'] = Variable<double>(kg.value);
    }
    if (grossKg.present) {
      map['gross_kg'] = Variable<double>(grossKg.value);
    }
    if (deductionKg.present) {
      map['deduction_kg'] = Variable<double>(deductionKg.value);
    }
    if (ratePaisaPerKg.present) {
      map['rate_paisa_per_kg'] = Variable<int>(ratePaisaPerKg.value);
    }
    if (ratePaisaPerMaund.present) {
      map['rate_paisa_per_maund'] = Variable<int>(ratePaisaPerMaund.value);
    }
    if (totalPaisa.present) {
      map['total_paisa'] = Variable<int>(totalPaisa.value);
    }
    if (sellerName.present) {
      map['seller_name'] = Variable<String>(sellerName.value);
    }
    if (paidPaisa.present) {
      map['paid_paisa'] = Variable<int>(paidPaisa.value);
    }
    if (note.present) {
      map['note'] = Variable<String>(note.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('HatPurchaseItemsCompanion(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('sessionId: $sessionId, ')
          ..write('productName: $productName, ')
          ..write('kg: $kg, ')
          ..write('grossKg: $grossKg, ')
          ..write('deductionKg: $deductionKg, ')
          ..write('ratePaisaPerKg: $ratePaisaPerKg, ')
          ..write('ratePaisaPerMaund: $ratePaisaPerMaund, ')
          ..write('totalPaisa: $totalPaisa, ')
          ..write('sellerName: $sellerName, ')
          ..write('paidPaisa: $paidPaisa, ')
          ..write('note: $note, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $IncomeHatTable extends IncomeHat
    with TableInfo<$IncomeHatTable, IncomeHatData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $IncomeHatTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<String> createdAt = GeneratedColumn<String>(
      'created_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<String> updatedAt = GeneratedColumn<String>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _deletedAtMeta =
      const VerificationMeta('deletedAt');
  @override
  late final GeneratedColumn<String> deletedAt = GeneratedColumn<String>(
      'deleted_at', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _versionMeta =
      const VerificationMeta('version');
  @override
  late final GeneratedColumn<int> version = GeneratedColumn<int>(
      'version', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('pending'));
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<String> userId = GeneratedColumn<String>(
      'user_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _hatIdMeta = const VerificationMeta('hatId');
  @override
  late final GeneratedColumn<String> hatId = GeneratedColumn<String>(
      'hat_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _sessionIdMeta =
      const VerificationMeta('sessionId');
  @override
  late final GeneratedColumn<String> sessionId = GeneratedColumn<String>(
      'session_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _txnDateMeta =
      const VerificationMeta('txnDate');
  @override
  late final GeneratedColumn<String> txnDate = GeneratedColumn<String>(
      'txn_date', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _amountPaisaMeta =
      const VerificationMeta('amountPaisa');
  @override
  late final GeneratedColumn<int> amountPaisa = GeneratedColumn<int>(
      'amount_paisa', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _paymentMethodMeta =
      const VerificationMeta('paymentMethod');
  @override
  late final GeneratedColumn<String> paymentMethod = GeneratedColumn<String>(
      'payment_method', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('cash'));
  static const VerificationMeta _walletIdMeta =
      const VerificationMeta('walletId');
  @override
  late final GeneratedColumn<String> walletId = GeneratedColumn<String>(
      'wallet_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _noteMeta = const VerificationMeta('note');
  @override
  late final GeneratedColumn<String> note = GeneratedColumn<String>(
      'note', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        createdAt,
        updatedAt,
        deletedAt,
        version,
        syncStatus,
        id,
        userId,
        hatId,
        sessionId,
        txnDate,
        amountPaisa,
        paymentMethod,
        walletId,
        note
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'income_hat';
  @override
  VerificationContext validateIntegrity(Insertable<IncomeHatData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    if (data.containsKey('deleted_at')) {
      context.handle(_deletedAtMeta,
          deletedAt.isAcceptableOrUnknown(data['deleted_at']!, _deletedAtMeta));
    }
    if (data.containsKey('version')) {
      context.handle(_versionMeta,
          version.isAcceptableOrUnknown(data['version']!, _versionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('user_id')) {
      context.handle(_userIdMeta,
          userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta));
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('hat_id')) {
      context.handle(
          _hatIdMeta, hatId.isAcceptableOrUnknown(data['hat_id']!, _hatIdMeta));
    }
    if (data.containsKey('session_id')) {
      context.handle(_sessionIdMeta,
          sessionId.isAcceptableOrUnknown(data['session_id']!, _sessionIdMeta));
    }
    if (data.containsKey('txn_date')) {
      context.handle(_txnDateMeta,
          txnDate.isAcceptableOrUnknown(data['txn_date']!, _txnDateMeta));
    } else if (isInserting) {
      context.missing(_txnDateMeta);
    }
    if (data.containsKey('amount_paisa')) {
      context.handle(
          _amountPaisaMeta,
          amountPaisa.isAcceptableOrUnknown(
              data['amount_paisa']!, _amountPaisaMeta));
    } else if (isInserting) {
      context.missing(_amountPaisaMeta);
    }
    if (data.containsKey('payment_method')) {
      context.handle(
          _paymentMethodMeta,
          paymentMethod.isAcceptableOrUnknown(
              data['payment_method']!, _paymentMethodMeta));
    }
    if (data.containsKey('wallet_id')) {
      context.handle(_walletIdMeta,
          walletId.isAcceptableOrUnknown(data['wallet_id']!, _walletIdMeta));
    }
    if (data.containsKey('note')) {
      context.handle(
          _noteMeta, note.isAcceptableOrUnknown(data['note']!, _noteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  IncomeHatData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return IncomeHatData(
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}updated_at'])!,
      deletedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}deleted_at']),
      version: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}version'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      userId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}user_id'])!,
      hatId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}hat_id']),
      sessionId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}session_id']),
      txnDate: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}txn_date'])!,
      amountPaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}amount_paisa'])!,
      paymentMethod: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}payment_method'])!,
      walletId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}wallet_id']),
      note: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}note']),
    );
  }

  @override
  $IncomeHatTable createAlias(String alias) {
    return $IncomeHatTable(attachedDatabase, alias);
  }
}

class IncomeHatData extends DataClass implements Insertable<IncomeHatData> {
  final String createdAt;
  final String updatedAt;
  final String? deletedAt;
  final int version;
  final String syncStatus;
  final String id;
  final String userId;
  final String? hatId;
  final String? sessionId;
  final String txnDate;
  final int amountPaisa;
  final String paymentMethod;
  final String? walletId;
  final String? note;
  const IncomeHatData(
      {required this.createdAt,
      required this.updatedAt,
      this.deletedAt,
      required this.version,
      required this.syncStatus,
      required this.id,
      required this.userId,
      this.hatId,
      this.sessionId,
      required this.txnDate,
      required this.amountPaisa,
      required this.paymentMethod,
      this.walletId,
      this.note});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['created_at'] = Variable<String>(createdAt);
    map['updated_at'] = Variable<String>(updatedAt);
    if (!nullToAbsent || deletedAt != null) {
      map['deleted_at'] = Variable<String>(deletedAt);
    }
    map['version'] = Variable<int>(version);
    map['sync_status'] = Variable<String>(syncStatus);
    map['id'] = Variable<String>(id);
    map['user_id'] = Variable<String>(userId);
    if (!nullToAbsent || hatId != null) {
      map['hat_id'] = Variable<String>(hatId);
    }
    if (!nullToAbsent || sessionId != null) {
      map['session_id'] = Variable<String>(sessionId);
    }
    map['txn_date'] = Variable<String>(txnDate);
    map['amount_paisa'] = Variable<int>(amountPaisa);
    map['payment_method'] = Variable<String>(paymentMethod);
    if (!nullToAbsent || walletId != null) {
      map['wallet_id'] = Variable<String>(walletId);
    }
    if (!nullToAbsent || note != null) {
      map['note'] = Variable<String>(note);
    }
    return map;
  }

  IncomeHatCompanion toCompanion(bool nullToAbsent) {
    return IncomeHatCompanion(
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      deletedAt: deletedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(deletedAt),
      version: Value(version),
      syncStatus: Value(syncStatus),
      id: Value(id),
      userId: Value(userId),
      hatId:
          hatId == null && nullToAbsent ? const Value.absent() : Value(hatId),
      sessionId: sessionId == null && nullToAbsent
          ? const Value.absent()
          : Value(sessionId),
      txnDate: Value(txnDate),
      amountPaisa: Value(amountPaisa),
      paymentMethod: Value(paymentMethod),
      walletId: walletId == null && nullToAbsent
          ? const Value.absent()
          : Value(walletId),
      note: note == null && nullToAbsent ? const Value.absent() : Value(note),
    );
  }

  factory IncomeHatData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return IncomeHatData(
      createdAt: serializer.fromJson<String>(json['createdAt']),
      updatedAt: serializer.fromJson<String>(json['updatedAt']),
      deletedAt: serializer.fromJson<String?>(json['deletedAt']),
      version: serializer.fromJson<int>(json['version']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      id: serializer.fromJson<String>(json['id']),
      userId: serializer.fromJson<String>(json['userId']),
      hatId: serializer.fromJson<String?>(json['hatId']),
      sessionId: serializer.fromJson<String?>(json['sessionId']),
      txnDate: serializer.fromJson<String>(json['txnDate']),
      amountPaisa: serializer.fromJson<int>(json['amountPaisa']),
      paymentMethod: serializer.fromJson<String>(json['paymentMethod']),
      walletId: serializer.fromJson<String?>(json['walletId']),
      note: serializer.fromJson<String?>(json['note']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'createdAt': serializer.toJson<String>(createdAt),
      'updatedAt': serializer.toJson<String>(updatedAt),
      'deletedAt': serializer.toJson<String?>(deletedAt),
      'version': serializer.toJson<int>(version),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'id': serializer.toJson<String>(id),
      'userId': serializer.toJson<String>(userId),
      'hatId': serializer.toJson<String?>(hatId),
      'sessionId': serializer.toJson<String?>(sessionId),
      'txnDate': serializer.toJson<String>(txnDate),
      'amountPaisa': serializer.toJson<int>(amountPaisa),
      'paymentMethod': serializer.toJson<String>(paymentMethod),
      'walletId': serializer.toJson<String?>(walletId),
      'note': serializer.toJson<String?>(note),
    };
  }

  IncomeHatData copyWith(
          {String? createdAt,
          String? updatedAt,
          Value<String?> deletedAt = const Value.absent(),
          int? version,
          String? syncStatus,
          String? id,
          String? userId,
          Value<String?> hatId = const Value.absent(),
          Value<String?> sessionId = const Value.absent(),
          String? txnDate,
          int? amountPaisa,
          String? paymentMethod,
          Value<String?> walletId = const Value.absent(),
          Value<String?> note = const Value.absent()}) =>
      IncomeHatData(
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: deletedAt.present ? deletedAt.value : this.deletedAt,
        version: version ?? this.version,
        syncStatus: syncStatus ?? this.syncStatus,
        id: id ?? this.id,
        userId: userId ?? this.userId,
        hatId: hatId.present ? hatId.value : this.hatId,
        sessionId: sessionId.present ? sessionId.value : this.sessionId,
        txnDate: txnDate ?? this.txnDate,
        amountPaisa: amountPaisa ?? this.amountPaisa,
        paymentMethod: paymentMethod ?? this.paymentMethod,
        walletId: walletId.present ? walletId.value : this.walletId,
        note: note.present ? note.value : this.note,
      );
  IncomeHatData copyWithCompanion(IncomeHatCompanion data) {
    return IncomeHatData(
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      deletedAt: data.deletedAt.present ? data.deletedAt.value : this.deletedAt,
      version: data.version.present ? data.version.value : this.version,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      id: data.id.present ? data.id.value : this.id,
      userId: data.userId.present ? data.userId.value : this.userId,
      hatId: data.hatId.present ? data.hatId.value : this.hatId,
      sessionId: data.sessionId.present ? data.sessionId.value : this.sessionId,
      txnDate: data.txnDate.present ? data.txnDate.value : this.txnDate,
      amountPaisa:
          data.amountPaisa.present ? data.amountPaisa.value : this.amountPaisa,
      paymentMethod: data.paymentMethod.present
          ? data.paymentMethod.value
          : this.paymentMethod,
      walletId: data.walletId.present ? data.walletId.value : this.walletId,
      note: data.note.present ? data.note.value : this.note,
    );
  }

  @override
  String toString() {
    return (StringBuffer('IncomeHatData(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('hatId: $hatId, ')
          ..write('sessionId: $sessionId, ')
          ..write('txnDate: $txnDate, ')
          ..write('amountPaisa: $amountPaisa, ')
          ..write('paymentMethod: $paymentMethod, ')
          ..write('walletId: $walletId, ')
          ..write('note: $note')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      createdAt,
      updatedAt,
      deletedAt,
      version,
      syncStatus,
      id,
      userId,
      hatId,
      sessionId,
      txnDate,
      amountPaisa,
      paymentMethod,
      walletId,
      note);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is IncomeHatData &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.deletedAt == this.deletedAt &&
          other.version == this.version &&
          other.syncStatus == this.syncStatus &&
          other.id == this.id &&
          other.userId == this.userId &&
          other.hatId == this.hatId &&
          other.sessionId == this.sessionId &&
          other.txnDate == this.txnDate &&
          other.amountPaisa == this.amountPaisa &&
          other.paymentMethod == this.paymentMethod &&
          other.walletId == this.walletId &&
          other.note == this.note);
}

class IncomeHatCompanion extends UpdateCompanion<IncomeHatData> {
  final Value<String> createdAt;
  final Value<String> updatedAt;
  final Value<String?> deletedAt;
  final Value<int> version;
  final Value<String> syncStatus;
  final Value<String> id;
  final Value<String> userId;
  final Value<String?> hatId;
  final Value<String?> sessionId;
  final Value<String> txnDate;
  final Value<int> amountPaisa;
  final Value<String> paymentMethod;
  final Value<String?> walletId;
  final Value<String?> note;
  final Value<int> rowid;
  const IncomeHatCompanion({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.id = const Value.absent(),
    this.userId = const Value.absent(),
    this.hatId = const Value.absent(),
    this.sessionId = const Value.absent(),
    this.txnDate = const Value.absent(),
    this.amountPaisa = const Value.absent(),
    this.paymentMethod = const Value.absent(),
    this.walletId = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  IncomeHatCompanion.insert({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    required String id,
    required String userId,
    this.hatId = const Value.absent(),
    this.sessionId = const Value.absent(),
    required String txnDate,
    required int amountPaisa,
    this.paymentMethod = const Value.absent(),
    this.walletId = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        userId = Value(userId),
        txnDate = Value(txnDate),
        amountPaisa = Value(amountPaisa);
  static Insertable<IncomeHatData> custom({
    Expression<String>? createdAt,
    Expression<String>? updatedAt,
    Expression<String>? deletedAt,
    Expression<int>? version,
    Expression<String>? syncStatus,
    Expression<String>? id,
    Expression<String>? userId,
    Expression<String>? hatId,
    Expression<String>? sessionId,
    Expression<String>? txnDate,
    Expression<int>? amountPaisa,
    Expression<String>? paymentMethod,
    Expression<String>? walletId,
    Expression<String>? note,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (deletedAt != null) 'deleted_at': deletedAt,
      if (version != null) 'version': version,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (id != null) 'id': id,
      if (userId != null) 'user_id': userId,
      if (hatId != null) 'hat_id': hatId,
      if (sessionId != null) 'session_id': sessionId,
      if (txnDate != null) 'txn_date': txnDate,
      if (amountPaisa != null) 'amount_paisa': amountPaisa,
      if (paymentMethod != null) 'payment_method': paymentMethod,
      if (walletId != null) 'wallet_id': walletId,
      if (note != null) 'note': note,
      if (rowid != null) 'rowid': rowid,
    });
  }

  IncomeHatCompanion copyWith(
      {Value<String>? createdAt,
      Value<String>? updatedAt,
      Value<String?>? deletedAt,
      Value<int>? version,
      Value<String>? syncStatus,
      Value<String>? id,
      Value<String>? userId,
      Value<String?>? hatId,
      Value<String?>? sessionId,
      Value<String>? txnDate,
      Value<int>? amountPaisa,
      Value<String>? paymentMethod,
      Value<String?>? walletId,
      Value<String?>? note,
      Value<int>? rowid}) {
    return IncomeHatCompanion(
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      version: version ?? this.version,
      syncStatus: syncStatus ?? this.syncStatus,
      id: id ?? this.id,
      userId: userId ?? this.userId,
      hatId: hatId ?? this.hatId,
      sessionId: sessionId ?? this.sessionId,
      txnDate: txnDate ?? this.txnDate,
      amountPaisa: amountPaisa ?? this.amountPaisa,
      paymentMethod: paymentMethod ?? this.paymentMethod,
      walletId: walletId ?? this.walletId,
      note: note ?? this.note,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (createdAt.present) {
      map['created_at'] = Variable<String>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<String>(updatedAt.value);
    }
    if (deletedAt.present) {
      map['deleted_at'] = Variable<String>(deletedAt.value);
    }
    if (version.present) {
      map['version'] = Variable<int>(version.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<String>(userId.value);
    }
    if (hatId.present) {
      map['hat_id'] = Variable<String>(hatId.value);
    }
    if (sessionId.present) {
      map['session_id'] = Variable<String>(sessionId.value);
    }
    if (txnDate.present) {
      map['txn_date'] = Variable<String>(txnDate.value);
    }
    if (amountPaisa.present) {
      map['amount_paisa'] = Variable<int>(amountPaisa.value);
    }
    if (paymentMethod.present) {
      map['payment_method'] = Variable<String>(paymentMethod.value);
    }
    if (walletId.present) {
      map['wallet_id'] = Variable<String>(walletId.value);
    }
    if (note.present) {
      map['note'] = Variable<String>(note.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('IncomeHatCompanion(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('hatId: $hatId, ')
          ..write('sessionId: $sessionId, ')
          ..write('txnDate: $txnDate, ')
          ..write('amountPaisa: $amountPaisa, ')
          ..write('paymentMethod: $paymentMethod, ')
          ..write('walletId: $walletId, ')
          ..write('note: $note, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $IncomePersonalTable extends IncomePersonal
    with TableInfo<$IncomePersonalTable, IncomePersonalData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $IncomePersonalTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<String> createdAt = GeneratedColumn<String>(
      'created_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<String> updatedAt = GeneratedColumn<String>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _deletedAtMeta =
      const VerificationMeta('deletedAt');
  @override
  late final GeneratedColumn<String> deletedAt = GeneratedColumn<String>(
      'deleted_at', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _versionMeta =
      const VerificationMeta('version');
  @override
  late final GeneratedColumn<int> version = GeneratedColumn<int>(
      'version', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('pending'));
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<String> userId = GeneratedColumn<String>(
      'user_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _titleMeta = const VerificationMeta('title');
  @override
  late final GeneratedColumn<String> title = GeneratedColumn<String>(
      'title', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _categoryMeta =
      const VerificationMeta('category');
  @override
  late final GeneratedColumn<String> category = GeneratedColumn<String>(
      'category', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _txnDateMeta =
      const VerificationMeta('txnDate');
  @override
  late final GeneratedColumn<String> txnDate = GeneratedColumn<String>(
      'txn_date', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _amountPaisaMeta =
      const VerificationMeta('amountPaisa');
  @override
  late final GeneratedColumn<int> amountPaisa = GeneratedColumn<int>(
      'amount_paisa', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _paymentMethodMeta =
      const VerificationMeta('paymentMethod');
  @override
  late final GeneratedColumn<String> paymentMethod = GeneratedColumn<String>(
      'payment_method', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('cash'));
  static const VerificationMeta _walletIdMeta =
      const VerificationMeta('walletId');
  @override
  late final GeneratedColumn<String> walletId = GeneratedColumn<String>(
      'wallet_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _noteMeta = const VerificationMeta('note');
  @override
  late final GeneratedColumn<String> note = GeneratedColumn<String>(
      'note', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        createdAt,
        updatedAt,
        deletedAt,
        version,
        syncStatus,
        id,
        userId,
        title,
        category,
        txnDate,
        amountPaisa,
        paymentMethod,
        walletId,
        note
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'income_personal';
  @override
  VerificationContext validateIntegrity(Insertable<IncomePersonalData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    if (data.containsKey('deleted_at')) {
      context.handle(_deletedAtMeta,
          deletedAt.isAcceptableOrUnknown(data['deleted_at']!, _deletedAtMeta));
    }
    if (data.containsKey('version')) {
      context.handle(_versionMeta,
          version.isAcceptableOrUnknown(data['version']!, _versionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('user_id')) {
      context.handle(_userIdMeta,
          userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta));
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('title')) {
      context.handle(
          _titleMeta, title.isAcceptableOrUnknown(data['title']!, _titleMeta));
    } else if (isInserting) {
      context.missing(_titleMeta);
    }
    if (data.containsKey('category')) {
      context.handle(_categoryMeta,
          category.isAcceptableOrUnknown(data['category']!, _categoryMeta));
    }
    if (data.containsKey('txn_date')) {
      context.handle(_txnDateMeta,
          txnDate.isAcceptableOrUnknown(data['txn_date']!, _txnDateMeta));
    } else if (isInserting) {
      context.missing(_txnDateMeta);
    }
    if (data.containsKey('amount_paisa')) {
      context.handle(
          _amountPaisaMeta,
          amountPaisa.isAcceptableOrUnknown(
              data['amount_paisa']!, _amountPaisaMeta));
    } else if (isInserting) {
      context.missing(_amountPaisaMeta);
    }
    if (data.containsKey('payment_method')) {
      context.handle(
          _paymentMethodMeta,
          paymentMethod.isAcceptableOrUnknown(
              data['payment_method']!, _paymentMethodMeta));
    }
    if (data.containsKey('wallet_id')) {
      context.handle(_walletIdMeta,
          walletId.isAcceptableOrUnknown(data['wallet_id']!, _walletIdMeta));
    }
    if (data.containsKey('note')) {
      context.handle(
          _noteMeta, note.isAcceptableOrUnknown(data['note']!, _noteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  IncomePersonalData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return IncomePersonalData(
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}updated_at'])!,
      deletedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}deleted_at']),
      version: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}version'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      userId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}user_id'])!,
      title: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}title'])!,
      category: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}category']),
      txnDate: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}txn_date'])!,
      amountPaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}amount_paisa'])!,
      paymentMethod: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}payment_method'])!,
      walletId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}wallet_id']),
      note: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}note']),
    );
  }

  @override
  $IncomePersonalTable createAlias(String alias) {
    return $IncomePersonalTable(attachedDatabase, alias);
  }
}

class IncomePersonalData extends DataClass
    implements Insertable<IncomePersonalData> {
  final String createdAt;
  final String updatedAt;
  final String? deletedAt;
  final int version;
  final String syncStatus;
  final String id;
  final String userId;
  final String title;
  final String? category;
  final String txnDate;
  final int amountPaisa;
  final String paymentMethod;
  final String? walletId;
  final String? note;
  const IncomePersonalData(
      {required this.createdAt,
      required this.updatedAt,
      this.deletedAt,
      required this.version,
      required this.syncStatus,
      required this.id,
      required this.userId,
      required this.title,
      this.category,
      required this.txnDate,
      required this.amountPaisa,
      required this.paymentMethod,
      this.walletId,
      this.note});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['created_at'] = Variable<String>(createdAt);
    map['updated_at'] = Variable<String>(updatedAt);
    if (!nullToAbsent || deletedAt != null) {
      map['deleted_at'] = Variable<String>(deletedAt);
    }
    map['version'] = Variable<int>(version);
    map['sync_status'] = Variable<String>(syncStatus);
    map['id'] = Variable<String>(id);
    map['user_id'] = Variable<String>(userId);
    map['title'] = Variable<String>(title);
    if (!nullToAbsent || category != null) {
      map['category'] = Variable<String>(category);
    }
    map['txn_date'] = Variable<String>(txnDate);
    map['amount_paisa'] = Variable<int>(amountPaisa);
    map['payment_method'] = Variable<String>(paymentMethod);
    if (!nullToAbsent || walletId != null) {
      map['wallet_id'] = Variable<String>(walletId);
    }
    if (!nullToAbsent || note != null) {
      map['note'] = Variable<String>(note);
    }
    return map;
  }

  IncomePersonalCompanion toCompanion(bool nullToAbsent) {
    return IncomePersonalCompanion(
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      deletedAt: deletedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(deletedAt),
      version: Value(version),
      syncStatus: Value(syncStatus),
      id: Value(id),
      userId: Value(userId),
      title: Value(title),
      category: category == null && nullToAbsent
          ? const Value.absent()
          : Value(category),
      txnDate: Value(txnDate),
      amountPaisa: Value(amountPaisa),
      paymentMethod: Value(paymentMethod),
      walletId: walletId == null && nullToAbsent
          ? const Value.absent()
          : Value(walletId),
      note: note == null && nullToAbsent ? const Value.absent() : Value(note),
    );
  }

  factory IncomePersonalData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return IncomePersonalData(
      createdAt: serializer.fromJson<String>(json['createdAt']),
      updatedAt: serializer.fromJson<String>(json['updatedAt']),
      deletedAt: serializer.fromJson<String?>(json['deletedAt']),
      version: serializer.fromJson<int>(json['version']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      id: serializer.fromJson<String>(json['id']),
      userId: serializer.fromJson<String>(json['userId']),
      title: serializer.fromJson<String>(json['title']),
      category: serializer.fromJson<String?>(json['category']),
      txnDate: serializer.fromJson<String>(json['txnDate']),
      amountPaisa: serializer.fromJson<int>(json['amountPaisa']),
      paymentMethod: serializer.fromJson<String>(json['paymentMethod']),
      walletId: serializer.fromJson<String?>(json['walletId']),
      note: serializer.fromJson<String?>(json['note']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'createdAt': serializer.toJson<String>(createdAt),
      'updatedAt': serializer.toJson<String>(updatedAt),
      'deletedAt': serializer.toJson<String?>(deletedAt),
      'version': serializer.toJson<int>(version),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'id': serializer.toJson<String>(id),
      'userId': serializer.toJson<String>(userId),
      'title': serializer.toJson<String>(title),
      'category': serializer.toJson<String?>(category),
      'txnDate': serializer.toJson<String>(txnDate),
      'amountPaisa': serializer.toJson<int>(amountPaisa),
      'paymentMethod': serializer.toJson<String>(paymentMethod),
      'walletId': serializer.toJson<String?>(walletId),
      'note': serializer.toJson<String?>(note),
    };
  }

  IncomePersonalData copyWith(
          {String? createdAt,
          String? updatedAt,
          Value<String?> deletedAt = const Value.absent(),
          int? version,
          String? syncStatus,
          String? id,
          String? userId,
          String? title,
          Value<String?> category = const Value.absent(),
          String? txnDate,
          int? amountPaisa,
          String? paymentMethod,
          Value<String?> walletId = const Value.absent(),
          Value<String?> note = const Value.absent()}) =>
      IncomePersonalData(
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: deletedAt.present ? deletedAt.value : this.deletedAt,
        version: version ?? this.version,
        syncStatus: syncStatus ?? this.syncStatus,
        id: id ?? this.id,
        userId: userId ?? this.userId,
        title: title ?? this.title,
        category: category.present ? category.value : this.category,
        txnDate: txnDate ?? this.txnDate,
        amountPaisa: amountPaisa ?? this.amountPaisa,
        paymentMethod: paymentMethod ?? this.paymentMethod,
        walletId: walletId.present ? walletId.value : this.walletId,
        note: note.present ? note.value : this.note,
      );
  IncomePersonalData copyWithCompanion(IncomePersonalCompanion data) {
    return IncomePersonalData(
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      deletedAt: data.deletedAt.present ? data.deletedAt.value : this.deletedAt,
      version: data.version.present ? data.version.value : this.version,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      id: data.id.present ? data.id.value : this.id,
      userId: data.userId.present ? data.userId.value : this.userId,
      title: data.title.present ? data.title.value : this.title,
      category: data.category.present ? data.category.value : this.category,
      txnDate: data.txnDate.present ? data.txnDate.value : this.txnDate,
      amountPaisa:
          data.amountPaisa.present ? data.amountPaisa.value : this.amountPaisa,
      paymentMethod: data.paymentMethod.present
          ? data.paymentMethod.value
          : this.paymentMethod,
      walletId: data.walletId.present ? data.walletId.value : this.walletId,
      note: data.note.present ? data.note.value : this.note,
    );
  }

  @override
  String toString() {
    return (StringBuffer('IncomePersonalData(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('title: $title, ')
          ..write('category: $category, ')
          ..write('txnDate: $txnDate, ')
          ..write('amountPaisa: $amountPaisa, ')
          ..write('paymentMethod: $paymentMethod, ')
          ..write('walletId: $walletId, ')
          ..write('note: $note')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      createdAt,
      updatedAt,
      deletedAt,
      version,
      syncStatus,
      id,
      userId,
      title,
      category,
      txnDate,
      amountPaisa,
      paymentMethod,
      walletId,
      note);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is IncomePersonalData &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.deletedAt == this.deletedAt &&
          other.version == this.version &&
          other.syncStatus == this.syncStatus &&
          other.id == this.id &&
          other.userId == this.userId &&
          other.title == this.title &&
          other.category == this.category &&
          other.txnDate == this.txnDate &&
          other.amountPaisa == this.amountPaisa &&
          other.paymentMethod == this.paymentMethod &&
          other.walletId == this.walletId &&
          other.note == this.note);
}

class IncomePersonalCompanion extends UpdateCompanion<IncomePersonalData> {
  final Value<String> createdAt;
  final Value<String> updatedAt;
  final Value<String?> deletedAt;
  final Value<int> version;
  final Value<String> syncStatus;
  final Value<String> id;
  final Value<String> userId;
  final Value<String> title;
  final Value<String?> category;
  final Value<String> txnDate;
  final Value<int> amountPaisa;
  final Value<String> paymentMethod;
  final Value<String?> walletId;
  final Value<String?> note;
  final Value<int> rowid;
  const IncomePersonalCompanion({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.id = const Value.absent(),
    this.userId = const Value.absent(),
    this.title = const Value.absent(),
    this.category = const Value.absent(),
    this.txnDate = const Value.absent(),
    this.amountPaisa = const Value.absent(),
    this.paymentMethod = const Value.absent(),
    this.walletId = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  IncomePersonalCompanion.insert({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    required String id,
    required String userId,
    required String title,
    this.category = const Value.absent(),
    required String txnDate,
    required int amountPaisa,
    this.paymentMethod = const Value.absent(),
    this.walletId = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        userId = Value(userId),
        title = Value(title),
        txnDate = Value(txnDate),
        amountPaisa = Value(amountPaisa);
  static Insertable<IncomePersonalData> custom({
    Expression<String>? createdAt,
    Expression<String>? updatedAt,
    Expression<String>? deletedAt,
    Expression<int>? version,
    Expression<String>? syncStatus,
    Expression<String>? id,
    Expression<String>? userId,
    Expression<String>? title,
    Expression<String>? category,
    Expression<String>? txnDate,
    Expression<int>? amountPaisa,
    Expression<String>? paymentMethod,
    Expression<String>? walletId,
    Expression<String>? note,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (deletedAt != null) 'deleted_at': deletedAt,
      if (version != null) 'version': version,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (id != null) 'id': id,
      if (userId != null) 'user_id': userId,
      if (title != null) 'title': title,
      if (category != null) 'category': category,
      if (txnDate != null) 'txn_date': txnDate,
      if (amountPaisa != null) 'amount_paisa': amountPaisa,
      if (paymentMethod != null) 'payment_method': paymentMethod,
      if (walletId != null) 'wallet_id': walletId,
      if (note != null) 'note': note,
      if (rowid != null) 'rowid': rowid,
    });
  }

  IncomePersonalCompanion copyWith(
      {Value<String>? createdAt,
      Value<String>? updatedAt,
      Value<String?>? deletedAt,
      Value<int>? version,
      Value<String>? syncStatus,
      Value<String>? id,
      Value<String>? userId,
      Value<String>? title,
      Value<String?>? category,
      Value<String>? txnDate,
      Value<int>? amountPaisa,
      Value<String>? paymentMethod,
      Value<String?>? walletId,
      Value<String?>? note,
      Value<int>? rowid}) {
    return IncomePersonalCompanion(
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      version: version ?? this.version,
      syncStatus: syncStatus ?? this.syncStatus,
      id: id ?? this.id,
      userId: userId ?? this.userId,
      title: title ?? this.title,
      category: category ?? this.category,
      txnDate: txnDate ?? this.txnDate,
      amountPaisa: amountPaisa ?? this.amountPaisa,
      paymentMethod: paymentMethod ?? this.paymentMethod,
      walletId: walletId ?? this.walletId,
      note: note ?? this.note,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (createdAt.present) {
      map['created_at'] = Variable<String>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<String>(updatedAt.value);
    }
    if (deletedAt.present) {
      map['deleted_at'] = Variable<String>(deletedAt.value);
    }
    if (version.present) {
      map['version'] = Variable<int>(version.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<String>(userId.value);
    }
    if (title.present) {
      map['title'] = Variable<String>(title.value);
    }
    if (category.present) {
      map['category'] = Variable<String>(category.value);
    }
    if (txnDate.present) {
      map['txn_date'] = Variable<String>(txnDate.value);
    }
    if (amountPaisa.present) {
      map['amount_paisa'] = Variable<int>(amountPaisa.value);
    }
    if (paymentMethod.present) {
      map['payment_method'] = Variable<String>(paymentMethod.value);
    }
    if (walletId.present) {
      map['wallet_id'] = Variable<String>(walletId.value);
    }
    if (note.present) {
      map['note'] = Variable<String>(note.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('IncomePersonalCompanion(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('title: $title, ')
          ..write('category: $category, ')
          ..write('txnDate: $txnDate, ')
          ..write('amountPaisa: $amountPaisa, ')
          ..write('paymentMethod: $paymentMethod, ')
          ..write('walletId: $walletId, ')
          ..write('note: $note, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $CategoriesTable extends Categories
    with TableInfo<$CategoriesTable, Category> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CategoriesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<String> createdAt = GeneratedColumn<String>(
      'created_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<String> updatedAt = GeneratedColumn<String>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _deletedAtMeta =
      const VerificationMeta('deletedAt');
  @override
  late final GeneratedColumn<String> deletedAt = GeneratedColumn<String>(
      'deleted_at', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _versionMeta =
      const VerificationMeta('version');
  @override
  late final GeneratedColumn<int> version = GeneratedColumn<int>(
      'version', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('pending'));
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<String> userId = GeneratedColumn<String>(
      'user_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _iconMeta = const VerificationMeta('icon');
  @override
  late final GeneratedColumn<String> icon = GeneratedColumn<String>(
      'icon', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _colorHexMeta =
      const VerificationMeta('colorHex');
  @override
  late final GeneratedColumn<String> colorHex = GeneratedColumn<String>(
      'color_hex', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _scopeMeta = const VerificationMeta('scope');
  @override
  late final GeneratedColumn<String> scope = GeneratedColumn<String>(
      'scope', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('expense'));
  static const VerificationMeta _isSystemMeta =
      const VerificationMeta('isSystem');
  @override
  late final GeneratedColumn<bool> isSystem = GeneratedColumn<bool>(
      'is_system', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_system" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _sortOrderMeta =
      const VerificationMeta('sortOrder');
  @override
  late final GeneratedColumn<int> sortOrder = GeneratedColumn<int>(
      'sort_order', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  @override
  List<GeneratedColumn> get $columns => [
        createdAt,
        updatedAt,
        deletedAt,
        version,
        syncStatus,
        id,
        userId,
        name,
        icon,
        colorHex,
        scope,
        isSystem,
        sortOrder
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'categories';
  @override
  VerificationContext validateIntegrity(Insertable<Category> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    if (data.containsKey('deleted_at')) {
      context.handle(_deletedAtMeta,
          deletedAt.isAcceptableOrUnknown(data['deleted_at']!, _deletedAtMeta));
    }
    if (data.containsKey('version')) {
      context.handle(_versionMeta,
          version.isAcceptableOrUnknown(data['version']!, _versionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('user_id')) {
      context.handle(_userIdMeta,
          userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta));
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    } else if (isInserting) {
      context.missing(_nameMeta);
    }
    if (data.containsKey('icon')) {
      context.handle(
          _iconMeta, icon.isAcceptableOrUnknown(data['icon']!, _iconMeta));
    }
    if (data.containsKey('color_hex')) {
      context.handle(_colorHexMeta,
          colorHex.isAcceptableOrUnknown(data['color_hex']!, _colorHexMeta));
    }
    if (data.containsKey('scope')) {
      context.handle(
          _scopeMeta, scope.isAcceptableOrUnknown(data['scope']!, _scopeMeta));
    }
    if (data.containsKey('is_system')) {
      context.handle(_isSystemMeta,
          isSystem.isAcceptableOrUnknown(data['is_system']!, _isSystemMeta));
    }
    if (data.containsKey('sort_order')) {
      context.handle(_sortOrderMeta,
          sortOrder.isAcceptableOrUnknown(data['sort_order']!, _sortOrderMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Category map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Category(
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}updated_at'])!,
      deletedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}deleted_at']),
      version: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}version'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      userId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}user_id'])!,
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name'])!,
      icon: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}icon']),
      colorHex: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}color_hex']),
      scope: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}scope'])!,
      isSystem: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_system'])!,
      sortOrder: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}sort_order'])!,
    );
  }

  @override
  $CategoriesTable createAlias(String alias) {
    return $CategoriesTable(attachedDatabase, alias);
  }
}

class Category extends DataClass implements Insertable<Category> {
  final String createdAt;
  final String updatedAt;
  final String? deletedAt;
  final int version;
  final String syncStatus;
  final String id;
  final String userId;
  final String name;
  final String? icon;
  final String? colorHex;
  final String scope;
  final bool isSystem;
  final int sortOrder;
  const Category(
      {required this.createdAt,
      required this.updatedAt,
      this.deletedAt,
      required this.version,
      required this.syncStatus,
      required this.id,
      required this.userId,
      required this.name,
      this.icon,
      this.colorHex,
      required this.scope,
      required this.isSystem,
      required this.sortOrder});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['created_at'] = Variable<String>(createdAt);
    map['updated_at'] = Variable<String>(updatedAt);
    if (!nullToAbsent || deletedAt != null) {
      map['deleted_at'] = Variable<String>(deletedAt);
    }
    map['version'] = Variable<int>(version);
    map['sync_status'] = Variable<String>(syncStatus);
    map['id'] = Variable<String>(id);
    map['user_id'] = Variable<String>(userId);
    map['name'] = Variable<String>(name);
    if (!nullToAbsent || icon != null) {
      map['icon'] = Variable<String>(icon);
    }
    if (!nullToAbsent || colorHex != null) {
      map['color_hex'] = Variable<String>(colorHex);
    }
    map['scope'] = Variable<String>(scope);
    map['is_system'] = Variable<bool>(isSystem);
    map['sort_order'] = Variable<int>(sortOrder);
    return map;
  }

  CategoriesCompanion toCompanion(bool nullToAbsent) {
    return CategoriesCompanion(
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      deletedAt: deletedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(deletedAt),
      version: Value(version),
      syncStatus: Value(syncStatus),
      id: Value(id),
      userId: Value(userId),
      name: Value(name),
      icon: icon == null && nullToAbsent ? const Value.absent() : Value(icon),
      colorHex: colorHex == null && nullToAbsent
          ? const Value.absent()
          : Value(colorHex),
      scope: Value(scope),
      isSystem: Value(isSystem),
      sortOrder: Value(sortOrder),
    );
  }

  factory Category.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Category(
      createdAt: serializer.fromJson<String>(json['createdAt']),
      updatedAt: serializer.fromJson<String>(json['updatedAt']),
      deletedAt: serializer.fromJson<String?>(json['deletedAt']),
      version: serializer.fromJson<int>(json['version']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      id: serializer.fromJson<String>(json['id']),
      userId: serializer.fromJson<String>(json['userId']),
      name: serializer.fromJson<String>(json['name']),
      icon: serializer.fromJson<String?>(json['icon']),
      colorHex: serializer.fromJson<String?>(json['colorHex']),
      scope: serializer.fromJson<String>(json['scope']),
      isSystem: serializer.fromJson<bool>(json['isSystem']),
      sortOrder: serializer.fromJson<int>(json['sortOrder']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'createdAt': serializer.toJson<String>(createdAt),
      'updatedAt': serializer.toJson<String>(updatedAt),
      'deletedAt': serializer.toJson<String?>(deletedAt),
      'version': serializer.toJson<int>(version),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'id': serializer.toJson<String>(id),
      'userId': serializer.toJson<String>(userId),
      'name': serializer.toJson<String>(name),
      'icon': serializer.toJson<String?>(icon),
      'colorHex': serializer.toJson<String?>(colorHex),
      'scope': serializer.toJson<String>(scope),
      'isSystem': serializer.toJson<bool>(isSystem),
      'sortOrder': serializer.toJson<int>(sortOrder),
    };
  }

  Category copyWith(
          {String? createdAt,
          String? updatedAt,
          Value<String?> deletedAt = const Value.absent(),
          int? version,
          String? syncStatus,
          String? id,
          String? userId,
          String? name,
          Value<String?> icon = const Value.absent(),
          Value<String?> colorHex = const Value.absent(),
          String? scope,
          bool? isSystem,
          int? sortOrder}) =>
      Category(
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: deletedAt.present ? deletedAt.value : this.deletedAt,
        version: version ?? this.version,
        syncStatus: syncStatus ?? this.syncStatus,
        id: id ?? this.id,
        userId: userId ?? this.userId,
        name: name ?? this.name,
        icon: icon.present ? icon.value : this.icon,
        colorHex: colorHex.present ? colorHex.value : this.colorHex,
        scope: scope ?? this.scope,
        isSystem: isSystem ?? this.isSystem,
        sortOrder: sortOrder ?? this.sortOrder,
      );
  Category copyWithCompanion(CategoriesCompanion data) {
    return Category(
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      deletedAt: data.deletedAt.present ? data.deletedAt.value : this.deletedAt,
      version: data.version.present ? data.version.value : this.version,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      id: data.id.present ? data.id.value : this.id,
      userId: data.userId.present ? data.userId.value : this.userId,
      name: data.name.present ? data.name.value : this.name,
      icon: data.icon.present ? data.icon.value : this.icon,
      colorHex: data.colorHex.present ? data.colorHex.value : this.colorHex,
      scope: data.scope.present ? data.scope.value : this.scope,
      isSystem: data.isSystem.present ? data.isSystem.value : this.isSystem,
      sortOrder: data.sortOrder.present ? data.sortOrder.value : this.sortOrder,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Category(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('name: $name, ')
          ..write('icon: $icon, ')
          ..write('colorHex: $colorHex, ')
          ..write('scope: $scope, ')
          ..write('isSystem: $isSystem, ')
          ..write('sortOrder: $sortOrder')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(createdAt, updatedAt, deletedAt, version,
      syncStatus, id, userId, name, icon, colorHex, scope, isSystem, sortOrder);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Category &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.deletedAt == this.deletedAt &&
          other.version == this.version &&
          other.syncStatus == this.syncStatus &&
          other.id == this.id &&
          other.userId == this.userId &&
          other.name == this.name &&
          other.icon == this.icon &&
          other.colorHex == this.colorHex &&
          other.scope == this.scope &&
          other.isSystem == this.isSystem &&
          other.sortOrder == this.sortOrder);
}

class CategoriesCompanion extends UpdateCompanion<Category> {
  final Value<String> createdAt;
  final Value<String> updatedAt;
  final Value<String?> deletedAt;
  final Value<int> version;
  final Value<String> syncStatus;
  final Value<String> id;
  final Value<String> userId;
  final Value<String> name;
  final Value<String?> icon;
  final Value<String?> colorHex;
  final Value<String> scope;
  final Value<bool> isSystem;
  final Value<int> sortOrder;
  final Value<int> rowid;
  const CategoriesCompanion({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.id = const Value.absent(),
    this.userId = const Value.absent(),
    this.name = const Value.absent(),
    this.icon = const Value.absent(),
    this.colorHex = const Value.absent(),
    this.scope = const Value.absent(),
    this.isSystem = const Value.absent(),
    this.sortOrder = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  CategoriesCompanion.insert({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    required String id,
    required String userId,
    required String name,
    this.icon = const Value.absent(),
    this.colorHex = const Value.absent(),
    this.scope = const Value.absent(),
    this.isSystem = const Value.absent(),
    this.sortOrder = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        userId = Value(userId),
        name = Value(name);
  static Insertable<Category> custom({
    Expression<String>? createdAt,
    Expression<String>? updatedAt,
    Expression<String>? deletedAt,
    Expression<int>? version,
    Expression<String>? syncStatus,
    Expression<String>? id,
    Expression<String>? userId,
    Expression<String>? name,
    Expression<String>? icon,
    Expression<String>? colorHex,
    Expression<String>? scope,
    Expression<bool>? isSystem,
    Expression<int>? sortOrder,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (deletedAt != null) 'deleted_at': deletedAt,
      if (version != null) 'version': version,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (id != null) 'id': id,
      if (userId != null) 'user_id': userId,
      if (name != null) 'name': name,
      if (icon != null) 'icon': icon,
      if (colorHex != null) 'color_hex': colorHex,
      if (scope != null) 'scope': scope,
      if (isSystem != null) 'is_system': isSystem,
      if (sortOrder != null) 'sort_order': sortOrder,
      if (rowid != null) 'rowid': rowid,
    });
  }

  CategoriesCompanion copyWith(
      {Value<String>? createdAt,
      Value<String>? updatedAt,
      Value<String?>? deletedAt,
      Value<int>? version,
      Value<String>? syncStatus,
      Value<String>? id,
      Value<String>? userId,
      Value<String>? name,
      Value<String?>? icon,
      Value<String?>? colorHex,
      Value<String>? scope,
      Value<bool>? isSystem,
      Value<int>? sortOrder,
      Value<int>? rowid}) {
    return CategoriesCompanion(
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      version: version ?? this.version,
      syncStatus: syncStatus ?? this.syncStatus,
      id: id ?? this.id,
      userId: userId ?? this.userId,
      name: name ?? this.name,
      icon: icon ?? this.icon,
      colorHex: colorHex ?? this.colorHex,
      scope: scope ?? this.scope,
      isSystem: isSystem ?? this.isSystem,
      sortOrder: sortOrder ?? this.sortOrder,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (createdAt.present) {
      map['created_at'] = Variable<String>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<String>(updatedAt.value);
    }
    if (deletedAt.present) {
      map['deleted_at'] = Variable<String>(deletedAt.value);
    }
    if (version.present) {
      map['version'] = Variable<int>(version.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<String>(userId.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (icon.present) {
      map['icon'] = Variable<String>(icon.value);
    }
    if (colorHex.present) {
      map['color_hex'] = Variable<String>(colorHex.value);
    }
    if (scope.present) {
      map['scope'] = Variable<String>(scope.value);
    }
    if (isSystem.present) {
      map['is_system'] = Variable<bool>(isSystem.value);
    }
    if (sortOrder.present) {
      map['sort_order'] = Variable<int>(sortOrder.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CategoriesCompanion(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('name: $name, ')
          ..write('icon: $icon, ')
          ..write('colorHex: $colorHex, ')
          ..write('scope: $scope, ')
          ..write('isSystem: $isSystem, ')
          ..write('sortOrder: $sortOrder, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $ProductsTable extends Products with TableInfo<$ProductsTable, Product> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProductsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<String> createdAt = GeneratedColumn<String>(
      'created_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<String> updatedAt = GeneratedColumn<String>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _deletedAtMeta =
      const VerificationMeta('deletedAt');
  @override
  late final GeneratedColumn<String> deletedAt = GeneratedColumn<String>(
      'deleted_at', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _versionMeta =
      const VerificationMeta('version');
  @override
  late final GeneratedColumn<int> version = GeneratedColumn<int>(
      'version', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('pending'));
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<String> userId = GeneratedColumn<String>(
      'user_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _lastRatePaisaPerKgMeta =
      const VerificationMeta('lastRatePaisaPerKg');
  @override
  late final GeneratedColumn<int> lastRatePaisaPerKg = GeneratedColumn<int>(
      'last_rate_paisa_per_kg', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _unitMeta = const VerificationMeta('unit');
  @override
  late final GeneratedColumn<String> unit = GeneratedColumn<String>(
      'unit', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('kg'));
  @override
  List<GeneratedColumn> get $columns => [
        createdAt,
        updatedAt,
        deletedAt,
        version,
        syncStatus,
        id,
        userId,
        name,
        lastRatePaisaPerKg,
        unit
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'products';
  @override
  VerificationContext validateIntegrity(Insertable<Product> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    if (data.containsKey('deleted_at')) {
      context.handle(_deletedAtMeta,
          deletedAt.isAcceptableOrUnknown(data['deleted_at']!, _deletedAtMeta));
    }
    if (data.containsKey('version')) {
      context.handle(_versionMeta,
          version.isAcceptableOrUnknown(data['version']!, _versionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('user_id')) {
      context.handle(_userIdMeta,
          userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta));
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    } else if (isInserting) {
      context.missing(_nameMeta);
    }
    if (data.containsKey('last_rate_paisa_per_kg')) {
      context.handle(
          _lastRatePaisaPerKgMeta,
          lastRatePaisaPerKg.isAcceptableOrUnknown(
              data['last_rate_paisa_per_kg']!, _lastRatePaisaPerKgMeta));
    }
    if (data.containsKey('unit')) {
      context.handle(
          _unitMeta, unit.isAcceptableOrUnknown(data['unit']!, _unitMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Product map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Product(
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}updated_at'])!,
      deletedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}deleted_at']),
      version: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}version'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      userId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}user_id'])!,
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name'])!,
      lastRatePaisaPerKg: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}last_rate_paisa_per_kg']),
      unit: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}unit'])!,
    );
  }

  @override
  $ProductsTable createAlias(String alias) {
    return $ProductsTable(attachedDatabase, alias);
  }
}

class Product extends DataClass implements Insertable<Product> {
  final String createdAt;
  final String updatedAt;
  final String? deletedAt;
  final int version;
  final String syncStatus;
  final String id;
  final String userId;
  final String name;
  final int? lastRatePaisaPerKg;
  final String unit;
  const Product(
      {required this.createdAt,
      required this.updatedAt,
      this.deletedAt,
      required this.version,
      required this.syncStatus,
      required this.id,
      required this.userId,
      required this.name,
      this.lastRatePaisaPerKg,
      required this.unit});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['created_at'] = Variable<String>(createdAt);
    map['updated_at'] = Variable<String>(updatedAt);
    if (!nullToAbsent || deletedAt != null) {
      map['deleted_at'] = Variable<String>(deletedAt);
    }
    map['version'] = Variable<int>(version);
    map['sync_status'] = Variable<String>(syncStatus);
    map['id'] = Variable<String>(id);
    map['user_id'] = Variable<String>(userId);
    map['name'] = Variable<String>(name);
    if (!nullToAbsent || lastRatePaisaPerKg != null) {
      map['last_rate_paisa_per_kg'] = Variable<int>(lastRatePaisaPerKg);
    }
    map['unit'] = Variable<String>(unit);
    return map;
  }

  ProductsCompanion toCompanion(bool nullToAbsent) {
    return ProductsCompanion(
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      deletedAt: deletedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(deletedAt),
      version: Value(version),
      syncStatus: Value(syncStatus),
      id: Value(id),
      userId: Value(userId),
      name: Value(name),
      lastRatePaisaPerKg: lastRatePaisaPerKg == null && nullToAbsent
          ? const Value.absent()
          : Value(lastRatePaisaPerKg),
      unit: Value(unit),
    );
  }

  factory Product.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Product(
      createdAt: serializer.fromJson<String>(json['createdAt']),
      updatedAt: serializer.fromJson<String>(json['updatedAt']),
      deletedAt: serializer.fromJson<String?>(json['deletedAt']),
      version: serializer.fromJson<int>(json['version']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      id: serializer.fromJson<String>(json['id']),
      userId: serializer.fromJson<String>(json['userId']),
      name: serializer.fromJson<String>(json['name']),
      lastRatePaisaPerKg: serializer.fromJson<int?>(json['lastRatePaisaPerKg']),
      unit: serializer.fromJson<String>(json['unit']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'createdAt': serializer.toJson<String>(createdAt),
      'updatedAt': serializer.toJson<String>(updatedAt),
      'deletedAt': serializer.toJson<String?>(deletedAt),
      'version': serializer.toJson<int>(version),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'id': serializer.toJson<String>(id),
      'userId': serializer.toJson<String>(userId),
      'name': serializer.toJson<String>(name),
      'lastRatePaisaPerKg': serializer.toJson<int?>(lastRatePaisaPerKg),
      'unit': serializer.toJson<String>(unit),
    };
  }

  Product copyWith(
          {String? createdAt,
          String? updatedAt,
          Value<String?> deletedAt = const Value.absent(),
          int? version,
          String? syncStatus,
          String? id,
          String? userId,
          String? name,
          Value<int?> lastRatePaisaPerKg = const Value.absent(),
          String? unit}) =>
      Product(
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: deletedAt.present ? deletedAt.value : this.deletedAt,
        version: version ?? this.version,
        syncStatus: syncStatus ?? this.syncStatus,
        id: id ?? this.id,
        userId: userId ?? this.userId,
        name: name ?? this.name,
        lastRatePaisaPerKg: lastRatePaisaPerKg.present
            ? lastRatePaisaPerKg.value
            : this.lastRatePaisaPerKg,
        unit: unit ?? this.unit,
      );
  Product copyWithCompanion(ProductsCompanion data) {
    return Product(
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      deletedAt: data.deletedAt.present ? data.deletedAt.value : this.deletedAt,
      version: data.version.present ? data.version.value : this.version,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      id: data.id.present ? data.id.value : this.id,
      userId: data.userId.present ? data.userId.value : this.userId,
      name: data.name.present ? data.name.value : this.name,
      lastRatePaisaPerKg: data.lastRatePaisaPerKg.present
          ? data.lastRatePaisaPerKg.value
          : this.lastRatePaisaPerKg,
      unit: data.unit.present ? data.unit.value : this.unit,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Product(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('name: $name, ')
          ..write('lastRatePaisaPerKg: $lastRatePaisaPerKg, ')
          ..write('unit: $unit')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(createdAt, updatedAt, deletedAt, version,
      syncStatus, id, userId, name, lastRatePaisaPerKg, unit);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Product &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.deletedAt == this.deletedAt &&
          other.version == this.version &&
          other.syncStatus == this.syncStatus &&
          other.id == this.id &&
          other.userId == this.userId &&
          other.name == this.name &&
          other.lastRatePaisaPerKg == this.lastRatePaisaPerKg &&
          other.unit == this.unit);
}

class ProductsCompanion extends UpdateCompanion<Product> {
  final Value<String> createdAt;
  final Value<String> updatedAt;
  final Value<String?> deletedAt;
  final Value<int> version;
  final Value<String> syncStatus;
  final Value<String> id;
  final Value<String> userId;
  final Value<String> name;
  final Value<int?> lastRatePaisaPerKg;
  final Value<String> unit;
  final Value<int> rowid;
  const ProductsCompanion({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.id = const Value.absent(),
    this.userId = const Value.absent(),
    this.name = const Value.absent(),
    this.lastRatePaisaPerKg = const Value.absent(),
    this.unit = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  ProductsCompanion.insert({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    required String id,
    required String userId,
    required String name,
    this.lastRatePaisaPerKg = const Value.absent(),
    this.unit = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        userId = Value(userId),
        name = Value(name);
  static Insertable<Product> custom({
    Expression<String>? createdAt,
    Expression<String>? updatedAt,
    Expression<String>? deletedAt,
    Expression<int>? version,
    Expression<String>? syncStatus,
    Expression<String>? id,
    Expression<String>? userId,
    Expression<String>? name,
    Expression<int>? lastRatePaisaPerKg,
    Expression<String>? unit,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (deletedAt != null) 'deleted_at': deletedAt,
      if (version != null) 'version': version,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (id != null) 'id': id,
      if (userId != null) 'user_id': userId,
      if (name != null) 'name': name,
      if (lastRatePaisaPerKg != null)
        'last_rate_paisa_per_kg': lastRatePaisaPerKg,
      if (unit != null) 'unit': unit,
      if (rowid != null) 'rowid': rowid,
    });
  }

  ProductsCompanion copyWith(
      {Value<String>? createdAt,
      Value<String>? updatedAt,
      Value<String?>? deletedAt,
      Value<int>? version,
      Value<String>? syncStatus,
      Value<String>? id,
      Value<String>? userId,
      Value<String>? name,
      Value<int?>? lastRatePaisaPerKg,
      Value<String>? unit,
      Value<int>? rowid}) {
    return ProductsCompanion(
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      version: version ?? this.version,
      syncStatus: syncStatus ?? this.syncStatus,
      id: id ?? this.id,
      userId: userId ?? this.userId,
      name: name ?? this.name,
      lastRatePaisaPerKg: lastRatePaisaPerKg ?? this.lastRatePaisaPerKg,
      unit: unit ?? this.unit,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (createdAt.present) {
      map['created_at'] = Variable<String>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<String>(updatedAt.value);
    }
    if (deletedAt.present) {
      map['deleted_at'] = Variable<String>(deletedAt.value);
    }
    if (version.present) {
      map['version'] = Variable<int>(version.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<String>(userId.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (lastRatePaisaPerKg.present) {
      map['last_rate_paisa_per_kg'] = Variable<int>(lastRatePaisaPerKg.value);
    }
    if (unit.present) {
      map['unit'] = Variable<String>(unit.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProductsCompanion(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('name: $name, ')
          ..write('lastRatePaisaPerKg: $lastRatePaisaPerKg, ')
          ..write('unit: $unit, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $ExpensesTable extends Expenses with TableInfo<$ExpensesTable, Expense> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ExpensesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<String> createdAt = GeneratedColumn<String>(
      'created_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<String> updatedAt = GeneratedColumn<String>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _deletedAtMeta =
      const VerificationMeta('deletedAt');
  @override
  late final GeneratedColumn<String> deletedAt = GeneratedColumn<String>(
      'deleted_at', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _versionMeta =
      const VerificationMeta('version');
  @override
  late final GeneratedColumn<int> version = GeneratedColumn<int>(
      'version', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('pending'));
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<String> userId = GeneratedColumn<String>(
      'user_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _scopeMeta = const VerificationMeta('scope');
  @override
  late final GeneratedColumn<String> scope = GeneratedColumn<String>(
      'scope', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('personal'));
  static const VerificationMeta _hatIdMeta = const VerificationMeta('hatId');
  @override
  late final GeneratedColumn<String> hatId = GeneratedColumn<String>(
      'hat_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _sessionIdMeta =
      const VerificationMeta('sessionId');
  @override
  late final GeneratedColumn<String> sessionId = GeneratedColumn<String>(
      'session_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _categoryIdMeta =
      const VerificationMeta('categoryId');
  @override
  late final GeneratedColumn<String> categoryId = GeneratedColumn<String>(
      'category_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _txnDateMeta =
      const VerificationMeta('txnDate');
  @override
  late final GeneratedColumn<String> txnDate = GeneratedColumn<String>(
      'txn_date', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _amountPaisaMeta =
      const VerificationMeta('amountPaisa');
  @override
  late final GeneratedColumn<int> amountPaisa = GeneratedColumn<int>(
      'amount_paisa', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _paymentMethodMeta =
      const VerificationMeta('paymentMethod');
  @override
  late final GeneratedColumn<String> paymentMethod = GeneratedColumn<String>(
      'payment_method', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('cash'));
  static const VerificationMeta _walletIdMeta =
      const VerificationMeta('walletId');
  @override
  late final GeneratedColumn<String> walletId = GeneratedColumn<String>(
      'wallet_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _noteMeta = const VerificationMeta('note');
  @override
  late final GeneratedColumn<String> note = GeneratedColumn<String>(
      'note', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        createdAt,
        updatedAt,
        deletedAt,
        version,
        syncStatus,
        id,
        userId,
        scope,
        hatId,
        sessionId,
        categoryId,
        txnDate,
        amountPaisa,
        paymentMethod,
        walletId,
        note
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'expenses';
  @override
  VerificationContext validateIntegrity(Insertable<Expense> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    if (data.containsKey('deleted_at')) {
      context.handle(_deletedAtMeta,
          deletedAt.isAcceptableOrUnknown(data['deleted_at']!, _deletedAtMeta));
    }
    if (data.containsKey('version')) {
      context.handle(_versionMeta,
          version.isAcceptableOrUnknown(data['version']!, _versionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('user_id')) {
      context.handle(_userIdMeta,
          userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta));
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('scope')) {
      context.handle(
          _scopeMeta, scope.isAcceptableOrUnknown(data['scope']!, _scopeMeta));
    }
    if (data.containsKey('hat_id')) {
      context.handle(
          _hatIdMeta, hatId.isAcceptableOrUnknown(data['hat_id']!, _hatIdMeta));
    }
    if (data.containsKey('session_id')) {
      context.handle(_sessionIdMeta,
          sessionId.isAcceptableOrUnknown(data['session_id']!, _sessionIdMeta));
    }
    if (data.containsKey('category_id')) {
      context.handle(
          _categoryIdMeta,
          categoryId.isAcceptableOrUnknown(
              data['category_id']!, _categoryIdMeta));
    }
    if (data.containsKey('txn_date')) {
      context.handle(_txnDateMeta,
          txnDate.isAcceptableOrUnknown(data['txn_date']!, _txnDateMeta));
    } else if (isInserting) {
      context.missing(_txnDateMeta);
    }
    if (data.containsKey('amount_paisa')) {
      context.handle(
          _amountPaisaMeta,
          amountPaisa.isAcceptableOrUnknown(
              data['amount_paisa']!, _amountPaisaMeta));
    } else if (isInserting) {
      context.missing(_amountPaisaMeta);
    }
    if (data.containsKey('payment_method')) {
      context.handle(
          _paymentMethodMeta,
          paymentMethod.isAcceptableOrUnknown(
              data['payment_method']!, _paymentMethodMeta));
    }
    if (data.containsKey('wallet_id')) {
      context.handle(_walletIdMeta,
          walletId.isAcceptableOrUnknown(data['wallet_id']!, _walletIdMeta));
    }
    if (data.containsKey('note')) {
      context.handle(
          _noteMeta, note.isAcceptableOrUnknown(data['note']!, _noteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Expense map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Expense(
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}updated_at'])!,
      deletedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}deleted_at']),
      version: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}version'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      userId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}user_id'])!,
      scope: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}scope'])!,
      hatId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}hat_id']),
      sessionId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}session_id']),
      categoryId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}category_id']),
      txnDate: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}txn_date'])!,
      amountPaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}amount_paisa'])!,
      paymentMethod: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}payment_method'])!,
      walletId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}wallet_id']),
      note: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}note']),
    );
  }

  @override
  $ExpensesTable createAlias(String alias) {
    return $ExpensesTable(attachedDatabase, alias);
  }
}

class Expense extends DataClass implements Insertable<Expense> {
  final String createdAt;
  final String updatedAt;
  final String? deletedAt;
  final int version;
  final String syncStatus;
  final String id;
  final String userId;
  final String scope;
  final String? hatId;
  final String? sessionId;
  final String? categoryId;
  final String txnDate;
  final int amountPaisa;
  final String paymentMethod;
  final String? walletId;
  final String? note;
  const Expense(
      {required this.createdAt,
      required this.updatedAt,
      this.deletedAt,
      required this.version,
      required this.syncStatus,
      required this.id,
      required this.userId,
      required this.scope,
      this.hatId,
      this.sessionId,
      this.categoryId,
      required this.txnDate,
      required this.amountPaisa,
      required this.paymentMethod,
      this.walletId,
      this.note});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['created_at'] = Variable<String>(createdAt);
    map['updated_at'] = Variable<String>(updatedAt);
    if (!nullToAbsent || deletedAt != null) {
      map['deleted_at'] = Variable<String>(deletedAt);
    }
    map['version'] = Variable<int>(version);
    map['sync_status'] = Variable<String>(syncStatus);
    map['id'] = Variable<String>(id);
    map['user_id'] = Variable<String>(userId);
    map['scope'] = Variable<String>(scope);
    if (!nullToAbsent || hatId != null) {
      map['hat_id'] = Variable<String>(hatId);
    }
    if (!nullToAbsent || sessionId != null) {
      map['session_id'] = Variable<String>(sessionId);
    }
    if (!nullToAbsent || categoryId != null) {
      map['category_id'] = Variable<String>(categoryId);
    }
    map['txn_date'] = Variable<String>(txnDate);
    map['amount_paisa'] = Variable<int>(amountPaisa);
    map['payment_method'] = Variable<String>(paymentMethod);
    if (!nullToAbsent || walletId != null) {
      map['wallet_id'] = Variable<String>(walletId);
    }
    if (!nullToAbsent || note != null) {
      map['note'] = Variable<String>(note);
    }
    return map;
  }

  ExpensesCompanion toCompanion(bool nullToAbsent) {
    return ExpensesCompanion(
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      deletedAt: deletedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(deletedAt),
      version: Value(version),
      syncStatus: Value(syncStatus),
      id: Value(id),
      userId: Value(userId),
      scope: Value(scope),
      hatId:
          hatId == null && nullToAbsent ? const Value.absent() : Value(hatId),
      sessionId: sessionId == null && nullToAbsent
          ? const Value.absent()
          : Value(sessionId),
      categoryId: categoryId == null && nullToAbsent
          ? const Value.absent()
          : Value(categoryId),
      txnDate: Value(txnDate),
      amountPaisa: Value(amountPaisa),
      paymentMethod: Value(paymentMethod),
      walletId: walletId == null && nullToAbsent
          ? const Value.absent()
          : Value(walletId),
      note: note == null && nullToAbsent ? const Value.absent() : Value(note),
    );
  }

  factory Expense.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Expense(
      createdAt: serializer.fromJson<String>(json['createdAt']),
      updatedAt: serializer.fromJson<String>(json['updatedAt']),
      deletedAt: serializer.fromJson<String?>(json['deletedAt']),
      version: serializer.fromJson<int>(json['version']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      id: serializer.fromJson<String>(json['id']),
      userId: serializer.fromJson<String>(json['userId']),
      scope: serializer.fromJson<String>(json['scope']),
      hatId: serializer.fromJson<String?>(json['hatId']),
      sessionId: serializer.fromJson<String?>(json['sessionId']),
      categoryId: serializer.fromJson<String?>(json['categoryId']),
      txnDate: serializer.fromJson<String>(json['txnDate']),
      amountPaisa: serializer.fromJson<int>(json['amountPaisa']),
      paymentMethod: serializer.fromJson<String>(json['paymentMethod']),
      walletId: serializer.fromJson<String?>(json['walletId']),
      note: serializer.fromJson<String?>(json['note']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'createdAt': serializer.toJson<String>(createdAt),
      'updatedAt': serializer.toJson<String>(updatedAt),
      'deletedAt': serializer.toJson<String?>(deletedAt),
      'version': serializer.toJson<int>(version),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'id': serializer.toJson<String>(id),
      'userId': serializer.toJson<String>(userId),
      'scope': serializer.toJson<String>(scope),
      'hatId': serializer.toJson<String?>(hatId),
      'sessionId': serializer.toJson<String?>(sessionId),
      'categoryId': serializer.toJson<String?>(categoryId),
      'txnDate': serializer.toJson<String>(txnDate),
      'amountPaisa': serializer.toJson<int>(amountPaisa),
      'paymentMethod': serializer.toJson<String>(paymentMethod),
      'walletId': serializer.toJson<String?>(walletId),
      'note': serializer.toJson<String?>(note),
    };
  }

  Expense copyWith(
          {String? createdAt,
          String? updatedAt,
          Value<String?> deletedAt = const Value.absent(),
          int? version,
          String? syncStatus,
          String? id,
          String? userId,
          String? scope,
          Value<String?> hatId = const Value.absent(),
          Value<String?> sessionId = const Value.absent(),
          Value<String?> categoryId = const Value.absent(),
          String? txnDate,
          int? amountPaisa,
          String? paymentMethod,
          Value<String?> walletId = const Value.absent(),
          Value<String?> note = const Value.absent()}) =>
      Expense(
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: deletedAt.present ? deletedAt.value : this.deletedAt,
        version: version ?? this.version,
        syncStatus: syncStatus ?? this.syncStatus,
        id: id ?? this.id,
        userId: userId ?? this.userId,
        scope: scope ?? this.scope,
        hatId: hatId.present ? hatId.value : this.hatId,
        sessionId: sessionId.present ? sessionId.value : this.sessionId,
        categoryId: categoryId.present ? categoryId.value : this.categoryId,
        txnDate: txnDate ?? this.txnDate,
        amountPaisa: amountPaisa ?? this.amountPaisa,
        paymentMethod: paymentMethod ?? this.paymentMethod,
        walletId: walletId.present ? walletId.value : this.walletId,
        note: note.present ? note.value : this.note,
      );
  Expense copyWithCompanion(ExpensesCompanion data) {
    return Expense(
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      deletedAt: data.deletedAt.present ? data.deletedAt.value : this.deletedAt,
      version: data.version.present ? data.version.value : this.version,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      id: data.id.present ? data.id.value : this.id,
      userId: data.userId.present ? data.userId.value : this.userId,
      scope: data.scope.present ? data.scope.value : this.scope,
      hatId: data.hatId.present ? data.hatId.value : this.hatId,
      sessionId: data.sessionId.present ? data.sessionId.value : this.sessionId,
      categoryId:
          data.categoryId.present ? data.categoryId.value : this.categoryId,
      txnDate: data.txnDate.present ? data.txnDate.value : this.txnDate,
      amountPaisa:
          data.amountPaisa.present ? data.amountPaisa.value : this.amountPaisa,
      paymentMethod: data.paymentMethod.present
          ? data.paymentMethod.value
          : this.paymentMethod,
      walletId: data.walletId.present ? data.walletId.value : this.walletId,
      note: data.note.present ? data.note.value : this.note,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Expense(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('scope: $scope, ')
          ..write('hatId: $hatId, ')
          ..write('sessionId: $sessionId, ')
          ..write('categoryId: $categoryId, ')
          ..write('txnDate: $txnDate, ')
          ..write('amountPaisa: $amountPaisa, ')
          ..write('paymentMethod: $paymentMethod, ')
          ..write('walletId: $walletId, ')
          ..write('note: $note')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      createdAt,
      updatedAt,
      deletedAt,
      version,
      syncStatus,
      id,
      userId,
      scope,
      hatId,
      sessionId,
      categoryId,
      txnDate,
      amountPaisa,
      paymentMethod,
      walletId,
      note);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Expense &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.deletedAt == this.deletedAt &&
          other.version == this.version &&
          other.syncStatus == this.syncStatus &&
          other.id == this.id &&
          other.userId == this.userId &&
          other.scope == this.scope &&
          other.hatId == this.hatId &&
          other.sessionId == this.sessionId &&
          other.categoryId == this.categoryId &&
          other.txnDate == this.txnDate &&
          other.amountPaisa == this.amountPaisa &&
          other.paymentMethod == this.paymentMethod &&
          other.walletId == this.walletId &&
          other.note == this.note);
}

class ExpensesCompanion extends UpdateCompanion<Expense> {
  final Value<String> createdAt;
  final Value<String> updatedAt;
  final Value<String?> deletedAt;
  final Value<int> version;
  final Value<String> syncStatus;
  final Value<String> id;
  final Value<String> userId;
  final Value<String> scope;
  final Value<String?> hatId;
  final Value<String?> sessionId;
  final Value<String?> categoryId;
  final Value<String> txnDate;
  final Value<int> amountPaisa;
  final Value<String> paymentMethod;
  final Value<String?> walletId;
  final Value<String?> note;
  final Value<int> rowid;
  const ExpensesCompanion({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.id = const Value.absent(),
    this.userId = const Value.absent(),
    this.scope = const Value.absent(),
    this.hatId = const Value.absent(),
    this.sessionId = const Value.absent(),
    this.categoryId = const Value.absent(),
    this.txnDate = const Value.absent(),
    this.amountPaisa = const Value.absent(),
    this.paymentMethod = const Value.absent(),
    this.walletId = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  ExpensesCompanion.insert({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    required String id,
    required String userId,
    this.scope = const Value.absent(),
    this.hatId = const Value.absent(),
    this.sessionId = const Value.absent(),
    this.categoryId = const Value.absent(),
    required String txnDate,
    required int amountPaisa,
    this.paymentMethod = const Value.absent(),
    this.walletId = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        userId = Value(userId),
        txnDate = Value(txnDate),
        amountPaisa = Value(amountPaisa);
  static Insertable<Expense> custom({
    Expression<String>? createdAt,
    Expression<String>? updatedAt,
    Expression<String>? deletedAt,
    Expression<int>? version,
    Expression<String>? syncStatus,
    Expression<String>? id,
    Expression<String>? userId,
    Expression<String>? scope,
    Expression<String>? hatId,
    Expression<String>? sessionId,
    Expression<String>? categoryId,
    Expression<String>? txnDate,
    Expression<int>? amountPaisa,
    Expression<String>? paymentMethod,
    Expression<String>? walletId,
    Expression<String>? note,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (deletedAt != null) 'deleted_at': deletedAt,
      if (version != null) 'version': version,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (id != null) 'id': id,
      if (userId != null) 'user_id': userId,
      if (scope != null) 'scope': scope,
      if (hatId != null) 'hat_id': hatId,
      if (sessionId != null) 'session_id': sessionId,
      if (categoryId != null) 'category_id': categoryId,
      if (txnDate != null) 'txn_date': txnDate,
      if (amountPaisa != null) 'amount_paisa': amountPaisa,
      if (paymentMethod != null) 'payment_method': paymentMethod,
      if (walletId != null) 'wallet_id': walletId,
      if (note != null) 'note': note,
      if (rowid != null) 'rowid': rowid,
    });
  }

  ExpensesCompanion copyWith(
      {Value<String>? createdAt,
      Value<String>? updatedAt,
      Value<String?>? deletedAt,
      Value<int>? version,
      Value<String>? syncStatus,
      Value<String>? id,
      Value<String>? userId,
      Value<String>? scope,
      Value<String?>? hatId,
      Value<String?>? sessionId,
      Value<String?>? categoryId,
      Value<String>? txnDate,
      Value<int>? amountPaisa,
      Value<String>? paymentMethod,
      Value<String?>? walletId,
      Value<String?>? note,
      Value<int>? rowid}) {
    return ExpensesCompanion(
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      version: version ?? this.version,
      syncStatus: syncStatus ?? this.syncStatus,
      id: id ?? this.id,
      userId: userId ?? this.userId,
      scope: scope ?? this.scope,
      hatId: hatId ?? this.hatId,
      sessionId: sessionId ?? this.sessionId,
      categoryId: categoryId ?? this.categoryId,
      txnDate: txnDate ?? this.txnDate,
      amountPaisa: amountPaisa ?? this.amountPaisa,
      paymentMethod: paymentMethod ?? this.paymentMethod,
      walletId: walletId ?? this.walletId,
      note: note ?? this.note,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (createdAt.present) {
      map['created_at'] = Variable<String>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<String>(updatedAt.value);
    }
    if (deletedAt.present) {
      map['deleted_at'] = Variable<String>(deletedAt.value);
    }
    if (version.present) {
      map['version'] = Variable<int>(version.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<String>(userId.value);
    }
    if (scope.present) {
      map['scope'] = Variable<String>(scope.value);
    }
    if (hatId.present) {
      map['hat_id'] = Variable<String>(hatId.value);
    }
    if (sessionId.present) {
      map['session_id'] = Variable<String>(sessionId.value);
    }
    if (categoryId.present) {
      map['category_id'] = Variable<String>(categoryId.value);
    }
    if (txnDate.present) {
      map['txn_date'] = Variable<String>(txnDate.value);
    }
    if (amountPaisa.present) {
      map['amount_paisa'] = Variable<int>(amountPaisa.value);
    }
    if (paymentMethod.present) {
      map['payment_method'] = Variable<String>(paymentMethod.value);
    }
    if (walletId.present) {
      map['wallet_id'] = Variable<String>(walletId.value);
    }
    if (note.present) {
      map['note'] = Variable<String>(note.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ExpensesCompanion(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('scope: $scope, ')
          ..write('hatId: $hatId, ')
          ..write('sessionId: $sessionId, ')
          ..write('categoryId: $categoryId, ')
          ..write('txnDate: $txnDate, ')
          ..write('amountPaisa: $amountPaisa, ')
          ..write('paymentMethod: $paymentMethod, ')
          ..write('walletId: $walletId, ')
          ..write('note: $note, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $MotherPaymentsTable extends MotherPayments
    with TableInfo<$MotherPaymentsTable, MotherPayment> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $MotherPaymentsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<String> createdAt = GeneratedColumn<String>(
      'created_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<String> updatedAt = GeneratedColumn<String>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _deletedAtMeta =
      const VerificationMeta('deletedAt');
  @override
  late final GeneratedColumn<String> deletedAt = GeneratedColumn<String>(
      'deleted_at', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _versionMeta =
      const VerificationMeta('version');
  @override
  late final GeneratedColumn<int> version = GeneratedColumn<int>(
      'version', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('pending'));
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<String> userId = GeneratedColumn<String>(
      'user_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _txnDateMeta =
      const VerificationMeta('txnDate');
  @override
  late final GeneratedColumn<String> txnDate = GeneratedColumn<String>(
      'txn_date', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _amountPaisaMeta =
      const VerificationMeta('amountPaisa');
  @override
  late final GeneratedColumn<int> amountPaisa = GeneratedColumn<int>(
      'amount_paisa', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _paymentMethodMeta =
      const VerificationMeta('paymentMethod');
  @override
  late final GeneratedColumn<String> paymentMethod = GeneratedColumn<String>(
      'payment_method', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('cash'));
  static const VerificationMeta _walletIdMeta =
      const VerificationMeta('walletId');
  @override
  late final GeneratedColumn<String> walletId = GeneratedColumn<String>(
      'wallet_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _noteMeta = const VerificationMeta('note');
  @override
  late final GeneratedColumn<String> note = GeneratedColumn<String>(
      'note', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        createdAt,
        updatedAt,
        deletedAt,
        version,
        syncStatus,
        id,
        userId,
        txnDate,
        amountPaisa,
        paymentMethod,
        walletId,
        note
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'mother_payments';
  @override
  VerificationContext validateIntegrity(Insertable<MotherPayment> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    if (data.containsKey('deleted_at')) {
      context.handle(_deletedAtMeta,
          deletedAt.isAcceptableOrUnknown(data['deleted_at']!, _deletedAtMeta));
    }
    if (data.containsKey('version')) {
      context.handle(_versionMeta,
          version.isAcceptableOrUnknown(data['version']!, _versionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('user_id')) {
      context.handle(_userIdMeta,
          userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta));
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('txn_date')) {
      context.handle(_txnDateMeta,
          txnDate.isAcceptableOrUnknown(data['txn_date']!, _txnDateMeta));
    } else if (isInserting) {
      context.missing(_txnDateMeta);
    }
    if (data.containsKey('amount_paisa')) {
      context.handle(
          _amountPaisaMeta,
          amountPaisa.isAcceptableOrUnknown(
              data['amount_paisa']!, _amountPaisaMeta));
    } else if (isInserting) {
      context.missing(_amountPaisaMeta);
    }
    if (data.containsKey('payment_method')) {
      context.handle(
          _paymentMethodMeta,
          paymentMethod.isAcceptableOrUnknown(
              data['payment_method']!, _paymentMethodMeta));
    }
    if (data.containsKey('wallet_id')) {
      context.handle(_walletIdMeta,
          walletId.isAcceptableOrUnknown(data['wallet_id']!, _walletIdMeta));
    }
    if (data.containsKey('note')) {
      context.handle(
          _noteMeta, note.isAcceptableOrUnknown(data['note']!, _noteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  MotherPayment map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return MotherPayment(
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}updated_at'])!,
      deletedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}deleted_at']),
      version: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}version'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      userId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}user_id'])!,
      txnDate: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}txn_date'])!,
      amountPaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}amount_paisa'])!,
      paymentMethod: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}payment_method'])!,
      walletId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}wallet_id']),
      note: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}note']),
    );
  }

  @override
  $MotherPaymentsTable createAlias(String alias) {
    return $MotherPaymentsTable(attachedDatabase, alias);
  }
}

class MotherPayment extends DataClass implements Insertable<MotherPayment> {
  final String createdAt;
  final String updatedAt;
  final String? deletedAt;
  final int version;
  final String syncStatus;
  final String id;
  final String userId;
  final String txnDate;
  final int amountPaisa;
  final String paymentMethod;
  final String? walletId;
  final String? note;
  const MotherPayment(
      {required this.createdAt,
      required this.updatedAt,
      this.deletedAt,
      required this.version,
      required this.syncStatus,
      required this.id,
      required this.userId,
      required this.txnDate,
      required this.amountPaisa,
      required this.paymentMethod,
      this.walletId,
      this.note});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['created_at'] = Variable<String>(createdAt);
    map['updated_at'] = Variable<String>(updatedAt);
    if (!nullToAbsent || deletedAt != null) {
      map['deleted_at'] = Variable<String>(deletedAt);
    }
    map['version'] = Variable<int>(version);
    map['sync_status'] = Variable<String>(syncStatus);
    map['id'] = Variable<String>(id);
    map['user_id'] = Variable<String>(userId);
    map['txn_date'] = Variable<String>(txnDate);
    map['amount_paisa'] = Variable<int>(amountPaisa);
    map['payment_method'] = Variable<String>(paymentMethod);
    if (!nullToAbsent || walletId != null) {
      map['wallet_id'] = Variable<String>(walletId);
    }
    if (!nullToAbsent || note != null) {
      map['note'] = Variable<String>(note);
    }
    return map;
  }

  MotherPaymentsCompanion toCompanion(bool nullToAbsent) {
    return MotherPaymentsCompanion(
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      deletedAt: deletedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(deletedAt),
      version: Value(version),
      syncStatus: Value(syncStatus),
      id: Value(id),
      userId: Value(userId),
      txnDate: Value(txnDate),
      amountPaisa: Value(amountPaisa),
      paymentMethod: Value(paymentMethod),
      walletId: walletId == null && nullToAbsent
          ? const Value.absent()
          : Value(walletId),
      note: note == null && nullToAbsent ? const Value.absent() : Value(note),
    );
  }

  factory MotherPayment.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return MotherPayment(
      createdAt: serializer.fromJson<String>(json['createdAt']),
      updatedAt: serializer.fromJson<String>(json['updatedAt']),
      deletedAt: serializer.fromJson<String?>(json['deletedAt']),
      version: serializer.fromJson<int>(json['version']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      id: serializer.fromJson<String>(json['id']),
      userId: serializer.fromJson<String>(json['userId']),
      txnDate: serializer.fromJson<String>(json['txnDate']),
      amountPaisa: serializer.fromJson<int>(json['amountPaisa']),
      paymentMethod: serializer.fromJson<String>(json['paymentMethod']),
      walletId: serializer.fromJson<String?>(json['walletId']),
      note: serializer.fromJson<String?>(json['note']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'createdAt': serializer.toJson<String>(createdAt),
      'updatedAt': serializer.toJson<String>(updatedAt),
      'deletedAt': serializer.toJson<String?>(deletedAt),
      'version': serializer.toJson<int>(version),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'id': serializer.toJson<String>(id),
      'userId': serializer.toJson<String>(userId),
      'txnDate': serializer.toJson<String>(txnDate),
      'amountPaisa': serializer.toJson<int>(amountPaisa),
      'paymentMethod': serializer.toJson<String>(paymentMethod),
      'walletId': serializer.toJson<String?>(walletId),
      'note': serializer.toJson<String?>(note),
    };
  }

  MotherPayment copyWith(
          {String? createdAt,
          String? updatedAt,
          Value<String?> deletedAt = const Value.absent(),
          int? version,
          String? syncStatus,
          String? id,
          String? userId,
          String? txnDate,
          int? amountPaisa,
          String? paymentMethod,
          Value<String?> walletId = const Value.absent(),
          Value<String?> note = const Value.absent()}) =>
      MotherPayment(
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: deletedAt.present ? deletedAt.value : this.deletedAt,
        version: version ?? this.version,
        syncStatus: syncStatus ?? this.syncStatus,
        id: id ?? this.id,
        userId: userId ?? this.userId,
        txnDate: txnDate ?? this.txnDate,
        amountPaisa: amountPaisa ?? this.amountPaisa,
        paymentMethod: paymentMethod ?? this.paymentMethod,
        walletId: walletId.present ? walletId.value : this.walletId,
        note: note.present ? note.value : this.note,
      );
  MotherPayment copyWithCompanion(MotherPaymentsCompanion data) {
    return MotherPayment(
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      deletedAt: data.deletedAt.present ? data.deletedAt.value : this.deletedAt,
      version: data.version.present ? data.version.value : this.version,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      id: data.id.present ? data.id.value : this.id,
      userId: data.userId.present ? data.userId.value : this.userId,
      txnDate: data.txnDate.present ? data.txnDate.value : this.txnDate,
      amountPaisa:
          data.amountPaisa.present ? data.amountPaisa.value : this.amountPaisa,
      paymentMethod: data.paymentMethod.present
          ? data.paymentMethod.value
          : this.paymentMethod,
      walletId: data.walletId.present ? data.walletId.value : this.walletId,
      note: data.note.present ? data.note.value : this.note,
    );
  }

  @override
  String toString() {
    return (StringBuffer('MotherPayment(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('txnDate: $txnDate, ')
          ..write('amountPaisa: $amountPaisa, ')
          ..write('paymentMethod: $paymentMethod, ')
          ..write('walletId: $walletId, ')
          ..write('note: $note')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      createdAt,
      updatedAt,
      deletedAt,
      version,
      syncStatus,
      id,
      userId,
      txnDate,
      amountPaisa,
      paymentMethod,
      walletId,
      note);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is MotherPayment &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.deletedAt == this.deletedAt &&
          other.version == this.version &&
          other.syncStatus == this.syncStatus &&
          other.id == this.id &&
          other.userId == this.userId &&
          other.txnDate == this.txnDate &&
          other.amountPaisa == this.amountPaisa &&
          other.paymentMethod == this.paymentMethod &&
          other.walletId == this.walletId &&
          other.note == this.note);
}

class MotherPaymentsCompanion extends UpdateCompanion<MotherPayment> {
  final Value<String> createdAt;
  final Value<String> updatedAt;
  final Value<String?> deletedAt;
  final Value<int> version;
  final Value<String> syncStatus;
  final Value<String> id;
  final Value<String> userId;
  final Value<String> txnDate;
  final Value<int> amountPaisa;
  final Value<String> paymentMethod;
  final Value<String?> walletId;
  final Value<String?> note;
  final Value<int> rowid;
  const MotherPaymentsCompanion({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.id = const Value.absent(),
    this.userId = const Value.absent(),
    this.txnDate = const Value.absent(),
    this.amountPaisa = const Value.absent(),
    this.paymentMethod = const Value.absent(),
    this.walletId = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  MotherPaymentsCompanion.insert({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    required String id,
    required String userId,
    required String txnDate,
    required int amountPaisa,
    this.paymentMethod = const Value.absent(),
    this.walletId = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        userId = Value(userId),
        txnDate = Value(txnDate),
        amountPaisa = Value(amountPaisa);
  static Insertable<MotherPayment> custom({
    Expression<String>? createdAt,
    Expression<String>? updatedAt,
    Expression<String>? deletedAt,
    Expression<int>? version,
    Expression<String>? syncStatus,
    Expression<String>? id,
    Expression<String>? userId,
    Expression<String>? txnDate,
    Expression<int>? amountPaisa,
    Expression<String>? paymentMethod,
    Expression<String>? walletId,
    Expression<String>? note,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (deletedAt != null) 'deleted_at': deletedAt,
      if (version != null) 'version': version,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (id != null) 'id': id,
      if (userId != null) 'user_id': userId,
      if (txnDate != null) 'txn_date': txnDate,
      if (amountPaisa != null) 'amount_paisa': amountPaisa,
      if (paymentMethod != null) 'payment_method': paymentMethod,
      if (walletId != null) 'wallet_id': walletId,
      if (note != null) 'note': note,
      if (rowid != null) 'rowid': rowid,
    });
  }

  MotherPaymentsCompanion copyWith(
      {Value<String>? createdAt,
      Value<String>? updatedAt,
      Value<String?>? deletedAt,
      Value<int>? version,
      Value<String>? syncStatus,
      Value<String>? id,
      Value<String>? userId,
      Value<String>? txnDate,
      Value<int>? amountPaisa,
      Value<String>? paymentMethod,
      Value<String?>? walletId,
      Value<String?>? note,
      Value<int>? rowid}) {
    return MotherPaymentsCompanion(
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      version: version ?? this.version,
      syncStatus: syncStatus ?? this.syncStatus,
      id: id ?? this.id,
      userId: userId ?? this.userId,
      txnDate: txnDate ?? this.txnDate,
      amountPaisa: amountPaisa ?? this.amountPaisa,
      paymentMethod: paymentMethod ?? this.paymentMethod,
      walletId: walletId ?? this.walletId,
      note: note ?? this.note,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (createdAt.present) {
      map['created_at'] = Variable<String>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<String>(updatedAt.value);
    }
    if (deletedAt.present) {
      map['deleted_at'] = Variable<String>(deletedAt.value);
    }
    if (version.present) {
      map['version'] = Variable<int>(version.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<String>(userId.value);
    }
    if (txnDate.present) {
      map['txn_date'] = Variable<String>(txnDate.value);
    }
    if (amountPaisa.present) {
      map['amount_paisa'] = Variable<int>(amountPaisa.value);
    }
    if (paymentMethod.present) {
      map['payment_method'] = Variable<String>(paymentMethod.value);
    }
    if (walletId.present) {
      map['wallet_id'] = Variable<String>(walletId.value);
    }
    if (note.present) {
      map['note'] = Variable<String>(note.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('MotherPaymentsCompanion(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('txnDate: $txnDate, ')
          ..write('amountPaisa: $amountPaisa, ')
          ..write('paymentMethod: $paymentMethod, ')
          ..write('walletId: $walletId, ')
          ..write('note: $note, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $DpsAccountsTable extends DpsAccounts
    with TableInfo<$DpsAccountsTable, DpsAccount> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $DpsAccountsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<String> createdAt = GeneratedColumn<String>(
      'created_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<String> updatedAt = GeneratedColumn<String>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _deletedAtMeta =
      const VerificationMeta('deletedAt');
  @override
  late final GeneratedColumn<String> deletedAt = GeneratedColumn<String>(
      'deleted_at', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _versionMeta =
      const VerificationMeta('version');
  @override
  late final GeneratedColumn<int> version = GeneratedColumn<int>(
      'version', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('pending'));
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<String> userId = GeneratedColumn<String>(
      'user_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _institutionNameMeta =
      const VerificationMeta('institutionName');
  @override
  late final GeneratedColumn<String> institutionName = GeneratedColumn<String>(
      'institution_name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _monthlyInstallmentPaisaMeta =
      const VerificationMeta('monthlyInstallmentPaisa');
  @override
  late final GeneratedColumn<int> monthlyInstallmentPaisa =
      GeneratedColumn<int>('monthly_installment_paisa', aliasedName, false,
          type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _frequencyMeta =
      const VerificationMeta('frequency');
  @override
  late final GeneratedColumn<String> frequency = GeneratedColumn<String>(
      'frequency', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('monthly'));
  static const VerificationMeta _dueDayMeta = const VerificationMeta('dueDay');
  @override
  late final GeneratedColumn<int> dueDay = GeneratedColumn<int>(
      'due_day', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _startDateMeta =
      const VerificationMeta('startDate');
  @override
  late final GeneratedColumn<String> startDate = GeneratedColumn<String>(
      'start_date', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _durationMonthsMeta =
      const VerificationMeta('durationMonths');
  @override
  late final GeneratedColumn<int> durationMonths = GeneratedColumn<int>(
      'duration_months', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _targetPaisaMeta =
      const VerificationMeta('targetPaisa');
  @override
  late final GeneratedColumn<int> targetPaisa = GeneratedColumn<int>(
      'target_paisa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _statusMeta = const VerificationMeta('status');
  @override
  late final GeneratedColumn<String> status = GeneratedColumn<String>(
      'status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('active'));
  static const VerificationMeta _noteMeta = const VerificationMeta('note');
  @override
  late final GeneratedColumn<String> note = GeneratedColumn<String>(
      'note', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        createdAt,
        updatedAt,
        deletedAt,
        version,
        syncStatus,
        id,
        userId,
        institutionName,
        monthlyInstallmentPaisa,
        frequency,
        dueDay,
        startDate,
        durationMonths,
        targetPaisa,
        status,
        note
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'dps_accounts';
  @override
  VerificationContext validateIntegrity(Insertable<DpsAccount> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    if (data.containsKey('deleted_at')) {
      context.handle(_deletedAtMeta,
          deletedAt.isAcceptableOrUnknown(data['deleted_at']!, _deletedAtMeta));
    }
    if (data.containsKey('version')) {
      context.handle(_versionMeta,
          version.isAcceptableOrUnknown(data['version']!, _versionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('user_id')) {
      context.handle(_userIdMeta,
          userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta));
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('institution_name')) {
      context.handle(
          _institutionNameMeta,
          institutionName.isAcceptableOrUnknown(
              data['institution_name']!, _institutionNameMeta));
    } else if (isInserting) {
      context.missing(_institutionNameMeta);
    }
    if (data.containsKey('monthly_installment_paisa')) {
      context.handle(
          _monthlyInstallmentPaisaMeta,
          monthlyInstallmentPaisa.isAcceptableOrUnknown(
              data['monthly_installment_paisa']!,
              _monthlyInstallmentPaisaMeta));
    } else if (isInserting) {
      context.missing(_monthlyInstallmentPaisaMeta);
    }
    if (data.containsKey('frequency')) {
      context.handle(_frequencyMeta,
          frequency.isAcceptableOrUnknown(data['frequency']!, _frequencyMeta));
    }
    if (data.containsKey('due_day')) {
      context.handle(_dueDayMeta,
          dueDay.isAcceptableOrUnknown(data['due_day']!, _dueDayMeta));
    }
    if (data.containsKey('start_date')) {
      context.handle(_startDateMeta,
          startDate.isAcceptableOrUnknown(data['start_date']!, _startDateMeta));
    } else if (isInserting) {
      context.missing(_startDateMeta);
    }
    if (data.containsKey('duration_months')) {
      context.handle(
          _durationMonthsMeta,
          durationMonths.isAcceptableOrUnknown(
              data['duration_months']!, _durationMonthsMeta));
    }
    if (data.containsKey('target_paisa')) {
      context.handle(
          _targetPaisaMeta,
          targetPaisa.isAcceptableOrUnknown(
              data['target_paisa']!, _targetPaisaMeta));
    }
    if (data.containsKey('status')) {
      context.handle(_statusMeta,
          status.isAcceptableOrUnknown(data['status']!, _statusMeta));
    }
    if (data.containsKey('note')) {
      context.handle(
          _noteMeta, note.isAcceptableOrUnknown(data['note']!, _noteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  DpsAccount map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return DpsAccount(
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}updated_at'])!,
      deletedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}deleted_at']),
      version: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}version'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      userId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}user_id'])!,
      institutionName: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}institution_name'])!,
      monthlyInstallmentPaisa: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}monthly_installment_paisa'])!,
      frequency: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}frequency'])!,
      dueDay: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}due_day'])!,
      startDate: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}start_date'])!,
      durationMonths: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}duration_months']),
      targetPaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}target_paisa']),
      status: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}status'])!,
      note: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}note']),
    );
  }

  @override
  $DpsAccountsTable createAlias(String alias) {
    return $DpsAccountsTable(attachedDatabase, alias);
  }
}

class DpsAccount extends DataClass implements Insertable<DpsAccount> {
  final String createdAt;
  final String updatedAt;
  final String? deletedAt;
  final int version;
  final String syncStatus;
  final String id;
  final String userId;
  final String institutionName;
  final int monthlyInstallmentPaisa;

  /// v1.1: daily | weekly | monthly
  final String frequency;

  /// monthly → ১–২৮ তারিখ; weekly → DateTime.weekday (১=সোম..৭=রবি); daily → উপেক্ষিত
  final int dueDay;
  final String startDate;
  final int? durationMonths;
  final int? targetPaisa;
  final String status;
  final String? note;
  const DpsAccount(
      {required this.createdAt,
      required this.updatedAt,
      this.deletedAt,
      required this.version,
      required this.syncStatus,
      required this.id,
      required this.userId,
      required this.institutionName,
      required this.monthlyInstallmentPaisa,
      required this.frequency,
      required this.dueDay,
      required this.startDate,
      this.durationMonths,
      this.targetPaisa,
      required this.status,
      this.note});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['created_at'] = Variable<String>(createdAt);
    map['updated_at'] = Variable<String>(updatedAt);
    if (!nullToAbsent || deletedAt != null) {
      map['deleted_at'] = Variable<String>(deletedAt);
    }
    map['version'] = Variable<int>(version);
    map['sync_status'] = Variable<String>(syncStatus);
    map['id'] = Variable<String>(id);
    map['user_id'] = Variable<String>(userId);
    map['institution_name'] = Variable<String>(institutionName);
    map['monthly_installment_paisa'] = Variable<int>(monthlyInstallmentPaisa);
    map['frequency'] = Variable<String>(frequency);
    map['due_day'] = Variable<int>(dueDay);
    map['start_date'] = Variable<String>(startDate);
    if (!nullToAbsent || durationMonths != null) {
      map['duration_months'] = Variable<int>(durationMonths);
    }
    if (!nullToAbsent || targetPaisa != null) {
      map['target_paisa'] = Variable<int>(targetPaisa);
    }
    map['status'] = Variable<String>(status);
    if (!nullToAbsent || note != null) {
      map['note'] = Variable<String>(note);
    }
    return map;
  }

  DpsAccountsCompanion toCompanion(bool nullToAbsent) {
    return DpsAccountsCompanion(
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      deletedAt: deletedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(deletedAt),
      version: Value(version),
      syncStatus: Value(syncStatus),
      id: Value(id),
      userId: Value(userId),
      institutionName: Value(institutionName),
      monthlyInstallmentPaisa: Value(monthlyInstallmentPaisa),
      frequency: Value(frequency),
      dueDay: Value(dueDay),
      startDate: Value(startDate),
      durationMonths: durationMonths == null && nullToAbsent
          ? const Value.absent()
          : Value(durationMonths),
      targetPaisa: targetPaisa == null && nullToAbsent
          ? const Value.absent()
          : Value(targetPaisa),
      status: Value(status),
      note: note == null && nullToAbsent ? const Value.absent() : Value(note),
    );
  }

  factory DpsAccount.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return DpsAccount(
      createdAt: serializer.fromJson<String>(json['createdAt']),
      updatedAt: serializer.fromJson<String>(json['updatedAt']),
      deletedAt: serializer.fromJson<String?>(json['deletedAt']),
      version: serializer.fromJson<int>(json['version']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      id: serializer.fromJson<String>(json['id']),
      userId: serializer.fromJson<String>(json['userId']),
      institutionName: serializer.fromJson<String>(json['institutionName']),
      monthlyInstallmentPaisa:
          serializer.fromJson<int>(json['monthlyInstallmentPaisa']),
      frequency: serializer.fromJson<String>(json['frequency']),
      dueDay: serializer.fromJson<int>(json['dueDay']),
      startDate: serializer.fromJson<String>(json['startDate']),
      durationMonths: serializer.fromJson<int?>(json['durationMonths']),
      targetPaisa: serializer.fromJson<int?>(json['targetPaisa']),
      status: serializer.fromJson<String>(json['status']),
      note: serializer.fromJson<String?>(json['note']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'createdAt': serializer.toJson<String>(createdAt),
      'updatedAt': serializer.toJson<String>(updatedAt),
      'deletedAt': serializer.toJson<String?>(deletedAt),
      'version': serializer.toJson<int>(version),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'id': serializer.toJson<String>(id),
      'userId': serializer.toJson<String>(userId),
      'institutionName': serializer.toJson<String>(institutionName),
      'monthlyInstallmentPaisa':
          serializer.toJson<int>(monthlyInstallmentPaisa),
      'frequency': serializer.toJson<String>(frequency),
      'dueDay': serializer.toJson<int>(dueDay),
      'startDate': serializer.toJson<String>(startDate),
      'durationMonths': serializer.toJson<int?>(durationMonths),
      'targetPaisa': serializer.toJson<int?>(targetPaisa),
      'status': serializer.toJson<String>(status),
      'note': serializer.toJson<String?>(note),
    };
  }

  DpsAccount copyWith(
          {String? createdAt,
          String? updatedAt,
          Value<String?> deletedAt = const Value.absent(),
          int? version,
          String? syncStatus,
          String? id,
          String? userId,
          String? institutionName,
          int? monthlyInstallmentPaisa,
          String? frequency,
          int? dueDay,
          String? startDate,
          Value<int?> durationMonths = const Value.absent(),
          Value<int?> targetPaisa = const Value.absent(),
          String? status,
          Value<String?> note = const Value.absent()}) =>
      DpsAccount(
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: deletedAt.present ? deletedAt.value : this.deletedAt,
        version: version ?? this.version,
        syncStatus: syncStatus ?? this.syncStatus,
        id: id ?? this.id,
        userId: userId ?? this.userId,
        institutionName: institutionName ?? this.institutionName,
        monthlyInstallmentPaisa:
            monthlyInstallmentPaisa ?? this.monthlyInstallmentPaisa,
        frequency: frequency ?? this.frequency,
        dueDay: dueDay ?? this.dueDay,
        startDate: startDate ?? this.startDate,
        durationMonths:
            durationMonths.present ? durationMonths.value : this.durationMonths,
        targetPaisa: targetPaisa.present ? targetPaisa.value : this.targetPaisa,
        status: status ?? this.status,
        note: note.present ? note.value : this.note,
      );
  DpsAccount copyWithCompanion(DpsAccountsCompanion data) {
    return DpsAccount(
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      deletedAt: data.deletedAt.present ? data.deletedAt.value : this.deletedAt,
      version: data.version.present ? data.version.value : this.version,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      id: data.id.present ? data.id.value : this.id,
      userId: data.userId.present ? data.userId.value : this.userId,
      institutionName: data.institutionName.present
          ? data.institutionName.value
          : this.institutionName,
      monthlyInstallmentPaisa: data.monthlyInstallmentPaisa.present
          ? data.monthlyInstallmentPaisa.value
          : this.monthlyInstallmentPaisa,
      frequency: data.frequency.present ? data.frequency.value : this.frequency,
      dueDay: data.dueDay.present ? data.dueDay.value : this.dueDay,
      startDate: data.startDate.present ? data.startDate.value : this.startDate,
      durationMonths: data.durationMonths.present
          ? data.durationMonths.value
          : this.durationMonths,
      targetPaisa:
          data.targetPaisa.present ? data.targetPaisa.value : this.targetPaisa,
      status: data.status.present ? data.status.value : this.status,
      note: data.note.present ? data.note.value : this.note,
    );
  }

  @override
  String toString() {
    return (StringBuffer('DpsAccount(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('institutionName: $institutionName, ')
          ..write('monthlyInstallmentPaisa: $monthlyInstallmentPaisa, ')
          ..write('frequency: $frequency, ')
          ..write('dueDay: $dueDay, ')
          ..write('startDate: $startDate, ')
          ..write('durationMonths: $durationMonths, ')
          ..write('targetPaisa: $targetPaisa, ')
          ..write('status: $status, ')
          ..write('note: $note')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      createdAt,
      updatedAt,
      deletedAt,
      version,
      syncStatus,
      id,
      userId,
      institutionName,
      monthlyInstallmentPaisa,
      frequency,
      dueDay,
      startDate,
      durationMonths,
      targetPaisa,
      status,
      note);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is DpsAccount &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.deletedAt == this.deletedAt &&
          other.version == this.version &&
          other.syncStatus == this.syncStatus &&
          other.id == this.id &&
          other.userId == this.userId &&
          other.institutionName == this.institutionName &&
          other.monthlyInstallmentPaisa == this.monthlyInstallmentPaisa &&
          other.frequency == this.frequency &&
          other.dueDay == this.dueDay &&
          other.startDate == this.startDate &&
          other.durationMonths == this.durationMonths &&
          other.targetPaisa == this.targetPaisa &&
          other.status == this.status &&
          other.note == this.note);
}

class DpsAccountsCompanion extends UpdateCompanion<DpsAccount> {
  final Value<String> createdAt;
  final Value<String> updatedAt;
  final Value<String?> deletedAt;
  final Value<int> version;
  final Value<String> syncStatus;
  final Value<String> id;
  final Value<String> userId;
  final Value<String> institutionName;
  final Value<int> monthlyInstallmentPaisa;
  final Value<String> frequency;
  final Value<int> dueDay;
  final Value<String> startDate;
  final Value<int?> durationMonths;
  final Value<int?> targetPaisa;
  final Value<String> status;
  final Value<String?> note;
  final Value<int> rowid;
  const DpsAccountsCompanion({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.id = const Value.absent(),
    this.userId = const Value.absent(),
    this.institutionName = const Value.absent(),
    this.monthlyInstallmentPaisa = const Value.absent(),
    this.frequency = const Value.absent(),
    this.dueDay = const Value.absent(),
    this.startDate = const Value.absent(),
    this.durationMonths = const Value.absent(),
    this.targetPaisa = const Value.absent(),
    this.status = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  DpsAccountsCompanion.insert({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    required String id,
    required String userId,
    required String institutionName,
    required int monthlyInstallmentPaisa,
    this.frequency = const Value.absent(),
    this.dueDay = const Value.absent(),
    required String startDate,
    this.durationMonths = const Value.absent(),
    this.targetPaisa = const Value.absent(),
    this.status = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        userId = Value(userId),
        institutionName = Value(institutionName),
        monthlyInstallmentPaisa = Value(monthlyInstallmentPaisa),
        startDate = Value(startDate);
  static Insertable<DpsAccount> custom({
    Expression<String>? createdAt,
    Expression<String>? updatedAt,
    Expression<String>? deletedAt,
    Expression<int>? version,
    Expression<String>? syncStatus,
    Expression<String>? id,
    Expression<String>? userId,
    Expression<String>? institutionName,
    Expression<int>? monthlyInstallmentPaisa,
    Expression<String>? frequency,
    Expression<int>? dueDay,
    Expression<String>? startDate,
    Expression<int>? durationMonths,
    Expression<int>? targetPaisa,
    Expression<String>? status,
    Expression<String>? note,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (deletedAt != null) 'deleted_at': deletedAt,
      if (version != null) 'version': version,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (id != null) 'id': id,
      if (userId != null) 'user_id': userId,
      if (institutionName != null) 'institution_name': institutionName,
      if (monthlyInstallmentPaisa != null)
        'monthly_installment_paisa': monthlyInstallmentPaisa,
      if (frequency != null) 'frequency': frequency,
      if (dueDay != null) 'due_day': dueDay,
      if (startDate != null) 'start_date': startDate,
      if (durationMonths != null) 'duration_months': durationMonths,
      if (targetPaisa != null) 'target_paisa': targetPaisa,
      if (status != null) 'status': status,
      if (note != null) 'note': note,
      if (rowid != null) 'rowid': rowid,
    });
  }

  DpsAccountsCompanion copyWith(
      {Value<String>? createdAt,
      Value<String>? updatedAt,
      Value<String?>? deletedAt,
      Value<int>? version,
      Value<String>? syncStatus,
      Value<String>? id,
      Value<String>? userId,
      Value<String>? institutionName,
      Value<int>? monthlyInstallmentPaisa,
      Value<String>? frequency,
      Value<int>? dueDay,
      Value<String>? startDate,
      Value<int?>? durationMonths,
      Value<int?>? targetPaisa,
      Value<String>? status,
      Value<String?>? note,
      Value<int>? rowid}) {
    return DpsAccountsCompanion(
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      version: version ?? this.version,
      syncStatus: syncStatus ?? this.syncStatus,
      id: id ?? this.id,
      userId: userId ?? this.userId,
      institutionName: institutionName ?? this.institutionName,
      monthlyInstallmentPaisa:
          monthlyInstallmentPaisa ?? this.monthlyInstallmentPaisa,
      frequency: frequency ?? this.frequency,
      dueDay: dueDay ?? this.dueDay,
      startDate: startDate ?? this.startDate,
      durationMonths: durationMonths ?? this.durationMonths,
      targetPaisa: targetPaisa ?? this.targetPaisa,
      status: status ?? this.status,
      note: note ?? this.note,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (createdAt.present) {
      map['created_at'] = Variable<String>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<String>(updatedAt.value);
    }
    if (deletedAt.present) {
      map['deleted_at'] = Variable<String>(deletedAt.value);
    }
    if (version.present) {
      map['version'] = Variable<int>(version.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<String>(userId.value);
    }
    if (institutionName.present) {
      map['institution_name'] = Variable<String>(institutionName.value);
    }
    if (monthlyInstallmentPaisa.present) {
      map['monthly_installment_paisa'] =
          Variable<int>(monthlyInstallmentPaisa.value);
    }
    if (frequency.present) {
      map['frequency'] = Variable<String>(frequency.value);
    }
    if (dueDay.present) {
      map['due_day'] = Variable<int>(dueDay.value);
    }
    if (startDate.present) {
      map['start_date'] = Variable<String>(startDate.value);
    }
    if (durationMonths.present) {
      map['duration_months'] = Variable<int>(durationMonths.value);
    }
    if (targetPaisa.present) {
      map['target_paisa'] = Variable<int>(targetPaisa.value);
    }
    if (status.present) {
      map['status'] = Variable<String>(status.value);
    }
    if (note.present) {
      map['note'] = Variable<String>(note.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('DpsAccountsCompanion(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('institutionName: $institutionName, ')
          ..write('monthlyInstallmentPaisa: $monthlyInstallmentPaisa, ')
          ..write('frequency: $frequency, ')
          ..write('dueDay: $dueDay, ')
          ..write('startDate: $startDate, ')
          ..write('durationMonths: $durationMonths, ')
          ..write('targetPaisa: $targetPaisa, ')
          ..write('status: $status, ')
          ..write('note: $note, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $DpsTransactionsTable extends DpsTransactions
    with TableInfo<$DpsTransactionsTable, DpsTransaction> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $DpsTransactionsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<String> createdAt = GeneratedColumn<String>(
      'created_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<String> updatedAt = GeneratedColumn<String>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _deletedAtMeta =
      const VerificationMeta('deletedAt');
  @override
  late final GeneratedColumn<String> deletedAt = GeneratedColumn<String>(
      'deleted_at', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _versionMeta =
      const VerificationMeta('version');
  @override
  late final GeneratedColumn<int> version = GeneratedColumn<int>(
      'version', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('pending'));
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<String> userId = GeneratedColumn<String>(
      'user_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _dpsAccountIdMeta =
      const VerificationMeta('dpsAccountId');
  @override
  late final GeneratedColumn<String> dpsAccountId = GeneratedColumn<String>(
      'dps_account_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _txnDateMeta =
      const VerificationMeta('txnDate');
  @override
  late final GeneratedColumn<String> txnDate = GeneratedColumn<String>(
      'txn_date', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _txnAtMeta = const VerificationMeta('txnAt');
  @override
  late final GeneratedColumn<int> txnAt = GeneratedColumn<int>(
      'txn_at', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _amountPaisaMeta =
      const VerificationMeta('amountPaisa');
  @override
  late final GeneratedColumn<int> amountPaisa = GeneratedColumn<int>(
      'amount_paisa', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _paymentMethodMeta =
      const VerificationMeta('paymentMethod');
  @override
  late final GeneratedColumn<String> paymentMethod = GeneratedColumn<String>(
      'payment_method', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('cash'));
  static const VerificationMeta _walletIdMeta =
      const VerificationMeta('walletId');
  @override
  late final GeneratedColumn<String> walletId = GeneratedColumn<String>(
      'wallet_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _noteMeta = const VerificationMeta('note');
  @override
  late final GeneratedColumn<String> note = GeneratedColumn<String>(
      'note', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        createdAt,
        updatedAt,
        deletedAt,
        version,
        syncStatus,
        id,
        userId,
        dpsAccountId,
        txnDate,
        txnAt,
        amountPaisa,
        paymentMethod,
        walletId,
        note
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'dps_transactions';
  @override
  VerificationContext validateIntegrity(Insertable<DpsTransaction> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    if (data.containsKey('deleted_at')) {
      context.handle(_deletedAtMeta,
          deletedAt.isAcceptableOrUnknown(data['deleted_at']!, _deletedAtMeta));
    }
    if (data.containsKey('version')) {
      context.handle(_versionMeta,
          version.isAcceptableOrUnknown(data['version']!, _versionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('user_id')) {
      context.handle(_userIdMeta,
          userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta));
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('dps_account_id')) {
      context.handle(
          _dpsAccountIdMeta,
          dpsAccountId.isAcceptableOrUnknown(
              data['dps_account_id']!, _dpsAccountIdMeta));
    } else if (isInserting) {
      context.missing(_dpsAccountIdMeta);
    }
    if (data.containsKey('txn_date')) {
      context.handle(_txnDateMeta,
          txnDate.isAcceptableOrUnknown(data['txn_date']!, _txnDateMeta));
    } else if (isInserting) {
      context.missing(_txnDateMeta);
    }
    if (data.containsKey('txn_at')) {
      context.handle(
          _txnAtMeta, txnAt.isAcceptableOrUnknown(data['txn_at']!, _txnAtMeta));
    }
    if (data.containsKey('amount_paisa')) {
      context.handle(
          _amountPaisaMeta,
          amountPaisa.isAcceptableOrUnknown(
              data['amount_paisa']!, _amountPaisaMeta));
    } else if (isInserting) {
      context.missing(_amountPaisaMeta);
    }
    if (data.containsKey('payment_method')) {
      context.handle(
          _paymentMethodMeta,
          paymentMethod.isAcceptableOrUnknown(
              data['payment_method']!, _paymentMethodMeta));
    }
    if (data.containsKey('wallet_id')) {
      context.handle(_walletIdMeta,
          walletId.isAcceptableOrUnknown(data['wallet_id']!, _walletIdMeta));
    }
    if (data.containsKey('note')) {
      context.handle(
          _noteMeta, note.isAcceptableOrUnknown(data['note']!, _noteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  DpsTransaction map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return DpsTransaction(
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}updated_at'])!,
      deletedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}deleted_at']),
      version: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}version'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      userId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}user_id'])!,
      dpsAccountId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}dps_account_id'])!,
      txnDate: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}txn_date'])!,
      txnAt: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}txn_at'])!,
      amountPaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}amount_paisa'])!,
      paymentMethod: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}payment_method'])!,
      walletId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}wallet_id']),
      note: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}note']),
    );
  }

  @override
  $DpsTransactionsTable createAlias(String alias) {
    return $DpsTransactionsTable(attachedDatabase, alias);
  }
}

class DpsTransaction extends DataClass implements Insertable<DpsTransaction> {
  final String createdAt;
  final String updatedAt;
  final String? deletedAt;
  final int version;
  final String syncStatus;
  final String id;
  final String userId;
  final String dpsAccountId;
  final String txnDate;
  final int txnAt;
  final int amountPaisa;
  final String paymentMethod;
  final String? walletId;
  final String? note;
  const DpsTransaction(
      {required this.createdAt,
      required this.updatedAt,
      this.deletedAt,
      required this.version,
      required this.syncStatus,
      required this.id,
      required this.userId,
      required this.dpsAccountId,
      required this.txnDate,
      required this.txnAt,
      required this.amountPaisa,
      required this.paymentMethod,
      this.walletId,
      this.note});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['created_at'] = Variable<String>(createdAt);
    map['updated_at'] = Variable<String>(updatedAt);
    if (!nullToAbsent || deletedAt != null) {
      map['deleted_at'] = Variable<String>(deletedAt);
    }
    map['version'] = Variable<int>(version);
    map['sync_status'] = Variable<String>(syncStatus);
    map['id'] = Variable<String>(id);
    map['user_id'] = Variable<String>(userId);
    map['dps_account_id'] = Variable<String>(dpsAccountId);
    map['txn_date'] = Variable<String>(txnDate);
    map['txn_at'] = Variable<int>(txnAt);
    map['amount_paisa'] = Variable<int>(amountPaisa);
    map['payment_method'] = Variable<String>(paymentMethod);
    if (!nullToAbsent || walletId != null) {
      map['wallet_id'] = Variable<String>(walletId);
    }
    if (!nullToAbsent || note != null) {
      map['note'] = Variable<String>(note);
    }
    return map;
  }

  DpsTransactionsCompanion toCompanion(bool nullToAbsent) {
    return DpsTransactionsCompanion(
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      deletedAt: deletedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(deletedAt),
      version: Value(version),
      syncStatus: Value(syncStatus),
      id: Value(id),
      userId: Value(userId),
      dpsAccountId: Value(dpsAccountId),
      txnDate: Value(txnDate),
      txnAt: Value(txnAt),
      amountPaisa: Value(amountPaisa),
      paymentMethod: Value(paymentMethod),
      walletId: walletId == null && nullToAbsent
          ? const Value.absent()
          : Value(walletId),
      note: note == null && nullToAbsent ? const Value.absent() : Value(note),
    );
  }

  factory DpsTransaction.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return DpsTransaction(
      createdAt: serializer.fromJson<String>(json['createdAt']),
      updatedAt: serializer.fromJson<String>(json['updatedAt']),
      deletedAt: serializer.fromJson<String?>(json['deletedAt']),
      version: serializer.fromJson<int>(json['version']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      id: serializer.fromJson<String>(json['id']),
      userId: serializer.fromJson<String>(json['userId']),
      dpsAccountId: serializer.fromJson<String>(json['dpsAccountId']),
      txnDate: serializer.fromJson<String>(json['txnDate']),
      txnAt: serializer.fromJson<int>(json['txnAt']),
      amountPaisa: serializer.fromJson<int>(json['amountPaisa']),
      paymentMethod: serializer.fromJson<String>(json['paymentMethod']),
      walletId: serializer.fromJson<String?>(json['walletId']),
      note: serializer.fromJson<String?>(json['note']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'createdAt': serializer.toJson<String>(createdAt),
      'updatedAt': serializer.toJson<String>(updatedAt),
      'deletedAt': serializer.toJson<String?>(deletedAt),
      'version': serializer.toJson<int>(version),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'id': serializer.toJson<String>(id),
      'userId': serializer.toJson<String>(userId),
      'dpsAccountId': serializer.toJson<String>(dpsAccountId),
      'txnDate': serializer.toJson<String>(txnDate),
      'txnAt': serializer.toJson<int>(txnAt),
      'amountPaisa': serializer.toJson<int>(amountPaisa),
      'paymentMethod': serializer.toJson<String>(paymentMethod),
      'walletId': serializer.toJson<String?>(walletId),
      'note': serializer.toJson<String?>(note),
    };
  }

  DpsTransaction copyWith(
          {String? createdAt,
          String? updatedAt,
          Value<String?> deletedAt = const Value.absent(),
          int? version,
          String? syncStatus,
          String? id,
          String? userId,
          String? dpsAccountId,
          String? txnDate,
          int? txnAt,
          int? amountPaisa,
          String? paymentMethod,
          Value<String?> walletId = const Value.absent(),
          Value<String?> note = const Value.absent()}) =>
      DpsTransaction(
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: deletedAt.present ? deletedAt.value : this.deletedAt,
        version: version ?? this.version,
        syncStatus: syncStatus ?? this.syncStatus,
        id: id ?? this.id,
        userId: userId ?? this.userId,
        dpsAccountId: dpsAccountId ?? this.dpsAccountId,
        txnDate: txnDate ?? this.txnDate,
        txnAt: txnAt ?? this.txnAt,
        amountPaisa: amountPaisa ?? this.amountPaisa,
        paymentMethod: paymentMethod ?? this.paymentMethod,
        walletId: walletId.present ? walletId.value : this.walletId,
        note: note.present ? note.value : this.note,
      );
  DpsTransaction copyWithCompanion(DpsTransactionsCompanion data) {
    return DpsTransaction(
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      deletedAt: data.deletedAt.present ? data.deletedAt.value : this.deletedAt,
      version: data.version.present ? data.version.value : this.version,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      id: data.id.present ? data.id.value : this.id,
      userId: data.userId.present ? data.userId.value : this.userId,
      dpsAccountId: data.dpsAccountId.present
          ? data.dpsAccountId.value
          : this.dpsAccountId,
      txnDate: data.txnDate.present ? data.txnDate.value : this.txnDate,
      txnAt: data.txnAt.present ? data.txnAt.value : this.txnAt,
      amountPaisa:
          data.amountPaisa.present ? data.amountPaisa.value : this.amountPaisa,
      paymentMethod: data.paymentMethod.present
          ? data.paymentMethod.value
          : this.paymentMethod,
      walletId: data.walletId.present ? data.walletId.value : this.walletId,
      note: data.note.present ? data.note.value : this.note,
    );
  }

  @override
  String toString() {
    return (StringBuffer('DpsTransaction(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('dpsAccountId: $dpsAccountId, ')
          ..write('txnDate: $txnDate, ')
          ..write('txnAt: $txnAt, ')
          ..write('amountPaisa: $amountPaisa, ')
          ..write('paymentMethod: $paymentMethod, ')
          ..write('walletId: $walletId, ')
          ..write('note: $note')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      createdAt,
      updatedAt,
      deletedAt,
      version,
      syncStatus,
      id,
      userId,
      dpsAccountId,
      txnDate,
      txnAt,
      amountPaisa,
      paymentMethod,
      walletId,
      note);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is DpsTransaction &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.deletedAt == this.deletedAt &&
          other.version == this.version &&
          other.syncStatus == this.syncStatus &&
          other.id == this.id &&
          other.userId == this.userId &&
          other.dpsAccountId == this.dpsAccountId &&
          other.txnDate == this.txnDate &&
          other.txnAt == this.txnAt &&
          other.amountPaisa == this.amountPaisa &&
          other.paymentMethod == this.paymentMethod &&
          other.walletId == this.walletId &&
          other.note == this.note);
}

class DpsTransactionsCompanion extends UpdateCompanion<DpsTransaction> {
  final Value<String> createdAt;
  final Value<String> updatedAt;
  final Value<String?> deletedAt;
  final Value<int> version;
  final Value<String> syncStatus;
  final Value<String> id;
  final Value<String> userId;
  final Value<String> dpsAccountId;
  final Value<String> txnDate;
  final Value<int> txnAt;
  final Value<int> amountPaisa;
  final Value<String> paymentMethod;
  final Value<String?> walletId;
  final Value<String?> note;
  final Value<int> rowid;
  const DpsTransactionsCompanion({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.id = const Value.absent(),
    this.userId = const Value.absent(),
    this.dpsAccountId = const Value.absent(),
    this.txnDate = const Value.absent(),
    this.txnAt = const Value.absent(),
    this.amountPaisa = const Value.absent(),
    this.paymentMethod = const Value.absent(),
    this.walletId = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  DpsTransactionsCompanion.insert({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    required String id,
    required String userId,
    required String dpsAccountId,
    required String txnDate,
    this.txnAt = const Value.absent(),
    required int amountPaisa,
    this.paymentMethod = const Value.absent(),
    this.walletId = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        userId = Value(userId),
        dpsAccountId = Value(dpsAccountId),
        txnDate = Value(txnDate),
        amountPaisa = Value(amountPaisa);
  static Insertable<DpsTransaction> custom({
    Expression<String>? createdAt,
    Expression<String>? updatedAt,
    Expression<String>? deletedAt,
    Expression<int>? version,
    Expression<String>? syncStatus,
    Expression<String>? id,
    Expression<String>? userId,
    Expression<String>? dpsAccountId,
    Expression<String>? txnDate,
    Expression<int>? txnAt,
    Expression<int>? amountPaisa,
    Expression<String>? paymentMethod,
    Expression<String>? walletId,
    Expression<String>? note,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (deletedAt != null) 'deleted_at': deletedAt,
      if (version != null) 'version': version,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (id != null) 'id': id,
      if (userId != null) 'user_id': userId,
      if (dpsAccountId != null) 'dps_account_id': dpsAccountId,
      if (txnDate != null) 'txn_date': txnDate,
      if (txnAt != null) 'txn_at': txnAt,
      if (amountPaisa != null) 'amount_paisa': amountPaisa,
      if (paymentMethod != null) 'payment_method': paymentMethod,
      if (walletId != null) 'wallet_id': walletId,
      if (note != null) 'note': note,
      if (rowid != null) 'rowid': rowid,
    });
  }

  DpsTransactionsCompanion copyWith(
      {Value<String>? createdAt,
      Value<String>? updatedAt,
      Value<String?>? deletedAt,
      Value<int>? version,
      Value<String>? syncStatus,
      Value<String>? id,
      Value<String>? userId,
      Value<String>? dpsAccountId,
      Value<String>? txnDate,
      Value<int>? txnAt,
      Value<int>? amountPaisa,
      Value<String>? paymentMethod,
      Value<String?>? walletId,
      Value<String?>? note,
      Value<int>? rowid}) {
    return DpsTransactionsCompanion(
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      version: version ?? this.version,
      syncStatus: syncStatus ?? this.syncStatus,
      id: id ?? this.id,
      userId: userId ?? this.userId,
      dpsAccountId: dpsAccountId ?? this.dpsAccountId,
      txnDate: txnDate ?? this.txnDate,
      txnAt: txnAt ?? this.txnAt,
      amountPaisa: amountPaisa ?? this.amountPaisa,
      paymentMethod: paymentMethod ?? this.paymentMethod,
      walletId: walletId ?? this.walletId,
      note: note ?? this.note,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (createdAt.present) {
      map['created_at'] = Variable<String>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<String>(updatedAt.value);
    }
    if (deletedAt.present) {
      map['deleted_at'] = Variable<String>(deletedAt.value);
    }
    if (version.present) {
      map['version'] = Variable<int>(version.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<String>(userId.value);
    }
    if (dpsAccountId.present) {
      map['dps_account_id'] = Variable<String>(dpsAccountId.value);
    }
    if (txnDate.present) {
      map['txn_date'] = Variable<String>(txnDate.value);
    }
    if (txnAt.present) {
      map['txn_at'] = Variable<int>(txnAt.value);
    }
    if (amountPaisa.present) {
      map['amount_paisa'] = Variable<int>(amountPaisa.value);
    }
    if (paymentMethod.present) {
      map['payment_method'] = Variable<String>(paymentMethod.value);
    }
    if (walletId.present) {
      map['wallet_id'] = Variable<String>(walletId.value);
    }
    if (note.present) {
      map['note'] = Variable<String>(note.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('DpsTransactionsCompanion(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('dpsAccountId: $dpsAccountId, ')
          ..write('txnDate: $txnDate, ')
          ..write('txnAt: $txnAt, ')
          ..write('amountPaisa: $amountPaisa, ')
          ..write('paymentMethod: $paymentMethod, ')
          ..write('walletId: $walletId, ')
          ..write('note: $note, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $LoanPersonsTable extends LoanPersons
    with TableInfo<$LoanPersonsTable, LoanPerson> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $LoanPersonsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<String> createdAt = GeneratedColumn<String>(
      'created_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<String> updatedAt = GeneratedColumn<String>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _deletedAtMeta =
      const VerificationMeta('deletedAt');
  @override
  late final GeneratedColumn<String> deletedAt = GeneratedColumn<String>(
      'deleted_at', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _versionMeta =
      const VerificationMeta('version');
  @override
  late final GeneratedColumn<int> version = GeneratedColumn<int>(
      'version', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('pending'));
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<String> userId = GeneratedColumn<String>(
      'user_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _phoneMeta = const VerificationMeta('phone');
  @override
  late final GeneratedColumn<String> phone = GeneratedColumn<String>(
      'phone', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _addressMeta =
      const VerificationMeta('address');
  @override
  late final GeneratedColumn<String> address = GeneratedColumn<String>(
      'address', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _avatarPathMeta =
      const VerificationMeta('avatarPath');
  @override
  late final GeneratedColumn<String> avatarPath = GeneratedColumn<String>(
      'avatar_path', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _noteMeta = const VerificationMeta('note');
  @override
  late final GeneratedColumn<String> note = GeneratedColumn<String>(
      'note', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        createdAt,
        updatedAt,
        deletedAt,
        version,
        syncStatus,
        id,
        userId,
        name,
        phone,
        address,
        avatarPath,
        note
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'loan_persons';
  @override
  VerificationContext validateIntegrity(Insertable<LoanPerson> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    if (data.containsKey('deleted_at')) {
      context.handle(_deletedAtMeta,
          deletedAt.isAcceptableOrUnknown(data['deleted_at']!, _deletedAtMeta));
    }
    if (data.containsKey('version')) {
      context.handle(_versionMeta,
          version.isAcceptableOrUnknown(data['version']!, _versionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('user_id')) {
      context.handle(_userIdMeta,
          userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta));
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    } else if (isInserting) {
      context.missing(_nameMeta);
    }
    if (data.containsKey('phone')) {
      context.handle(
          _phoneMeta, phone.isAcceptableOrUnknown(data['phone']!, _phoneMeta));
    }
    if (data.containsKey('address')) {
      context.handle(_addressMeta,
          address.isAcceptableOrUnknown(data['address']!, _addressMeta));
    }
    if (data.containsKey('avatar_path')) {
      context.handle(
          _avatarPathMeta,
          avatarPath.isAcceptableOrUnknown(
              data['avatar_path']!, _avatarPathMeta));
    }
    if (data.containsKey('note')) {
      context.handle(
          _noteMeta, note.isAcceptableOrUnknown(data['note']!, _noteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  LoanPerson map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return LoanPerson(
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}updated_at'])!,
      deletedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}deleted_at']),
      version: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}version'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      userId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}user_id'])!,
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name'])!,
      phone: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}phone']),
      address: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}address']),
      avatarPath: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}avatar_path']),
      note: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}note']),
    );
  }

  @override
  $LoanPersonsTable createAlias(String alias) {
    return $LoanPersonsTable(attachedDatabase, alias);
  }
}

class LoanPerson extends DataClass implements Insertable<LoanPerson> {
  final String createdAt;
  final String updatedAt;
  final String? deletedAt;
  final int version;
  final String syncStatus;
  final String id;
  final String userId;
  final String name;
  final String? phone;
  final String? address;
  final String? avatarPath;
  final String? note;
  const LoanPerson(
      {required this.createdAt,
      required this.updatedAt,
      this.deletedAt,
      required this.version,
      required this.syncStatus,
      required this.id,
      required this.userId,
      required this.name,
      this.phone,
      this.address,
      this.avatarPath,
      this.note});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['created_at'] = Variable<String>(createdAt);
    map['updated_at'] = Variable<String>(updatedAt);
    if (!nullToAbsent || deletedAt != null) {
      map['deleted_at'] = Variable<String>(deletedAt);
    }
    map['version'] = Variable<int>(version);
    map['sync_status'] = Variable<String>(syncStatus);
    map['id'] = Variable<String>(id);
    map['user_id'] = Variable<String>(userId);
    map['name'] = Variable<String>(name);
    if (!nullToAbsent || phone != null) {
      map['phone'] = Variable<String>(phone);
    }
    if (!nullToAbsent || address != null) {
      map['address'] = Variable<String>(address);
    }
    if (!nullToAbsent || avatarPath != null) {
      map['avatar_path'] = Variable<String>(avatarPath);
    }
    if (!nullToAbsent || note != null) {
      map['note'] = Variable<String>(note);
    }
    return map;
  }

  LoanPersonsCompanion toCompanion(bool nullToAbsent) {
    return LoanPersonsCompanion(
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      deletedAt: deletedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(deletedAt),
      version: Value(version),
      syncStatus: Value(syncStatus),
      id: Value(id),
      userId: Value(userId),
      name: Value(name),
      phone:
          phone == null && nullToAbsent ? const Value.absent() : Value(phone),
      address: address == null && nullToAbsent
          ? const Value.absent()
          : Value(address),
      avatarPath: avatarPath == null && nullToAbsent
          ? const Value.absent()
          : Value(avatarPath),
      note: note == null && nullToAbsent ? const Value.absent() : Value(note),
    );
  }

  factory LoanPerson.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return LoanPerson(
      createdAt: serializer.fromJson<String>(json['createdAt']),
      updatedAt: serializer.fromJson<String>(json['updatedAt']),
      deletedAt: serializer.fromJson<String?>(json['deletedAt']),
      version: serializer.fromJson<int>(json['version']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      id: serializer.fromJson<String>(json['id']),
      userId: serializer.fromJson<String>(json['userId']),
      name: serializer.fromJson<String>(json['name']),
      phone: serializer.fromJson<String?>(json['phone']),
      address: serializer.fromJson<String?>(json['address']),
      avatarPath: serializer.fromJson<String?>(json['avatarPath']),
      note: serializer.fromJson<String?>(json['note']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'createdAt': serializer.toJson<String>(createdAt),
      'updatedAt': serializer.toJson<String>(updatedAt),
      'deletedAt': serializer.toJson<String?>(deletedAt),
      'version': serializer.toJson<int>(version),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'id': serializer.toJson<String>(id),
      'userId': serializer.toJson<String>(userId),
      'name': serializer.toJson<String>(name),
      'phone': serializer.toJson<String?>(phone),
      'address': serializer.toJson<String?>(address),
      'avatarPath': serializer.toJson<String?>(avatarPath),
      'note': serializer.toJson<String?>(note),
    };
  }

  LoanPerson copyWith(
          {String? createdAt,
          String? updatedAt,
          Value<String?> deletedAt = const Value.absent(),
          int? version,
          String? syncStatus,
          String? id,
          String? userId,
          String? name,
          Value<String?> phone = const Value.absent(),
          Value<String?> address = const Value.absent(),
          Value<String?> avatarPath = const Value.absent(),
          Value<String?> note = const Value.absent()}) =>
      LoanPerson(
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: deletedAt.present ? deletedAt.value : this.deletedAt,
        version: version ?? this.version,
        syncStatus: syncStatus ?? this.syncStatus,
        id: id ?? this.id,
        userId: userId ?? this.userId,
        name: name ?? this.name,
        phone: phone.present ? phone.value : this.phone,
        address: address.present ? address.value : this.address,
        avatarPath: avatarPath.present ? avatarPath.value : this.avatarPath,
        note: note.present ? note.value : this.note,
      );
  LoanPerson copyWithCompanion(LoanPersonsCompanion data) {
    return LoanPerson(
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      deletedAt: data.deletedAt.present ? data.deletedAt.value : this.deletedAt,
      version: data.version.present ? data.version.value : this.version,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      id: data.id.present ? data.id.value : this.id,
      userId: data.userId.present ? data.userId.value : this.userId,
      name: data.name.present ? data.name.value : this.name,
      phone: data.phone.present ? data.phone.value : this.phone,
      address: data.address.present ? data.address.value : this.address,
      avatarPath:
          data.avatarPath.present ? data.avatarPath.value : this.avatarPath,
      note: data.note.present ? data.note.value : this.note,
    );
  }

  @override
  String toString() {
    return (StringBuffer('LoanPerson(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('name: $name, ')
          ..write('phone: $phone, ')
          ..write('address: $address, ')
          ..write('avatarPath: $avatarPath, ')
          ..write('note: $note')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(createdAt, updatedAt, deletedAt, version,
      syncStatus, id, userId, name, phone, address, avatarPath, note);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is LoanPerson &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.deletedAt == this.deletedAt &&
          other.version == this.version &&
          other.syncStatus == this.syncStatus &&
          other.id == this.id &&
          other.userId == this.userId &&
          other.name == this.name &&
          other.phone == this.phone &&
          other.address == this.address &&
          other.avatarPath == this.avatarPath &&
          other.note == this.note);
}

class LoanPersonsCompanion extends UpdateCompanion<LoanPerson> {
  final Value<String> createdAt;
  final Value<String> updatedAt;
  final Value<String?> deletedAt;
  final Value<int> version;
  final Value<String> syncStatus;
  final Value<String> id;
  final Value<String> userId;
  final Value<String> name;
  final Value<String?> phone;
  final Value<String?> address;
  final Value<String?> avatarPath;
  final Value<String?> note;
  final Value<int> rowid;
  const LoanPersonsCompanion({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.id = const Value.absent(),
    this.userId = const Value.absent(),
    this.name = const Value.absent(),
    this.phone = const Value.absent(),
    this.address = const Value.absent(),
    this.avatarPath = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  LoanPersonsCompanion.insert({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    required String id,
    required String userId,
    required String name,
    this.phone = const Value.absent(),
    this.address = const Value.absent(),
    this.avatarPath = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        userId = Value(userId),
        name = Value(name);
  static Insertable<LoanPerson> custom({
    Expression<String>? createdAt,
    Expression<String>? updatedAt,
    Expression<String>? deletedAt,
    Expression<int>? version,
    Expression<String>? syncStatus,
    Expression<String>? id,
    Expression<String>? userId,
    Expression<String>? name,
    Expression<String>? phone,
    Expression<String>? address,
    Expression<String>? avatarPath,
    Expression<String>? note,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (deletedAt != null) 'deleted_at': deletedAt,
      if (version != null) 'version': version,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (id != null) 'id': id,
      if (userId != null) 'user_id': userId,
      if (name != null) 'name': name,
      if (phone != null) 'phone': phone,
      if (address != null) 'address': address,
      if (avatarPath != null) 'avatar_path': avatarPath,
      if (note != null) 'note': note,
      if (rowid != null) 'rowid': rowid,
    });
  }

  LoanPersonsCompanion copyWith(
      {Value<String>? createdAt,
      Value<String>? updatedAt,
      Value<String?>? deletedAt,
      Value<int>? version,
      Value<String>? syncStatus,
      Value<String>? id,
      Value<String>? userId,
      Value<String>? name,
      Value<String?>? phone,
      Value<String?>? address,
      Value<String?>? avatarPath,
      Value<String?>? note,
      Value<int>? rowid}) {
    return LoanPersonsCompanion(
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      version: version ?? this.version,
      syncStatus: syncStatus ?? this.syncStatus,
      id: id ?? this.id,
      userId: userId ?? this.userId,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      address: address ?? this.address,
      avatarPath: avatarPath ?? this.avatarPath,
      note: note ?? this.note,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (createdAt.present) {
      map['created_at'] = Variable<String>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<String>(updatedAt.value);
    }
    if (deletedAt.present) {
      map['deleted_at'] = Variable<String>(deletedAt.value);
    }
    if (version.present) {
      map['version'] = Variable<int>(version.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<String>(userId.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (phone.present) {
      map['phone'] = Variable<String>(phone.value);
    }
    if (address.present) {
      map['address'] = Variable<String>(address.value);
    }
    if (avatarPath.present) {
      map['avatar_path'] = Variable<String>(avatarPath.value);
    }
    if (note.present) {
      map['note'] = Variable<String>(note.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('LoanPersonsCompanion(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('name: $name, ')
          ..write('phone: $phone, ')
          ..write('address: $address, ')
          ..write('avatarPath: $avatarPath, ')
          ..write('note: $note, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $LoansTable extends Loans with TableInfo<$LoansTable, Loan> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $LoansTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<String> createdAt = GeneratedColumn<String>(
      'created_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<String> updatedAt = GeneratedColumn<String>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _deletedAtMeta =
      const VerificationMeta('deletedAt');
  @override
  late final GeneratedColumn<String> deletedAt = GeneratedColumn<String>(
      'deleted_at', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _versionMeta =
      const VerificationMeta('version');
  @override
  late final GeneratedColumn<int> version = GeneratedColumn<int>(
      'version', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('pending'));
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<String> userId = GeneratedColumn<String>(
      'user_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _personIdMeta =
      const VerificationMeta('personId');
  @override
  late final GeneratedColumn<String> personId = GeneratedColumn<String>(
      'person_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _typeMeta = const VerificationMeta('type');
  @override
  late final GeneratedColumn<String> type = GeneratedColumn<String>(
      'type', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('given'));
  static const VerificationMeta _principalPaisaMeta =
      const VerificationMeta('principalPaisa');
  @override
  late final GeneratedColumn<int> principalPaisa = GeneratedColumn<int>(
      'principal_paisa', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _txnDateMeta =
      const VerificationMeta('txnDate');
  @override
  late final GeneratedColumn<String> txnDate = GeneratedColumn<String>(
      'txn_date', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _dueDateMeta =
      const VerificationMeta('dueDate');
  @override
  late final GeneratedColumn<String> dueDate = GeneratedColumn<String>(
      'due_date', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _walletIdMeta =
      const VerificationMeta('walletId');
  @override
  late final GeneratedColumn<String> walletId = GeneratedColumn<String>(
      'wallet_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _noteMeta = const VerificationMeta('note');
  @override
  late final GeneratedColumn<String> note = GeneratedColumn<String>(
      'note', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        createdAt,
        updatedAt,
        deletedAt,
        version,
        syncStatus,
        id,
        userId,
        personId,
        type,
        principalPaisa,
        txnDate,
        dueDate,
        walletId,
        note
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'loans';
  @override
  VerificationContext validateIntegrity(Insertable<Loan> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    if (data.containsKey('deleted_at')) {
      context.handle(_deletedAtMeta,
          deletedAt.isAcceptableOrUnknown(data['deleted_at']!, _deletedAtMeta));
    }
    if (data.containsKey('version')) {
      context.handle(_versionMeta,
          version.isAcceptableOrUnknown(data['version']!, _versionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('user_id')) {
      context.handle(_userIdMeta,
          userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta));
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('person_id')) {
      context.handle(_personIdMeta,
          personId.isAcceptableOrUnknown(data['person_id']!, _personIdMeta));
    } else if (isInserting) {
      context.missing(_personIdMeta);
    }
    if (data.containsKey('type')) {
      context.handle(
          _typeMeta, type.isAcceptableOrUnknown(data['type']!, _typeMeta));
    }
    if (data.containsKey('principal_paisa')) {
      context.handle(
          _principalPaisaMeta,
          principalPaisa.isAcceptableOrUnknown(
              data['principal_paisa']!, _principalPaisaMeta));
    } else if (isInserting) {
      context.missing(_principalPaisaMeta);
    }
    if (data.containsKey('txn_date')) {
      context.handle(_txnDateMeta,
          txnDate.isAcceptableOrUnknown(data['txn_date']!, _txnDateMeta));
    } else if (isInserting) {
      context.missing(_txnDateMeta);
    }
    if (data.containsKey('due_date')) {
      context.handle(_dueDateMeta,
          dueDate.isAcceptableOrUnknown(data['due_date']!, _dueDateMeta));
    }
    if (data.containsKey('wallet_id')) {
      context.handle(_walletIdMeta,
          walletId.isAcceptableOrUnknown(data['wallet_id']!, _walletIdMeta));
    }
    if (data.containsKey('note')) {
      context.handle(
          _noteMeta, note.isAcceptableOrUnknown(data['note']!, _noteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Loan map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Loan(
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}updated_at'])!,
      deletedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}deleted_at']),
      version: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}version'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      userId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}user_id'])!,
      personId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}person_id'])!,
      type: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}type'])!,
      principalPaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}principal_paisa'])!,
      txnDate: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}txn_date'])!,
      dueDate: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}due_date']),
      walletId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}wallet_id']),
      note: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}note']),
    );
  }

  @override
  $LoansTable createAlias(String alias) {
    return $LoansTable(attachedDatabase, alias);
  }
}

class Loan extends DataClass implements Insertable<Loan> {
  final String createdAt;
  final String updatedAt;
  final String? deletedAt;
  final int version;
  final String syncStatus;
  final String id;
  final String userId;
  final String personId;
  final String type;
  final int principalPaisa;
  final String txnDate;
  final String? dueDate;
  final String? walletId;
  final String? note;
  const Loan(
      {required this.createdAt,
      required this.updatedAt,
      this.deletedAt,
      required this.version,
      required this.syncStatus,
      required this.id,
      required this.userId,
      required this.personId,
      required this.type,
      required this.principalPaisa,
      required this.txnDate,
      this.dueDate,
      this.walletId,
      this.note});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['created_at'] = Variable<String>(createdAt);
    map['updated_at'] = Variable<String>(updatedAt);
    if (!nullToAbsent || deletedAt != null) {
      map['deleted_at'] = Variable<String>(deletedAt);
    }
    map['version'] = Variable<int>(version);
    map['sync_status'] = Variable<String>(syncStatus);
    map['id'] = Variable<String>(id);
    map['user_id'] = Variable<String>(userId);
    map['person_id'] = Variable<String>(personId);
    map['type'] = Variable<String>(type);
    map['principal_paisa'] = Variable<int>(principalPaisa);
    map['txn_date'] = Variable<String>(txnDate);
    if (!nullToAbsent || dueDate != null) {
      map['due_date'] = Variable<String>(dueDate);
    }
    if (!nullToAbsent || walletId != null) {
      map['wallet_id'] = Variable<String>(walletId);
    }
    if (!nullToAbsent || note != null) {
      map['note'] = Variable<String>(note);
    }
    return map;
  }

  LoansCompanion toCompanion(bool nullToAbsent) {
    return LoansCompanion(
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      deletedAt: deletedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(deletedAt),
      version: Value(version),
      syncStatus: Value(syncStatus),
      id: Value(id),
      userId: Value(userId),
      personId: Value(personId),
      type: Value(type),
      principalPaisa: Value(principalPaisa),
      txnDate: Value(txnDate),
      dueDate: dueDate == null && nullToAbsent
          ? const Value.absent()
          : Value(dueDate),
      walletId: walletId == null && nullToAbsent
          ? const Value.absent()
          : Value(walletId),
      note: note == null && nullToAbsent ? const Value.absent() : Value(note),
    );
  }

  factory Loan.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Loan(
      createdAt: serializer.fromJson<String>(json['createdAt']),
      updatedAt: serializer.fromJson<String>(json['updatedAt']),
      deletedAt: serializer.fromJson<String?>(json['deletedAt']),
      version: serializer.fromJson<int>(json['version']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      id: serializer.fromJson<String>(json['id']),
      userId: serializer.fromJson<String>(json['userId']),
      personId: serializer.fromJson<String>(json['personId']),
      type: serializer.fromJson<String>(json['type']),
      principalPaisa: serializer.fromJson<int>(json['principalPaisa']),
      txnDate: serializer.fromJson<String>(json['txnDate']),
      dueDate: serializer.fromJson<String?>(json['dueDate']),
      walletId: serializer.fromJson<String?>(json['walletId']),
      note: serializer.fromJson<String?>(json['note']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'createdAt': serializer.toJson<String>(createdAt),
      'updatedAt': serializer.toJson<String>(updatedAt),
      'deletedAt': serializer.toJson<String?>(deletedAt),
      'version': serializer.toJson<int>(version),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'id': serializer.toJson<String>(id),
      'userId': serializer.toJson<String>(userId),
      'personId': serializer.toJson<String>(personId),
      'type': serializer.toJson<String>(type),
      'principalPaisa': serializer.toJson<int>(principalPaisa),
      'txnDate': serializer.toJson<String>(txnDate),
      'dueDate': serializer.toJson<String?>(dueDate),
      'walletId': serializer.toJson<String?>(walletId),
      'note': serializer.toJson<String?>(note),
    };
  }

  Loan copyWith(
          {String? createdAt,
          String? updatedAt,
          Value<String?> deletedAt = const Value.absent(),
          int? version,
          String? syncStatus,
          String? id,
          String? userId,
          String? personId,
          String? type,
          int? principalPaisa,
          String? txnDate,
          Value<String?> dueDate = const Value.absent(),
          Value<String?> walletId = const Value.absent(),
          Value<String?> note = const Value.absent()}) =>
      Loan(
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: deletedAt.present ? deletedAt.value : this.deletedAt,
        version: version ?? this.version,
        syncStatus: syncStatus ?? this.syncStatus,
        id: id ?? this.id,
        userId: userId ?? this.userId,
        personId: personId ?? this.personId,
        type: type ?? this.type,
        principalPaisa: principalPaisa ?? this.principalPaisa,
        txnDate: txnDate ?? this.txnDate,
        dueDate: dueDate.present ? dueDate.value : this.dueDate,
        walletId: walletId.present ? walletId.value : this.walletId,
        note: note.present ? note.value : this.note,
      );
  Loan copyWithCompanion(LoansCompanion data) {
    return Loan(
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      deletedAt: data.deletedAt.present ? data.deletedAt.value : this.deletedAt,
      version: data.version.present ? data.version.value : this.version,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      id: data.id.present ? data.id.value : this.id,
      userId: data.userId.present ? data.userId.value : this.userId,
      personId: data.personId.present ? data.personId.value : this.personId,
      type: data.type.present ? data.type.value : this.type,
      principalPaisa: data.principalPaisa.present
          ? data.principalPaisa.value
          : this.principalPaisa,
      txnDate: data.txnDate.present ? data.txnDate.value : this.txnDate,
      dueDate: data.dueDate.present ? data.dueDate.value : this.dueDate,
      walletId: data.walletId.present ? data.walletId.value : this.walletId,
      note: data.note.present ? data.note.value : this.note,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Loan(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('personId: $personId, ')
          ..write('type: $type, ')
          ..write('principalPaisa: $principalPaisa, ')
          ..write('txnDate: $txnDate, ')
          ..write('dueDate: $dueDate, ')
          ..write('walletId: $walletId, ')
          ..write('note: $note')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      createdAt,
      updatedAt,
      deletedAt,
      version,
      syncStatus,
      id,
      userId,
      personId,
      type,
      principalPaisa,
      txnDate,
      dueDate,
      walletId,
      note);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Loan &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.deletedAt == this.deletedAt &&
          other.version == this.version &&
          other.syncStatus == this.syncStatus &&
          other.id == this.id &&
          other.userId == this.userId &&
          other.personId == this.personId &&
          other.type == this.type &&
          other.principalPaisa == this.principalPaisa &&
          other.txnDate == this.txnDate &&
          other.dueDate == this.dueDate &&
          other.walletId == this.walletId &&
          other.note == this.note);
}

class LoansCompanion extends UpdateCompanion<Loan> {
  final Value<String> createdAt;
  final Value<String> updatedAt;
  final Value<String?> deletedAt;
  final Value<int> version;
  final Value<String> syncStatus;
  final Value<String> id;
  final Value<String> userId;
  final Value<String> personId;
  final Value<String> type;
  final Value<int> principalPaisa;
  final Value<String> txnDate;
  final Value<String?> dueDate;
  final Value<String?> walletId;
  final Value<String?> note;
  final Value<int> rowid;
  const LoansCompanion({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.id = const Value.absent(),
    this.userId = const Value.absent(),
    this.personId = const Value.absent(),
    this.type = const Value.absent(),
    this.principalPaisa = const Value.absent(),
    this.txnDate = const Value.absent(),
    this.dueDate = const Value.absent(),
    this.walletId = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  LoansCompanion.insert({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    required String id,
    required String userId,
    required String personId,
    this.type = const Value.absent(),
    required int principalPaisa,
    required String txnDate,
    this.dueDate = const Value.absent(),
    this.walletId = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        userId = Value(userId),
        personId = Value(personId),
        principalPaisa = Value(principalPaisa),
        txnDate = Value(txnDate);
  static Insertable<Loan> custom({
    Expression<String>? createdAt,
    Expression<String>? updatedAt,
    Expression<String>? deletedAt,
    Expression<int>? version,
    Expression<String>? syncStatus,
    Expression<String>? id,
    Expression<String>? userId,
    Expression<String>? personId,
    Expression<String>? type,
    Expression<int>? principalPaisa,
    Expression<String>? txnDate,
    Expression<String>? dueDate,
    Expression<String>? walletId,
    Expression<String>? note,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (deletedAt != null) 'deleted_at': deletedAt,
      if (version != null) 'version': version,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (id != null) 'id': id,
      if (userId != null) 'user_id': userId,
      if (personId != null) 'person_id': personId,
      if (type != null) 'type': type,
      if (principalPaisa != null) 'principal_paisa': principalPaisa,
      if (txnDate != null) 'txn_date': txnDate,
      if (dueDate != null) 'due_date': dueDate,
      if (walletId != null) 'wallet_id': walletId,
      if (note != null) 'note': note,
      if (rowid != null) 'rowid': rowid,
    });
  }

  LoansCompanion copyWith(
      {Value<String>? createdAt,
      Value<String>? updatedAt,
      Value<String?>? deletedAt,
      Value<int>? version,
      Value<String>? syncStatus,
      Value<String>? id,
      Value<String>? userId,
      Value<String>? personId,
      Value<String>? type,
      Value<int>? principalPaisa,
      Value<String>? txnDate,
      Value<String?>? dueDate,
      Value<String?>? walletId,
      Value<String?>? note,
      Value<int>? rowid}) {
    return LoansCompanion(
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      version: version ?? this.version,
      syncStatus: syncStatus ?? this.syncStatus,
      id: id ?? this.id,
      userId: userId ?? this.userId,
      personId: personId ?? this.personId,
      type: type ?? this.type,
      principalPaisa: principalPaisa ?? this.principalPaisa,
      txnDate: txnDate ?? this.txnDate,
      dueDate: dueDate ?? this.dueDate,
      walletId: walletId ?? this.walletId,
      note: note ?? this.note,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (createdAt.present) {
      map['created_at'] = Variable<String>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<String>(updatedAt.value);
    }
    if (deletedAt.present) {
      map['deleted_at'] = Variable<String>(deletedAt.value);
    }
    if (version.present) {
      map['version'] = Variable<int>(version.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<String>(userId.value);
    }
    if (personId.present) {
      map['person_id'] = Variable<String>(personId.value);
    }
    if (type.present) {
      map['type'] = Variable<String>(type.value);
    }
    if (principalPaisa.present) {
      map['principal_paisa'] = Variable<int>(principalPaisa.value);
    }
    if (txnDate.present) {
      map['txn_date'] = Variable<String>(txnDate.value);
    }
    if (dueDate.present) {
      map['due_date'] = Variable<String>(dueDate.value);
    }
    if (walletId.present) {
      map['wallet_id'] = Variable<String>(walletId.value);
    }
    if (note.present) {
      map['note'] = Variable<String>(note.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('LoansCompanion(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('personId: $personId, ')
          ..write('type: $type, ')
          ..write('principalPaisa: $principalPaisa, ')
          ..write('txnDate: $txnDate, ')
          ..write('dueDate: $dueDate, ')
          ..write('walletId: $walletId, ')
          ..write('note: $note, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $LoanPaymentsTable extends LoanPayments
    with TableInfo<$LoanPaymentsTable, LoanPayment> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $LoanPaymentsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<String> createdAt = GeneratedColumn<String>(
      'created_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<String> updatedAt = GeneratedColumn<String>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _deletedAtMeta =
      const VerificationMeta('deletedAt');
  @override
  late final GeneratedColumn<String> deletedAt = GeneratedColumn<String>(
      'deleted_at', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _versionMeta =
      const VerificationMeta('version');
  @override
  late final GeneratedColumn<int> version = GeneratedColumn<int>(
      'version', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('pending'));
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<String> userId = GeneratedColumn<String>(
      'user_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _loanIdMeta = const VerificationMeta('loanId');
  @override
  late final GeneratedColumn<String> loanId = GeneratedColumn<String>(
      'loan_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _txnDateMeta =
      const VerificationMeta('txnDate');
  @override
  late final GeneratedColumn<String> txnDate = GeneratedColumn<String>(
      'txn_date', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _amountPaisaMeta =
      const VerificationMeta('amountPaisa');
  @override
  late final GeneratedColumn<int> amountPaisa = GeneratedColumn<int>(
      'amount_paisa', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _walletIdMeta =
      const VerificationMeta('walletId');
  @override
  late final GeneratedColumn<String> walletId = GeneratedColumn<String>(
      'wallet_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _noteMeta = const VerificationMeta('note');
  @override
  late final GeneratedColumn<String> note = GeneratedColumn<String>(
      'note', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        createdAt,
        updatedAt,
        deletedAt,
        version,
        syncStatus,
        id,
        userId,
        loanId,
        txnDate,
        amountPaisa,
        walletId,
        note
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'loan_payments';
  @override
  VerificationContext validateIntegrity(Insertable<LoanPayment> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    if (data.containsKey('deleted_at')) {
      context.handle(_deletedAtMeta,
          deletedAt.isAcceptableOrUnknown(data['deleted_at']!, _deletedAtMeta));
    }
    if (data.containsKey('version')) {
      context.handle(_versionMeta,
          version.isAcceptableOrUnknown(data['version']!, _versionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('user_id')) {
      context.handle(_userIdMeta,
          userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta));
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('loan_id')) {
      context.handle(_loanIdMeta,
          loanId.isAcceptableOrUnknown(data['loan_id']!, _loanIdMeta));
    } else if (isInserting) {
      context.missing(_loanIdMeta);
    }
    if (data.containsKey('txn_date')) {
      context.handle(_txnDateMeta,
          txnDate.isAcceptableOrUnknown(data['txn_date']!, _txnDateMeta));
    } else if (isInserting) {
      context.missing(_txnDateMeta);
    }
    if (data.containsKey('amount_paisa')) {
      context.handle(
          _amountPaisaMeta,
          amountPaisa.isAcceptableOrUnknown(
              data['amount_paisa']!, _amountPaisaMeta));
    } else if (isInserting) {
      context.missing(_amountPaisaMeta);
    }
    if (data.containsKey('wallet_id')) {
      context.handle(_walletIdMeta,
          walletId.isAcceptableOrUnknown(data['wallet_id']!, _walletIdMeta));
    }
    if (data.containsKey('note')) {
      context.handle(
          _noteMeta, note.isAcceptableOrUnknown(data['note']!, _noteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  LoanPayment map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return LoanPayment(
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}updated_at'])!,
      deletedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}deleted_at']),
      version: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}version'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      userId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}user_id'])!,
      loanId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}loan_id'])!,
      txnDate: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}txn_date'])!,
      amountPaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}amount_paisa'])!,
      walletId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}wallet_id']),
      note: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}note']),
    );
  }

  @override
  $LoanPaymentsTable createAlias(String alias) {
    return $LoanPaymentsTable(attachedDatabase, alias);
  }
}

class LoanPayment extends DataClass implements Insertable<LoanPayment> {
  final String createdAt;
  final String updatedAt;
  final String? deletedAt;
  final int version;
  final String syncStatus;
  final String id;
  final String userId;
  final String loanId;
  final String txnDate;
  final int amountPaisa;
  final String? walletId;
  final String? note;
  const LoanPayment(
      {required this.createdAt,
      required this.updatedAt,
      this.deletedAt,
      required this.version,
      required this.syncStatus,
      required this.id,
      required this.userId,
      required this.loanId,
      required this.txnDate,
      required this.amountPaisa,
      this.walletId,
      this.note});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['created_at'] = Variable<String>(createdAt);
    map['updated_at'] = Variable<String>(updatedAt);
    if (!nullToAbsent || deletedAt != null) {
      map['deleted_at'] = Variable<String>(deletedAt);
    }
    map['version'] = Variable<int>(version);
    map['sync_status'] = Variable<String>(syncStatus);
    map['id'] = Variable<String>(id);
    map['user_id'] = Variable<String>(userId);
    map['loan_id'] = Variable<String>(loanId);
    map['txn_date'] = Variable<String>(txnDate);
    map['amount_paisa'] = Variable<int>(amountPaisa);
    if (!nullToAbsent || walletId != null) {
      map['wallet_id'] = Variable<String>(walletId);
    }
    if (!nullToAbsent || note != null) {
      map['note'] = Variable<String>(note);
    }
    return map;
  }

  LoanPaymentsCompanion toCompanion(bool nullToAbsent) {
    return LoanPaymentsCompanion(
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      deletedAt: deletedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(deletedAt),
      version: Value(version),
      syncStatus: Value(syncStatus),
      id: Value(id),
      userId: Value(userId),
      loanId: Value(loanId),
      txnDate: Value(txnDate),
      amountPaisa: Value(amountPaisa),
      walletId: walletId == null && nullToAbsent
          ? const Value.absent()
          : Value(walletId),
      note: note == null && nullToAbsent ? const Value.absent() : Value(note),
    );
  }

  factory LoanPayment.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return LoanPayment(
      createdAt: serializer.fromJson<String>(json['createdAt']),
      updatedAt: serializer.fromJson<String>(json['updatedAt']),
      deletedAt: serializer.fromJson<String?>(json['deletedAt']),
      version: serializer.fromJson<int>(json['version']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      id: serializer.fromJson<String>(json['id']),
      userId: serializer.fromJson<String>(json['userId']),
      loanId: serializer.fromJson<String>(json['loanId']),
      txnDate: serializer.fromJson<String>(json['txnDate']),
      amountPaisa: serializer.fromJson<int>(json['amountPaisa']),
      walletId: serializer.fromJson<String?>(json['walletId']),
      note: serializer.fromJson<String?>(json['note']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'createdAt': serializer.toJson<String>(createdAt),
      'updatedAt': serializer.toJson<String>(updatedAt),
      'deletedAt': serializer.toJson<String?>(deletedAt),
      'version': serializer.toJson<int>(version),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'id': serializer.toJson<String>(id),
      'userId': serializer.toJson<String>(userId),
      'loanId': serializer.toJson<String>(loanId),
      'txnDate': serializer.toJson<String>(txnDate),
      'amountPaisa': serializer.toJson<int>(amountPaisa),
      'walletId': serializer.toJson<String?>(walletId),
      'note': serializer.toJson<String?>(note),
    };
  }

  LoanPayment copyWith(
          {String? createdAt,
          String? updatedAt,
          Value<String?> deletedAt = const Value.absent(),
          int? version,
          String? syncStatus,
          String? id,
          String? userId,
          String? loanId,
          String? txnDate,
          int? amountPaisa,
          Value<String?> walletId = const Value.absent(),
          Value<String?> note = const Value.absent()}) =>
      LoanPayment(
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: deletedAt.present ? deletedAt.value : this.deletedAt,
        version: version ?? this.version,
        syncStatus: syncStatus ?? this.syncStatus,
        id: id ?? this.id,
        userId: userId ?? this.userId,
        loanId: loanId ?? this.loanId,
        txnDate: txnDate ?? this.txnDate,
        amountPaisa: amountPaisa ?? this.amountPaisa,
        walletId: walletId.present ? walletId.value : this.walletId,
        note: note.present ? note.value : this.note,
      );
  LoanPayment copyWithCompanion(LoanPaymentsCompanion data) {
    return LoanPayment(
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      deletedAt: data.deletedAt.present ? data.deletedAt.value : this.deletedAt,
      version: data.version.present ? data.version.value : this.version,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      id: data.id.present ? data.id.value : this.id,
      userId: data.userId.present ? data.userId.value : this.userId,
      loanId: data.loanId.present ? data.loanId.value : this.loanId,
      txnDate: data.txnDate.present ? data.txnDate.value : this.txnDate,
      amountPaisa:
          data.amountPaisa.present ? data.amountPaisa.value : this.amountPaisa,
      walletId: data.walletId.present ? data.walletId.value : this.walletId,
      note: data.note.present ? data.note.value : this.note,
    );
  }

  @override
  String toString() {
    return (StringBuffer('LoanPayment(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('loanId: $loanId, ')
          ..write('txnDate: $txnDate, ')
          ..write('amountPaisa: $amountPaisa, ')
          ..write('walletId: $walletId, ')
          ..write('note: $note')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(createdAt, updatedAt, deletedAt, version,
      syncStatus, id, userId, loanId, txnDate, amountPaisa, walletId, note);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is LoanPayment &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.deletedAt == this.deletedAt &&
          other.version == this.version &&
          other.syncStatus == this.syncStatus &&
          other.id == this.id &&
          other.userId == this.userId &&
          other.loanId == this.loanId &&
          other.txnDate == this.txnDate &&
          other.amountPaisa == this.amountPaisa &&
          other.walletId == this.walletId &&
          other.note == this.note);
}

class LoanPaymentsCompanion extends UpdateCompanion<LoanPayment> {
  final Value<String> createdAt;
  final Value<String> updatedAt;
  final Value<String?> deletedAt;
  final Value<int> version;
  final Value<String> syncStatus;
  final Value<String> id;
  final Value<String> userId;
  final Value<String> loanId;
  final Value<String> txnDate;
  final Value<int> amountPaisa;
  final Value<String?> walletId;
  final Value<String?> note;
  final Value<int> rowid;
  const LoanPaymentsCompanion({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.id = const Value.absent(),
    this.userId = const Value.absent(),
    this.loanId = const Value.absent(),
    this.txnDate = const Value.absent(),
    this.amountPaisa = const Value.absent(),
    this.walletId = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  LoanPaymentsCompanion.insert({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    required String id,
    required String userId,
    required String loanId,
    required String txnDate,
    required int amountPaisa,
    this.walletId = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        userId = Value(userId),
        loanId = Value(loanId),
        txnDate = Value(txnDate),
        amountPaisa = Value(amountPaisa);
  static Insertable<LoanPayment> custom({
    Expression<String>? createdAt,
    Expression<String>? updatedAt,
    Expression<String>? deletedAt,
    Expression<int>? version,
    Expression<String>? syncStatus,
    Expression<String>? id,
    Expression<String>? userId,
    Expression<String>? loanId,
    Expression<String>? txnDate,
    Expression<int>? amountPaisa,
    Expression<String>? walletId,
    Expression<String>? note,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (deletedAt != null) 'deleted_at': deletedAt,
      if (version != null) 'version': version,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (id != null) 'id': id,
      if (userId != null) 'user_id': userId,
      if (loanId != null) 'loan_id': loanId,
      if (txnDate != null) 'txn_date': txnDate,
      if (amountPaisa != null) 'amount_paisa': amountPaisa,
      if (walletId != null) 'wallet_id': walletId,
      if (note != null) 'note': note,
      if (rowid != null) 'rowid': rowid,
    });
  }

  LoanPaymentsCompanion copyWith(
      {Value<String>? createdAt,
      Value<String>? updatedAt,
      Value<String?>? deletedAt,
      Value<int>? version,
      Value<String>? syncStatus,
      Value<String>? id,
      Value<String>? userId,
      Value<String>? loanId,
      Value<String>? txnDate,
      Value<int>? amountPaisa,
      Value<String?>? walletId,
      Value<String?>? note,
      Value<int>? rowid}) {
    return LoanPaymentsCompanion(
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      version: version ?? this.version,
      syncStatus: syncStatus ?? this.syncStatus,
      id: id ?? this.id,
      userId: userId ?? this.userId,
      loanId: loanId ?? this.loanId,
      txnDate: txnDate ?? this.txnDate,
      amountPaisa: amountPaisa ?? this.amountPaisa,
      walletId: walletId ?? this.walletId,
      note: note ?? this.note,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (createdAt.present) {
      map['created_at'] = Variable<String>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<String>(updatedAt.value);
    }
    if (deletedAt.present) {
      map['deleted_at'] = Variable<String>(deletedAt.value);
    }
    if (version.present) {
      map['version'] = Variable<int>(version.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<String>(userId.value);
    }
    if (loanId.present) {
      map['loan_id'] = Variable<String>(loanId.value);
    }
    if (txnDate.present) {
      map['txn_date'] = Variable<String>(txnDate.value);
    }
    if (amountPaisa.present) {
      map['amount_paisa'] = Variable<int>(amountPaisa.value);
    }
    if (walletId.present) {
      map['wallet_id'] = Variable<String>(walletId.value);
    }
    if (note.present) {
      map['note'] = Variable<String>(note.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('LoanPaymentsCompanion(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('loanId: $loanId, ')
          ..write('txnDate: $txnDate, ')
          ..write('amountPaisa: $amountPaisa, ')
          ..write('walletId: $walletId, ')
          ..write('note: $note, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $FuelLogsTable extends FuelLogs with TableInfo<$FuelLogsTable, FuelLog> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FuelLogsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<String> createdAt = GeneratedColumn<String>(
      'created_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<String> updatedAt = GeneratedColumn<String>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _deletedAtMeta =
      const VerificationMeta('deletedAt');
  @override
  late final GeneratedColumn<String> deletedAt = GeneratedColumn<String>(
      'deleted_at', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _versionMeta =
      const VerificationMeta('version');
  @override
  late final GeneratedColumn<int> version = GeneratedColumn<int>(
      'version', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('pending'));
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<String> userId = GeneratedColumn<String>(
      'user_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _txnDateMeta =
      const VerificationMeta('txnDate');
  @override
  late final GeneratedColumn<String> txnDate = GeneratedColumn<String>(
      'txn_date', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _odometerKmMeta =
      const VerificationMeta('odometerKm');
  @override
  late final GeneratedColumn<double> odometerKm = GeneratedColumn<double>(
      'odometer_km', aliasedName, false,
      type: DriftSqlType.double, requiredDuringInsert: true);
  static const VerificationMeta _amountPaisaMeta =
      const VerificationMeta('amountPaisa');
  @override
  late final GeneratedColumn<int> amountPaisa = GeneratedColumn<int>(
      'amount_paisa', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _litreMeta = const VerificationMeta('litre');
  @override
  late final GeneratedColumn<double> litre = GeneratedColumn<double>(
      'litre', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _pricePerLitrePaisaMeta =
      const VerificationMeta('pricePerLitrePaisa');
  @override
  late final GeneratedColumn<int> pricePerLitrePaisa = GeneratedColumn<int>(
      'price_per_litre_paisa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _isFullTankMeta =
      const VerificationMeta('isFullTank');
  @override
  late final GeneratedColumn<bool> isFullTank = GeneratedColumn<bool>(
      'is_full_tank', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints: GeneratedColumn.constraintIsAlways(
          'CHECK ("is_full_tank" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _pumpNameMeta =
      const VerificationMeta('pumpName');
  @override
  late final GeneratedColumn<String> pumpName = GeneratedColumn<String>(
      'pump_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _walletIdMeta =
      const VerificationMeta('walletId');
  @override
  late final GeneratedColumn<String> walletId = GeneratedColumn<String>(
      'wallet_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _noteMeta = const VerificationMeta('note');
  @override
  late final GeneratedColumn<String> note = GeneratedColumn<String>(
      'note', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        createdAt,
        updatedAt,
        deletedAt,
        version,
        syncStatus,
        id,
        userId,
        txnDate,
        odometerKm,
        amountPaisa,
        litre,
        pricePerLitrePaisa,
        isFullTank,
        pumpName,
        walletId,
        note
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fuel_logs';
  @override
  VerificationContext validateIntegrity(Insertable<FuelLog> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    if (data.containsKey('deleted_at')) {
      context.handle(_deletedAtMeta,
          deletedAt.isAcceptableOrUnknown(data['deleted_at']!, _deletedAtMeta));
    }
    if (data.containsKey('version')) {
      context.handle(_versionMeta,
          version.isAcceptableOrUnknown(data['version']!, _versionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('user_id')) {
      context.handle(_userIdMeta,
          userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta));
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('txn_date')) {
      context.handle(_txnDateMeta,
          txnDate.isAcceptableOrUnknown(data['txn_date']!, _txnDateMeta));
    } else if (isInserting) {
      context.missing(_txnDateMeta);
    }
    if (data.containsKey('odometer_km')) {
      context.handle(
          _odometerKmMeta,
          odometerKm.isAcceptableOrUnknown(
              data['odometer_km']!, _odometerKmMeta));
    } else if (isInserting) {
      context.missing(_odometerKmMeta);
    }
    if (data.containsKey('amount_paisa')) {
      context.handle(
          _amountPaisaMeta,
          amountPaisa.isAcceptableOrUnknown(
              data['amount_paisa']!, _amountPaisaMeta));
    } else if (isInserting) {
      context.missing(_amountPaisaMeta);
    }
    if (data.containsKey('litre')) {
      context.handle(
          _litreMeta, litre.isAcceptableOrUnknown(data['litre']!, _litreMeta));
    }
    if (data.containsKey('price_per_litre_paisa')) {
      context.handle(
          _pricePerLitrePaisaMeta,
          pricePerLitrePaisa.isAcceptableOrUnknown(
              data['price_per_litre_paisa']!, _pricePerLitrePaisaMeta));
    }
    if (data.containsKey('is_full_tank')) {
      context.handle(
          _isFullTankMeta,
          isFullTank.isAcceptableOrUnknown(
              data['is_full_tank']!, _isFullTankMeta));
    }
    if (data.containsKey('pump_name')) {
      context.handle(_pumpNameMeta,
          pumpName.isAcceptableOrUnknown(data['pump_name']!, _pumpNameMeta));
    }
    if (data.containsKey('wallet_id')) {
      context.handle(_walletIdMeta,
          walletId.isAcceptableOrUnknown(data['wallet_id']!, _walletIdMeta));
    }
    if (data.containsKey('note')) {
      context.handle(
          _noteMeta, note.isAcceptableOrUnknown(data['note']!, _noteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FuelLog map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FuelLog(
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}updated_at'])!,
      deletedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}deleted_at']),
      version: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}version'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      userId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}user_id'])!,
      txnDate: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}txn_date'])!,
      odometerKm: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}odometer_km'])!,
      amountPaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}amount_paisa'])!,
      litre: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}litre']),
      pricePerLitrePaisa: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}price_per_litre_paisa']),
      isFullTank: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_full_tank'])!,
      pumpName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pump_name']),
      walletId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}wallet_id']),
      note: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}note']),
    );
  }

  @override
  $FuelLogsTable createAlias(String alias) {
    return $FuelLogsTable(attachedDatabase, alias);
  }
}

class FuelLog extends DataClass implements Insertable<FuelLog> {
  final String createdAt;
  final String updatedAt;
  final String? deletedAt;
  final int version;
  final String syncStatus;
  final String id;
  final String userId;
  final String txnDate;
  final double odometerKm;
  final int amountPaisa;
  final double? litre;
  final int? pricePerLitrePaisa;
  final bool isFullTank;
  final String? pumpName;
  final String? walletId;
  final String? note;
  const FuelLog(
      {required this.createdAt,
      required this.updatedAt,
      this.deletedAt,
      required this.version,
      required this.syncStatus,
      required this.id,
      required this.userId,
      required this.txnDate,
      required this.odometerKm,
      required this.amountPaisa,
      this.litre,
      this.pricePerLitrePaisa,
      required this.isFullTank,
      this.pumpName,
      this.walletId,
      this.note});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['created_at'] = Variable<String>(createdAt);
    map['updated_at'] = Variable<String>(updatedAt);
    if (!nullToAbsent || deletedAt != null) {
      map['deleted_at'] = Variable<String>(deletedAt);
    }
    map['version'] = Variable<int>(version);
    map['sync_status'] = Variable<String>(syncStatus);
    map['id'] = Variable<String>(id);
    map['user_id'] = Variable<String>(userId);
    map['txn_date'] = Variable<String>(txnDate);
    map['odometer_km'] = Variable<double>(odometerKm);
    map['amount_paisa'] = Variable<int>(amountPaisa);
    if (!nullToAbsent || litre != null) {
      map['litre'] = Variable<double>(litre);
    }
    if (!nullToAbsent || pricePerLitrePaisa != null) {
      map['price_per_litre_paisa'] = Variable<int>(pricePerLitrePaisa);
    }
    map['is_full_tank'] = Variable<bool>(isFullTank);
    if (!nullToAbsent || pumpName != null) {
      map['pump_name'] = Variable<String>(pumpName);
    }
    if (!nullToAbsent || walletId != null) {
      map['wallet_id'] = Variable<String>(walletId);
    }
    if (!nullToAbsent || note != null) {
      map['note'] = Variable<String>(note);
    }
    return map;
  }

  FuelLogsCompanion toCompanion(bool nullToAbsent) {
    return FuelLogsCompanion(
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      deletedAt: deletedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(deletedAt),
      version: Value(version),
      syncStatus: Value(syncStatus),
      id: Value(id),
      userId: Value(userId),
      txnDate: Value(txnDate),
      odometerKm: Value(odometerKm),
      amountPaisa: Value(amountPaisa),
      litre:
          litre == null && nullToAbsent ? const Value.absent() : Value(litre),
      pricePerLitrePaisa: pricePerLitrePaisa == null && nullToAbsent
          ? const Value.absent()
          : Value(pricePerLitrePaisa),
      isFullTank: Value(isFullTank),
      pumpName: pumpName == null && nullToAbsent
          ? const Value.absent()
          : Value(pumpName),
      walletId: walletId == null && nullToAbsent
          ? const Value.absent()
          : Value(walletId),
      note: note == null && nullToAbsent ? const Value.absent() : Value(note),
    );
  }

  factory FuelLog.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FuelLog(
      createdAt: serializer.fromJson<String>(json['createdAt']),
      updatedAt: serializer.fromJson<String>(json['updatedAt']),
      deletedAt: serializer.fromJson<String?>(json['deletedAt']),
      version: serializer.fromJson<int>(json['version']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      id: serializer.fromJson<String>(json['id']),
      userId: serializer.fromJson<String>(json['userId']),
      txnDate: serializer.fromJson<String>(json['txnDate']),
      odometerKm: serializer.fromJson<double>(json['odometerKm']),
      amountPaisa: serializer.fromJson<int>(json['amountPaisa']),
      litre: serializer.fromJson<double?>(json['litre']),
      pricePerLitrePaisa: serializer.fromJson<int?>(json['pricePerLitrePaisa']),
      isFullTank: serializer.fromJson<bool>(json['isFullTank']),
      pumpName: serializer.fromJson<String?>(json['pumpName']),
      walletId: serializer.fromJson<String?>(json['walletId']),
      note: serializer.fromJson<String?>(json['note']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'createdAt': serializer.toJson<String>(createdAt),
      'updatedAt': serializer.toJson<String>(updatedAt),
      'deletedAt': serializer.toJson<String?>(deletedAt),
      'version': serializer.toJson<int>(version),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'id': serializer.toJson<String>(id),
      'userId': serializer.toJson<String>(userId),
      'txnDate': serializer.toJson<String>(txnDate),
      'odometerKm': serializer.toJson<double>(odometerKm),
      'amountPaisa': serializer.toJson<int>(amountPaisa),
      'litre': serializer.toJson<double?>(litre),
      'pricePerLitrePaisa': serializer.toJson<int?>(pricePerLitrePaisa),
      'isFullTank': serializer.toJson<bool>(isFullTank),
      'pumpName': serializer.toJson<String?>(pumpName),
      'walletId': serializer.toJson<String?>(walletId),
      'note': serializer.toJson<String?>(note),
    };
  }

  FuelLog copyWith(
          {String? createdAt,
          String? updatedAt,
          Value<String?> deletedAt = const Value.absent(),
          int? version,
          String? syncStatus,
          String? id,
          String? userId,
          String? txnDate,
          double? odometerKm,
          int? amountPaisa,
          Value<double?> litre = const Value.absent(),
          Value<int?> pricePerLitrePaisa = const Value.absent(),
          bool? isFullTank,
          Value<String?> pumpName = const Value.absent(),
          Value<String?> walletId = const Value.absent(),
          Value<String?> note = const Value.absent()}) =>
      FuelLog(
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: deletedAt.present ? deletedAt.value : this.deletedAt,
        version: version ?? this.version,
        syncStatus: syncStatus ?? this.syncStatus,
        id: id ?? this.id,
        userId: userId ?? this.userId,
        txnDate: txnDate ?? this.txnDate,
        odometerKm: odometerKm ?? this.odometerKm,
        amountPaisa: amountPaisa ?? this.amountPaisa,
        litre: litre.present ? litre.value : this.litre,
        pricePerLitrePaisa: pricePerLitrePaisa.present
            ? pricePerLitrePaisa.value
            : this.pricePerLitrePaisa,
        isFullTank: isFullTank ?? this.isFullTank,
        pumpName: pumpName.present ? pumpName.value : this.pumpName,
        walletId: walletId.present ? walletId.value : this.walletId,
        note: note.present ? note.value : this.note,
      );
  FuelLog copyWithCompanion(FuelLogsCompanion data) {
    return FuelLog(
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      deletedAt: data.deletedAt.present ? data.deletedAt.value : this.deletedAt,
      version: data.version.present ? data.version.value : this.version,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      id: data.id.present ? data.id.value : this.id,
      userId: data.userId.present ? data.userId.value : this.userId,
      txnDate: data.txnDate.present ? data.txnDate.value : this.txnDate,
      odometerKm:
          data.odometerKm.present ? data.odometerKm.value : this.odometerKm,
      amountPaisa:
          data.amountPaisa.present ? data.amountPaisa.value : this.amountPaisa,
      litre: data.litre.present ? data.litre.value : this.litre,
      pricePerLitrePaisa: data.pricePerLitrePaisa.present
          ? data.pricePerLitrePaisa.value
          : this.pricePerLitrePaisa,
      isFullTank:
          data.isFullTank.present ? data.isFullTank.value : this.isFullTank,
      pumpName: data.pumpName.present ? data.pumpName.value : this.pumpName,
      walletId: data.walletId.present ? data.walletId.value : this.walletId,
      note: data.note.present ? data.note.value : this.note,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FuelLog(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('txnDate: $txnDate, ')
          ..write('odometerKm: $odometerKm, ')
          ..write('amountPaisa: $amountPaisa, ')
          ..write('litre: $litre, ')
          ..write('pricePerLitrePaisa: $pricePerLitrePaisa, ')
          ..write('isFullTank: $isFullTank, ')
          ..write('pumpName: $pumpName, ')
          ..write('walletId: $walletId, ')
          ..write('note: $note')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      createdAt,
      updatedAt,
      deletedAt,
      version,
      syncStatus,
      id,
      userId,
      txnDate,
      odometerKm,
      amountPaisa,
      litre,
      pricePerLitrePaisa,
      isFullTank,
      pumpName,
      walletId,
      note);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FuelLog &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.deletedAt == this.deletedAt &&
          other.version == this.version &&
          other.syncStatus == this.syncStatus &&
          other.id == this.id &&
          other.userId == this.userId &&
          other.txnDate == this.txnDate &&
          other.odometerKm == this.odometerKm &&
          other.amountPaisa == this.amountPaisa &&
          other.litre == this.litre &&
          other.pricePerLitrePaisa == this.pricePerLitrePaisa &&
          other.isFullTank == this.isFullTank &&
          other.pumpName == this.pumpName &&
          other.walletId == this.walletId &&
          other.note == this.note);
}

class FuelLogsCompanion extends UpdateCompanion<FuelLog> {
  final Value<String> createdAt;
  final Value<String> updatedAt;
  final Value<String?> deletedAt;
  final Value<int> version;
  final Value<String> syncStatus;
  final Value<String> id;
  final Value<String> userId;
  final Value<String> txnDate;
  final Value<double> odometerKm;
  final Value<int> amountPaisa;
  final Value<double?> litre;
  final Value<int?> pricePerLitrePaisa;
  final Value<bool> isFullTank;
  final Value<String?> pumpName;
  final Value<String?> walletId;
  final Value<String?> note;
  final Value<int> rowid;
  const FuelLogsCompanion({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.id = const Value.absent(),
    this.userId = const Value.absent(),
    this.txnDate = const Value.absent(),
    this.odometerKm = const Value.absent(),
    this.amountPaisa = const Value.absent(),
    this.litre = const Value.absent(),
    this.pricePerLitrePaisa = const Value.absent(),
    this.isFullTank = const Value.absent(),
    this.pumpName = const Value.absent(),
    this.walletId = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  FuelLogsCompanion.insert({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    required String id,
    required String userId,
    required String txnDate,
    required double odometerKm,
    required int amountPaisa,
    this.litre = const Value.absent(),
    this.pricePerLitrePaisa = const Value.absent(),
    this.isFullTank = const Value.absent(),
    this.pumpName = const Value.absent(),
    this.walletId = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        userId = Value(userId),
        txnDate = Value(txnDate),
        odometerKm = Value(odometerKm),
        amountPaisa = Value(amountPaisa);
  static Insertable<FuelLog> custom({
    Expression<String>? createdAt,
    Expression<String>? updatedAt,
    Expression<String>? deletedAt,
    Expression<int>? version,
    Expression<String>? syncStatus,
    Expression<String>? id,
    Expression<String>? userId,
    Expression<String>? txnDate,
    Expression<double>? odometerKm,
    Expression<int>? amountPaisa,
    Expression<double>? litre,
    Expression<int>? pricePerLitrePaisa,
    Expression<bool>? isFullTank,
    Expression<String>? pumpName,
    Expression<String>? walletId,
    Expression<String>? note,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (deletedAt != null) 'deleted_at': deletedAt,
      if (version != null) 'version': version,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (id != null) 'id': id,
      if (userId != null) 'user_id': userId,
      if (txnDate != null) 'txn_date': txnDate,
      if (odometerKm != null) 'odometer_km': odometerKm,
      if (amountPaisa != null) 'amount_paisa': amountPaisa,
      if (litre != null) 'litre': litre,
      if (pricePerLitrePaisa != null)
        'price_per_litre_paisa': pricePerLitrePaisa,
      if (isFullTank != null) 'is_full_tank': isFullTank,
      if (pumpName != null) 'pump_name': pumpName,
      if (walletId != null) 'wallet_id': walletId,
      if (note != null) 'note': note,
      if (rowid != null) 'rowid': rowid,
    });
  }

  FuelLogsCompanion copyWith(
      {Value<String>? createdAt,
      Value<String>? updatedAt,
      Value<String?>? deletedAt,
      Value<int>? version,
      Value<String>? syncStatus,
      Value<String>? id,
      Value<String>? userId,
      Value<String>? txnDate,
      Value<double>? odometerKm,
      Value<int>? amountPaisa,
      Value<double?>? litre,
      Value<int?>? pricePerLitrePaisa,
      Value<bool>? isFullTank,
      Value<String?>? pumpName,
      Value<String?>? walletId,
      Value<String?>? note,
      Value<int>? rowid}) {
    return FuelLogsCompanion(
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      version: version ?? this.version,
      syncStatus: syncStatus ?? this.syncStatus,
      id: id ?? this.id,
      userId: userId ?? this.userId,
      txnDate: txnDate ?? this.txnDate,
      odometerKm: odometerKm ?? this.odometerKm,
      amountPaisa: amountPaisa ?? this.amountPaisa,
      litre: litre ?? this.litre,
      pricePerLitrePaisa: pricePerLitrePaisa ?? this.pricePerLitrePaisa,
      isFullTank: isFullTank ?? this.isFullTank,
      pumpName: pumpName ?? this.pumpName,
      walletId: walletId ?? this.walletId,
      note: note ?? this.note,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (createdAt.present) {
      map['created_at'] = Variable<String>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<String>(updatedAt.value);
    }
    if (deletedAt.present) {
      map['deleted_at'] = Variable<String>(deletedAt.value);
    }
    if (version.present) {
      map['version'] = Variable<int>(version.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<String>(userId.value);
    }
    if (txnDate.present) {
      map['txn_date'] = Variable<String>(txnDate.value);
    }
    if (odometerKm.present) {
      map['odometer_km'] = Variable<double>(odometerKm.value);
    }
    if (amountPaisa.present) {
      map['amount_paisa'] = Variable<int>(amountPaisa.value);
    }
    if (litre.present) {
      map['litre'] = Variable<double>(litre.value);
    }
    if (pricePerLitrePaisa.present) {
      map['price_per_litre_paisa'] = Variable<int>(pricePerLitrePaisa.value);
    }
    if (isFullTank.present) {
      map['is_full_tank'] = Variable<bool>(isFullTank.value);
    }
    if (pumpName.present) {
      map['pump_name'] = Variable<String>(pumpName.value);
    }
    if (walletId.present) {
      map['wallet_id'] = Variable<String>(walletId.value);
    }
    if (note.present) {
      map['note'] = Variable<String>(note.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FuelLogsCompanion(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('txnDate: $txnDate, ')
          ..write('odometerKm: $odometerKm, ')
          ..write('amountPaisa: $amountPaisa, ')
          ..write('litre: $litre, ')
          ..write('pricePerLitrePaisa: $pricePerLitrePaisa, ')
          ..write('isFullTank: $isFullTank, ')
          ..write('pumpName: $pumpName, ')
          ..write('walletId: $walletId, ')
          ..write('note: $note, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $BikeMaintenanceTable extends BikeMaintenance
    with TableInfo<$BikeMaintenanceTable, BikeMaintenanceData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $BikeMaintenanceTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<String> createdAt = GeneratedColumn<String>(
      'created_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<String> updatedAt = GeneratedColumn<String>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _deletedAtMeta =
      const VerificationMeta('deletedAt');
  @override
  late final GeneratedColumn<String> deletedAt = GeneratedColumn<String>(
      'deleted_at', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _versionMeta =
      const VerificationMeta('version');
  @override
  late final GeneratedColumn<int> version = GeneratedColumn<int>(
      'version', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('pending'));
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<String> userId = GeneratedColumn<String>(
      'user_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _txnDateMeta =
      const VerificationMeta('txnDate');
  @override
  late final GeneratedColumn<String> txnDate = GeneratedColumn<String>(
      'txn_date', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _typeMeta = const VerificationMeta('type');
  @override
  late final GeneratedColumn<String> type = GeneratedColumn<String>(
      'type', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('other'));
  static const VerificationMeta _itemNameMeta =
      const VerificationMeta('itemName');
  @override
  late final GeneratedColumn<String> itemName = GeneratedColumn<String>(
      'item_name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _costPaisaMeta =
      const VerificationMeta('costPaisa');
  @override
  late final GeneratedColumn<int> costPaisa = GeneratedColumn<int>(
      'cost_paisa', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _odometerKmMeta =
      const VerificationMeta('odometerKm');
  @override
  late final GeneratedColumn<double> odometerKm = GeneratedColumn<double>(
      'odometer_km', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _nextServiceKmMeta =
      const VerificationMeta('nextServiceKm');
  @override
  late final GeneratedColumn<double> nextServiceKm = GeneratedColumn<double>(
      'next_service_km', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _nextServiceDateMeta =
      const VerificationMeta('nextServiceDate');
  @override
  late final GeneratedColumn<String> nextServiceDate = GeneratedColumn<String>(
      'next_service_date', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _walletIdMeta =
      const VerificationMeta('walletId');
  @override
  late final GeneratedColumn<String> walletId = GeneratedColumn<String>(
      'wallet_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _noteMeta = const VerificationMeta('note');
  @override
  late final GeneratedColumn<String> note = GeneratedColumn<String>(
      'note', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        createdAt,
        updatedAt,
        deletedAt,
        version,
        syncStatus,
        id,
        userId,
        txnDate,
        type,
        itemName,
        costPaisa,
        odometerKm,
        nextServiceKm,
        nextServiceDate,
        walletId,
        note
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'bike_maintenance';
  @override
  VerificationContext validateIntegrity(
      Insertable<BikeMaintenanceData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    if (data.containsKey('deleted_at')) {
      context.handle(_deletedAtMeta,
          deletedAt.isAcceptableOrUnknown(data['deleted_at']!, _deletedAtMeta));
    }
    if (data.containsKey('version')) {
      context.handle(_versionMeta,
          version.isAcceptableOrUnknown(data['version']!, _versionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('user_id')) {
      context.handle(_userIdMeta,
          userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta));
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('txn_date')) {
      context.handle(_txnDateMeta,
          txnDate.isAcceptableOrUnknown(data['txn_date']!, _txnDateMeta));
    } else if (isInserting) {
      context.missing(_txnDateMeta);
    }
    if (data.containsKey('type')) {
      context.handle(
          _typeMeta, type.isAcceptableOrUnknown(data['type']!, _typeMeta));
    }
    if (data.containsKey('item_name')) {
      context.handle(_itemNameMeta,
          itemName.isAcceptableOrUnknown(data['item_name']!, _itemNameMeta));
    } else if (isInserting) {
      context.missing(_itemNameMeta);
    }
    if (data.containsKey('cost_paisa')) {
      context.handle(_costPaisaMeta,
          costPaisa.isAcceptableOrUnknown(data['cost_paisa']!, _costPaisaMeta));
    } else if (isInserting) {
      context.missing(_costPaisaMeta);
    }
    if (data.containsKey('odometer_km')) {
      context.handle(
          _odometerKmMeta,
          odometerKm.isAcceptableOrUnknown(
              data['odometer_km']!, _odometerKmMeta));
    }
    if (data.containsKey('next_service_km')) {
      context.handle(
          _nextServiceKmMeta,
          nextServiceKm.isAcceptableOrUnknown(
              data['next_service_km']!, _nextServiceKmMeta));
    }
    if (data.containsKey('next_service_date')) {
      context.handle(
          _nextServiceDateMeta,
          nextServiceDate.isAcceptableOrUnknown(
              data['next_service_date']!, _nextServiceDateMeta));
    }
    if (data.containsKey('wallet_id')) {
      context.handle(_walletIdMeta,
          walletId.isAcceptableOrUnknown(data['wallet_id']!, _walletIdMeta));
    }
    if (data.containsKey('note')) {
      context.handle(
          _noteMeta, note.isAcceptableOrUnknown(data['note']!, _noteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  BikeMaintenanceData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return BikeMaintenanceData(
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}updated_at'])!,
      deletedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}deleted_at']),
      version: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}version'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      userId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}user_id'])!,
      txnDate: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}txn_date'])!,
      type: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}type'])!,
      itemName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}item_name'])!,
      costPaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}cost_paisa'])!,
      odometerKm: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}odometer_km']),
      nextServiceKm: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}next_service_km']),
      nextServiceDate: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}next_service_date']),
      walletId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}wallet_id']),
      note: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}note']),
    );
  }

  @override
  $BikeMaintenanceTable createAlias(String alias) {
    return $BikeMaintenanceTable(attachedDatabase, alias);
  }
}

class BikeMaintenanceData extends DataClass
    implements Insertable<BikeMaintenanceData> {
  final String createdAt;
  final String updatedAt;
  final String? deletedAt;
  final int version;
  final String syncStatus;
  final String id;
  final String userId;
  final String txnDate;
  final String type;
  final String itemName;
  final int costPaisa;
  final double? odometerKm;
  final double? nextServiceKm;
  final String? nextServiceDate;
  final String? walletId;
  final String? note;
  const BikeMaintenanceData(
      {required this.createdAt,
      required this.updatedAt,
      this.deletedAt,
      required this.version,
      required this.syncStatus,
      required this.id,
      required this.userId,
      required this.txnDate,
      required this.type,
      required this.itemName,
      required this.costPaisa,
      this.odometerKm,
      this.nextServiceKm,
      this.nextServiceDate,
      this.walletId,
      this.note});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['created_at'] = Variable<String>(createdAt);
    map['updated_at'] = Variable<String>(updatedAt);
    if (!nullToAbsent || deletedAt != null) {
      map['deleted_at'] = Variable<String>(deletedAt);
    }
    map['version'] = Variable<int>(version);
    map['sync_status'] = Variable<String>(syncStatus);
    map['id'] = Variable<String>(id);
    map['user_id'] = Variable<String>(userId);
    map['txn_date'] = Variable<String>(txnDate);
    map['type'] = Variable<String>(type);
    map['item_name'] = Variable<String>(itemName);
    map['cost_paisa'] = Variable<int>(costPaisa);
    if (!nullToAbsent || odometerKm != null) {
      map['odometer_km'] = Variable<double>(odometerKm);
    }
    if (!nullToAbsent || nextServiceKm != null) {
      map['next_service_km'] = Variable<double>(nextServiceKm);
    }
    if (!nullToAbsent || nextServiceDate != null) {
      map['next_service_date'] = Variable<String>(nextServiceDate);
    }
    if (!nullToAbsent || walletId != null) {
      map['wallet_id'] = Variable<String>(walletId);
    }
    if (!nullToAbsent || note != null) {
      map['note'] = Variable<String>(note);
    }
    return map;
  }

  BikeMaintenanceCompanion toCompanion(bool nullToAbsent) {
    return BikeMaintenanceCompanion(
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      deletedAt: deletedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(deletedAt),
      version: Value(version),
      syncStatus: Value(syncStatus),
      id: Value(id),
      userId: Value(userId),
      txnDate: Value(txnDate),
      type: Value(type),
      itemName: Value(itemName),
      costPaisa: Value(costPaisa),
      odometerKm: odometerKm == null && nullToAbsent
          ? const Value.absent()
          : Value(odometerKm),
      nextServiceKm: nextServiceKm == null && nullToAbsent
          ? const Value.absent()
          : Value(nextServiceKm),
      nextServiceDate: nextServiceDate == null && nullToAbsent
          ? const Value.absent()
          : Value(nextServiceDate),
      walletId: walletId == null && nullToAbsent
          ? const Value.absent()
          : Value(walletId),
      note: note == null && nullToAbsent ? const Value.absent() : Value(note),
    );
  }

  factory BikeMaintenanceData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return BikeMaintenanceData(
      createdAt: serializer.fromJson<String>(json['createdAt']),
      updatedAt: serializer.fromJson<String>(json['updatedAt']),
      deletedAt: serializer.fromJson<String?>(json['deletedAt']),
      version: serializer.fromJson<int>(json['version']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      id: serializer.fromJson<String>(json['id']),
      userId: serializer.fromJson<String>(json['userId']),
      txnDate: serializer.fromJson<String>(json['txnDate']),
      type: serializer.fromJson<String>(json['type']),
      itemName: serializer.fromJson<String>(json['itemName']),
      costPaisa: serializer.fromJson<int>(json['costPaisa']),
      odometerKm: serializer.fromJson<double?>(json['odometerKm']),
      nextServiceKm: serializer.fromJson<double?>(json['nextServiceKm']),
      nextServiceDate: serializer.fromJson<String?>(json['nextServiceDate']),
      walletId: serializer.fromJson<String?>(json['walletId']),
      note: serializer.fromJson<String?>(json['note']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'createdAt': serializer.toJson<String>(createdAt),
      'updatedAt': serializer.toJson<String>(updatedAt),
      'deletedAt': serializer.toJson<String?>(deletedAt),
      'version': serializer.toJson<int>(version),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'id': serializer.toJson<String>(id),
      'userId': serializer.toJson<String>(userId),
      'txnDate': serializer.toJson<String>(txnDate),
      'type': serializer.toJson<String>(type),
      'itemName': serializer.toJson<String>(itemName),
      'costPaisa': serializer.toJson<int>(costPaisa),
      'odometerKm': serializer.toJson<double?>(odometerKm),
      'nextServiceKm': serializer.toJson<double?>(nextServiceKm),
      'nextServiceDate': serializer.toJson<String?>(nextServiceDate),
      'walletId': serializer.toJson<String?>(walletId),
      'note': serializer.toJson<String?>(note),
    };
  }

  BikeMaintenanceData copyWith(
          {String? createdAt,
          String? updatedAt,
          Value<String?> deletedAt = const Value.absent(),
          int? version,
          String? syncStatus,
          String? id,
          String? userId,
          String? txnDate,
          String? type,
          String? itemName,
          int? costPaisa,
          Value<double?> odometerKm = const Value.absent(),
          Value<double?> nextServiceKm = const Value.absent(),
          Value<String?> nextServiceDate = const Value.absent(),
          Value<String?> walletId = const Value.absent(),
          Value<String?> note = const Value.absent()}) =>
      BikeMaintenanceData(
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: deletedAt.present ? deletedAt.value : this.deletedAt,
        version: version ?? this.version,
        syncStatus: syncStatus ?? this.syncStatus,
        id: id ?? this.id,
        userId: userId ?? this.userId,
        txnDate: txnDate ?? this.txnDate,
        type: type ?? this.type,
        itemName: itemName ?? this.itemName,
        costPaisa: costPaisa ?? this.costPaisa,
        odometerKm: odometerKm.present ? odometerKm.value : this.odometerKm,
        nextServiceKm:
            nextServiceKm.present ? nextServiceKm.value : this.nextServiceKm,
        nextServiceDate: nextServiceDate.present
            ? nextServiceDate.value
            : this.nextServiceDate,
        walletId: walletId.present ? walletId.value : this.walletId,
        note: note.present ? note.value : this.note,
      );
  BikeMaintenanceData copyWithCompanion(BikeMaintenanceCompanion data) {
    return BikeMaintenanceData(
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      deletedAt: data.deletedAt.present ? data.deletedAt.value : this.deletedAt,
      version: data.version.present ? data.version.value : this.version,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      id: data.id.present ? data.id.value : this.id,
      userId: data.userId.present ? data.userId.value : this.userId,
      txnDate: data.txnDate.present ? data.txnDate.value : this.txnDate,
      type: data.type.present ? data.type.value : this.type,
      itemName: data.itemName.present ? data.itemName.value : this.itemName,
      costPaisa: data.costPaisa.present ? data.costPaisa.value : this.costPaisa,
      odometerKm:
          data.odometerKm.present ? data.odometerKm.value : this.odometerKm,
      nextServiceKm: data.nextServiceKm.present
          ? data.nextServiceKm.value
          : this.nextServiceKm,
      nextServiceDate: data.nextServiceDate.present
          ? data.nextServiceDate.value
          : this.nextServiceDate,
      walletId: data.walletId.present ? data.walletId.value : this.walletId,
      note: data.note.present ? data.note.value : this.note,
    );
  }

  @override
  String toString() {
    return (StringBuffer('BikeMaintenanceData(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('txnDate: $txnDate, ')
          ..write('type: $type, ')
          ..write('itemName: $itemName, ')
          ..write('costPaisa: $costPaisa, ')
          ..write('odometerKm: $odometerKm, ')
          ..write('nextServiceKm: $nextServiceKm, ')
          ..write('nextServiceDate: $nextServiceDate, ')
          ..write('walletId: $walletId, ')
          ..write('note: $note')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      createdAt,
      updatedAt,
      deletedAt,
      version,
      syncStatus,
      id,
      userId,
      txnDate,
      type,
      itemName,
      costPaisa,
      odometerKm,
      nextServiceKm,
      nextServiceDate,
      walletId,
      note);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is BikeMaintenanceData &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.deletedAt == this.deletedAt &&
          other.version == this.version &&
          other.syncStatus == this.syncStatus &&
          other.id == this.id &&
          other.userId == this.userId &&
          other.txnDate == this.txnDate &&
          other.type == this.type &&
          other.itemName == this.itemName &&
          other.costPaisa == this.costPaisa &&
          other.odometerKm == this.odometerKm &&
          other.nextServiceKm == this.nextServiceKm &&
          other.nextServiceDate == this.nextServiceDate &&
          other.walletId == this.walletId &&
          other.note == this.note);
}

class BikeMaintenanceCompanion extends UpdateCompanion<BikeMaintenanceData> {
  final Value<String> createdAt;
  final Value<String> updatedAt;
  final Value<String?> deletedAt;
  final Value<int> version;
  final Value<String> syncStatus;
  final Value<String> id;
  final Value<String> userId;
  final Value<String> txnDate;
  final Value<String> type;
  final Value<String> itemName;
  final Value<int> costPaisa;
  final Value<double?> odometerKm;
  final Value<double?> nextServiceKm;
  final Value<String?> nextServiceDate;
  final Value<String?> walletId;
  final Value<String?> note;
  final Value<int> rowid;
  const BikeMaintenanceCompanion({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.id = const Value.absent(),
    this.userId = const Value.absent(),
    this.txnDate = const Value.absent(),
    this.type = const Value.absent(),
    this.itemName = const Value.absent(),
    this.costPaisa = const Value.absent(),
    this.odometerKm = const Value.absent(),
    this.nextServiceKm = const Value.absent(),
    this.nextServiceDate = const Value.absent(),
    this.walletId = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  BikeMaintenanceCompanion.insert({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    required String id,
    required String userId,
    required String txnDate,
    this.type = const Value.absent(),
    required String itemName,
    required int costPaisa,
    this.odometerKm = const Value.absent(),
    this.nextServiceKm = const Value.absent(),
    this.nextServiceDate = const Value.absent(),
    this.walletId = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        userId = Value(userId),
        txnDate = Value(txnDate),
        itemName = Value(itemName),
        costPaisa = Value(costPaisa);
  static Insertable<BikeMaintenanceData> custom({
    Expression<String>? createdAt,
    Expression<String>? updatedAt,
    Expression<String>? deletedAt,
    Expression<int>? version,
    Expression<String>? syncStatus,
    Expression<String>? id,
    Expression<String>? userId,
    Expression<String>? txnDate,
    Expression<String>? type,
    Expression<String>? itemName,
    Expression<int>? costPaisa,
    Expression<double>? odometerKm,
    Expression<double>? nextServiceKm,
    Expression<String>? nextServiceDate,
    Expression<String>? walletId,
    Expression<String>? note,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (deletedAt != null) 'deleted_at': deletedAt,
      if (version != null) 'version': version,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (id != null) 'id': id,
      if (userId != null) 'user_id': userId,
      if (txnDate != null) 'txn_date': txnDate,
      if (type != null) 'type': type,
      if (itemName != null) 'item_name': itemName,
      if (costPaisa != null) 'cost_paisa': costPaisa,
      if (odometerKm != null) 'odometer_km': odometerKm,
      if (nextServiceKm != null) 'next_service_km': nextServiceKm,
      if (nextServiceDate != null) 'next_service_date': nextServiceDate,
      if (walletId != null) 'wallet_id': walletId,
      if (note != null) 'note': note,
      if (rowid != null) 'rowid': rowid,
    });
  }

  BikeMaintenanceCompanion copyWith(
      {Value<String>? createdAt,
      Value<String>? updatedAt,
      Value<String?>? deletedAt,
      Value<int>? version,
      Value<String>? syncStatus,
      Value<String>? id,
      Value<String>? userId,
      Value<String>? txnDate,
      Value<String>? type,
      Value<String>? itemName,
      Value<int>? costPaisa,
      Value<double?>? odometerKm,
      Value<double?>? nextServiceKm,
      Value<String?>? nextServiceDate,
      Value<String?>? walletId,
      Value<String?>? note,
      Value<int>? rowid}) {
    return BikeMaintenanceCompanion(
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      version: version ?? this.version,
      syncStatus: syncStatus ?? this.syncStatus,
      id: id ?? this.id,
      userId: userId ?? this.userId,
      txnDate: txnDate ?? this.txnDate,
      type: type ?? this.type,
      itemName: itemName ?? this.itemName,
      costPaisa: costPaisa ?? this.costPaisa,
      odometerKm: odometerKm ?? this.odometerKm,
      nextServiceKm: nextServiceKm ?? this.nextServiceKm,
      nextServiceDate: nextServiceDate ?? this.nextServiceDate,
      walletId: walletId ?? this.walletId,
      note: note ?? this.note,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (createdAt.present) {
      map['created_at'] = Variable<String>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<String>(updatedAt.value);
    }
    if (deletedAt.present) {
      map['deleted_at'] = Variable<String>(deletedAt.value);
    }
    if (version.present) {
      map['version'] = Variable<int>(version.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<String>(userId.value);
    }
    if (txnDate.present) {
      map['txn_date'] = Variable<String>(txnDate.value);
    }
    if (type.present) {
      map['type'] = Variable<String>(type.value);
    }
    if (itemName.present) {
      map['item_name'] = Variable<String>(itemName.value);
    }
    if (costPaisa.present) {
      map['cost_paisa'] = Variable<int>(costPaisa.value);
    }
    if (odometerKm.present) {
      map['odometer_km'] = Variable<double>(odometerKm.value);
    }
    if (nextServiceKm.present) {
      map['next_service_km'] = Variable<double>(nextServiceKm.value);
    }
    if (nextServiceDate.present) {
      map['next_service_date'] = Variable<String>(nextServiceDate.value);
    }
    if (walletId.present) {
      map['wallet_id'] = Variable<String>(walletId.value);
    }
    if (note.present) {
      map['note'] = Variable<String>(note.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('BikeMaintenanceCompanion(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('txnDate: $txnDate, ')
          ..write('type: $type, ')
          ..write('itemName: $itemName, ')
          ..write('costPaisa: $costPaisa, ')
          ..write('odometerKm: $odometerKm, ')
          ..write('nextServiceKm: $nextServiceKm, ')
          ..write('nextServiceDate: $nextServiceDate, ')
          ..write('walletId: $walletId, ')
          ..write('note: $note, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $CashTalliesTable extends CashTallies
    with TableInfo<$CashTalliesTable, CashTally> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CashTalliesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<String> createdAt = GeneratedColumn<String>(
      'created_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<String> updatedAt = GeneratedColumn<String>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _deletedAtMeta =
      const VerificationMeta('deletedAt');
  @override
  late final GeneratedColumn<String> deletedAt = GeneratedColumn<String>(
      'deleted_at', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _versionMeta =
      const VerificationMeta('version');
  @override
  late final GeneratedColumn<int> version = GeneratedColumn<int>(
      'version', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('pending'));
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<String> userId = GeneratedColumn<String>(
      'user_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _txnDateMeta =
      const VerificationMeta('txnDate');
  @override
  late final GeneratedColumn<String> txnDate = GeneratedColumn<String>(
      'txn_date', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _walletIdMeta =
      const VerificationMeta('walletId');
  @override
  late final GeneratedColumn<String> walletId = GeneratedColumn<String>(
      'wallet_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _sessionIdMeta =
      const VerificationMeta('sessionId');
  @override
  late final GeneratedColumn<String> sessionId = GeneratedColumn<String>(
      'session_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _countedTotalPaisaMeta =
      const VerificationMeta('countedTotalPaisa');
  @override
  late final GeneratedColumn<int> countedTotalPaisa = GeneratedColumn<int>(
      'counted_total_paisa', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _expectedPaisaMeta =
      const VerificationMeta('expectedPaisa');
  @override
  late final GeneratedColumn<int> expectedPaisa = GeneratedColumn<int>(
      'expected_paisa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _differencePaisaMeta =
      const VerificationMeta('differencePaisa');
  @override
  late final GeneratedColumn<int> differencePaisa = GeneratedColumn<int>(
      'difference_paisa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _noteMeta = const VerificationMeta('note');
  @override
  late final GeneratedColumn<String> note = GeneratedColumn<String>(
      'note', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        createdAt,
        updatedAt,
        deletedAt,
        version,
        syncStatus,
        id,
        userId,
        txnDate,
        walletId,
        sessionId,
        countedTotalPaisa,
        expectedPaisa,
        differencePaisa,
        note
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cash_tallies';
  @override
  VerificationContext validateIntegrity(Insertable<CashTally> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    if (data.containsKey('deleted_at')) {
      context.handle(_deletedAtMeta,
          deletedAt.isAcceptableOrUnknown(data['deleted_at']!, _deletedAtMeta));
    }
    if (data.containsKey('version')) {
      context.handle(_versionMeta,
          version.isAcceptableOrUnknown(data['version']!, _versionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('user_id')) {
      context.handle(_userIdMeta,
          userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta));
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('txn_date')) {
      context.handle(_txnDateMeta,
          txnDate.isAcceptableOrUnknown(data['txn_date']!, _txnDateMeta));
    } else if (isInserting) {
      context.missing(_txnDateMeta);
    }
    if (data.containsKey('wallet_id')) {
      context.handle(_walletIdMeta,
          walletId.isAcceptableOrUnknown(data['wallet_id']!, _walletIdMeta));
    }
    if (data.containsKey('session_id')) {
      context.handle(_sessionIdMeta,
          sessionId.isAcceptableOrUnknown(data['session_id']!, _sessionIdMeta));
    }
    if (data.containsKey('counted_total_paisa')) {
      context.handle(
          _countedTotalPaisaMeta,
          countedTotalPaisa.isAcceptableOrUnknown(
              data['counted_total_paisa']!, _countedTotalPaisaMeta));
    }
    if (data.containsKey('expected_paisa')) {
      context.handle(
          _expectedPaisaMeta,
          expectedPaisa.isAcceptableOrUnknown(
              data['expected_paisa']!, _expectedPaisaMeta));
    }
    if (data.containsKey('difference_paisa')) {
      context.handle(
          _differencePaisaMeta,
          differencePaisa.isAcceptableOrUnknown(
              data['difference_paisa']!, _differencePaisaMeta));
    }
    if (data.containsKey('note')) {
      context.handle(
          _noteMeta, note.isAcceptableOrUnknown(data['note']!, _noteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CashTally map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CashTally(
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}updated_at'])!,
      deletedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}deleted_at']),
      version: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}version'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      userId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}user_id'])!,
      txnDate: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}txn_date'])!,
      walletId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}wallet_id']),
      sessionId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}session_id']),
      countedTotalPaisa: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}counted_total_paisa'])!,
      expectedPaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}expected_paisa']),
      differencePaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}difference_paisa']),
      note: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}note']),
    );
  }

  @override
  $CashTalliesTable createAlias(String alias) {
    return $CashTalliesTable(attachedDatabase, alias);
  }
}

class CashTally extends DataClass implements Insertable<CashTally> {
  final String createdAt;
  final String updatedAt;
  final String? deletedAt;
  final int version;
  final String syncStatus;
  final String id;
  final String userId;
  final String txnDate;
  final String? walletId;
  final String? sessionId;
  final int countedTotalPaisa;
  final int? expectedPaisa;
  final int? differencePaisa;
  final String? note;
  const CashTally(
      {required this.createdAt,
      required this.updatedAt,
      this.deletedAt,
      required this.version,
      required this.syncStatus,
      required this.id,
      required this.userId,
      required this.txnDate,
      this.walletId,
      this.sessionId,
      required this.countedTotalPaisa,
      this.expectedPaisa,
      this.differencePaisa,
      this.note});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['created_at'] = Variable<String>(createdAt);
    map['updated_at'] = Variable<String>(updatedAt);
    if (!nullToAbsent || deletedAt != null) {
      map['deleted_at'] = Variable<String>(deletedAt);
    }
    map['version'] = Variable<int>(version);
    map['sync_status'] = Variable<String>(syncStatus);
    map['id'] = Variable<String>(id);
    map['user_id'] = Variable<String>(userId);
    map['txn_date'] = Variable<String>(txnDate);
    if (!nullToAbsent || walletId != null) {
      map['wallet_id'] = Variable<String>(walletId);
    }
    if (!nullToAbsent || sessionId != null) {
      map['session_id'] = Variable<String>(sessionId);
    }
    map['counted_total_paisa'] = Variable<int>(countedTotalPaisa);
    if (!nullToAbsent || expectedPaisa != null) {
      map['expected_paisa'] = Variable<int>(expectedPaisa);
    }
    if (!nullToAbsent || differencePaisa != null) {
      map['difference_paisa'] = Variable<int>(differencePaisa);
    }
    if (!nullToAbsent || note != null) {
      map['note'] = Variable<String>(note);
    }
    return map;
  }

  CashTalliesCompanion toCompanion(bool nullToAbsent) {
    return CashTalliesCompanion(
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      deletedAt: deletedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(deletedAt),
      version: Value(version),
      syncStatus: Value(syncStatus),
      id: Value(id),
      userId: Value(userId),
      txnDate: Value(txnDate),
      walletId: walletId == null && nullToAbsent
          ? const Value.absent()
          : Value(walletId),
      sessionId: sessionId == null && nullToAbsent
          ? const Value.absent()
          : Value(sessionId),
      countedTotalPaisa: Value(countedTotalPaisa),
      expectedPaisa: expectedPaisa == null && nullToAbsent
          ? const Value.absent()
          : Value(expectedPaisa),
      differencePaisa: differencePaisa == null && nullToAbsent
          ? const Value.absent()
          : Value(differencePaisa),
      note: note == null && nullToAbsent ? const Value.absent() : Value(note),
    );
  }

  factory CashTally.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CashTally(
      createdAt: serializer.fromJson<String>(json['createdAt']),
      updatedAt: serializer.fromJson<String>(json['updatedAt']),
      deletedAt: serializer.fromJson<String?>(json['deletedAt']),
      version: serializer.fromJson<int>(json['version']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      id: serializer.fromJson<String>(json['id']),
      userId: serializer.fromJson<String>(json['userId']),
      txnDate: serializer.fromJson<String>(json['txnDate']),
      walletId: serializer.fromJson<String?>(json['walletId']),
      sessionId: serializer.fromJson<String?>(json['sessionId']),
      countedTotalPaisa: serializer.fromJson<int>(json['countedTotalPaisa']),
      expectedPaisa: serializer.fromJson<int?>(json['expectedPaisa']),
      differencePaisa: serializer.fromJson<int?>(json['differencePaisa']),
      note: serializer.fromJson<String?>(json['note']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'createdAt': serializer.toJson<String>(createdAt),
      'updatedAt': serializer.toJson<String>(updatedAt),
      'deletedAt': serializer.toJson<String?>(deletedAt),
      'version': serializer.toJson<int>(version),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'id': serializer.toJson<String>(id),
      'userId': serializer.toJson<String>(userId),
      'txnDate': serializer.toJson<String>(txnDate),
      'walletId': serializer.toJson<String?>(walletId),
      'sessionId': serializer.toJson<String?>(sessionId),
      'countedTotalPaisa': serializer.toJson<int>(countedTotalPaisa),
      'expectedPaisa': serializer.toJson<int?>(expectedPaisa),
      'differencePaisa': serializer.toJson<int?>(differencePaisa),
      'note': serializer.toJson<String?>(note),
    };
  }

  CashTally copyWith(
          {String? createdAt,
          String? updatedAt,
          Value<String?> deletedAt = const Value.absent(),
          int? version,
          String? syncStatus,
          String? id,
          String? userId,
          String? txnDate,
          Value<String?> walletId = const Value.absent(),
          Value<String?> sessionId = const Value.absent(),
          int? countedTotalPaisa,
          Value<int?> expectedPaisa = const Value.absent(),
          Value<int?> differencePaisa = const Value.absent(),
          Value<String?> note = const Value.absent()}) =>
      CashTally(
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: deletedAt.present ? deletedAt.value : this.deletedAt,
        version: version ?? this.version,
        syncStatus: syncStatus ?? this.syncStatus,
        id: id ?? this.id,
        userId: userId ?? this.userId,
        txnDate: txnDate ?? this.txnDate,
        walletId: walletId.present ? walletId.value : this.walletId,
        sessionId: sessionId.present ? sessionId.value : this.sessionId,
        countedTotalPaisa: countedTotalPaisa ?? this.countedTotalPaisa,
        expectedPaisa:
            expectedPaisa.present ? expectedPaisa.value : this.expectedPaisa,
        differencePaisa: differencePaisa.present
            ? differencePaisa.value
            : this.differencePaisa,
        note: note.present ? note.value : this.note,
      );
  CashTally copyWithCompanion(CashTalliesCompanion data) {
    return CashTally(
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      deletedAt: data.deletedAt.present ? data.deletedAt.value : this.deletedAt,
      version: data.version.present ? data.version.value : this.version,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      id: data.id.present ? data.id.value : this.id,
      userId: data.userId.present ? data.userId.value : this.userId,
      txnDate: data.txnDate.present ? data.txnDate.value : this.txnDate,
      walletId: data.walletId.present ? data.walletId.value : this.walletId,
      sessionId: data.sessionId.present ? data.sessionId.value : this.sessionId,
      countedTotalPaisa: data.countedTotalPaisa.present
          ? data.countedTotalPaisa.value
          : this.countedTotalPaisa,
      expectedPaisa: data.expectedPaisa.present
          ? data.expectedPaisa.value
          : this.expectedPaisa,
      differencePaisa: data.differencePaisa.present
          ? data.differencePaisa.value
          : this.differencePaisa,
      note: data.note.present ? data.note.value : this.note,
    );
  }

  @override
  String toString() {
    return (StringBuffer('CashTally(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('txnDate: $txnDate, ')
          ..write('walletId: $walletId, ')
          ..write('sessionId: $sessionId, ')
          ..write('countedTotalPaisa: $countedTotalPaisa, ')
          ..write('expectedPaisa: $expectedPaisa, ')
          ..write('differencePaisa: $differencePaisa, ')
          ..write('note: $note')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      createdAt,
      updatedAt,
      deletedAt,
      version,
      syncStatus,
      id,
      userId,
      txnDate,
      walletId,
      sessionId,
      countedTotalPaisa,
      expectedPaisa,
      differencePaisa,
      note);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CashTally &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.deletedAt == this.deletedAt &&
          other.version == this.version &&
          other.syncStatus == this.syncStatus &&
          other.id == this.id &&
          other.userId == this.userId &&
          other.txnDate == this.txnDate &&
          other.walletId == this.walletId &&
          other.sessionId == this.sessionId &&
          other.countedTotalPaisa == this.countedTotalPaisa &&
          other.expectedPaisa == this.expectedPaisa &&
          other.differencePaisa == this.differencePaisa &&
          other.note == this.note);
}

class CashTalliesCompanion extends UpdateCompanion<CashTally> {
  final Value<String> createdAt;
  final Value<String> updatedAt;
  final Value<String?> deletedAt;
  final Value<int> version;
  final Value<String> syncStatus;
  final Value<String> id;
  final Value<String> userId;
  final Value<String> txnDate;
  final Value<String?> walletId;
  final Value<String?> sessionId;
  final Value<int> countedTotalPaisa;
  final Value<int?> expectedPaisa;
  final Value<int?> differencePaisa;
  final Value<String?> note;
  final Value<int> rowid;
  const CashTalliesCompanion({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.id = const Value.absent(),
    this.userId = const Value.absent(),
    this.txnDate = const Value.absent(),
    this.walletId = const Value.absent(),
    this.sessionId = const Value.absent(),
    this.countedTotalPaisa = const Value.absent(),
    this.expectedPaisa = const Value.absent(),
    this.differencePaisa = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  CashTalliesCompanion.insert({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    required String id,
    required String userId,
    required String txnDate,
    this.walletId = const Value.absent(),
    this.sessionId = const Value.absent(),
    this.countedTotalPaisa = const Value.absent(),
    this.expectedPaisa = const Value.absent(),
    this.differencePaisa = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        userId = Value(userId),
        txnDate = Value(txnDate);
  static Insertable<CashTally> custom({
    Expression<String>? createdAt,
    Expression<String>? updatedAt,
    Expression<String>? deletedAt,
    Expression<int>? version,
    Expression<String>? syncStatus,
    Expression<String>? id,
    Expression<String>? userId,
    Expression<String>? txnDate,
    Expression<String>? walletId,
    Expression<String>? sessionId,
    Expression<int>? countedTotalPaisa,
    Expression<int>? expectedPaisa,
    Expression<int>? differencePaisa,
    Expression<String>? note,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (deletedAt != null) 'deleted_at': deletedAt,
      if (version != null) 'version': version,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (id != null) 'id': id,
      if (userId != null) 'user_id': userId,
      if (txnDate != null) 'txn_date': txnDate,
      if (walletId != null) 'wallet_id': walletId,
      if (sessionId != null) 'session_id': sessionId,
      if (countedTotalPaisa != null) 'counted_total_paisa': countedTotalPaisa,
      if (expectedPaisa != null) 'expected_paisa': expectedPaisa,
      if (differencePaisa != null) 'difference_paisa': differencePaisa,
      if (note != null) 'note': note,
      if (rowid != null) 'rowid': rowid,
    });
  }

  CashTalliesCompanion copyWith(
      {Value<String>? createdAt,
      Value<String>? updatedAt,
      Value<String?>? deletedAt,
      Value<int>? version,
      Value<String>? syncStatus,
      Value<String>? id,
      Value<String>? userId,
      Value<String>? txnDate,
      Value<String?>? walletId,
      Value<String?>? sessionId,
      Value<int>? countedTotalPaisa,
      Value<int?>? expectedPaisa,
      Value<int?>? differencePaisa,
      Value<String?>? note,
      Value<int>? rowid}) {
    return CashTalliesCompanion(
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      version: version ?? this.version,
      syncStatus: syncStatus ?? this.syncStatus,
      id: id ?? this.id,
      userId: userId ?? this.userId,
      txnDate: txnDate ?? this.txnDate,
      walletId: walletId ?? this.walletId,
      sessionId: sessionId ?? this.sessionId,
      countedTotalPaisa: countedTotalPaisa ?? this.countedTotalPaisa,
      expectedPaisa: expectedPaisa ?? this.expectedPaisa,
      differencePaisa: differencePaisa ?? this.differencePaisa,
      note: note ?? this.note,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (createdAt.present) {
      map['created_at'] = Variable<String>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<String>(updatedAt.value);
    }
    if (deletedAt.present) {
      map['deleted_at'] = Variable<String>(deletedAt.value);
    }
    if (version.present) {
      map['version'] = Variable<int>(version.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<String>(userId.value);
    }
    if (txnDate.present) {
      map['txn_date'] = Variable<String>(txnDate.value);
    }
    if (walletId.present) {
      map['wallet_id'] = Variable<String>(walletId.value);
    }
    if (sessionId.present) {
      map['session_id'] = Variable<String>(sessionId.value);
    }
    if (countedTotalPaisa.present) {
      map['counted_total_paisa'] = Variable<int>(countedTotalPaisa.value);
    }
    if (expectedPaisa.present) {
      map['expected_paisa'] = Variable<int>(expectedPaisa.value);
    }
    if (differencePaisa.present) {
      map['difference_paisa'] = Variable<int>(differencePaisa.value);
    }
    if (note.present) {
      map['note'] = Variable<String>(note.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CashTalliesCompanion(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('txnDate: $txnDate, ')
          ..write('walletId: $walletId, ')
          ..write('sessionId: $sessionId, ')
          ..write('countedTotalPaisa: $countedTotalPaisa, ')
          ..write('expectedPaisa: $expectedPaisa, ')
          ..write('differencePaisa: $differencePaisa, ')
          ..write('note: $note, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $CashTallyItemsTable extends CashTallyItems
    with TableInfo<$CashTallyItemsTable, CashTallyItem> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CashTallyItemsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<String> createdAt = GeneratedColumn<String>(
      'created_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<String> updatedAt = GeneratedColumn<String>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _deletedAtMeta =
      const VerificationMeta('deletedAt');
  @override
  late final GeneratedColumn<String> deletedAt = GeneratedColumn<String>(
      'deleted_at', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _versionMeta =
      const VerificationMeta('version');
  @override
  late final GeneratedColumn<int> version = GeneratedColumn<int>(
      'version', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('pending'));
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<String> userId = GeneratedColumn<String>(
      'user_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _tallyIdMeta =
      const VerificationMeta('tallyId');
  @override
  late final GeneratedColumn<String> tallyId = GeneratedColumn<String>(
      'tally_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _denominationPaisaMeta =
      const VerificationMeta('denominationPaisa');
  @override
  late final GeneratedColumn<int> denominationPaisa = GeneratedColumn<int>(
      'denomination_paisa', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _quantityMeta =
      const VerificationMeta('quantity');
  @override
  late final GeneratedColumn<int> quantity = GeneratedColumn<int>(
      'quantity', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _lineTotalPaisaMeta =
      const VerificationMeta('lineTotalPaisa');
  @override
  late final GeneratedColumn<int> lineTotalPaisa = GeneratedColumn<int>(
      'line_total_paisa', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  @override
  List<GeneratedColumn> get $columns => [
        createdAt,
        updatedAt,
        deletedAt,
        version,
        syncStatus,
        id,
        userId,
        tallyId,
        denominationPaisa,
        quantity,
        lineTotalPaisa
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'cash_tally_items';
  @override
  VerificationContext validateIntegrity(Insertable<CashTallyItem> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    if (data.containsKey('deleted_at')) {
      context.handle(_deletedAtMeta,
          deletedAt.isAcceptableOrUnknown(data['deleted_at']!, _deletedAtMeta));
    }
    if (data.containsKey('version')) {
      context.handle(_versionMeta,
          version.isAcceptableOrUnknown(data['version']!, _versionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('user_id')) {
      context.handle(_userIdMeta,
          userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta));
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('tally_id')) {
      context.handle(_tallyIdMeta,
          tallyId.isAcceptableOrUnknown(data['tally_id']!, _tallyIdMeta));
    } else if (isInserting) {
      context.missing(_tallyIdMeta);
    }
    if (data.containsKey('denomination_paisa')) {
      context.handle(
          _denominationPaisaMeta,
          denominationPaisa.isAcceptableOrUnknown(
              data['denomination_paisa']!, _denominationPaisaMeta));
    } else if (isInserting) {
      context.missing(_denominationPaisaMeta);
    }
    if (data.containsKey('quantity')) {
      context.handle(_quantityMeta,
          quantity.isAcceptableOrUnknown(data['quantity']!, _quantityMeta));
    }
    if (data.containsKey('line_total_paisa')) {
      context.handle(
          _lineTotalPaisaMeta,
          lineTotalPaisa.isAcceptableOrUnknown(
              data['line_total_paisa']!, _lineTotalPaisaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CashTallyItem map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CashTallyItem(
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}updated_at'])!,
      deletedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}deleted_at']),
      version: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}version'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      userId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}user_id'])!,
      tallyId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tally_id'])!,
      denominationPaisa: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}denomination_paisa'])!,
      quantity: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}quantity'])!,
      lineTotalPaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}line_total_paisa'])!,
    );
  }

  @override
  $CashTallyItemsTable createAlias(String alias) {
    return $CashTallyItemsTable(attachedDatabase, alias);
  }
}

class CashTallyItem extends DataClass implements Insertable<CashTallyItem> {
  final String createdAt;
  final String updatedAt;
  final String? deletedAt;
  final int version;
  final String syncStatus;
  final String id;
  final String userId;
  final String tallyId;
  final int denominationPaisa;
  final int quantity;
  final int lineTotalPaisa;
  const CashTallyItem(
      {required this.createdAt,
      required this.updatedAt,
      this.deletedAt,
      required this.version,
      required this.syncStatus,
      required this.id,
      required this.userId,
      required this.tallyId,
      required this.denominationPaisa,
      required this.quantity,
      required this.lineTotalPaisa});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['created_at'] = Variable<String>(createdAt);
    map['updated_at'] = Variable<String>(updatedAt);
    if (!nullToAbsent || deletedAt != null) {
      map['deleted_at'] = Variable<String>(deletedAt);
    }
    map['version'] = Variable<int>(version);
    map['sync_status'] = Variable<String>(syncStatus);
    map['id'] = Variable<String>(id);
    map['user_id'] = Variable<String>(userId);
    map['tally_id'] = Variable<String>(tallyId);
    map['denomination_paisa'] = Variable<int>(denominationPaisa);
    map['quantity'] = Variable<int>(quantity);
    map['line_total_paisa'] = Variable<int>(lineTotalPaisa);
    return map;
  }

  CashTallyItemsCompanion toCompanion(bool nullToAbsent) {
    return CashTallyItemsCompanion(
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      deletedAt: deletedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(deletedAt),
      version: Value(version),
      syncStatus: Value(syncStatus),
      id: Value(id),
      userId: Value(userId),
      tallyId: Value(tallyId),
      denominationPaisa: Value(denominationPaisa),
      quantity: Value(quantity),
      lineTotalPaisa: Value(lineTotalPaisa),
    );
  }

  factory CashTallyItem.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CashTallyItem(
      createdAt: serializer.fromJson<String>(json['createdAt']),
      updatedAt: serializer.fromJson<String>(json['updatedAt']),
      deletedAt: serializer.fromJson<String?>(json['deletedAt']),
      version: serializer.fromJson<int>(json['version']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      id: serializer.fromJson<String>(json['id']),
      userId: serializer.fromJson<String>(json['userId']),
      tallyId: serializer.fromJson<String>(json['tallyId']),
      denominationPaisa: serializer.fromJson<int>(json['denominationPaisa']),
      quantity: serializer.fromJson<int>(json['quantity']),
      lineTotalPaisa: serializer.fromJson<int>(json['lineTotalPaisa']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'createdAt': serializer.toJson<String>(createdAt),
      'updatedAt': serializer.toJson<String>(updatedAt),
      'deletedAt': serializer.toJson<String?>(deletedAt),
      'version': serializer.toJson<int>(version),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'id': serializer.toJson<String>(id),
      'userId': serializer.toJson<String>(userId),
      'tallyId': serializer.toJson<String>(tallyId),
      'denominationPaisa': serializer.toJson<int>(denominationPaisa),
      'quantity': serializer.toJson<int>(quantity),
      'lineTotalPaisa': serializer.toJson<int>(lineTotalPaisa),
    };
  }

  CashTallyItem copyWith(
          {String? createdAt,
          String? updatedAt,
          Value<String?> deletedAt = const Value.absent(),
          int? version,
          String? syncStatus,
          String? id,
          String? userId,
          String? tallyId,
          int? denominationPaisa,
          int? quantity,
          int? lineTotalPaisa}) =>
      CashTallyItem(
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: deletedAt.present ? deletedAt.value : this.deletedAt,
        version: version ?? this.version,
        syncStatus: syncStatus ?? this.syncStatus,
        id: id ?? this.id,
        userId: userId ?? this.userId,
        tallyId: tallyId ?? this.tallyId,
        denominationPaisa: denominationPaisa ?? this.denominationPaisa,
        quantity: quantity ?? this.quantity,
        lineTotalPaisa: lineTotalPaisa ?? this.lineTotalPaisa,
      );
  CashTallyItem copyWithCompanion(CashTallyItemsCompanion data) {
    return CashTallyItem(
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      deletedAt: data.deletedAt.present ? data.deletedAt.value : this.deletedAt,
      version: data.version.present ? data.version.value : this.version,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      id: data.id.present ? data.id.value : this.id,
      userId: data.userId.present ? data.userId.value : this.userId,
      tallyId: data.tallyId.present ? data.tallyId.value : this.tallyId,
      denominationPaisa: data.denominationPaisa.present
          ? data.denominationPaisa.value
          : this.denominationPaisa,
      quantity: data.quantity.present ? data.quantity.value : this.quantity,
      lineTotalPaisa: data.lineTotalPaisa.present
          ? data.lineTotalPaisa.value
          : this.lineTotalPaisa,
    );
  }

  @override
  String toString() {
    return (StringBuffer('CashTallyItem(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('tallyId: $tallyId, ')
          ..write('denominationPaisa: $denominationPaisa, ')
          ..write('quantity: $quantity, ')
          ..write('lineTotalPaisa: $lineTotalPaisa')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      createdAt,
      updatedAt,
      deletedAt,
      version,
      syncStatus,
      id,
      userId,
      tallyId,
      denominationPaisa,
      quantity,
      lineTotalPaisa);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CashTallyItem &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.deletedAt == this.deletedAt &&
          other.version == this.version &&
          other.syncStatus == this.syncStatus &&
          other.id == this.id &&
          other.userId == this.userId &&
          other.tallyId == this.tallyId &&
          other.denominationPaisa == this.denominationPaisa &&
          other.quantity == this.quantity &&
          other.lineTotalPaisa == this.lineTotalPaisa);
}

class CashTallyItemsCompanion extends UpdateCompanion<CashTallyItem> {
  final Value<String> createdAt;
  final Value<String> updatedAt;
  final Value<String?> deletedAt;
  final Value<int> version;
  final Value<String> syncStatus;
  final Value<String> id;
  final Value<String> userId;
  final Value<String> tallyId;
  final Value<int> denominationPaisa;
  final Value<int> quantity;
  final Value<int> lineTotalPaisa;
  final Value<int> rowid;
  const CashTallyItemsCompanion({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.id = const Value.absent(),
    this.userId = const Value.absent(),
    this.tallyId = const Value.absent(),
    this.denominationPaisa = const Value.absent(),
    this.quantity = const Value.absent(),
    this.lineTotalPaisa = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  CashTallyItemsCompanion.insert({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    required String id,
    required String userId,
    required String tallyId,
    required int denominationPaisa,
    this.quantity = const Value.absent(),
    this.lineTotalPaisa = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        userId = Value(userId),
        tallyId = Value(tallyId),
        denominationPaisa = Value(denominationPaisa);
  static Insertable<CashTallyItem> custom({
    Expression<String>? createdAt,
    Expression<String>? updatedAt,
    Expression<String>? deletedAt,
    Expression<int>? version,
    Expression<String>? syncStatus,
    Expression<String>? id,
    Expression<String>? userId,
    Expression<String>? tallyId,
    Expression<int>? denominationPaisa,
    Expression<int>? quantity,
    Expression<int>? lineTotalPaisa,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (deletedAt != null) 'deleted_at': deletedAt,
      if (version != null) 'version': version,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (id != null) 'id': id,
      if (userId != null) 'user_id': userId,
      if (tallyId != null) 'tally_id': tallyId,
      if (denominationPaisa != null) 'denomination_paisa': denominationPaisa,
      if (quantity != null) 'quantity': quantity,
      if (lineTotalPaisa != null) 'line_total_paisa': lineTotalPaisa,
      if (rowid != null) 'rowid': rowid,
    });
  }

  CashTallyItemsCompanion copyWith(
      {Value<String>? createdAt,
      Value<String>? updatedAt,
      Value<String?>? deletedAt,
      Value<int>? version,
      Value<String>? syncStatus,
      Value<String>? id,
      Value<String>? userId,
      Value<String>? tallyId,
      Value<int>? denominationPaisa,
      Value<int>? quantity,
      Value<int>? lineTotalPaisa,
      Value<int>? rowid}) {
    return CashTallyItemsCompanion(
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      version: version ?? this.version,
      syncStatus: syncStatus ?? this.syncStatus,
      id: id ?? this.id,
      userId: userId ?? this.userId,
      tallyId: tallyId ?? this.tallyId,
      denominationPaisa: denominationPaisa ?? this.denominationPaisa,
      quantity: quantity ?? this.quantity,
      lineTotalPaisa: lineTotalPaisa ?? this.lineTotalPaisa,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (createdAt.present) {
      map['created_at'] = Variable<String>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<String>(updatedAt.value);
    }
    if (deletedAt.present) {
      map['deleted_at'] = Variable<String>(deletedAt.value);
    }
    if (version.present) {
      map['version'] = Variable<int>(version.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<String>(userId.value);
    }
    if (tallyId.present) {
      map['tally_id'] = Variable<String>(tallyId.value);
    }
    if (denominationPaisa.present) {
      map['denomination_paisa'] = Variable<int>(denominationPaisa.value);
    }
    if (quantity.present) {
      map['quantity'] = Variable<int>(quantity.value);
    }
    if (lineTotalPaisa.present) {
      map['line_total_paisa'] = Variable<int>(lineTotalPaisa.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CashTallyItemsCompanion(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('tallyId: $tallyId, ')
          ..write('denominationPaisa: $denominationPaisa, ')
          ..write('quantity: $quantity, ')
          ..write('lineTotalPaisa: $lineTotalPaisa, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $DailyClosingsTable extends DailyClosings
    with TableInfo<$DailyClosingsTable, DailyClosing> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $DailyClosingsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<String> createdAt = GeneratedColumn<String>(
      'created_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<String> updatedAt = GeneratedColumn<String>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _deletedAtMeta =
      const VerificationMeta('deletedAt');
  @override
  late final GeneratedColumn<String> deletedAt = GeneratedColumn<String>(
      'deleted_at', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _versionMeta =
      const VerificationMeta('version');
  @override
  late final GeneratedColumn<int> version = GeneratedColumn<int>(
      'version', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('pending'));
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<String> userId = GeneratedColumn<String>(
      'user_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _txnDateMeta =
      const VerificationMeta('txnDate');
  @override
  late final GeneratedColumn<String> txnDate = GeneratedColumn<String>(
      'txn_date', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _expectedCashPaisaMeta =
      const VerificationMeta('expectedCashPaisa');
  @override
  late final GeneratedColumn<int> expectedCashPaisa = GeneratedColumn<int>(
      'expected_cash_paisa', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _countedCashPaisaMeta =
      const VerificationMeta('countedCashPaisa');
  @override
  late final GeneratedColumn<int> countedCashPaisa = GeneratedColumn<int>(
      'counted_cash_paisa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _differencePaisaMeta =
      const VerificationMeta('differencePaisa');
  @override
  late final GeneratedColumn<int> differencePaisa = GeneratedColumn<int>(
      'difference_paisa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _noteMeta = const VerificationMeta('note');
  @override
  late final GeneratedColumn<String> note = GeneratedColumn<String>(
      'note', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _closedAtMeta =
      const VerificationMeta('closedAt');
  @override
  late final GeneratedColumn<int> closedAt = GeneratedColumn<int>(
      'closed_at', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  @override
  List<GeneratedColumn> get $columns => [
        createdAt,
        updatedAt,
        deletedAt,
        version,
        syncStatus,
        id,
        userId,
        txnDate,
        expectedCashPaisa,
        countedCashPaisa,
        differencePaisa,
        note,
        closedAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'daily_closings';
  @override
  VerificationContext validateIntegrity(Insertable<DailyClosing> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    if (data.containsKey('deleted_at')) {
      context.handle(_deletedAtMeta,
          deletedAt.isAcceptableOrUnknown(data['deleted_at']!, _deletedAtMeta));
    }
    if (data.containsKey('version')) {
      context.handle(_versionMeta,
          version.isAcceptableOrUnknown(data['version']!, _versionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('user_id')) {
      context.handle(_userIdMeta,
          userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta));
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('txn_date')) {
      context.handle(_txnDateMeta,
          txnDate.isAcceptableOrUnknown(data['txn_date']!, _txnDateMeta));
    } else if (isInserting) {
      context.missing(_txnDateMeta);
    }
    if (data.containsKey('expected_cash_paisa')) {
      context.handle(
          _expectedCashPaisaMeta,
          expectedCashPaisa.isAcceptableOrUnknown(
              data['expected_cash_paisa']!, _expectedCashPaisaMeta));
    }
    if (data.containsKey('counted_cash_paisa')) {
      context.handle(
          _countedCashPaisaMeta,
          countedCashPaisa.isAcceptableOrUnknown(
              data['counted_cash_paisa']!, _countedCashPaisaMeta));
    }
    if (data.containsKey('difference_paisa')) {
      context.handle(
          _differencePaisaMeta,
          differencePaisa.isAcceptableOrUnknown(
              data['difference_paisa']!, _differencePaisaMeta));
    }
    if (data.containsKey('note')) {
      context.handle(
          _noteMeta, note.isAcceptableOrUnknown(data['note']!, _noteMeta));
    }
    if (data.containsKey('closed_at')) {
      context.handle(_closedAtMeta,
          closedAt.isAcceptableOrUnknown(data['closed_at']!, _closedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  DailyClosing map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return DailyClosing(
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}updated_at'])!,
      deletedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}deleted_at']),
      version: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}version'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      userId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}user_id'])!,
      txnDate: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}txn_date'])!,
      expectedCashPaisa: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}expected_cash_paisa'])!,
      countedCashPaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}counted_cash_paisa']),
      differencePaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}difference_paisa']),
      note: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}note']),
      closedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}closed_at'])!,
    );
  }

  @override
  $DailyClosingsTable createAlias(String alias) {
    return $DailyClosingsTable(attachedDatabase, alias);
  }
}

class DailyClosing extends DataClass implements Insertable<DailyClosing> {
  final String createdAt;
  final String updatedAt;
  final String? deletedAt;
  final int version;
  final String syncStatus;
  final String id;
  final String userId;
  final String txnDate;
  final int expectedCashPaisa;
  final int? countedCashPaisa;
  final int? differencePaisa;
  final String? note;
  final int closedAt;
  const DailyClosing(
      {required this.createdAt,
      required this.updatedAt,
      this.deletedAt,
      required this.version,
      required this.syncStatus,
      required this.id,
      required this.userId,
      required this.txnDate,
      required this.expectedCashPaisa,
      this.countedCashPaisa,
      this.differencePaisa,
      this.note,
      required this.closedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['created_at'] = Variable<String>(createdAt);
    map['updated_at'] = Variable<String>(updatedAt);
    if (!nullToAbsent || deletedAt != null) {
      map['deleted_at'] = Variable<String>(deletedAt);
    }
    map['version'] = Variable<int>(version);
    map['sync_status'] = Variable<String>(syncStatus);
    map['id'] = Variable<String>(id);
    map['user_id'] = Variable<String>(userId);
    map['txn_date'] = Variable<String>(txnDate);
    map['expected_cash_paisa'] = Variable<int>(expectedCashPaisa);
    if (!nullToAbsent || countedCashPaisa != null) {
      map['counted_cash_paisa'] = Variable<int>(countedCashPaisa);
    }
    if (!nullToAbsent || differencePaisa != null) {
      map['difference_paisa'] = Variable<int>(differencePaisa);
    }
    if (!nullToAbsent || note != null) {
      map['note'] = Variable<String>(note);
    }
    map['closed_at'] = Variable<int>(closedAt);
    return map;
  }

  DailyClosingsCompanion toCompanion(bool nullToAbsent) {
    return DailyClosingsCompanion(
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      deletedAt: deletedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(deletedAt),
      version: Value(version),
      syncStatus: Value(syncStatus),
      id: Value(id),
      userId: Value(userId),
      txnDate: Value(txnDate),
      expectedCashPaisa: Value(expectedCashPaisa),
      countedCashPaisa: countedCashPaisa == null && nullToAbsent
          ? const Value.absent()
          : Value(countedCashPaisa),
      differencePaisa: differencePaisa == null && nullToAbsent
          ? const Value.absent()
          : Value(differencePaisa),
      note: note == null && nullToAbsent ? const Value.absent() : Value(note),
      closedAt: Value(closedAt),
    );
  }

  factory DailyClosing.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return DailyClosing(
      createdAt: serializer.fromJson<String>(json['createdAt']),
      updatedAt: serializer.fromJson<String>(json['updatedAt']),
      deletedAt: serializer.fromJson<String?>(json['deletedAt']),
      version: serializer.fromJson<int>(json['version']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      id: serializer.fromJson<String>(json['id']),
      userId: serializer.fromJson<String>(json['userId']),
      txnDate: serializer.fromJson<String>(json['txnDate']),
      expectedCashPaisa: serializer.fromJson<int>(json['expectedCashPaisa']),
      countedCashPaisa: serializer.fromJson<int?>(json['countedCashPaisa']),
      differencePaisa: serializer.fromJson<int?>(json['differencePaisa']),
      note: serializer.fromJson<String?>(json['note']),
      closedAt: serializer.fromJson<int>(json['closedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'createdAt': serializer.toJson<String>(createdAt),
      'updatedAt': serializer.toJson<String>(updatedAt),
      'deletedAt': serializer.toJson<String?>(deletedAt),
      'version': serializer.toJson<int>(version),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'id': serializer.toJson<String>(id),
      'userId': serializer.toJson<String>(userId),
      'txnDate': serializer.toJson<String>(txnDate),
      'expectedCashPaisa': serializer.toJson<int>(expectedCashPaisa),
      'countedCashPaisa': serializer.toJson<int?>(countedCashPaisa),
      'differencePaisa': serializer.toJson<int?>(differencePaisa),
      'note': serializer.toJson<String?>(note),
      'closedAt': serializer.toJson<int>(closedAt),
    };
  }

  DailyClosing copyWith(
          {String? createdAt,
          String? updatedAt,
          Value<String?> deletedAt = const Value.absent(),
          int? version,
          String? syncStatus,
          String? id,
          String? userId,
          String? txnDate,
          int? expectedCashPaisa,
          Value<int?> countedCashPaisa = const Value.absent(),
          Value<int?> differencePaisa = const Value.absent(),
          Value<String?> note = const Value.absent(),
          int? closedAt}) =>
      DailyClosing(
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: deletedAt.present ? deletedAt.value : this.deletedAt,
        version: version ?? this.version,
        syncStatus: syncStatus ?? this.syncStatus,
        id: id ?? this.id,
        userId: userId ?? this.userId,
        txnDate: txnDate ?? this.txnDate,
        expectedCashPaisa: expectedCashPaisa ?? this.expectedCashPaisa,
        countedCashPaisa: countedCashPaisa.present
            ? countedCashPaisa.value
            : this.countedCashPaisa,
        differencePaisa: differencePaisa.present
            ? differencePaisa.value
            : this.differencePaisa,
        note: note.present ? note.value : this.note,
        closedAt: closedAt ?? this.closedAt,
      );
  DailyClosing copyWithCompanion(DailyClosingsCompanion data) {
    return DailyClosing(
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      deletedAt: data.deletedAt.present ? data.deletedAt.value : this.deletedAt,
      version: data.version.present ? data.version.value : this.version,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      id: data.id.present ? data.id.value : this.id,
      userId: data.userId.present ? data.userId.value : this.userId,
      txnDate: data.txnDate.present ? data.txnDate.value : this.txnDate,
      expectedCashPaisa: data.expectedCashPaisa.present
          ? data.expectedCashPaisa.value
          : this.expectedCashPaisa,
      countedCashPaisa: data.countedCashPaisa.present
          ? data.countedCashPaisa.value
          : this.countedCashPaisa,
      differencePaisa: data.differencePaisa.present
          ? data.differencePaisa.value
          : this.differencePaisa,
      note: data.note.present ? data.note.value : this.note,
      closedAt: data.closedAt.present ? data.closedAt.value : this.closedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('DailyClosing(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('txnDate: $txnDate, ')
          ..write('expectedCashPaisa: $expectedCashPaisa, ')
          ..write('countedCashPaisa: $countedCashPaisa, ')
          ..write('differencePaisa: $differencePaisa, ')
          ..write('note: $note, ')
          ..write('closedAt: $closedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      createdAt,
      updatedAt,
      deletedAt,
      version,
      syncStatus,
      id,
      userId,
      txnDate,
      expectedCashPaisa,
      countedCashPaisa,
      differencePaisa,
      note,
      closedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is DailyClosing &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.deletedAt == this.deletedAt &&
          other.version == this.version &&
          other.syncStatus == this.syncStatus &&
          other.id == this.id &&
          other.userId == this.userId &&
          other.txnDate == this.txnDate &&
          other.expectedCashPaisa == this.expectedCashPaisa &&
          other.countedCashPaisa == this.countedCashPaisa &&
          other.differencePaisa == this.differencePaisa &&
          other.note == this.note &&
          other.closedAt == this.closedAt);
}

class DailyClosingsCompanion extends UpdateCompanion<DailyClosing> {
  final Value<String> createdAt;
  final Value<String> updatedAt;
  final Value<String?> deletedAt;
  final Value<int> version;
  final Value<String> syncStatus;
  final Value<String> id;
  final Value<String> userId;
  final Value<String> txnDate;
  final Value<int> expectedCashPaisa;
  final Value<int?> countedCashPaisa;
  final Value<int?> differencePaisa;
  final Value<String?> note;
  final Value<int> closedAt;
  final Value<int> rowid;
  const DailyClosingsCompanion({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.id = const Value.absent(),
    this.userId = const Value.absent(),
    this.txnDate = const Value.absent(),
    this.expectedCashPaisa = const Value.absent(),
    this.countedCashPaisa = const Value.absent(),
    this.differencePaisa = const Value.absent(),
    this.note = const Value.absent(),
    this.closedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  DailyClosingsCompanion.insert({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    required String id,
    required String userId,
    required String txnDate,
    this.expectedCashPaisa = const Value.absent(),
    this.countedCashPaisa = const Value.absent(),
    this.differencePaisa = const Value.absent(),
    this.note = const Value.absent(),
    this.closedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        userId = Value(userId),
        txnDate = Value(txnDate);
  static Insertable<DailyClosing> custom({
    Expression<String>? createdAt,
    Expression<String>? updatedAt,
    Expression<String>? deletedAt,
    Expression<int>? version,
    Expression<String>? syncStatus,
    Expression<String>? id,
    Expression<String>? userId,
    Expression<String>? txnDate,
    Expression<int>? expectedCashPaisa,
    Expression<int>? countedCashPaisa,
    Expression<int>? differencePaisa,
    Expression<String>? note,
    Expression<int>? closedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (deletedAt != null) 'deleted_at': deletedAt,
      if (version != null) 'version': version,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (id != null) 'id': id,
      if (userId != null) 'user_id': userId,
      if (txnDate != null) 'txn_date': txnDate,
      if (expectedCashPaisa != null) 'expected_cash_paisa': expectedCashPaisa,
      if (countedCashPaisa != null) 'counted_cash_paisa': countedCashPaisa,
      if (differencePaisa != null) 'difference_paisa': differencePaisa,
      if (note != null) 'note': note,
      if (closedAt != null) 'closed_at': closedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  DailyClosingsCompanion copyWith(
      {Value<String>? createdAt,
      Value<String>? updatedAt,
      Value<String?>? deletedAt,
      Value<int>? version,
      Value<String>? syncStatus,
      Value<String>? id,
      Value<String>? userId,
      Value<String>? txnDate,
      Value<int>? expectedCashPaisa,
      Value<int?>? countedCashPaisa,
      Value<int?>? differencePaisa,
      Value<String?>? note,
      Value<int>? closedAt,
      Value<int>? rowid}) {
    return DailyClosingsCompanion(
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      version: version ?? this.version,
      syncStatus: syncStatus ?? this.syncStatus,
      id: id ?? this.id,
      userId: userId ?? this.userId,
      txnDate: txnDate ?? this.txnDate,
      expectedCashPaisa: expectedCashPaisa ?? this.expectedCashPaisa,
      countedCashPaisa: countedCashPaisa ?? this.countedCashPaisa,
      differencePaisa: differencePaisa ?? this.differencePaisa,
      note: note ?? this.note,
      closedAt: closedAt ?? this.closedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (createdAt.present) {
      map['created_at'] = Variable<String>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<String>(updatedAt.value);
    }
    if (deletedAt.present) {
      map['deleted_at'] = Variable<String>(deletedAt.value);
    }
    if (version.present) {
      map['version'] = Variable<int>(version.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<String>(userId.value);
    }
    if (txnDate.present) {
      map['txn_date'] = Variable<String>(txnDate.value);
    }
    if (expectedCashPaisa.present) {
      map['expected_cash_paisa'] = Variable<int>(expectedCashPaisa.value);
    }
    if (countedCashPaisa.present) {
      map['counted_cash_paisa'] = Variable<int>(countedCashPaisa.value);
    }
    if (differencePaisa.present) {
      map['difference_paisa'] = Variable<int>(differencePaisa.value);
    }
    if (note.present) {
      map['note'] = Variable<String>(note.value);
    }
    if (closedAt.present) {
      map['closed_at'] = Variable<int>(closedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('DailyClosingsCompanion(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('txnDate: $txnDate, ')
          ..write('expectedCashPaisa: $expectedCashPaisa, ')
          ..write('countedCashPaisa: $countedCashPaisa, ')
          ..write('differencePaisa: $differencePaisa, ')
          ..write('note: $note, ')
          ..write('closedAt: $closedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $AttachmentsTable extends Attachments
    with TableInfo<$AttachmentsTable, Attachment> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $AttachmentsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<String> createdAt = GeneratedColumn<String>(
      'created_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<String> updatedAt = GeneratedColumn<String>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _deletedAtMeta =
      const VerificationMeta('deletedAt');
  @override
  late final GeneratedColumn<String> deletedAt = GeneratedColumn<String>(
      'deleted_at', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _versionMeta =
      const VerificationMeta('version');
  @override
  late final GeneratedColumn<int> version = GeneratedColumn<int>(
      'version', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('pending'));
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<String> userId = GeneratedColumn<String>(
      'user_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _ownerTypeMeta =
      const VerificationMeta('ownerType');
  @override
  late final GeneratedColumn<String> ownerType = GeneratedColumn<String>(
      'owner_type', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _ownerIdMeta =
      const VerificationMeta('ownerId');
  @override
  late final GeneratedColumn<String> ownerId = GeneratedColumn<String>(
      'owner_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _localPathMeta =
      const VerificationMeta('localPath');
  @override
  late final GeneratedColumn<String> localPath = GeneratedColumn<String>(
      'local_path', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _remotePathMeta =
      const VerificationMeta('remotePath');
  @override
  late final GeneratedColumn<String> remotePath = GeneratedColumn<String>(
      'remote_path', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _mimeMeta = const VerificationMeta('mime');
  @override
  late final GeneratedColumn<String> mime = GeneratedColumn<String>(
      'mime', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _sizeBytesMeta =
      const VerificationMeta('sizeBytes');
  @override
  late final GeneratedColumn<int> sizeBytes = GeneratedColumn<int>(
      'size_bytes', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        createdAt,
        updatedAt,
        deletedAt,
        version,
        syncStatus,
        id,
        userId,
        ownerType,
        ownerId,
        localPath,
        remotePath,
        mime,
        sizeBytes
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'attachments';
  @override
  VerificationContext validateIntegrity(Insertable<Attachment> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    if (data.containsKey('deleted_at')) {
      context.handle(_deletedAtMeta,
          deletedAt.isAcceptableOrUnknown(data['deleted_at']!, _deletedAtMeta));
    }
    if (data.containsKey('version')) {
      context.handle(_versionMeta,
          version.isAcceptableOrUnknown(data['version']!, _versionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('user_id')) {
      context.handle(_userIdMeta,
          userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta));
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('owner_type')) {
      context.handle(_ownerTypeMeta,
          ownerType.isAcceptableOrUnknown(data['owner_type']!, _ownerTypeMeta));
    } else if (isInserting) {
      context.missing(_ownerTypeMeta);
    }
    if (data.containsKey('owner_id')) {
      context.handle(_ownerIdMeta,
          ownerId.isAcceptableOrUnknown(data['owner_id']!, _ownerIdMeta));
    } else if (isInserting) {
      context.missing(_ownerIdMeta);
    }
    if (data.containsKey('local_path')) {
      context.handle(_localPathMeta,
          localPath.isAcceptableOrUnknown(data['local_path']!, _localPathMeta));
    } else if (isInserting) {
      context.missing(_localPathMeta);
    }
    if (data.containsKey('remote_path')) {
      context.handle(
          _remotePathMeta,
          remotePath.isAcceptableOrUnknown(
              data['remote_path']!, _remotePathMeta));
    }
    if (data.containsKey('mime')) {
      context.handle(
          _mimeMeta, mime.isAcceptableOrUnknown(data['mime']!, _mimeMeta));
    }
    if (data.containsKey('size_bytes')) {
      context.handle(_sizeBytesMeta,
          sizeBytes.isAcceptableOrUnknown(data['size_bytes']!, _sizeBytesMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Attachment map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Attachment(
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}updated_at'])!,
      deletedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}deleted_at']),
      version: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}version'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      userId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}user_id'])!,
      ownerType: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}owner_type'])!,
      ownerId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}owner_id'])!,
      localPath: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}local_path'])!,
      remotePath: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}remote_path']),
      mime: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}mime']),
      sizeBytes: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}size_bytes']),
    );
  }

  @override
  $AttachmentsTable createAlias(String alias) {
    return $AttachmentsTable(attachedDatabase, alias);
  }
}

class Attachment extends DataClass implements Insertable<Attachment> {
  final String createdAt;
  final String updatedAt;
  final String? deletedAt;
  final int version;
  final String syncStatus;
  final String id;
  final String userId;
  final String ownerType;
  final String ownerId;
  final String localPath;
  final String? remotePath;
  final String? mime;
  final int? sizeBytes;
  const Attachment(
      {required this.createdAt,
      required this.updatedAt,
      this.deletedAt,
      required this.version,
      required this.syncStatus,
      required this.id,
      required this.userId,
      required this.ownerType,
      required this.ownerId,
      required this.localPath,
      this.remotePath,
      this.mime,
      this.sizeBytes});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['created_at'] = Variable<String>(createdAt);
    map['updated_at'] = Variable<String>(updatedAt);
    if (!nullToAbsent || deletedAt != null) {
      map['deleted_at'] = Variable<String>(deletedAt);
    }
    map['version'] = Variable<int>(version);
    map['sync_status'] = Variable<String>(syncStatus);
    map['id'] = Variable<String>(id);
    map['user_id'] = Variable<String>(userId);
    map['owner_type'] = Variable<String>(ownerType);
    map['owner_id'] = Variable<String>(ownerId);
    map['local_path'] = Variable<String>(localPath);
    if (!nullToAbsent || remotePath != null) {
      map['remote_path'] = Variable<String>(remotePath);
    }
    if (!nullToAbsent || mime != null) {
      map['mime'] = Variable<String>(mime);
    }
    if (!nullToAbsent || sizeBytes != null) {
      map['size_bytes'] = Variable<int>(sizeBytes);
    }
    return map;
  }

  AttachmentsCompanion toCompanion(bool nullToAbsent) {
    return AttachmentsCompanion(
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      deletedAt: deletedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(deletedAt),
      version: Value(version),
      syncStatus: Value(syncStatus),
      id: Value(id),
      userId: Value(userId),
      ownerType: Value(ownerType),
      ownerId: Value(ownerId),
      localPath: Value(localPath),
      remotePath: remotePath == null && nullToAbsent
          ? const Value.absent()
          : Value(remotePath),
      mime: mime == null && nullToAbsent ? const Value.absent() : Value(mime),
      sizeBytes: sizeBytes == null && nullToAbsent
          ? const Value.absent()
          : Value(sizeBytes),
    );
  }

  factory Attachment.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Attachment(
      createdAt: serializer.fromJson<String>(json['createdAt']),
      updatedAt: serializer.fromJson<String>(json['updatedAt']),
      deletedAt: serializer.fromJson<String?>(json['deletedAt']),
      version: serializer.fromJson<int>(json['version']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      id: serializer.fromJson<String>(json['id']),
      userId: serializer.fromJson<String>(json['userId']),
      ownerType: serializer.fromJson<String>(json['ownerType']),
      ownerId: serializer.fromJson<String>(json['ownerId']),
      localPath: serializer.fromJson<String>(json['localPath']),
      remotePath: serializer.fromJson<String?>(json['remotePath']),
      mime: serializer.fromJson<String?>(json['mime']),
      sizeBytes: serializer.fromJson<int?>(json['sizeBytes']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'createdAt': serializer.toJson<String>(createdAt),
      'updatedAt': serializer.toJson<String>(updatedAt),
      'deletedAt': serializer.toJson<String?>(deletedAt),
      'version': serializer.toJson<int>(version),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'id': serializer.toJson<String>(id),
      'userId': serializer.toJson<String>(userId),
      'ownerType': serializer.toJson<String>(ownerType),
      'ownerId': serializer.toJson<String>(ownerId),
      'localPath': serializer.toJson<String>(localPath),
      'remotePath': serializer.toJson<String?>(remotePath),
      'mime': serializer.toJson<String?>(mime),
      'sizeBytes': serializer.toJson<int?>(sizeBytes),
    };
  }

  Attachment copyWith(
          {String? createdAt,
          String? updatedAt,
          Value<String?> deletedAt = const Value.absent(),
          int? version,
          String? syncStatus,
          String? id,
          String? userId,
          String? ownerType,
          String? ownerId,
          String? localPath,
          Value<String?> remotePath = const Value.absent(),
          Value<String?> mime = const Value.absent(),
          Value<int?> sizeBytes = const Value.absent()}) =>
      Attachment(
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: deletedAt.present ? deletedAt.value : this.deletedAt,
        version: version ?? this.version,
        syncStatus: syncStatus ?? this.syncStatus,
        id: id ?? this.id,
        userId: userId ?? this.userId,
        ownerType: ownerType ?? this.ownerType,
        ownerId: ownerId ?? this.ownerId,
        localPath: localPath ?? this.localPath,
        remotePath: remotePath.present ? remotePath.value : this.remotePath,
        mime: mime.present ? mime.value : this.mime,
        sizeBytes: sizeBytes.present ? sizeBytes.value : this.sizeBytes,
      );
  Attachment copyWithCompanion(AttachmentsCompanion data) {
    return Attachment(
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      deletedAt: data.deletedAt.present ? data.deletedAt.value : this.deletedAt,
      version: data.version.present ? data.version.value : this.version,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      id: data.id.present ? data.id.value : this.id,
      userId: data.userId.present ? data.userId.value : this.userId,
      ownerType: data.ownerType.present ? data.ownerType.value : this.ownerType,
      ownerId: data.ownerId.present ? data.ownerId.value : this.ownerId,
      localPath: data.localPath.present ? data.localPath.value : this.localPath,
      remotePath:
          data.remotePath.present ? data.remotePath.value : this.remotePath,
      mime: data.mime.present ? data.mime.value : this.mime,
      sizeBytes: data.sizeBytes.present ? data.sizeBytes.value : this.sizeBytes,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Attachment(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('ownerType: $ownerType, ')
          ..write('ownerId: $ownerId, ')
          ..write('localPath: $localPath, ')
          ..write('remotePath: $remotePath, ')
          ..write('mime: $mime, ')
          ..write('sizeBytes: $sizeBytes')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      createdAt,
      updatedAt,
      deletedAt,
      version,
      syncStatus,
      id,
      userId,
      ownerType,
      ownerId,
      localPath,
      remotePath,
      mime,
      sizeBytes);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Attachment &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.deletedAt == this.deletedAt &&
          other.version == this.version &&
          other.syncStatus == this.syncStatus &&
          other.id == this.id &&
          other.userId == this.userId &&
          other.ownerType == this.ownerType &&
          other.ownerId == this.ownerId &&
          other.localPath == this.localPath &&
          other.remotePath == this.remotePath &&
          other.mime == this.mime &&
          other.sizeBytes == this.sizeBytes);
}

class AttachmentsCompanion extends UpdateCompanion<Attachment> {
  final Value<String> createdAt;
  final Value<String> updatedAt;
  final Value<String?> deletedAt;
  final Value<int> version;
  final Value<String> syncStatus;
  final Value<String> id;
  final Value<String> userId;
  final Value<String> ownerType;
  final Value<String> ownerId;
  final Value<String> localPath;
  final Value<String?> remotePath;
  final Value<String?> mime;
  final Value<int?> sizeBytes;
  final Value<int> rowid;
  const AttachmentsCompanion({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.id = const Value.absent(),
    this.userId = const Value.absent(),
    this.ownerType = const Value.absent(),
    this.ownerId = const Value.absent(),
    this.localPath = const Value.absent(),
    this.remotePath = const Value.absent(),
    this.mime = const Value.absent(),
    this.sizeBytes = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  AttachmentsCompanion.insert({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    required String id,
    required String userId,
    required String ownerType,
    required String ownerId,
    required String localPath,
    this.remotePath = const Value.absent(),
    this.mime = const Value.absent(),
    this.sizeBytes = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        userId = Value(userId),
        ownerType = Value(ownerType),
        ownerId = Value(ownerId),
        localPath = Value(localPath);
  static Insertable<Attachment> custom({
    Expression<String>? createdAt,
    Expression<String>? updatedAt,
    Expression<String>? deletedAt,
    Expression<int>? version,
    Expression<String>? syncStatus,
    Expression<String>? id,
    Expression<String>? userId,
    Expression<String>? ownerType,
    Expression<String>? ownerId,
    Expression<String>? localPath,
    Expression<String>? remotePath,
    Expression<String>? mime,
    Expression<int>? sizeBytes,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (deletedAt != null) 'deleted_at': deletedAt,
      if (version != null) 'version': version,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (id != null) 'id': id,
      if (userId != null) 'user_id': userId,
      if (ownerType != null) 'owner_type': ownerType,
      if (ownerId != null) 'owner_id': ownerId,
      if (localPath != null) 'local_path': localPath,
      if (remotePath != null) 'remote_path': remotePath,
      if (mime != null) 'mime': mime,
      if (sizeBytes != null) 'size_bytes': sizeBytes,
      if (rowid != null) 'rowid': rowid,
    });
  }

  AttachmentsCompanion copyWith(
      {Value<String>? createdAt,
      Value<String>? updatedAt,
      Value<String?>? deletedAt,
      Value<int>? version,
      Value<String>? syncStatus,
      Value<String>? id,
      Value<String>? userId,
      Value<String>? ownerType,
      Value<String>? ownerId,
      Value<String>? localPath,
      Value<String?>? remotePath,
      Value<String?>? mime,
      Value<int?>? sizeBytes,
      Value<int>? rowid}) {
    return AttachmentsCompanion(
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      version: version ?? this.version,
      syncStatus: syncStatus ?? this.syncStatus,
      id: id ?? this.id,
      userId: userId ?? this.userId,
      ownerType: ownerType ?? this.ownerType,
      ownerId: ownerId ?? this.ownerId,
      localPath: localPath ?? this.localPath,
      remotePath: remotePath ?? this.remotePath,
      mime: mime ?? this.mime,
      sizeBytes: sizeBytes ?? this.sizeBytes,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (createdAt.present) {
      map['created_at'] = Variable<String>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<String>(updatedAt.value);
    }
    if (deletedAt.present) {
      map['deleted_at'] = Variable<String>(deletedAt.value);
    }
    if (version.present) {
      map['version'] = Variable<int>(version.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<String>(userId.value);
    }
    if (ownerType.present) {
      map['owner_type'] = Variable<String>(ownerType.value);
    }
    if (ownerId.present) {
      map['owner_id'] = Variable<String>(ownerId.value);
    }
    if (localPath.present) {
      map['local_path'] = Variable<String>(localPath.value);
    }
    if (remotePath.present) {
      map['remote_path'] = Variable<String>(remotePath.value);
    }
    if (mime.present) {
      map['mime'] = Variable<String>(mime.value);
    }
    if (sizeBytes.present) {
      map['size_bytes'] = Variable<int>(sizeBytes.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('AttachmentsCompanion(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('ownerType: $ownerType, ')
          ..write('ownerId: $ownerId, ')
          ..write('localPath: $localPath, ')
          ..write('remotePath: $remotePath, ')
          ..write('mime: $mime, ')
          ..write('sizeBytes: $sizeBytes, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $MonthlyBudgetsTable extends MonthlyBudgets
    with TableInfo<$MonthlyBudgetsTable, MonthlyBudget> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $MonthlyBudgetsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<String> createdAt = GeneratedColumn<String>(
      'created_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<String> updatedAt = GeneratedColumn<String>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _deletedAtMeta =
      const VerificationMeta('deletedAt');
  @override
  late final GeneratedColumn<String> deletedAt = GeneratedColumn<String>(
      'deleted_at', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _versionMeta =
      const VerificationMeta('version');
  @override
  late final GeneratedColumn<int> version = GeneratedColumn<int>(
      'version', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('pending'));
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<String> userId = GeneratedColumn<String>(
      'user_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _categoryMeta =
      const VerificationMeta('category');
  @override
  late final GeneratedColumn<String> category = GeneratedColumn<String>(
      'category', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _monthMeta = const VerificationMeta('month');
  @override
  late final GeneratedColumn<String> month = GeneratedColumn<String>(
      'month', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _limitPaisaMeta =
      const VerificationMeta('limitPaisa');
  @override
  late final GeneratedColumn<int> limitPaisa = GeneratedColumn<int>(
      'limit_paisa', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  @override
  List<GeneratedColumn> get $columns => [
        createdAt,
        updatedAt,
        deletedAt,
        version,
        syncStatus,
        id,
        userId,
        category,
        month,
        limitPaisa
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'monthly_budgets';
  @override
  VerificationContext validateIntegrity(Insertable<MonthlyBudget> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    if (data.containsKey('deleted_at')) {
      context.handle(_deletedAtMeta,
          deletedAt.isAcceptableOrUnknown(data['deleted_at']!, _deletedAtMeta));
    }
    if (data.containsKey('version')) {
      context.handle(_versionMeta,
          version.isAcceptableOrUnknown(data['version']!, _versionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('user_id')) {
      context.handle(_userIdMeta,
          userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta));
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('category')) {
      context.handle(_categoryMeta,
          category.isAcceptableOrUnknown(data['category']!, _categoryMeta));
    } else if (isInserting) {
      context.missing(_categoryMeta);
    }
    if (data.containsKey('month')) {
      context.handle(
          _monthMeta, month.isAcceptableOrUnknown(data['month']!, _monthMeta));
    } else if (isInserting) {
      context.missing(_monthMeta);
    }
    if (data.containsKey('limit_paisa')) {
      context.handle(
          _limitPaisaMeta,
          limitPaisa.isAcceptableOrUnknown(
              data['limit_paisa']!, _limitPaisaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  MonthlyBudget map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return MonthlyBudget(
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}updated_at'])!,
      deletedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}deleted_at']),
      version: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}version'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      userId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}user_id'])!,
      category: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}category'])!,
      month: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}month'])!,
      limitPaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}limit_paisa'])!,
    );
  }

  @override
  $MonthlyBudgetsTable createAlias(String alias) {
    return $MonthlyBudgetsTable(attachedDatabase, alias);
  }
}

class MonthlyBudget extends DataClass implements Insertable<MonthlyBudget> {
  final String createdAt;
  final String updatedAt;
  final String? deletedAt;
  final int version;
  final String syncStatus;
  final String id;
  final String userId;
  final String category;
  final String month;
  final int limitPaisa;
  const MonthlyBudget(
      {required this.createdAt,
      required this.updatedAt,
      this.deletedAt,
      required this.version,
      required this.syncStatus,
      required this.id,
      required this.userId,
      required this.category,
      required this.month,
      required this.limitPaisa});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['created_at'] = Variable<String>(createdAt);
    map['updated_at'] = Variable<String>(updatedAt);
    if (!nullToAbsent || deletedAt != null) {
      map['deleted_at'] = Variable<String>(deletedAt);
    }
    map['version'] = Variable<int>(version);
    map['sync_status'] = Variable<String>(syncStatus);
    map['id'] = Variable<String>(id);
    map['user_id'] = Variable<String>(userId);
    map['category'] = Variable<String>(category);
    map['month'] = Variable<String>(month);
    map['limit_paisa'] = Variable<int>(limitPaisa);
    return map;
  }

  MonthlyBudgetsCompanion toCompanion(bool nullToAbsent) {
    return MonthlyBudgetsCompanion(
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      deletedAt: deletedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(deletedAt),
      version: Value(version),
      syncStatus: Value(syncStatus),
      id: Value(id),
      userId: Value(userId),
      category: Value(category),
      month: Value(month),
      limitPaisa: Value(limitPaisa),
    );
  }

  factory MonthlyBudget.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return MonthlyBudget(
      createdAt: serializer.fromJson<String>(json['createdAt']),
      updatedAt: serializer.fromJson<String>(json['updatedAt']),
      deletedAt: serializer.fromJson<String?>(json['deletedAt']),
      version: serializer.fromJson<int>(json['version']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      id: serializer.fromJson<String>(json['id']),
      userId: serializer.fromJson<String>(json['userId']),
      category: serializer.fromJson<String>(json['category']),
      month: serializer.fromJson<String>(json['month']),
      limitPaisa: serializer.fromJson<int>(json['limitPaisa']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'createdAt': serializer.toJson<String>(createdAt),
      'updatedAt': serializer.toJson<String>(updatedAt),
      'deletedAt': serializer.toJson<String?>(deletedAt),
      'version': serializer.toJson<int>(version),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'id': serializer.toJson<String>(id),
      'userId': serializer.toJson<String>(userId),
      'category': serializer.toJson<String>(category),
      'month': serializer.toJson<String>(month),
      'limitPaisa': serializer.toJson<int>(limitPaisa),
    };
  }

  MonthlyBudget copyWith(
          {String? createdAt,
          String? updatedAt,
          Value<String?> deletedAt = const Value.absent(),
          int? version,
          String? syncStatus,
          String? id,
          String? userId,
          String? category,
          String? month,
          int? limitPaisa}) =>
      MonthlyBudget(
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: deletedAt.present ? deletedAt.value : this.deletedAt,
        version: version ?? this.version,
        syncStatus: syncStatus ?? this.syncStatus,
        id: id ?? this.id,
        userId: userId ?? this.userId,
        category: category ?? this.category,
        month: month ?? this.month,
        limitPaisa: limitPaisa ?? this.limitPaisa,
      );
  MonthlyBudget copyWithCompanion(MonthlyBudgetsCompanion data) {
    return MonthlyBudget(
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      deletedAt: data.deletedAt.present ? data.deletedAt.value : this.deletedAt,
      version: data.version.present ? data.version.value : this.version,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      id: data.id.present ? data.id.value : this.id,
      userId: data.userId.present ? data.userId.value : this.userId,
      category: data.category.present ? data.category.value : this.category,
      month: data.month.present ? data.month.value : this.month,
      limitPaisa:
          data.limitPaisa.present ? data.limitPaisa.value : this.limitPaisa,
    );
  }

  @override
  String toString() {
    return (StringBuffer('MonthlyBudget(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('category: $category, ')
          ..write('month: $month, ')
          ..write('limitPaisa: $limitPaisa')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(createdAt, updatedAt, deletedAt, version,
      syncStatus, id, userId, category, month, limitPaisa);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is MonthlyBudget &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.deletedAt == this.deletedAt &&
          other.version == this.version &&
          other.syncStatus == this.syncStatus &&
          other.id == this.id &&
          other.userId == this.userId &&
          other.category == this.category &&
          other.month == this.month &&
          other.limitPaisa == this.limitPaisa);
}

class MonthlyBudgetsCompanion extends UpdateCompanion<MonthlyBudget> {
  final Value<String> createdAt;
  final Value<String> updatedAt;
  final Value<String?> deletedAt;
  final Value<int> version;
  final Value<String> syncStatus;
  final Value<String> id;
  final Value<String> userId;
  final Value<String> category;
  final Value<String> month;
  final Value<int> limitPaisa;
  final Value<int> rowid;
  const MonthlyBudgetsCompanion({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.id = const Value.absent(),
    this.userId = const Value.absent(),
    this.category = const Value.absent(),
    this.month = const Value.absent(),
    this.limitPaisa = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  MonthlyBudgetsCompanion.insert({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    required String id,
    required String userId,
    required String category,
    required String month,
    this.limitPaisa = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        userId = Value(userId),
        category = Value(category),
        month = Value(month);
  static Insertable<MonthlyBudget> custom({
    Expression<String>? createdAt,
    Expression<String>? updatedAt,
    Expression<String>? deletedAt,
    Expression<int>? version,
    Expression<String>? syncStatus,
    Expression<String>? id,
    Expression<String>? userId,
    Expression<String>? category,
    Expression<String>? month,
    Expression<int>? limitPaisa,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (deletedAt != null) 'deleted_at': deletedAt,
      if (version != null) 'version': version,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (id != null) 'id': id,
      if (userId != null) 'user_id': userId,
      if (category != null) 'category': category,
      if (month != null) 'month': month,
      if (limitPaisa != null) 'limit_paisa': limitPaisa,
      if (rowid != null) 'rowid': rowid,
    });
  }

  MonthlyBudgetsCompanion copyWith(
      {Value<String>? createdAt,
      Value<String>? updatedAt,
      Value<String?>? deletedAt,
      Value<int>? version,
      Value<String>? syncStatus,
      Value<String>? id,
      Value<String>? userId,
      Value<String>? category,
      Value<String>? month,
      Value<int>? limitPaisa,
      Value<int>? rowid}) {
    return MonthlyBudgetsCompanion(
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      version: version ?? this.version,
      syncStatus: syncStatus ?? this.syncStatus,
      id: id ?? this.id,
      userId: userId ?? this.userId,
      category: category ?? this.category,
      month: month ?? this.month,
      limitPaisa: limitPaisa ?? this.limitPaisa,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (createdAt.present) {
      map['created_at'] = Variable<String>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<String>(updatedAt.value);
    }
    if (deletedAt.present) {
      map['deleted_at'] = Variable<String>(deletedAt.value);
    }
    if (version.present) {
      map['version'] = Variable<int>(version.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<String>(userId.value);
    }
    if (category.present) {
      map['category'] = Variable<String>(category.value);
    }
    if (month.present) {
      map['month'] = Variable<String>(month.value);
    }
    if (limitPaisa.present) {
      map['limit_paisa'] = Variable<int>(limitPaisa.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('MonthlyBudgetsCompanion(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('category: $category, ')
          ..write('month: $month, ')
          ..write('limitPaisa: $limitPaisa, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $SavingsGoalsTable extends SavingsGoals
    with TableInfo<$SavingsGoalsTable, SavingsGoal> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SavingsGoalsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<String> createdAt = GeneratedColumn<String>(
      'created_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<String> updatedAt = GeneratedColumn<String>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant(''));
  static const VerificationMeta _deletedAtMeta =
      const VerificationMeta('deletedAt');
  @override
  late final GeneratedColumn<String> deletedAt = GeneratedColumn<String>(
      'deleted_at', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _versionMeta =
      const VerificationMeta('version');
  @override
  late final GeneratedColumn<int> version = GeneratedColumn<int>(
      'version', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(1));
  static const VerificationMeta _syncStatusMeta =
      const VerificationMeta('syncStatus');
  @override
  late final GeneratedColumn<String> syncStatus = GeneratedColumn<String>(
      'sync_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('pending'));
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<String> userId = GeneratedColumn<String>(
      'user_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _targetPaisaMeta =
      const VerificationMeta('targetPaisa');
  @override
  late final GeneratedColumn<int> targetPaisa = GeneratedColumn<int>(
      'target_paisa', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _currentPaisaMeta =
      const VerificationMeta('currentPaisa');
  @override
  late final GeneratedColumn<int> currentPaisa = GeneratedColumn<int>(
      'current_paisa', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _deadlineMeta =
      const VerificationMeta('deadline');
  @override
  late final GeneratedColumn<String> deadline = GeneratedColumn<String>(
      'deadline', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _noteMeta = const VerificationMeta('note');
  @override
  late final GeneratedColumn<String> note = GeneratedColumn<String>(
      'note', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        createdAt,
        updatedAt,
        deletedAt,
        version,
        syncStatus,
        id,
        userId,
        name,
        targetPaisa,
        currentPaisa,
        deadline,
        note
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'savings_goals';
  @override
  VerificationContext validateIntegrity(Insertable<SavingsGoal> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    if (data.containsKey('deleted_at')) {
      context.handle(_deletedAtMeta,
          deletedAt.isAcceptableOrUnknown(data['deleted_at']!, _deletedAtMeta));
    }
    if (data.containsKey('version')) {
      context.handle(_versionMeta,
          version.isAcceptableOrUnknown(data['version']!, _versionMeta));
    }
    if (data.containsKey('sync_status')) {
      context.handle(
          _syncStatusMeta,
          syncStatus.isAcceptableOrUnknown(
              data['sync_status']!, _syncStatusMeta));
    }
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('user_id')) {
      context.handle(_userIdMeta,
          userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta));
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    } else if (isInserting) {
      context.missing(_nameMeta);
    }
    if (data.containsKey('target_paisa')) {
      context.handle(
          _targetPaisaMeta,
          targetPaisa.isAcceptableOrUnknown(
              data['target_paisa']!, _targetPaisaMeta));
    } else if (isInserting) {
      context.missing(_targetPaisaMeta);
    }
    if (data.containsKey('current_paisa')) {
      context.handle(
          _currentPaisaMeta,
          currentPaisa.isAcceptableOrUnknown(
              data['current_paisa']!, _currentPaisaMeta));
    }
    if (data.containsKey('deadline')) {
      context.handle(_deadlineMeta,
          deadline.isAcceptableOrUnknown(data['deadline']!, _deadlineMeta));
    }
    if (data.containsKey('note')) {
      context.handle(
          _noteMeta, note.isAcceptableOrUnknown(data['note']!, _noteMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  SavingsGoal map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return SavingsGoal(
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}updated_at'])!,
      deletedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}deleted_at']),
      version: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}version'])!,
      syncStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sync_status'])!,
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      userId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}user_id'])!,
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name'])!,
      targetPaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}target_paisa'])!,
      currentPaisa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}current_paisa'])!,
      deadline: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}deadline']),
      note: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}note']),
    );
  }

  @override
  $SavingsGoalsTable createAlias(String alias) {
    return $SavingsGoalsTable(attachedDatabase, alias);
  }
}

class SavingsGoal extends DataClass implements Insertable<SavingsGoal> {
  final String createdAt;
  final String updatedAt;
  final String? deletedAt;
  final int version;
  final String syncStatus;
  final String id;
  final String userId;
  final String name;
  final int targetPaisa;
  final int currentPaisa;
  final String? deadline;
  final String? note;
  const SavingsGoal(
      {required this.createdAt,
      required this.updatedAt,
      this.deletedAt,
      required this.version,
      required this.syncStatus,
      required this.id,
      required this.userId,
      required this.name,
      required this.targetPaisa,
      required this.currentPaisa,
      this.deadline,
      this.note});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['created_at'] = Variable<String>(createdAt);
    map['updated_at'] = Variable<String>(updatedAt);
    if (!nullToAbsent || deletedAt != null) {
      map['deleted_at'] = Variable<String>(deletedAt);
    }
    map['version'] = Variable<int>(version);
    map['sync_status'] = Variable<String>(syncStatus);
    map['id'] = Variable<String>(id);
    map['user_id'] = Variable<String>(userId);
    map['name'] = Variable<String>(name);
    map['target_paisa'] = Variable<int>(targetPaisa);
    map['current_paisa'] = Variable<int>(currentPaisa);
    if (!nullToAbsent || deadline != null) {
      map['deadline'] = Variable<String>(deadline);
    }
    if (!nullToAbsent || note != null) {
      map['note'] = Variable<String>(note);
    }
    return map;
  }

  SavingsGoalsCompanion toCompanion(bool nullToAbsent) {
    return SavingsGoalsCompanion(
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
      deletedAt: deletedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(deletedAt),
      version: Value(version),
      syncStatus: Value(syncStatus),
      id: Value(id),
      userId: Value(userId),
      name: Value(name),
      targetPaisa: Value(targetPaisa),
      currentPaisa: Value(currentPaisa),
      deadline: deadline == null && nullToAbsent
          ? const Value.absent()
          : Value(deadline),
      note: note == null && nullToAbsent ? const Value.absent() : Value(note),
    );
  }

  factory SavingsGoal.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return SavingsGoal(
      createdAt: serializer.fromJson<String>(json['createdAt']),
      updatedAt: serializer.fromJson<String>(json['updatedAt']),
      deletedAt: serializer.fromJson<String?>(json['deletedAt']),
      version: serializer.fromJson<int>(json['version']),
      syncStatus: serializer.fromJson<String>(json['syncStatus']),
      id: serializer.fromJson<String>(json['id']),
      userId: serializer.fromJson<String>(json['userId']),
      name: serializer.fromJson<String>(json['name']),
      targetPaisa: serializer.fromJson<int>(json['targetPaisa']),
      currentPaisa: serializer.fromJson<int>(json['currentPaisa']),
      deadline: serializer.fromJson<String?>(json['deadline']),
      note: serializer.fromJson<String?>(json['note']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'createdAt': serializer.toJson<String>(createdAt),
      'updatedAt': serializer.toJson<String>(updatedAt),
      'deletedAt': serializer.toJson<String?>(deletedAt),
      'version': serializer.toJson<int>(version),
      'syncStatus': serializer.toJson<String>(syncStatus),
      'id': serializer.toJson<String>(id),
      'userId': serializer.toJson<String>(userId),
      'name': serializer.toJson<String>(name),
      'targetPaisa': serializer.toJson<int>(targetPaisa),
      'currentPaisa': serializer.toJson<int>(currentPaisa),
      'deadline': serializer.toJson<String?>(deadline),
      'note': serializer.toJson<String?>(note),
    };
  }

  SavingsGoal copyWith(
          {String? createdAt,
          String? updatedAt,
          Value<String?> deletedAt = const Value.absent(),
          int? version,
          String? syncStatus,
          String? id,
          String? userId,
          String? name,
          int? targetPaisa,
          int? currentPaisa,
          Value<String?> deadline = const Value.absent(),
          Value<String?> note = const Value.absent()}) =>
      SavingsGoal(
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        deletedAt: deletedAt.present ? deletedAt.value : this.deletedAt,
        version: version ?? this.version,
        syncStatus: syncStatus ?? this.syncStatus,
        id: id ?? this.id,
        userId: userId ?? this.userId,
        name: name ?? this.name,
        targetPaisa: targetPaisa ?? this.targetPaisa,
        currentPaisa: currentPaisa ?? this.currentPaisa,
        deadline: deadline.present ? deadline.value : this.deadline,
        note: note.present ? note.value : this.note,
      );
  SavingsGoal copyWithCompanion(SavingsGoalsCompanion data) {
    return SavingsGoal(
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
      deletedAt: data.deletedAt.present ? data.deletedAt.value : this.deletedAt,
      version: data.version.present ? data.version.value : this.version,
      syncStatus:
          data.syncStatus.present ? data.syncStatus.value : this.syncStatus,
      id: data.id.present ? data.id.value : this.id,
      userId: data.userId.present ? data.userId.value : this.userId,
      name: data.name.present ? data.name.value : this.name,
      targetPaisa:
          data.targetPaisa.present ? data.targetPaisa.value : this.targetPaisa,
      currentPaisa: data.currentPaisa.present
          ? data.currentPaisa.value
          : this.currentPaisa,
      deadline: data.deadline.present ? data.deadline.value : this.deadline,
      note: data.note.present ? data.note.value : this.note,
    );
  }

  @override
  String toString() {
    return (StringBuffer('SavingsGoal(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('name: $name, ')
          ..write('targetPaisa: $targetPaisa, ')
          ..write('currentPaisa: $currentPaisa, ')
          ..write('deadline: $deadline, ')
          ..write('note: $note')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(createdAt, updatedAt, deletedAt, version,
      syncStatus, id, userId, name, targetPaisa, currentPaisa, deadline, note);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SavingsGoal &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt &&
          other.deletedAt == this.deletedAt &&
          other.version == this.version &&
          other.syncStatus == this.syncStatus &&
          other.id == this.id &&
          other.userId == this.userId &&
          other.name == this.name &&
          other.targetPaisa == this.targetPaisa &&
          other.currentPaisa == this.currentPaisa &&
          other.deadline == this.deadline &&
          other.note == this.note);
}

class SavingsGoalsCompanion extends UpdateCompanion<SavingsGoal> {
  final Value<String> createdAt;
  final Value<String> updatedAt;
  final Value<String?> deletedAt;
  final Value<int> version;
  final Value<String> syncStatus;
  final Value<String> id;
  final Value<String> userId;
  final Value<String> name;
  final Value<int> targetPaisa;
  final Value<int> currentPaisa;
  final Value<String?> deadline;
  final Value<String?> note;
  final Value<int> rowid;
  const SavingsGoalsCompanion({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    this.id = const Value.absent(),
    this.userId = const Value.absent(),
    this.name = const Value.absent(),
    this.targetPaisa = const Value.absent(),
    this.currentPaisa = const Value.absent(),
    this.deadline = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  SavingsGoalsCompanion.insert({
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.deletedAt = const Value.absent(),
    this.version = const Value.absent(),
    this.syncStatus = const Value.absent(),
    required String id,
    required String userId,
    required String name,
    required int targetPaisa,
    this.currentPaisa = const Value.absent(),
    this.deadline = const Value.absent(),
    this.note = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        userId = Value(userId),
        name = Value(name),
        targetPaisa = Value(targetPaisa);
  static Insertable<SavingsGoal> custom({
    Expression<String>? createdAt,
    Expression<String>? updatedAt,
    Expression<String>? deletedAt,
    Expression<int>? version,
    Expression<String>? syncStatus,
    Expression<String>? id,
    Expression<String>? userId,
    Expression<String>? name,
    Expression<int>? targetPaisa,
    Expression<int>? currentPaisa,
    Expression<String>? deadline,
    Expression<String>? note,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (deletedAt != null) 'deleted_at': deletedAt,
      if (version != null) 'version': version,
      if (syncStatus != null) 'sync_status': syncStatus,
      if (id != null) 'id': id,
      if (userId != null) 'user_id': userId,
      if (name != null) 'name': name,
      if (targetPaisa != null) 'target_paisa': targetPaisa,
      if (currentPaisa != null) 'current_paisa': currentPaisa,
      if (deadline != null) 'deadline': deadline,
      if (note != null) 'note': note,
      if (rowid != null) 'rowid': rowid,
    });
  }

  SavingsGoalsCompanion copyWith(
      {Value<String>? createdAt,
      Value<String>? updatedAt,
      Value<String?>? deletedAt,
      Value<int>? version,
      Value<String>? syncStatus,
      Value<String>? id,
      Value<String>? userId,
      Value<String>? name,
      Value<int>? targetPaisa,
      Value<int>? currentPaisa,
      Value<String?>? deadline,
      Value<String?>? note,
      Value<int>? rowid}) {
    return SavingsGoalsCompanion(
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      deletedAt: deletedAt ?? this.deletedAt,
      version: version ?? this.version,
      syncStatus: syncStatus ?? this.syncStatus,
      id: id ?? this.id,
      userId: userId ?? this.userId,
      name: name ?? this.name,
      targetPaisa: targetPaisa ?? this.targetPaisa,
      currentPaisa: currentPaisa ?? this.currentPaisa,
      deadline: deadline ?? this.deadline,
      note: note ?? this.note,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (createdAt.present) {
      map['created_at'] = Variable<String>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<String>(updatedAt.value);
    }
    if (deletedAt.present) {
      map['deleted_at'] = Variable<String>(deletedAt.value);
    }
    if (version.present) {
      map['version'] = Variable<int>(version.value);
    }
    if (syncStatus.present) {
      map['sync_status'] = Variable<String>(syncStatus.value);
    }
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<String>(userId.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (targetPaisa.present) {
      map['target_paisa'] = Variable<int>(targetPaisa.value);
    }
    if (currentPaisa.present) {
      map['current_paisa'] = Variable<int>(currentPaisa.value);
    }
    if (deadline.present) {
      map['deadline'] = Variable<String>(deadline.value);
    }
    if (note.present) {
      map['note'] = Variable<String>(note.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SavingsGoalsCompanion(')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('deletedAt: $deletedAt, ')
          ..write('version: $version, ')
          ..write('syncStatus: $syncStatus, ')
          ..write('id: $id, ')
          ..write('userId: $userId, ')
          ..write('name: $name, ')
          ..write('targetPaisa: $targetPaisa, ')
          ..write('currentPaisa: $currentPaisa, ')
          ..write('deadline: $deadline, ')
          ..write('note: $note, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $SyncQueueTable extends SyncQueue
    with TableInfo<$SyncQueueTable, SyncQueueData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SyncQueueTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, false,
      hasAutoIncrement: true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'));
  static const VerificationMeta _targetTableMeta =
      const VerificationMeta('targetTable');
  @override
  late final GeneratedColumn<String> targetTable = GeneratedColumn<String>(
      'target_table', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _rowIdMeta = const VerificationMeta('rowId');
  @override
  late final GeneratedColumn<String> rowId = GeneratedColumn<String>(
      'row_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _operationMeta =
      const VerificationMeta('operation');
  @override
  late final GeneratedColumn<String> operation = GeneratedColumn<String>(
      'operation', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _payloadJsonMeta =
      const VerificationMeta('payloadJson');
  @override
  late final GeneratedColumn<String> payloadJson = GeneratedColumn<String>(
      'payload_json', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('{}'));
  static const VerificationMeta _attemptsMeta =
      const VerificationMeta('attempts');
  @override
  late final GeneratedColumn<int> attempts = GeneratedColumn<int>(
      'attempts', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _lastErrorMeta =
      const VerificationMeta('lastError');
  @override
  late final GeneratedColumn<String> lastError = GeneratedColumn<String>(
      'last_error', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<int> createdAt = GeneratedColumn<int>(
      'created_at', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  @override
  List<GeneratedColumn> get $columns => [
        id,
        targetTable,
        rowId,
        operation,
        payloadJson,
        attempts,
        lastError,
        createdAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'sync_queue';
  @override
  VerificationContext validateIntegrity(Insertable<SyncQueueData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('target_table')) {
      context.handle(
          _targetTableMeta,
          targetTable.isAcceptableOrUnknown(
              data['target_table']!, _targetTableMeta));
    } else if (isInserting) {
      context.missing(_targetTableMeta);
    }
    if (data.containsKey('row_id')) {
      context.handle(
          _rowIdMeta, rowId.isAcceptableOrUnknown(data['row_id']!, _rowIdMeta));
    } else if (isInserting) {
      context.missing(_rowIdMeta);
    }
    if (data.containsKey('operation')) {
      context.handle(_operationMeta,
          operation.isAcceptableOrUnknown(data['operation']!, _operationMeta));
    } else if (isInserting) {
      context.missing(_operationMeta);
    }
    if (data.containsKey('payload_json')) {
      context.handle(
          _payloadJsonMeta,
          payloadJson.isAcceptableOrUnknown(
              data['payload_json']!, _payloadJsonMeta));
    }
    if (data.containsKey('attempts')) {
      context.handle(_attemptsMeta,
          attempts.isAcceptableOrUnknown(data['attempts']!, _attemptsMeta));
    }
    if (data.containsKey('last_error')) {
      context.handle(_lastErrorMeta,
          lastError.isAcceptableOrUnknown(data['last_error']!, _lastErrorMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  SyncQueueData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return SyncQueueData(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id'])!,
      targetTable: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}target_table'])!,
      rowId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}row_id'])!,
      operation: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}operation'])!,
      payloadJson: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}payload_json'])!,
      attempts: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}attempts'])!,
      lastError: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}last_error']),
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}created_at'])!,
    );
  }

  @override
  $SyncQueueTable createAlias(String alias) {
    return $SyncQueueTable(attachedDatabase, alias);
  }
}

class SyncQueueData extends DataClass implements Insertable<SyncQueueData> {
  final int id;
  final String targetTable;
  final String rowId;
  final String operation;
  final String payloadJson;
  final int attempts;
  final String? lastError;
  final int createdAt;
  const SyncQueueData(
      {required this.id,
      required this.targetTable,
      required this.rowId,
      required this.operation,
      required this.payloadJson,
      required this.attempts,
      this.lastError,
      required this.createdAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['target_table'] = Variable<String>(targetTable);
    map['row_id'] = Variable<String>(rowId);
    map['operation'] = Variable<String>(operation);
    map['payload_json'] = Variable<String>(payloadJson);
    map['attempts'] = Variable<int>(attempts);
    if (!nullToAbsent || lastError != null) {
      map['last_error'] = Variable<String>(lastError);
    }
    map['created_at'] = Variable<int>(createdAt);
    return map;
  }

  SyncQueueCompanion toCompanion(bool nullToAbsent) {
    return SyncQueueCompanion(
      id: Value(id),
      targetTable: Value(targetTable),
      rowId: Value(rowId),
      operation: Value(operation),
      payloadJson: Value(payloadJson),
      attempts: Value(attempts),
      lastError: lastError == null && nullToAbsent
          ? const Value.absent()
          : Value(lastError),
      createdAt: Value(createdAt),
    );
  }

  factory SyncQueueData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return SyncQueueData(
      id: serializer.fromJson<int>(json['id']),
      targetTable: serializer.fromJson<String>(json['targetTable']),
      rowId: serializer.fromJson<String>(json['rowId']),
      operation: serializer.fromJson<String>(json['operation']),
      payloadJson: serializer.fromJson<String>(json['payloadJson']),
      attempts: serializer.fromJson<int>(json['attempts']),
      lastError: serializer.fromJson<String?>(json['lastError']),
      createdAt: serializer.fromJson<int>(json['createdAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'targetTable': serializer.toJson<String>(targetTable),
      'rowId': serializer.toJson<String>(rowId),
      'operation': serializer.toJson<String>(operation),
      'payloadJson': serializer.toJson<String>(payloadJson),
      'attempts': serializer.toJson<int>(attempts),
      'lastError': serializer.toJson<String?>(lastError),
      'createdAt': serializer.toJson<int>(createdAt),
    };
  }

  SyncQueueData copyWith(
          {int? id,
          String? targetTable,
          String? rowId,
          String? operation,
          String? payloadJson,
          int? attempts,
          Value<String?> lastError = const Value.absent(),
          int? createdAt}) =>
      SyncQueueData(
        id: id ?? this.id,
        targetTable: targetTable ?? this.targetTable,
        rowId: rowId ?? this.rowId,
        operation: operation ?? this.operation,
        payloadJson: payloadJson ?? this.payloadJson,
        attempts: attempts ?? this.attempts,
        lastError: lastError.present ? lastError.value : this.lastError,
        createdAt: createdAt ?? this.createdAt,
      );
  SyncQueueData copyWithCompanion(SyncQueueCompanion data) {
    return SyncQueueData(
      id: data.id.present ? data.id.value : this.id,
      targetTable:
          data.targetTable.present ? data.targetTable.value : this.targetTable,
      rowId: data.rowId.present ? data.rowId.value : this.rowId,
      operation: data.operation.present ? data.operation.value : this.operation,
      payloadJson:
          data.payloadJson.present ? data.payloadJson.value : this.payloadJson,
      attempts: data.attempts.present ? data.attempts.value : this.attempts,
      lastError: data.lastError.present ? data.lastError.value : this.lastError,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('SyncQueueData(')
          ..write('id: $id, ')
          ..write('targetTable: $targetTable, ')
          ..write('rowId: $rowId, ')
          ..write('operation: $operation, ')
          ..write('payloadJson: $payloadJson, ')
          ..write('attempts: $attempts, ')
          ..write('lastError: $lastError, ')
          ..write('createdAt: $createdAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, targetTable, rowId, operation,
      payloadJson, attempts, lastError, createdAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SyncQueueData &&
          other.id == this.id &&
          other.targetTable == this.targetTable &&
          other.rowId == this.rowId &&
          other.operation == this.operation &&
          other.payloadJson == this.payloadJson &&
          other.attempts == this.attempts &&
          other.lastError == this.lastError &&
          other.createdAt == this.createdAt);
}

class SyncQueueCompanion extends UpdateCompanion<SyncQueueData> {
  final Value<int> id;
  final Value<String> targetTable;
  final Value<String> rowId;
  final Value<String> operation;
  final Value<String> payloadJson;
  final Value<int> attempts;
  final Value<String?> lastError;
  final Value<int> createdAt;
  const SyncQueueCompanion({
    this.id = const Value.absent(),
    this.targetTable = const Value.absent(),
    this.rowId = const Value.absent(),
    this.operation = const Value.absent(),
    this.payloadJson = const Value.absent(),
    this.attempts = const Value.absent(),
    this.lastError = const Value.absent(),
    this.createdAt = const Value.absent(),
  });
  SyncQueueCompanion.insert({
    this.id = const Value.absent(),
    required String targetTable,
    required String rowId,
    required String operation,
    this.payloadJson = const Value.absent(),
    this.attempts = const Value.absent(),
    this.lastError = const Value.absent(),
    this.createdAt = const Value.absent(),
  })  : targetTable = Value(targetTable),
        rowId = Value(rowId),
        operation = Value(operation);
  static Insertable<SyncQueueData> custom({
    Expression<int>? id,
    Expression<String>? targetTable,
    Expression<String>? rowId,
    Expression<String>? operation,
    Expression<String>? payloadJson,
    Expression<int>? attempts,
    Expression<String>? lastError,
    Expression<int>? createdAt,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (targetTable != null) 'target_table': targetTable,
      if (rowId != null) 'row_id': rowId,
      if (operation != null) 'operation': operation,
      if (payloadJson != null) 'payload_json': payloadJson,
      if (attempts != null) 'attempts': attempts,
      if (lastError != null) 'last_error': lastError,
      if (createdAt != null) 'created_at': createdAt,
    });
  }

  SyncQueueCompanion copyWith(
      {Value<int>? id,
      Value<String>? targetTable,
      Value<String>? rowId,
      Value<String>? operation,
      Value<String>? payloadJson,
      Value<int>? attempts,
      Value<String?>? lastError,
      Value<int>? createdAt}) {
    return SyncQueueCompanion(
      id: id ?? this.id,
      targetTable: targetTable ?? this.targetTable,
      rowId: rowId ?? this.rowId,
      operation: operation ?? this.operation,
      payloadJson: payloadJson ?? this.payloadJson,
      attempts: attempts ?? this.attempts,
      lastError: lastError ?? this.lastError,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (targetTable.present) {
      map['target_table'] = Variable<String>(targetTable.value);
    }
    if (rowId.present) {
      map['row_id'] = Variable<String>(rowId.value);
    }
    if (operation.present) {
      map['operation'] = Variable<String>(operation.value);
    }
    if (payloadJson.present) {
      map['payload_json'] = Variable<String>(payloadJson.value);
    }
    if (attempts.present) {
      map['attempts'] = Variable<int>(attempts.value);
    }
    if (lastError.present) {
      map['last_error'] = Variable<String>(lastError.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<int>(createdAt.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SyncQueueCompanion(')
          ..write('id: $id, ')
          ..write('targetTable: $targetTable, ')
          ..write('rowId: $rowId, ')
          ..write('operation: $operation, ')
          ..write('payloadJson: $payloadJson, ')
          ..write('attempts: $attempts, ')
          ..write('lastError: $lastError, ')
          ..write('createdAt: $createdAt')
          ..write(')'))
        .toString();
  }
}

class $SyncMetaTable extends SyncMeta
    with TableInfo<$SyncMetaTable, SyncMetaData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SyncMetaTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _keyMeta = const VerificationMeta('key');
  @override
  late final GeneratedColumn<String> key = GeneratedColumn<String>(
      'key', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _valueMeta = const VerificationMeta('value');
  @override
  late final GeneratedColumn<String> value = GeneratedColumn<String>(
      'value', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [key, value];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'sync_meta';
  @override
  VerificationContext validateIntegrity(Insertable<SyncMetaData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('key')) {
      context.handle(
          _keyMeta, key.isAcceptableOrUnknown(data['key']!, _keyMeta));
    } else if (isInserting) {
      context.missing(_keyMeta);
    }
    if (data.containsKey('value')) {
      context.handle(
          _valueMeta, value.isAcceptableOrUnknown(data['value']!, _valueMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {key};
  @override
  SyncMetaData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return SyncMetaData(
      key: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}key'])!,
      value: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}value']),
    );
  }

  @override
  $SyncMetaTable createAlias(String alias) {
    return $SyncMetaTable(attachedDatabase, alias);
  }
}

class SyncMetaData extends DataClass implements Insertable<SyncMetaData> {
  final String key;
  final String? value;
  const SyncMetaData({required this.key, this.value});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['key'] = Variable<String>(key);
    if (!nullToAbsent || value != null) {
      map['value'] = Variable<String>(value);
    }
    return map;
  }

  SyncMetaCompanion toCompanion(bool nullToAbsent) {
    return SyncMetaCompanion(
      key: Value(key),
      value:
          value == null && nullToAbsent ? const Value.absent() : Value(value),
    );
  }

  factory SyncMetaData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return SyncMetaData(
      key: serializer.fromJson<String>(json['key']),
      value: serializer.fromJson<String?>(json['value']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'key': serializer.toJson<String>(key),
      'value': serializer.toJson<String?>(value),
    };
  }

  SyncMetaData copyWith(
          {String? key, Value<String?> value = const Value.absent()}) =>
      SyncMetaData(
        key: key ?? this.key,
        value: value.present ? value.value : this.value,
      );
  SyncMetaData copyWithCompanion(SyncMetaCompanion data) {
    return SyncMetaData(
      key: data.key.present ? data.key.value : this.key,
      value: data.value.present ? data.value.value : this.value,
    );
  }

  @override
  String toString() {
    return (StringBuffer('SyncMetaData(')
          ..write('key: $key, ')
          ..write('value: $value')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(key, value);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SyncMetaData &&
          other.key == this.key &&
          other.value == this.value);
}

class SyncMetaCompanion extends UpdateCompanion<SyncMetaData> {
  final Value<String> key;
  final Value<String?> value;
  final Value<int> rowid;
  const SyncMetaCompanion({
    this.key = const Value.absent(),
    this.value = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  SyncMetaCompanion.insert({
    required String key,
    this.value = const Value.absent(),
    this.rowid = const Value.absent(),
  }) : key = Value(key);
  static Insertable<SyncMetaData> custom({
    Expression<String>? key,
    Expression<String>? value,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (key != null) 'key': key,
      if (value != null) 'value': value,
      if (rowid != null) 'rowid': rowid,
    });
  }

  SyncMetaCompanion copyWith(
      {Value<String>? key, Value<String?>? value, Value<int>? rowid}) {
    return SyncMetaCompanion(
      key: key ?? this.key,
      value: value ?? this.value,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (key.present) {
      map['key'] = Variable<String>(key.value);
    }
    if (value.present) {
      map['value'] = Variable<String>(value.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SyncMetaCompanion(')
          ..write('key: $key, ')
          ..write('value: $value, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $AppSettingsTable extends AppSettings
    with TableInfo<$AppSettingsTable, AppSetting> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $AppSettingsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _keyMeta = const VerificationMeta('key');
  @override
  late final GeneratedColumn<String> key = GeneratedColumn<String>(
      'key', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _valueMeta = const VerificationMeta('value');
  @override
  late final GeneratedColumn<String> value = GeneratedColumn<String>(
      'value', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [key, value];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'app_settings';
  @override
  VerificationContext validateIntegrity(Insertable<AppSetting> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('key')) {
      context.handle(
          _keyMeta, key.isAcceptableOrUnknown(data['key']!, _keyMeta));
    } else if (isInserting) {
      context.missing(_keyMeta);
    }
    if (data.containsKey('value')) {
      context.handle(
          _valueMeta, value.isAcceptableOrUnknown(data['value']!, _valueMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {key};
  @override
  AppSetting map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return AppSetting(
      key: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}key'])!,
      value: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}value']),
    );
  }

  @override
  $AppSettingsTable createAlias(String alias) {
    return $AppSettingsTable(attachedDatabase, alias);
  }
}

class AppSetting extends DataClass implements Insertable<AppSetting> {
  final String key;
  final String? value;
  const AppSetting({required this.key, this.value});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['key'] = Variable<String>(key);
    if (!nullToAbsent || value != null) {
      map['value'] = Variable<String>(value);
    }
    return map;
  }

  AppSettingsCompanion toCompanion(bool nullToAbsent) {
    return AppSettingsCompanion(
      key: Value(key),
      value:
          value == null && nullToAbsent ? const Value.absent() : Value(value),
    );
  }

  factory AppSetting.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return AppSetting(
      key: serializer.fromJson<String>(json['key']),
      value: serializer.fromJson<String?>(json['value']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'key': serializer.toJson<String>(key),
      'value': serializer.toJson<String?>(value),
    };
  }

  AppSetting copyWith(
          {String? key, Value<String?> value = const Value.absent()}) =>
      AppSetting(
        key: key ?? this.key,
        value: value.present ? value.value : this.value,
      );
  AppSetting copyWithCompanion(AppSettingsCompanion data) {
    return AppSetting(
      key: data.key.present ? data.key.value : this.key,
      value: data.value.present ? data.value.value : this.value,
    );
  }

  @override
  String toString() {
    return (StringBuffer('AppSetting(')
          ..write('key: $key, ')
          ..write('value: $value')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(key, value);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is AppSetting &&
          other.key == this.key &&
          other.value == this.value);
}

class AppSettingsCompanion extends UpdateCompanion<AppSetting> {
  final Value<String> key;
  final Value<String?> value;
  final Value<int> rowid;
  const AppSettingsCompanion({
    this.key = const Value.absent(),
    this.value = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  AppSettingsCompanion.insert({
    required String key,
    this.value = const Value.absent(),
    this.rowid = const Value.absent(),
  }) : key = Value(key);
  static Insertable<AppSetting> custom({
    Expression<String>? key,
    Expression<String>? value,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (key != null) 'key': key,
      if (value != null) 'value': value,
      if (rowid != null) 'rowid': rowid,
    });
  }

  AppSettingsCompanion copyWith(
      {Value<String>? key, Value<String?>? value, Value<int>? rowid}) {
    return AppSettingsCompanion(
      key: key ?? this.key,
      value: value ?? this.value,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (key.present) {
      map['key'] = Variable<String>(key.value);
    }
    if (value.present) {
      map['value'] = Variable<String>(value.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('AppSettingsCompanion(')
          ..write('key: $key, ')
          ..write('value: $value, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $ProfilesTable profiles = $ProfilesTable(this);
  late final $WalletsTable wallets = $WalletsTable(this);
  late final $HatsTable hats = $HatsTable(this);
  late final $HatSessionsTable hatSessions = $HatSessionsTable(this);
  late final $HatPurchaseItemsTable hatPurchaseItems =
      $HatPurchaseItemsTable(this);
  late final $IncomeHatTable incomeHat = $IncomeHatTable(this);
  late final $IncomePersonalTable incomePersonal = $IncomePersonalTable(this);
  late final $CategoriesTable categories = $CategoriesTable(this);
  late final $ProductsTable products = $ProductsTable(this);
  late final $ExpensesTable expenses = $ExpensesTable(this);
  late final $MotherPaymentsTable motherPayments = $MotherPaymentsTable(this);
  late final $DpsAccountsTable dpsAccounts = $DpsAccountsTable(this);
  late final $DpsTransactionsTable dpsTransactions =
      $DpsTransactionsTable(this);
  late final $LoanPersonsTable loanPersons = $LoanPersonsTable(this);
  late final $LoansTable loans = $LoansTable(this);
  late final $LoanPaymentsTable loanPayments = $LoanPaymentsTable(this);
  late final $FuelLogsTable fuelLogs = $FuelLogsTable(this);
  late final $BikeMaintenanceTable bikeMaintenance =
      $BikeMaintenanceTable(this);
  late final $CashTalliesTable cashTallies = $CashTalliesTable(this);
  late final $CashTallyItemsTable cashTallyItems = $CashTallyItemsTable(this);
  late final $DailyClosingsTable dailyClosings = $DailyClosingsTable(this);
  late final $AttachmentsTable attachments = $AttachmentsTable(this);
  late final $MonthlyBudgetsTable monthlyBudgets = $MonthlyBudgetsTable(this);
  late final $SavingsGoalsTable savingsGoals = $SavingsGoalsTable(this);
  late final $SyncQueueTable syncQueue = $SyncQueueTable(this);
  late final $SyncMetaTable syncMeta = $SyncMetaTable(this);
  late final $AppSettingsTable appSettings = $AppSettingsTable(this);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        profiles,
        wallets,
        hats,
        hatSessions,
        hatPurchaseItems,
        incomeHat,
        incomePersonal,
        categories,
        products,
        expenses,
        motherPayments,
        dpsAccounts,
        dpsTransactions,
        loanPersons,
        loans,
        loanPayments,
        fuelLogs,
        bikeMaintenance,
        cashTallies,
        cashTallyItems,
        dailyClosings,
        attachments,
        monthlyBudgets,
        savingsGoals,
        syncQueue,
        syncMeta,
        appSettings
      ];
}

typedef $$ProfilesTableCreateCompanionBuilder = ProfilesCompanion Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  required String id,
  Value<String> displayName,
  Value<String?> phone,
  Value<int> defaultMotherAmountPaisa,
  Value<String> numberStyle,
  Value<String> themeMode,
  Value<String> dailyClosingTime,
  Value<int> rowid,
});
typedef $$ProfilesTableUpdateCompanionBuilder = ProfilesCompanion Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  Value<String> id,
  Value<String> displayName,
  Value<String?> phone,
  Value<int> defaultMotherAmountPaisa,
  Value<String> numberStyle,
  Value<String> themeMode,
  Value<String> dailyClosingTime,
  Value<int> rowid,
});

class $$ProfilesTableFilterComposer
    extends Composer<_$AppDatabase, $ProfilesTable> {
  $$ProfilesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get displayName => $composableBuilder(
      column: $table.displayName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get phone => $composableBuilder(
      column: $table.phone, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get defaultMotherAmountPaisa => $composableBuilder(
      column: $table.defaultMotherAmountPaisa,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get numberStyle => $composableBuilder(
      column: $table.numberStyle, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get themeMode => $composableBuilder(
      column: $table.themeMode, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get dailyClosingTime => $composableBuilder(
      column: $table.dailyClosingTime,
      builder: (column) => ColumnFilters(column));
}

class $$ProfilesTableOrderingComposer
    extends Composer<_$AppDatabase, $ProfilesTable> {
  $$ProfilesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get displayName => $composableBuilder(
      column: $table.displayName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get phone => $composableBuilder(
      column: $table.phone, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get defaultMotherAmountPaisa => $composableBuilder(
      column: $table.defaultMotherAmountPaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get numberStyle => $composableBuilder(
      column: $table.numberStyle, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get themeMode => $composableBuilder(
      column: $table.themeMode, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get dailyClosingTime => $composableBuilder(
      column: $table.dailyClosingTime,
      builder: (column) => ColumnOrderings(column));
}

class $$ProfilesTableAnnotationComposer
    extends Composer<_$AppDatabase, $ProfilesTable> {
  $$ProfilesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<String> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<String> get deletedAt =>
      $composableBuilder(column: $table.deletedAt, builder: (column) => column);

  GeneratedColumn<int> get version =>
      $composableBuilder(column: $table.version, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get displayName => $composableBuilder(
      column: $table.displayName, builder: (column) => column);

  GeneratedColumn<String> get phone =>
      $composableBuilder(column: $table.phone, builder: (column) => column);

  GeneratedColumn<int> get defaultMotherAmountPaisa => $composableBuilder(
      column: $table.defaultMotherAmountPaisa, builder: (column) => column);

  GeneratedColumn<String> get numberStyle => $composableBuilder(
      column: $table.numberStyle, builder: (column) => column);

  GeneratedColumn<String> get themeMode =>
      $composableBuilder(column: $table.themeMode, builder: (column) => column);

  GeneratedColumn<String> get dailyClosingTime => $composableBuilder(
      column: $table.dailyClosingTime, builder: (column) => column);
}

class $$ProfilesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ProfilesTable,
    Profile,
    $$ProfilesTableFilterComposer,
    $$ProfilesTableOrderingComposer,
    $$ProfilesTableAnnotationComposer,
    $$ProfilesTableCreateCompanionBuilder,
    $$ProfilesTableUpdateCompanionBuilder,
    (Profile, BaseReferences<_$AppDatabase, $ProfilesTable, Profile>),
    Profile,
    PrefetchHooks Function()> {
  $$ProfilesTableTableManager(_$AppDatabase db, $ProfilesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$ProfilesTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$ProfilesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$ProfilesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<String> id = const Value.absent(),
            Value<String> displayName = const Value.absent(),
            Value<String?> phone = const Value.absent(),
            Value<int> defaultMotherAmountPaisa = const Value.absent(),
            Value<String> numberStyle = const Value.absent(),
            Value<String> themeMode = const Value.absent(),
            Value<String> dailyClosingTime = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ProfilesCompanion(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            displayName: displayName,
            phone: phone,
            defaultMotherAmountPaisa: defaultMotherAmountPaisa,
            numberStyle: numberStyle,
            themeMode: themeMode,
            dailyClosingTime: dailyClosingTime,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            required String id,
            Value<String> displayName = const Value.absent(),
            Value<String?> phone = const Value.absent(),
            Value<int> defaultMotherAmountPaisa = const Value.absent(),
            Value<String> numberStyle = const Value.absent(),
            Value<String> themeMode = const Value.absent(),
            Value<String> dailyClosingTime = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ProfilesCompanion.insert(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            displayName: displayName,
            phone: phone,
            defaultMotherAmountPaisa: defaultMotherAmountPaisa,
            numberStyle: numberStyle,
            themeMode: themeMode,
            dailyClosingTime: dailyClosingTime,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$ProfilesTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $ProfilesTable,
    Profile,
    $$ProfilesTableFilterComposer,
    $$ProfilesTableOrderingComposer,
    $$ProfilesTableAnnotationComposer,
    $$ProfilesTableCreateCompanionBuilder,
    $$ProfilesTableUpdateCompanionBuilder,
    (Profile, BaseReferences<_$AppDatabase, $ProfilesTable, Profile>),
    Profile,
    PrefetchHooks Function()>;
typedef $$WalletsTableCreateCompanionBuilder = WalletsCompanion Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  required String id,
  required String userId,
  required String name,
  Value<String> type,
  Value<int> openingBalancePaisa,
  Value<bool> isArchived,
  Value<int> rowid,
});
typedef $$WalletsTableUpdateCompanionBuilder = WalletsCompanion Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  Value<String> id,
  Value<String> userId,
  Value<String> name,
  Value<String> type,
  Value<int> openingBalancePaisa,
  Value<bool> isArchived,
  Value<int> rowid,
});

class $$WalletsTableFilterComposer
    extends Composer<_$AppDatabase, $WalletsTable> {
  $$WalletsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get type => $composableBuilder(
      column: $table.type, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get openingBalancePaisa => $composableBuilder(
      column: $table.openingBalancePaisa,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isArchived => $composableBuilder(
      column: $table.isArchived, builder: (column) => ColumnFilters(column));
}

class $$WalletsTableOrderingComposer
    extends Composer<_$AppDatabase, $WalletsTable> {
  $$WalletsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get type => $composableBuilder(
      column: $table.type, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get openingBalancePaisa => $composableBuilder(
      column: $table.openingBalancePaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isArchived => $composableBuilder(
      column: $table.isArchived, builder: (column) => ColumnOrderings(column));
}

class $$WalletsTableAnnotationComposer
    extends Composer<_$AppDatabase, $WalletsTable> {
  $$WalletsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<String> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<String> get deletedAt =>
      $composableBuilder(column: $table.deletedAt, builder: (column) => column);

  GeneratedColumn<int> get version =>
      $composableBuilder(column: $table.version, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);

  GeneratedColumn<String> get type =>
      $composableBuilder(column: $table.type, builder: (column) => column);

  GeneratedColumn<int> get openingBalancePaisa => $composableBuilder(
      column: $table.openingBalancePaisa, builder: (column) => column);

  GeneratedColumn<bool> get isArchived => $composableBuilder(
      column: $table.isArchived, builder: (column) => column);
}

class $$WalletsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $WalletsTable,
    Wallet,
    $$WalletsTableFilterComposer,
    $$WalletsTableOrderingComposer,
    $$WalletsTableAnnotationComposer,
    $$WalletsTableCreateCompanionBuilder,
    $$WalletsTableUpdateCompanionBuilder,
    (Wallet, BaseReferences<_$AppDatabase, $WalletsTable, Wallet>),
    Wallet,
    PrefetchHooks Function()> {
  $$WalletsTableTableManager(_$AppDatabase db, $WalletsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$WalletsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$WalletsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$WalletsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<String> id = const Value.absent(),
            Value<String> userId = const Value.absent(),
            Value<String> name = const Value.absent(),
            Value<String> type = const Value.absent(),
            Value<int> openingBalancePaisa = const Value.absent(),
            Value<bool> isArchived = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              WalletsCompanion(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            name: name,
            type: type,
            openingBalancePaisa: openingBalancePaisa,
            isArchived: isArchived,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            required String id,
            required String userId,
            required String name,
            Value<String> type = const Value.absent(),
            Value<int> openingBalancePaisa = const Value.absent(),
            Value<bool> isArchived = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              WalletsCompanion.insert(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            name: name,
            type: type,
            openingBalancePaisa: openingBalancePaisa,
            isArchived: isArchived,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$WalletsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $WalletsTable,
    Wallet,
    $$WalletsTableFilterComposer,
    $$WalletsTableOrderingComposer,
    $$WalletsTableAnnotationComposer,
    $$WalletsTableCreateCompanionBuilder,
    $$WalletsTableUpdateCompanionBuilder,
    (Wallet, BaseReferences<_$AppDatabase, $WalletsTable, Wallet>),
    Wallet,
    PrefetchHooks Function()>;
typedef $$HatsTableCreateCompanionBuilder = HatsCompanion Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  required String id,
  required String userId,
  required String name,
  Value<String?> location,
  Value<String> hatDays,
  Value<String> colorHex,
  Value<String> icon,
  Value<String?> defaultOwnerName,
  Value<bool> isArchived,
  Value<int> rowid,
});
typedef $$HatsTableUpdateCompanionBuilder = HatsCompanion Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  Value<String> id,
  Value<String> userId,
  Value<String> name,
  Value<String?> location,
  Value<String> hatDays,
  Value<String> colorHex,
  Value<String> icon,
  Value<String?> defaultOwnerName,
  Value<bool> isArchived,
  Value<int> rowid,
});

class $$HatsTableFilterComposer extends Composer<_$AppDatabase, $HatsTable> {
  $$HatsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get location => $composableBuilder(
      column: $table.location, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get hatDays => $composableBuilder(
      column: $table.hatDays, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get colorHex => $composableBuilder(
      column: $table.colorHex, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get icon => $composableBuilder(
      column: $table.icon, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get defaultOwnerName => $composableBuilder(
      column: $table.defaultOwnerName,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isArchived => $composableBuilder(
      column: $table.isArchived, builder: (column) => ColumnFilters(column));
}

class $$HatsTableOrderingComposer extends Composer<_$AppDatabase, $HatsTable> {
  $$HatsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get location => $composableBuilder(
      column: $table.location, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get hatDays => $composableBuilder(
      column: $table.hatDays, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get colorHex => $composableBuilder(
      column: $table.colorHex, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get icon => $composableBuilder(
      column: $table.icon, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get defaultOwnerName => $composableBuilder(
      column: $table.defaultOwnerName,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isArchived => $composableBuilder(
      column: $table.isArchived, builder: (column) => ColumnOrderings(column));
}

class $$HatsTableAnnotationComposer
    extends Composer<_$AppDatabase, $HatsTable> {
  $$HatsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<String> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<String> get deletedAt =>
      $composableBuilder(column: $table.deletedAt, builder: (column) => column);

  GeneratedColumn<int> get version =>
      $composableBuilder(column: $table.version, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);

  GeneratedColumn<String> get location =>
      $composableBuilder(column: $table.location, builder: (column) => column);

  GeneratedColumn<String> get hatDays =>
      $composableBuilder(column: $table.hatDays, builder: (column) => column);

  GeneratedColumn<String> get colorHex =>
      $composableBuilder(column: $table.colorHex, builder: (column) => column);

  GeneratedColumn<String> get icon =>
      $composableBuilder(column: $table.icon, builder: (column) => column);

  GeneratedColumn<String> get defaultOwnerName => $composableBuilder(
      column: $table.defaultOwnerName, builder: (column) => column);

  GeneratedColumn<bool> get isArchived => $composableBuilder(
      column: $table.isArchived, builder: (column) => column);
}

class $$HatsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $HatsTable,
    Hat,
    $$HatsTableFilterComposer,
    $$HatsTableOrderingComposer,
    $$HatsTableAnnotationComposer,
    $$HatsTableCreateCompanionBuilder,
    $$HatsTableUpdateCompanionBuilder,
    (Hat, BaseReferences<_$AppDatabase, $HatsTable, Hat>),
    Hat,
    PrefetchHooks Function()> {
  $$HatsTableTableManager(_$AppDatabase db, $HatsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$HatsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$HatsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$HatsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<String> id = const Value.absent(),
            Value<String> userId = const Value.absent(),
            Value<String> name = const Value.absent(),
            Value<String?> location = const Value.absent(),
            Value<String> hatDays = const Value.absent(),
            Value<String> colorHex = const Value.absent(),
            Value<String> icon = const Value.absent(),
            Value<String?> defaultOwnerName = const Value.absent(),
            Value<bool> isArchived = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              HatsCompanion(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            name: name,
            location: location,
            hatDays: hatDays,
            colorHex: colorHex,
            icon: icon,
            defaultOwnerName: defaultOwnerName,
            isArchived: isArchived,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            required String id,
            required String userId,
            required String name,
            Value<String?> location = const Value.absent(),
            Value<String> hatDays = const Value.absent(),
            Value<String> colorHex = const Value.absent(),
            Value<String> icon = const Value.absent(),
            Value<String?> defaultOwnerName = const Value.absent(),
            Value<bool> isArchived = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              HatsCompanion.insert(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            name: name,
            location: location,
            hatDays: hatDays,
            colorHex: colorHex,
            icon: icon,
            defaultOwnerName: defaultOwnerName,
            isArchived: isArchived,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$HatsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $HatsTable,
    Hat,
    $$HatsTableFilterComposer,
    $$HatsTableOrderingComposer,
    $$HatsTableAnnotationComposer,
    $$HatsTableCreateCompanionBuilder,
    $$HatsTableUpdateCompanionBuilder,
    (Hat, BaseReferences<_$AppDatabase, $HatsTable, Hat>),
    Hat,
    PrefetchHooks Function()>;
typedef $$HatSessionsTableCreateCompanionBuilder = HatSessionsCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  required String id,
  required String userId,
  required String hatId,
  required String txnDate,
  Value<String?> ownerName,
  Value<String> status,
  Value<int> openingCashPaisa,
  Value<int> ownerCashReceivedPaisa,
  Value<int> wagePaisa,
  Value<int> chotaPaisa,
  Value<int> slipChargePaisa,
  Value<int> memoChargePaisa,
  Value<int> returnedToOwnerPaisa,
  Value<int?> countedCashPaisa,
  Value<int?> expectedCashPaisa,
  Value<int?> cashDifferencePaisa,
  Value<String?> residualHolder,
  Value<String?> walletId,
  Value<String?> note,
  Value<String?> differenceNote,
  Value<int> rowid,
});
typedef $$HatSessionsTableUpdateCompanionBuilder = HatSessionsCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  Value<String> id,
  Value<String> userId,
  Value<String> hatId,
  Value<String> txnDate,
  Value<String?> ownerName,
  Value<String> status,
  Value<int> openingCashPaisa,
  Value<int> ownerCashReceivedPaisa,
  Value<int> wagePaisa,
  Value<int> chotaPaisa,
  Value<int> slipChargePaisa,
  Value<int> memoChargePaisa,
  Value<int> returnedToOwnerPaisa,
  Value<int?> countedCashPaisa,
  Value<int?> expectedCashPaisa,
  Value<int?> cashDifferencePaisa,
  Value<String?> residualHolder,
  Value<String?> walletId,
  Value<String?> note,
  Value<String?> differenceNote,
  Value<int> rowid,
});

class $$HatSessionsTableFilterComposer
    extends Composer<_$AppDatabase, $HatSessionsTable> {
  $$HatSessionsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get hatId => $composableBuilder(
      column: $table.hatId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get txnDate => $composableBuilder(
      column: $table.txnDate, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get ownerName => $composableBuilder(
      column: $table.ownerName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get openingCashPaisa => $composableBuilder(
      column: $table.openingCashPaisa,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get ownerCashReceivedPaisa => $composableBuilder(
      column: $table.ownerCashReceivedPaisa,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get wagePaisa => $composableBuilder(
      column: $table.wagePaisa, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get chotaPaisa => $composableBuilder(
      column: $table.chotaPaisa, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get slipChargePaisa => $composableBuilder(
      column: $table.slipChargePaisa,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get memoChargePaisa => $composableBuilder(
      column: $table.memoChargePaisa,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get returnedToOwnerPaisa => $composableBuilder(
      column: $table.returnedToOwnerPaisa,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get countedCashPaisa => $composableBuilder(
      column: $table.countedCashPaisa,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get expectedCashPaisa => $composableBuilder(
      column: $table.expectedCashPaisa,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get cashDifferencePaisa => $composableBuilder(
      column: $table.cashDifferencePaisa,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get residualHolder => $composableBuilder(
      column: $table.residualHolder,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get walletId => $composableBuilder(
      column: $table.walletId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get differenceNote => $composableBuilder(
      column: $table.differenceNote,
      builder: (column) => ColumnFilters(column));
}

class $$HatSessionsTableOrderingComposer
    extends Composer<_$AppDatabase, $HatSessionsTable> {
  $$HatSessionsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get hatId => $composableBuilder(
      column: $table.hatId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get txnDate => $composableBuilder(
      column: $table.txnDate, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get ownerName => $composableBuilder(
      column: $table.ownerName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get openingCashPaisa => $composableBuilder(
      column: $table.openingCashPaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get ownerCashReceivedPaisa => $composableBuilder(
      column: $table.ownerCashReceivedPaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get wagePaisa => $composableBuilder(
      column: $table.wagePaisa, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get chotaPaisa => $composableBuilder(
      column: $table.chotaPaisa, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get slipChargePaisa => $composableBuilder(
      column: $table.slipChargePaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get memoChargePaisa => $composableBuilder(
      column: $table.memoChargePaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get returnedToOwnerPaisa => $composableBuilder(
      column: $table.returnedToOwnerPaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get countedCashPaisa => $composableBuilder(
      column: $table.countedCashPaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get expectedCashPaisa => $composableBuilder(
      column: $table.expectedCashPaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get cashDifferencePaisa => $composableBuilder(
      column: $table.cashDifferencePaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get residualHolder => $composableBuilder(
      column: $table.residualHolder,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get walletId => $composableBuilder(
      column: $table.walletId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get differenceNote => $composableBuilder(
      column: $table.differenceNote,
      builder: (column) => ColumnOrderings(column));
}

class $$HatSessionsTableAnnotationComposer
    extends Composer<_$AppDatabase, $HatSessionsTable> {
  $$HatSessionsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<String> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<String> get deletedAt =>
      $composableBuilder(column: $table.deletedAt, builder: (column) => column);

  GeneratedColumn<int> get version =>
      $composableBuilder(column: $table.version, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get hatId =>
      $composableBuilder(column: $table.hatId, builder: (column) => column);

  GeneratedColumn<String> get txnDate =>
      $composableBuilder(column: $table.txnDate, builder: (column) => column);

  GeneratedColumn<String> get ownerName =>
      $composableBuilder(column: $table.ownerName, builder: (column) => column);

  GeneratedColumn<String> get status =>
      $composableBuilder(column: $table.status, builder: (column) => column);

  GeneratedColumn<int> get openingCashPaisa => $composableBuilder(
      column: $table.openingCashPaisa, builder: (column) => column);

  GeneratedColumn<int> get ownerCashReceivedPaisa => $composableBuilder(
      column: $table.ownerCashReceivedPaisa, builder: (column) => column);

  GeneratedColumn<int> get wagePaisa =>
      $composableBuilder(column: $table.wagePaisa, builder: (column) => column);

  GeneratedColumn<int> get chotaPaisa => $composableBuilder(
      column: $table.chotaPaisa, builder: (column) => column);

  GeneratedColumn<int> get slipChargePaisa => $composableBuilder(
      column: $table.slipChargePaisa, builder: (column) => column);

  GeneratedColumn<int> get memoChargePaisa => $composableBuilder(
      column: $table.memoChargePaisa, builder: (column) => column);

  GeneratedColumn<int> get returnedToOwnerPaisa => $composableBuilder(
      column: $table.returnedToOwnerPaisa, builder: (column) => column);

  GeneratedColumn<int> get countedCashPaisa => $composableBuilder(
      column: $table.countedCashPaisa, builder: (column) => column);

  GeneratedColumn<int> get expectedCashPaisa => $composableBuilder(
      column: $table.expectedCashPaisa, builder: (column) => column);

  GeneratedColumn<int> get cashDifferencePaisa => $composableBuilder(
      column: $table.cashDifferencePaisa, builder: (column) => column);

  GeneratedColumn<String> get residualHolder => $composableBuilder(
      column: $table.residualHolder, builder: (column) => column);

  GeneratedColumn<String> get walletId =>
      $composableBuilder(column: $table.walletId, builder: (column) => column);

  GeneratedColumn<String> get note =>
      $composableBuilder(column: $table.note, builder: (column) => column);

  GeneratedColumn<String> get differenceNote => $composableBuilder(
      column: $table.differenceNote, builder: (column) => column);
}

class $$HatSessionsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $HatSessionsTable,
    HatSession,
    $$HatSessionsTableFilterComposer,
    $$HatSessionsTableOrderingComposer,
    $$HatSessionsTableAnnotationComposer,
    $$HatSessionsTableCreateCompanionBuilder,
    $$HatSessionsTableUpdateCompanionBuilder,
    (HatSession, BaseReferences<_$AppDatabase, $HatSessionsTable, HatSession>),
    HatSession,
    PrefetchHooks Function()> {
  $$HatSessionsTableTableManager(_$AppDatabase db, $HatSessionsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$HatSessionsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$HatSessionsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$HatSessionsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<String> id = const Value.absent(),
            Value<String> userId = const Value.absent(),
            Value<String> hatId = const Value.absent(),
            Value<String> txnDate = const Value.absent(),
            Value<String?> ownerName = const Value.absent(),
            Value<String> status = const Value.absent(),
            Value<int> openingCashPaisa = const Value.absent(),
            Value<int> ownerCashReceivedPaisa = const Value.absent(),
            Value<int> wagePaisa = const Value.absent(),
            Value<int> chotaPaisa = const Value.absent(),
            Value<int> slipChargePaisa = const Value.absent(),
            Value<int> memoChargePaisa = const Value.absent(),
            Value<int> returnedToOwnerPaisa = const Value.absent(),
            Value<int?> countedCashPaisa = const Value.absent(),
            Value<int?> expectedCashPaisa = const Value.absent(),
            Value<int?> cashDifferencePaisa = const Value.absent(),
            Value<String?> residualHolder = const Value.absent(),
            Value<String?> walletId = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<String?> differenceNote = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              HatSessionsCompanion(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            hatId: hatId,
            txnDate: txnDate,
            ownerName: ownerName,
            status: status,
            openingCashPaisa: openingCashPaisa,
            ownerCashReceivedPaisa: ownerCashReceivedPaisa,
            wagePaisa: wagePaisa,
            chotaPaisa: chotaPaisa,
            slipChargePaisa: slipChargePaisa,
            memoChargePaisa: memoChargePaisa,
            returnedToOwnerPaisa: returnedToOwnerPaisa,
            countedCashPaisa: countedCashPaisa,
            expectedCashPaisa: expectedCashPaisa,
            cashDifferencePaisa: cashDifferencePaisa,
            residualHolder: residualHolder,
            walletId: walletId,
            note: note,
            differenceNote: differenceNote,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            required String id,
            required String userId,
            required String hatId,
            required String txnDate,
            Value<String?> ownerName = const Value.absent(),
            Value<String> status = const Value.absent(),
            Value<int> openingCashPaisa = const Value.absent(),
            Value<int> ownerCashReceivedPaisa = const Value.absent(),
            Value<int> wagePaisa = const Value.absent(),
            Value<int> chotaPaisa = const Value.absent(),
            Value<int> slipChargePaisa = const Value.absent(),
            Value<int> memoChargePaisa = const Value.absent(),
            Value<int> returnedToOwnerPaisa = const Value.absent(),
            Value<int?> countedCashPaisa = const Value.absent(),
            Value<int?> expectedCashPaisa = const Value.absent(),
            Value<int?> cashDifferencePaisa = const Value.absent(),
            Value<String?> residualHolder = const Value.absent(),
            Value<String?> walletId = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<String?> differenceNote = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              HatSessionsCompanion.insert(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            hatId: hatId,
            txnDate: txnDate,
            ownerName: ownerName,
            status: status,
            openingCashPaisa: openingCashPaisa,
            ownerCashReceivedPaisa: ownerCashReceivedPaisa,
            wagePaisa: wagePaisa,
            chotaPaisa: chotaPaisa,
            slipChargePaisa: slipChargePaisa,
            memoChargePaisa: memoChargePaisa,
            returnedToOwnerPaisa: returnedToOwnerPaisa,
            countedCashPaisa: countedCashPaisa,
            expectedCashPaisa: expectedCashPaisa,
            cashDifferencePaisa: cashDifferencePaisa,
            residualHolder: residualHolder,
            walletId: walletId,
            note: note,
            differenceNote: differenceNote,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$HatSessionsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $HatSessionsTable,
    HatSession,
    $$HatSessionsTableFilterComposer,
    $$HatSessionsTableOrderingComposer,
    $$HatSessionsTableAnnotationComposer,
    $$HatSessionsTableCreateCompanionBuilder,
    $$HatSessionsTableUpdateCompanionBuilder,
    (HatSession, BaseReferences<_$AppDatabase, $HatSessionsTable, HatSession>),
    HatSession,
    PrefetchHooks Function()>;
typedef $$HatPurchaseItemsTableCreateCompanionBuilder
    = HatPurchaseItemsCompanion Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  required String id,
  required String userId,
  required String sessionId,
  Value<String> productName,
  required double kg,
  Value<double?> grossKg,
  Value<double> deductionKg,
  required int ratePaisaPerKg,
  Value<int?> ratePaisaPerMaund,
  required int totalPaisa,
  Value<String?> sellerName,
  Value<int> paidPaisa,
  Value<String?> note,
  Value<int> rowid,
});
typedef $$HatPurchaseItemsTableUpdateCompanionBuilder
    = HatPurchaseItemsCompanion Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  Value<String> id,
  Value<String> userId,
  Value<String> sessionId,
  Value<String> productName,
  Value<double> kg,
  Value<double?> grossKg,
  Value<double> deductionKg,
  Value<int> ratePaisaPerKg,
  Value<int?> ratePaisaPerMaund,
  Value<int> totalPaisa,
  Value<String?> sellerName,
  Value<int> paidPaisa,
  Value<String?> note,
  Value<int> rowid,
});

class $$HatPurchaseItemsTableFilterComposer
    extends Composer<_$AppDatabase, $HatPurchaseItemsTable> {
  $$HatPurchaseItemsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get sessionId => $composableBuilder(
      column: $table.sessionId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get productName => $composableBuilder(
      column: $table.productName, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get kg => $composableBuilder(
      column: $table.kg, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get grossKg => $composableBuilder(
      column: $table.grossKg, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get deductionKg => $composableBuilder(
      column: $table.deductionKg, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get ratePaisaPerKg => $composableBuilder(
      column: $table.ratePaisaPerKg,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get ratePaisaPerMaund => $composableBuilder(
      column: $table.ratePaisaPerMaund,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get totalPaisa => $composableBuilder(
      column: $table.totalPaisa, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get sellerName => $composableBuilder(
      column: $table.sellerName, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get paidPaisa => $composableBuilder(
      column: $table.paidPaisa, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnFilters(column));
}

class $$HatPurchaseItemsTableOrderingComposer
    extends Composer<_$AppDatabase, $HatPurchaseItemsTable> {
  $$HatPurchaseItemsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get sessionId => $composableBuilder(
      column: $table.sessionId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get productName => $composableBuilder(
      column: $table.productName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get kg => $composableBuilder(
      column: $table.kg, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get grossKg => $composableBuilder(
      column: $table.grossKg, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get deductionKg => $composableBuilder(
      column: $table.deductionKg, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get ratePaisaPerKg => $composableBuilder(
      column: $table.ratePaisaPerKg,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get ratePaisaPerMaund => $composableBuilder(
      column: $table.ratePaisaPerMaund,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get totalPaisa => $composableBuilder(
      column: $table.totalPaisa, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get sellerName => $composableBuilder(
      column: $table.sellerName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get paidPaisa => $composableBuilder(
      column: $table.paidPaisa, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnOrderings(column));
}

class $$HatPurchaseItemsTableAnnotationComposer
    extends Composer<_$AppDatabase, $HatPurchaseItemsTable> {
  $$HatPurchaseItemsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<String> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<String> get deletedAt =>
      $composableBuilder(column: $table.deletedAt, builder: (column) => column);

  GeneratedColumn<int> get version =>
      $composableBuilder(column: $table.version, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get sessionId =>
      $composableBuilder(column: $table.sessionId, builder: (column) => column);

  GeneratedColumn<String> get productName => $composableBuilder(
      column: $table.productName, builder: (column) => column);

  GeneratedColumn<double> get kg =>
      $composableBuilder(column: $table.kg, builder: (column) => column);

  GeneratedColumn<double> get grossKg =>
      $composableBuilder(column: $table.grossKg, builder: (column) => column);

  GeneratedColumn<double> get deductionKg => $composableBuilder(
      column: $table.deductionKg, builder: (column) => column);

  GeneratedColumn<int> get ratePaisaPerKg => $composableBuilder(
      column: $table.ratePaisaPerKg, builder: (column) => column);

  GeneratedColumn<int> get ratePaisaPerMaund => $composableBuilder(
      column: $table.ratePaisaPerMaund, builder: (column) => column);

  GeneratedColumn<int> get totalPaisa => $composableBuilder(
      column: $table.totalPaisa, builder: (column) => column);

  GeneratedColumn<String> get sellerName => $composableBuilder(
      column: $table.sellerName, builder: (column) => column);

  GeneratedColumn<int> get paidPaisa =>
      $composableBuilder(column: $table.paidPaisa, builder: (column) => column);

  GeneratedColumn<String> get note =>
      $composableBuilder(column: $table.note, builder: (column) => column);
}

class $$HatPurchaseItemsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $HatPurchaseItemsTable,
    HatPurchaseItem,
    $$HatPurchaseItemsTableFilterComposer,
    $$HatPurchaseItemsTableOrderingComposer,
    $$HatPurchaseItemsTableAnnotationComposer,
    $$HatPurchaseItemsTableCreateCompanionBuilder,
    $$HatPurchaseItemsTableUpdateCompanionBuilder,
    (
      HatPurchaseItem,
      BaseReferences<_$AppDatabase, $HatPurchaseItemsTable, HatPurchaseItem>
    ),
    HatPurchaseItem,
    PrefetchHooks Function()> {
  $$HatPurchaseItemsTableTableManager(
      _$AppDatabase db, $HatPurchaseItemsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$HatPurchaseItemsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$HatPurchaseItemsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$HatPurchaseItemsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<String> id = const Value.absent(),
            Value<String> userId = const Value.absent(),
            Value<String> sessionId = const Value.absent(),
            Value<String> productName = const Value.absent(),
            Value<double> kg = const Value.absent(),
            Value<double?> grossKg = const Value.absent(),
            Value<double> deductionKg = const Value.absent(),
            Value<int> ratePaisaPerKg = const Value.absent(),
            Value<int?> ratePaisaPerMaund = const Value.absent(),
            Value<int> totalPaisa = const Value.absent(),
            Value<String?> sellerName = const Value.absent(),
            Value<int> paidPaisa = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              HatPurchaseItemsCompanion(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            sessionId: sessionId,
            productName: productName,
            kg: kg,
            grossKg: grossKg,
            deductionKg: deductionKg,
            ratePaisaPerKg: ratePaisaPerKg,
            ratePaisaPerMaund: ratePaisaPerMaund,
            totalPaisa: totalPaisa,
            sellerName: sellerName,
            paidPaisa: paidPaisa,
            note: note,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            required String id,
            required String userId,
            required String sessionId,
            Value<String> productName = const Value.absent(),
            required double kg,
            Value<double?> grossKg = const Value.absent(),
            Value<double> deductionKg = const Value.absent(),
            required int ratePaisaPerKg,
            Value<int?> ratePaisaPerMaund = const Value.absent(),
            required int totalPaisa,
            Value<String?> sellerName = const Value.absent(),
            Value<int> paidPaisa = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              HatPurchaseItemsCompanion.insert(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            sessionId: sessionId,
            productName: productName,
            kg: kg,
            grossKg: grossKg,
            deductionKg: deductionKg,
            ratePaisaPerKg: ratePaisaPerKg,
            ratePaisaPerMaund: ratePaisaPerMaund,
            totalPaisa: totalPaisa,
            sellerName: sellerName,
            paidPaisa: paidPaisa,
            note: note,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$HatPurchaseItemsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $HatPurchaseItemsTable,
    HatPurchaseItem,
    $$HatPurchaseItemsTableFilterComposer,
    $$HatPurchaseItemsTableOrderingComposer,
    $$HatPurchaseItemsTableAnnotationComposer,
    $$HatPurchaseItemsTableCreateCompanionBuilder,
    $$HatPurchaseItemsTableUpdateCompanionBuilder,
    (
      HatPurchaseItem,
      BaseReferences<_$AppDatabase, $HatPurchaseItemsTable, HatPurchaseItem>
    ),
    HatPurchaseItem,
    PrefetchHooks Function()>;
typedef $$IncomeHatTableCreateCompanionBuilder = IncomeHatCompanion Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  required String id,
  required String userId,
  Value<String?> hatId,
  Value<String?> sessionId,
  required String txnDate,
  required int amountPaisa,
  Value<String> paymentMethod,
  Value<String?> walletId,
  Value<String?> note,
  Value<int> rowid,
});
typedef $$IncomeHatTableUpdateCompanionBuilder = IncomeHatCompanion Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  Value<String> id,
  Value<String> userId,
  Value<String?> hatId,
  Value<String?> sessionId,
  Value<String> txnDate,
  Value<int> amountPaisa,
  Value<String> paymentMethod,
  Value<String?> walletId,
  Value<String?> note,
  Value<int> rowid,
});

class $$IncomeHatTableFilterComposer
    extends Composer<_$AppDatabase, $IncomeHatTable> {
  $$IncomeHatTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get hatId => $composableBuilder(
      column: $table.hatId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get sessionId => $composableBuilder(
      column: $table.sessionId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get txnDate => $composableBuilder(
      column: $table.txnDate, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get paymentMethod => $composableBuilder(
      column: $table.paymentMethod, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get walletId => $composableBuilder(
      column: $table.walletId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnFilters(column));
}

class $$IncomeHatTableOrderingComposer
    extends Composer<_$AppDatabase, $IncomeHatTable> {
  $$IncomeHatTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get hatId => $composableBuilder(
      column: $table.hatId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get sessionId => $composableBuilder(
      column: $table.sessionId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get txnDate => $composableBuilder(
      column: $table.txnDate, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get paymentMethod => $composableBuilder(
      column: $table.paymentMethod,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get walletId => $composableBuilder(
      column: $table.walletId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnOrderings(column));
}

class $$IncomeHatTableAnnotationComposer
    extends Composer<_$AppDatabase, $IncomeHatTable> {
  $$IncomeHatTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<String> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<String> get deletedAt =>
      $composableBuilder(column: $table.deletedAt, builder: (column) => column);

  GeneratedColumn<int> get version =>
      $composableBuilder(column: $table.version, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get hatId =>
      $composableBuilder(column: $table.hatId, builder: (column) => column);

  GeneratedColumn<String> get sessionId =>
      $composableBuilder(column: $table.sessionId, builder: (column) => column);

  GeneratedColumn<String> get txnDate =>
      $composableBuilder(column: $table.txnDate, builder: (column) => column);

  GeneratedColumn<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => column);

  GeneratedColumn<String> get paymentMethod => $composableBuilder(
      column: $table.paymentMethod, builder: (column) => column);

  GeneratedColumn<String> get walletId =>
      $composableBuilder(column: $table.walletId, builder: (column) => column);

  GeneratedColumn<String> get note =>
      $composableBuilder(column: $table.note, builder: (column) => column);
}

class $$IncomeHatTableTableManager extends RootTableManager<
    _$AppDatabase,
    $IncomeHatTable,
    IncomeHatData,
    $$IncomeHatTableFilterComposer,
    $$IncomeHatTableOrderingComposer,
    $$IncomeHatTableAnnotationComposer,
    $$IncomeHatTableCreateCompanionBuilder,
    $$IncomeHatTableUpdateCompanionBuilder,
    (
      IncomeHatData,
      BaseReferences<_$AppDatabase, $IncomeHatTable, IncomeHatData>
    ),
    IncomeHatData,
    PrefetchHooks Function()> {
  $$IncomeHatTableTableManager(_$AppDatabase db, $IncomeHatTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$IncomeHatTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$IncomeHatTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$IncomeHatTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<String> id = const Value.absent(),
            Value<String> userId = const Value.absent(),
            Value<String?> hatId = const Value.absent(),
            Value<String?> sessionId = const Value.absent(),
            Value<String> txnDate = const Value.absent(),
            Value<int> amountPaisa = const Value.absent(),
            Value<String> paymentMethod = const Value.absent(),
            Value<String?> walletId = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              IncomeHatCompanion(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            hatId: hatId,
            sessionId: sessionId,
            txnDate: txnDate,
            amountPaisa: amountPaisa,
            paymentMethod: paymentMethod,
            walletId: walletId,
            note: note,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            required String id,
            required String userId,
            Value<String?> hatId = const Value.absent(),
            Value<String?> sessionId = const Value.absent(),
            required String txnDate,
            required int amountPaisa,
            Value<String> paymentMethod = const Value.absent(),
            Value<String?> walletId = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              IncomeHatCompanion.insert(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            hatId: hatId,
            sessionId: sessionId,
            txnDate: txnDate,
            amountPaisa: amountPaisa,
            paymentMethod: paymentMethod,
            walletId: walletId,
            note: note,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$IncomeHatTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $IncomeHatTable,
    IncomeHatData,
    $$IncomeHatTableFilterComposer,
    $$IncomeHatTableOrderingComposer,
    $$IncomeHatTableAnnotationComposer,
    $$IncomeHatTableCreateCompanionBuilder,
    $$IncomeHatTableUpdateCompanionBuilder,
    (
      IncomeHatData,
      BaseReferences<_$AppDatabase, $IncomeHatTable, IncomeHatData>
    ),
    IncomeHatData,
    PrefetchHooks Function()>;
typedef $$IncomePersonalTableCreateCompanionBuilder = IncomePersonalCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  required String id,
  required String userId,
  required String title,
  Value<String?> category,
  required String txnDate,
  required int amountPaisa,
  Value<String> paymentMethod,
  Value<String?> walletId,
  Value<String?> note,
  Value<int> rowid,
});
typedef $$IncomePersonalTableUpdateCompanionBuilder = IncomePersonalCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  Value<String> id,
  Value<String> userId,
  Value<String> title,
  Value<String?> category,
  Value<String> txnDate,
  Value<int> amountPaisa,
  Value<String> paymentMethod,
  Value<String?> walletId,
  Value<String?> note,
  Value<int> rowid,
});

class $$IncomePersonalTableFilterComposer
    extends Composer<_$AppDatabase, $IncomePersonalTable> {
  $$IncomePersonalTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get title => $composableBuilder(
      column: $table.title, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get category => $composableBuilder(
      column: $table.category, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get txnDate => $composableBuilder(
      column: $table.txnDate, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get paymentMethod => $composableBuilder(
      column: $table.paymentMethod, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get walletId => $composableBuilder(
      column: $table.walletId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnFilters(column));
}

class $$IncomePersonalTableOrderingComposer
    extends Composer<_$AppDatabase, $IncomePersonalTable> {
  $$IncomePersonalTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get title => $composableBuilder(
      column: $table.title, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get category => $composableBuilder(
      column: $table.category, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get txnDate => $composableBuilder(
      column: $table.txnDate, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get paymentMethod => $composableBuilder(
      column: $table.paymentMethod,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get walletId => $composableBuilder(
      column: $table.walletId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnOrderings(column));
}

class $$IncomePersonalTableAnnotationComposer
    extends Composer<_$AppDatabase, $IncomePersonalTable> {
  $$IncomePersonalTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<String> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<String> get deletedAt =>
      $composableBuilder(column: $table.deletedAt, builder: (column) => column);

  GeneratedColumn<int> get version =>
      $composableBuilder(column: $table.version, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get title =>
      $composableBuilder(column: $table.title, builder: (column) => column);

  GeneratedColumn<String> get category =>
      $composableBuilder(column: $table.category, builder: (column) => column);

  GeneratedColumn<String> get txnDate =>
      $composableBuilder(column: $table.txnDate, builder: (column) => column);

  GeneratedColumn<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => column);

  GeneratedColumn<String> get paymentMethod => $composableBuilder(
      column: $table.paymentMethod, builder: (column) => column);

  GeneratedColumn<String> get walletId =>
      $composableBuilder(column: $table.walletId, builder: (column) => column);

  GeneratedColumn<String> get note =>
      $composableBuilder(column: $table.note, builder: (column) => column);
}

class $$IncomePersonalTableTableManager extends RootTableManager<
    _$AppDatabase,
    $IncomePersonalTable,
    IncomePersonalData,
    $$IncomePersonalTableFilterComposer,
    $$IncomePersonalTableOrderingComposer,
    $$IncomePersonalTableAnnotationComposer,
    $$IncomePersonalTableCreateCompanionBuilder,
    $$IncomePersonalTableUpdateCompanionBuilder,
    (
      IncomePersonalData,
      BaseReferences<_$AppDatabase, $IncomePersonalTable, IncomePersonalData>
    ),
    IncomePersonalData,
    PrefetchHooks Function()> {
  $$IncomePersonalTableTableManager(
      _$AppDatabase db, $IncomePersonalTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$IncomePersonalTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$IncomePersonalTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$IncomePersonalTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<String> id = const Value.absent(),
            Value<String> userId = const Value.absent(),
            Value<String> title = const Value.absent(),
            Value<String?> category = const Value.absent(),
            Value<String> txnDate = const Value.absent(),
            Value<int> amountPaisa = const Value.absent(),
            Value<String> paymentMethod = const Value.absent(),
            Value<String?> walletId = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              IncomePersonalCompanion(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            title: title,
            category: category,
            txnDate: txnDate,
            amountPaisa: amountPaisa,
            paymentMethod: paymentMethod,
            walletId: walletId,
            note: note,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            required String id,
            required String userId,
            required String title,
            Value<String?> category = const Value.absent(),
            required String txnDate,
            required int amountPaisa,
            Value<String> paymentMethod = const Value.absent(),
            Value<String?> walletId = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              IncomePersonalCompanion.insert(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            title: title,
            category: category,
            txnDate: txnDate,
            amountPaisa: amountPaisa,
            paymentMethod: paymentMethod,
            walletId: walletId,
            note: note,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$IncomePersonalTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $IncomePersonalTable,
    IncomePersonalData,
    $$IncomePersonalTableFilterComposer,
    $$IncomePersonalTableOrderingComposer,
    $$IncomePersonalTableAnnotationComposer,
    $$IncomePersonalTableCreateCompanionBuilder,
    $$IncomePersonalTableUpdateCompanionBuilder,
    (
      IncomePersonalData,
      BaseReferences<_$AppDatabase, $IncomePersonalTable, IncomePersonalData>
    ),
    IncomePersonalData,
    PrefetchHooks Function()>;
typedef $$CategoriesTableCreateCompanionBuilder = CategoriesCompanion Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  required String id,
  required String userId,
  required String name,
  Value<String?> icon,
  Value<String?> colorHex,
  Value<String> scope,
  Value<bool> isSystem,
  Value<int> sortOrder,
  Value<int> rowid,
});
typedef $$CategoriesTableUpdateCompanionBuilder = CategoriesCompanion Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  Value<String> id,
  Value<String> userId,
  Value<String> name,
  Value<String?> icon,
  Value<String?> colorHex,
  Value<String> scope,
  Value<bool> isSystem,
  Value<int> sortOrder,
  Value<int> rowid,
});

class $$CategoriesTableFilterComposer
    extends Composer<_$AppDatabase, $CategoriesTable> {
  $$CategoriesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get icon => $composableBuilder(
      column: $table.icon, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get colorHex => $composableBuilder(
      column: $table.colorHex, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get scope => $composableBuilder(
      column: $table.scope, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isSystem => $composableBuilder(
      column: $table.isSystem, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get sortOrder => $composableBuilder(
      column: $table.sortOrder, builder: (column) => ColumnFilters(column));
}

class $$CategoriesTableOrderingComposer
    extends Composer<_$AppDatabase, $CategoriesTable> {
  $$CategoriesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get icon => $composableBuilder(
      column: $table.icon, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get colorHex => $composableBuilder(
      column: $table.colorHex, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get scope => $composableBuilder(
      column: $table.scope, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isSystem => $composableBuilder(
      column: $table.isSystem, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get sortOrder => $composableBuilder(
      column: $table.sortOrder, builder: (column) => ColumnOrderings(column));
}

class $$CategoriesTableAnnotationComposer
    extends Composer<_$AppDatabase, $CategoriesTable> {
  $$CategoriesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<String> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<String> get deletedAt =>
      $composableBuilder(column: $table.deletedAt, builder: (column) => column);

  GeneratedColumn<int> get version =>
      $composableBuilder(column: $table.version, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);

  GeneratedColumn<String> get icon =>
      $composableBuilder(column: $table.icon, builder: (column) => column);

  GeneratedColumn<String> get colorHex =>
      $composableBuilder(column: $table.colorHex, builder: (column) => column);

  GeneratedColumn<String> get scope =>
      $composableBuilder(column: $table.scope, builder: (column) => column);

  GeneratedColumn<bool> get isSystem =>
      $composableBuilder(column: $table.isSystem, builder: (column) => column);

  GeneratedColumn<int> get sortOrder =>
      $composableBuilder(column: $table.sortOrder, builder: (column) => column);
}

class $$CategoriesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $CategoriesTable,
    Category,
    $$CategoriesTableFilterComposer,
    $$CategoriesTableOrderingComposer,
    $$CategoriesTableAnnotationComposer,
    $$CategoriesTableCreateCompanionBuilder,
    $$CategoriesTableUpdateCompanionBuilder,
    (Category, BaseReferences<_$AppDatabase, $CategoriesTable, Category>),
    Category,
    PrefetchHooks Function()> {
  $$CategoriesTableTableManager(_$AppDatabase db, $CategoriesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$CategoriesTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$CategoriesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$CategoriesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<String> id = const Value.absent(),
            Value<String> userId = const Value.absent(),
            Value<String> name = const Value.absent(),
            Value<String?> icon = const Value.absent(),
            Value<String?> colorHex = const Value.absent(),
            Value<String> scope = const Value.absent(),
            Value<bool> isSystem = const Value.absent(),
            Value<int> sortOrder = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              CategoriesCompanion(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            name: name,
            icon: icon,
            colorHex: colorHex,
            scope: scope,
            isSystem: isSystem,
            sortOrder: sortOrder,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            required String id,
            required String userId,
            required String name,
            Value<String?> icon = const Value.absent(),
            Value<String?> colorHex = const Value.absent(),
            Value<String> scope = const Value.absent(),
            Value<bool> isSystem = const Value.absent(),
            Value<int> sortOrder = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              CategoriesCompanion.insert(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            name: name,
            icon: icon,
            colorHex: colorHex,
            scope: scope,
            isSystem: isSystem,
            sortOrder: sortOrder,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$CategoriesTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $CategoriesTable,
    Category,
    $$CategoriesTableFilterComposer,
    $$CategoriesTableOrderingComposer,
    $$CategoriesTableAnnotationComposer,
    $$CategoriesTableCreateCompanionBuilder,
    $$CategoriesTableUpdateCompanionBuilder,
    (Category, BaseReferences<_$AppDatabase, $CategoriesTable, Category>),
    Category,
    PrefetchHooks Function()>;
typedef $$ProductsTableCreateCompanionBuilder = ProductsCompanion Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  required String id,
  required String userId,
  required String name,
  Value<int?> lastRatePaisaPerKg,
  Value<String> unit,
  Value<int> rowid,
});
typedef $$ProductsTableUpdateCompanionBuilder = ProductsCompanion Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  Value<String> id,
  Value<String> userId,
  Value<String> name,
  Value<int?> lastRatePaisaPerKg,
  Value<String> unit,
  Value<int> rowid,
});

class $$ProductsTableFilterComposer
    extends Composer<_$AppDatabase, $ProductsTable> {
  $$ProductsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get lastRatePaisaPerKg => $composableBuilder(
      column: $table.lastRatePaisaPerKg,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get unit => $composableBuilder(
      column: $table.unit, builder: (column) => ColumnFilters(column));
}

class $$ProductsTableOrderingComposer
    extends Composer<_$AppDatabase, $ProductsTable> {
  $$ProductsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get lastRatePaisaPerKg => $composableBuilder(
      column: $table.lastRatePaisaPerKg,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get unit => $composableBuilder(
      column: $table.unit, builder: (column) => ColumnOrderings(column));
}

class $$ProductsTableAnnotationComposer
    extends Composer<_$AppDatabase, $ProductsTable> {
  $$ProductsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<String> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<String> get deletedAt =>
      $composableBuilder(column: $table.deletedAt, builder: (column) => column);

  GeneratedColumn<int> get version =>
      $composableBuilder(column: $table.version, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);

  GeneratedColumn<int> get lastRatePaisaPerKg => $composableBuilder(
      column: $table.lastRatePaisaPerKg, builder: (column) => column);

  GeneratedColumn<String> get unit =>
      $composableBuilder(column: $table.unit, builder: (column) => column);
}

class $$ProductsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ProductsTable,
    Product,
    $$ProductsTableFilterComposer,
    $$ProductsTableOrderingComposer,
    $$ProductsTableAnnotationComposer,
    $$ProductsTableCreateCompanionBuilder,
    $$ProductsTableUpdateCompanionBuilder,
    (Product, BaseReferences<_$AppDatabase, $ProductsTable, Product>),
    Product,
    PrefetchHooks Function()> {
  $$ProductsTableTableManager(_$AppDatabase db, $ProductsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$ProductsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$ProductsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$ProductsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<String> id = const Value.absent(),
            Value<String> userId = const Value.absent(),
            Value<String> name = const Value.absent(),
            Value<int?> lastRatePaisaPerKg = const Value.absent(),
            Value<String> unit = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ProductsCompanion(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            name: name,
            lastRatePaisaPerKg: lastRatePaisaPerKg,
            unit: unit,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            required String id,
            required String userId,
            required String name,
            Value<int?> lastRatePaisaPerKg = const Value.absent(),
            Value<String> unit = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ProductsCompanion.insert(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            name: name,
            lastRatePaisaPerKg: lastRatePaisaPerKg,
            unit: unit,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$ProductsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $ProductsTable,
    Product,
    $$ProductsTableFilterComposer,
    $$ProductsTableOrderingComposer,
    $$ProductsTableAnnotationComposer,
    $$ProductsTableCreateCompanionBuilder,
    $$ProductsTableUpdateCompanionBuilder,
    (Product, BaseReferences<_$AppDatabase, $ProductsTable, Product>),
    Product,
    PrefetchHooks Function()>;
typedef $$ExpensesTableCreateCompanionBuilder = ExpensesCompanion Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  required String id,
  required String userId,
  Value<String> scope,
  Value<String?> hatId,
  Value<String?> sessionId,
  Value<String?> categoryId,
  required String txnDate,
  required int amountPaisa,
  Value<String> paymentMethod,
  Value<String?> walletId,
  Value<String?> note,
  Value<int> rowid,
});
typedef $$ExpensesTableUpdateCompanionBuilder = ExpensesCompanion Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  Value<String> id,
  Value<String> userId,
  Value<String> scope,
  Value<String?> hatId,
  Value<String?> sessionId,
  Value<String?> categoryId,
  Value<String> txnDate,
  Value<int> amountPaisa,
  Value<String> paymentMethod,
  Value<String?> walletId,
  Value<String?> note,
  Value<int> rowid,
});

class $$ExpensesTableFilterComposer
    extends Composer<_$AppDatabase, $ExpensesTable> {
  $$ExpensesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get scope => $composableBuilder(
      column: $table.scope, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get hatId => $composableBuilder(
      column: $table.hatId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get sessionId => $composableBuilder(
      column: $table.sessionId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get categoryId => $composableBuilder(
      column: $table.categoryId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get txnDate => $composableBuilder(
      column: $table.txnDate, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get paymentMethod => $composableBuilder(
      column: $table.paymentMethod, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get walletId => $composableBuilder(
      column: $table.walletId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnFilters(column));
}

class $$ExpensesTableOrderingComposer
    extends Composer<_$AppDatabase, $ExpensesTable> {
  $$ExpensesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get scope => $composableBuilder(
      column: $table.scope, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get hatId => $composableBuilder(
      column: $table.hatId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get sessionId => $composableBuilder(
      column: $table.sessionId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get categoryId => $composableBuilder(
      column: $table.categoryId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get txnDate => $composableBuilder(
      column: $table.txnDate, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get paymentMethod => $composableBuilder(
      column: $table.paymentMethod,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get walletId => $composableBuilder(
      column: $table.walletId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnOrderings(column));
}

class $$ExpensesTableAnnotationComposer
    extends Composer<_$AppDatabase, $ExpensesTable> {
  $$ExpensesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<String> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<String> get deletedAt =>
      $composableBuilder(column: $table.deletedAt, builder: (column) => column);

  GeneratedColumn<int> get version =>
      $composableBuilder(column: $table.version, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get scope =>
      $composableBuilder(column: $table.scope, builder: (column) => column);

  GeneratedColumn<String> get hatId =>
      $composableBuilder(column: $table.hatId, builder: (column) => column);

  GeneratedColumn<String> get sessionId =>
      $composableBuilder(column: $table.sessionId, builder: (column) => column);

  GeneratedColumn<String> get categoryId => $composableBuilder(
      column: $table.categoryId, builder: (column) => column);

  GeneratedColumn<String> get txnDate =>
      $composableBuilder(column: $table.txnDate, builder: (column) => column);

  GeneratedColumn<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => column);

  GeneratedColumn<String> get paymentMethod => $composableBuilder(
      column: $table.paymentMethod, builder: (column) => column);

  GeneratedColumn<String> get walletId =>
      $composableBuilder(column: $table.walletId, builder: (column) => column);

  GeneratedColumn<String> get note =>
      $composableBuilder(column: $table.note, builder: (column) => column);
}

class $$ExpensesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ExpensesTable,
    Expense,
    $$ExpensesTableFilterComposer,
    $$ExpensesTableOrderingComposer,
    $$ExpensesTableAnnotationComposer,
    $$ExpensesTableCreateCompanionBuilder,
    $$ExpensesTableUpdateCompanionBuilder,
    (Expense, BaseReferences<_$AppDatabase, $ExpensesTable, Expense>),
    Expense,
    PrefetchHooks Function()> {
  $$ExpensesTableTableManager(_$AppDatabase db, $ExpensesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$ExpensesTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$ExpensesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$ExpensesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<String> id = const Value.absent(),
            Value<String> userId = const Value.absent(),
            Value<String> scope = const Value.absent(),
            Value<String?> hatId = const Value.absent(),
            Value<String?> sessionId = const Value.absent(),
            Value<String?> categoryId = const Value.absent(),
            Value<String> txnDate = const Value.absent(),
            Value<int> amountPaisa = const Value.absent(),
            Value<String> paymentMethod = const Value.absent(),
            Value<String?> walletId = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ExpensesCompanion(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            scope: scope,
            hatId: hatId,
            sessionId: sessionId,
            categoryId: categoryId,
            txnDate: txnDate,
            amountPaisa: amountPaisa,
            paymentMethod: paymentMethod,
            walletId: walletId,
            note: note,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            required String id,
            required String userId,
            Value<String> scope = const Value.absent(),
            Value<String?> hatId = const Value.absent(),
            Value<String?> sessionId = const Value.absent(),
            Value<String?> categoryId = const Value.absent(),
            required String txnDate,
            required int amountPaisa,
            Value<String> paymentMethod = const Value.absent(),
            Value<String?> walletId = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ExpensesCompanion.insert(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            scope: scope,
            hatId: hatId,
            sessionId: sessionId,
            categoryId: categoryId,
            txnDate: txnDate,
            amountPaisa: amountPaisa,
            paymentMethod: paymentMethod,
            walletId: walletId,
            note: note,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$ExpensesTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $ExpensesTable,
    Expense,
    $$ExpensesTableFilterComposer,
    $$ExpensesTableOrderingComposer,
    $$ExpensesTableAnnotationComposer,
    $$ExpensesTableCreateCompanionBuilder,
    $$ExpensesTableUpdateCompanionBuilder,
    (Expense, BaseReferences<_$AppDatabase, $ExpensesTable, Expense>),
    Expense,
    PrefetchHooks Function()>;
typedef $$MotherPaymentsTableCreateCompanionBuilder = MotherPaymentsCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  required String id,
  required String userId,
  required String txnDate,
  required int amountPaisa,
  Value<String> paymentMethod,
  Value<String?> walletId,
  Value<String?> note,
  Value<int> rowid,
});
typedef $$MotherPaymentsTableUpdateCompanionBuilder = MotherPaymentsCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  Value<String> id,
  Value<String> userId,
  Value<String> txnDate,
  Value<int> amountPaisa,
  Value<String> paymentMethod,
  Value<String?> walletId,
  Value<String?> note,
  Value<int> rowid,
});

class $$MotherPaymentsTableFilterComposer
    extends Composer<_$AppDatabase, $MotherPaymentsTable> {
  $$MotherPaymentsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get txnDate => $composableBuilder(
      column: $table.txnDate, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get paymentMethod => $composableBuilder(
      column: $table.paymentMethod, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get walletId => $composableBuilder(
      column: $table.walletId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnFilters(column));
}

class $$MotherPaymentsTableOrderingComposer
    extends Composer<_$AppDatabase, $MotherPaymentsTable> {
  $$MotherPaymentsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get txnDate => $composableBuilder(
      column: $table.txnDate, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get paymentMethod => $composableBuilder(
      column: $table.paymentMethod,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get walletId => $composableBuilder(
      column: $table.walletId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnOrderings(column));
}

class $$MotherPaymentsTableAnnotationComposer
    extends Composer<_$AppDatabase, $MotherPaymentsTable> {
  $$MotherPaymentsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<String> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<String> get deletedAt =>
      $composableBuilder(column: $table.deletedAt, builder: (column) => column);

  GeneratedColumn<int> get version =>
      $composableBuilder(column: $table.version, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get txnDate =>
      $composableBuilder(column: $table.txnDate, builder: (column) => column);

  GeneratedColumn<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => column);

  GeneratedColumn<String> get paymentMethod => $composableBuilder(
      column: $table.paymentMethod, builder: (column) => column);

  GeneratedColumn<String> get walletId =>
      $composableBuilder(column: $table.walletId, builder: (column) => column);

  GeneratedColumn<String> get note =>
      $composableBuilder(column: $table.note, builder: (column) => column);
}

class $$MotherPaymentsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $MotherPaymentsTable,
    MotherPayment,
    $$MotherPaymentsTableFilterComposer,
    $$MotherPaymentsTableOrderingComposer,
    $$MotherPaymentsTableAnnotationComposer,
    $$MotherPaymentsTableCreateCompanionBuilder,
    $$MotherPaymentsTableUpdateCompanionBuilder,
    (
      MotherPayment,
      BaseReferences<_$AppDatabase, $MotherPaymentsTable, MotherPayment>
    ),
    MotherPayment,
    PrefetchHooks Function()> {
  $$MotherPaymentsTableTableManager(
      _$AppDatabase db, $MotherPaymentsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$MotherPaymentsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$MotherPaymentsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$MotherPaymentsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<String> id = const Value.absent(),
            Value<String> userId = const Value.absent(),
            Value<String> txnDate = const Value.absent(),
            Value<int> amountPaisa = const Value.absent(),
            Value<String> paymentMethod = const Value.absent(),
            Value<String?> walletId = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              MotherPaymentsCompanion(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            txnDate: txnDate,
            amountPaisa: amountPaisa,
            paymentMethod: paymentMethod,
            walletId: walletId,
            note: note,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            required String id,
            required String userId,
            required String txnDate,
            required int amountPaisa,
            Value<String> paymentMethod = const Value.absent(),
            Value<String?> walletId = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              MotherPaymentsCompanion.insert(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            txnDate: txnDate,
            amountPaisa: amountPaisa,
            paymentMethod: paymentMethod,
            walletId: walletId,
            note: note,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$MotherPaymentsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $MotherPaymentsTable,
    MotherPayment,
    $$MotherPaymentsTableFilterComposer,
    $$MotherPaymentsTableOrderingComposer,
    $$MotherPaymentsTableAnnotationComposer,
    $$MotherPaymentsTableCreateCompanionBuilder,
    $$MotherPaymentsTableUpdateCompanionBuilder,
    (
      MotherPayment,
      BaseReferences<_$AppDatabase, $MotherPaymentsTable, MotherPayment>
    ),
    MotherPayment,
    PrefetchHooks Function()>;
typedef $$DpsAccountsTableCreateCompanionBuilder = DpsAccountsCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  required String id,
  required String userId,
  required String institutionName,
  required int monthlyInstallmentPaisa,
  Value<String> frequency,
  Value<int> dueDay,
  required String startDate,
  Value<int?> durationMonths,
  Value<int?> targetPaisa,
  Value<String> status,
  Value<String?> note,
  Value<int> rowid,
});
typedef $$DpsAccountsTableUpdateCompanionBuilder = DpsAccountsCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  Value<String> id,
  Value<String> userId,
  Value<String> institutionName,
  Value<int> monthlyInstallmentPaisa,
  Value<String> frequency,
  Value<int> dueDay,
  Value<String> startDate,
  Value<int?> durationMonths,
  Value<int?> targetPaisa,
  Value<String> status,
  Value<String?> note,
  Value<int> rowid,
});

class $$DpsAccountsTableFilterComposer
    extends Composer<_$AppDatabase, $DpsAccountsTable> {
  $$DpsAccountsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get institutionName => $composableBuilder(
      column: $table.institutionName,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get monthlyInstallmentPaisa => $composableBuilder(
      column: $table.monthlyInstallmentPaisa,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get frequency => $composableBuilder(
      column: $table.frequency, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get dueDay => $composableBuilder(
      column: $table.dueDay, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get startDate => $composableBuilder(
      column: $table.startDate, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get durationMonths => $composableBuilder(
      column: $table.durationMonths,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get targetPaisa => $composableBuilder(
      column: $table.targetPaisa, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnFilters(column));
}

class $$DpsAccountsTableOrderingComposer
    extends Composer<_$AppDatabase, $DpsAccountsTable> {
  $$DpsAccountsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get institutionName => $composableBuilder(
      column: $table.institutionName,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get monthlyInstallmentPaisa => $composableBuilder(
      column: $table.monthlyInstallmentPaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get frequency => $composableBuilder(
      column: $table.frequency, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get dueDay => $composableBuilder(
      column: $table.dueDay, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get startDate => $composableBuilder(
      column: $table.startDate, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get durationMonths => $composableBuilder(
      column: $table.durationMonths,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get targetPaisa => $composableBuilder(
      column: $table.targetPaisa, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnOrderings(column));
}

class $$DpsAccountsTableAnnotationComposer
    extends Composer<_$AppDatabase, $DpsAccountsTable> {
  $$DpsAccountsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<String> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<String> get deletedAt =>
      $composableBuilder(column: $table.deletedAt, builder: (column) => column);

  GeneratedColumn<int> get version =>
      $composableBuilder(column: $table.version, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get institutionName => $composableBuilder(
      column: $table.institutionName, builder: (column) => column);

  GeneratedColumn<int> get monthlyInstallmentPaisa => $composableBuilder(
      column: $table.monthlyInstallmentPaisa, builder: (column) => column);

  GeneratedColumn<String> get frequency =>
      $composableBuilder(column: $table.frequency, builder: (column) => column);

  GeneratedColumn<int> get dueDay =>
      $composableBuilder(column: $table.dueDay, builder: (column) => column);

  GeneratedColumn<String> get startDate =>
      $composableBuilder(column: $table.startDate, builder: (column) => column);

  GeneratedColumn<int> get durationMonths => $composableBuilder(
      column: $table.durationMonths, builder: (column) => column);

  GeneratedColumn<int> get targetPaisa => $composableBuilder(
      column: $table.targetPaisa, builder: (column) => column);

  GeneratedColumn<String> get status =>
      $composableBuilder(column: $table.status, builder: (column) => column);

  GeneratedColumn<String> get note =>
      $composableBuilder(column: $table.note, builder: (column) => column);
}

class $$DpsAccountsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $DpsAccountsTable,
    DpsAccount,
    $$DpsAccountsTableFilterComposer,
    $$DpsAccountsTableOrderingComposer,
    $$DpsAccountsTableAnnotationComposer,
    $$DpsAccountsTableCreateCompanionBuilder,
    $$DpsAccountsTableUpdateCompanionBuilder,
    (DpsAccount, BaseReferences<_$AppDatabase, $DpsAccountsTable, DpsAccount>),
    DpsAccount,
    PrefetchHooks Function()> {
  $$DpsAccountsTableTableManager(_$AppDatabase db, $DpsAccountsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$DpsAccountsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$DpsAccountsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$DpsAccountsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<String> id = const Value.absent(),
            Value<String> userId = const Value.absent(),
            Value<String> institutionName = const Value.absent(),
            Value<int> monthlyInstallmentPaisa = const Value.absent(),
            Value<String> frequency = const Value.absent(),
            Value<int> dueDay = const Value.absent(),
            Value<String> startDate = const Value.absent(),
            Value<int?> durationMonths = const Value.absent(),
            Value<int?> targetPaisa = const Value.absent(),
            Value<String> status = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              DpsAccountsCompanion(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            institutionName: institutionName,
            monthlyInstallmentPaisa: monthlyInstallmentPaisa,
            frequency: frequency,
            dueDay: dueDay,
            startDate: startDate,
            durationMonths: durationMonths,
            targetPaisa: targetPaisa,
            status: status,
            note: note,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            required String id,
            required String userId,
            required String institutionName,
            required int monthlyInstallmentPaisa,
            Value<String> frequency = const Value.absent(),
            Value<int> dueDay = const Value.absent(),
            required String startDate,
            Value<int?> durationMonths = const Value.absent(),
            Value<int?> targetPaisa = const Value.absent(),
            Value<String> status = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              DpsAccountsCompanion.insert(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            institutionName: institutionName,
            monthlyInstallmentPaisa: monthlyInstallmentPaisa,
            frequency: frequency,
            dueDay: dueDay,
            startDate: startDate,
            durationMonths: durationMonths,
            targetPaisa: targetPaisa,
            status: status,
            note: note,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$DpsAccountsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $DpsAccountsTable,
    DpsAccount,
    $$DpsAccountsTableFilterComposer,
    $$DpsAccountsTableOrderingComposer,
    $$DpsAccountsTableAnnotationComposer,
    $$DpsAccountsTableCreateCompanionBuilder,
    $$DpsAccountsTableUpdateCompanionBuilder,
    (DpsAccount, BaseReferences<_$AppDatabase, $DpsAccountsTable, DpsAccount>),
    DpsAccount,
    PrefetchHooks Function()>;
typedef $$DpsTransactionsTableCreateCompanionBuilder = DpsTransactionsCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  required String id,
  required String userId,
  required String dpsAccountId,
  required String txnDate,
  Value<int> txnAt,
  required int amountPaisa,
  Value<String> paymentMethod,
  Value<String?> walletId,
  Value<String?> note,
  Value<int> rowid,
});
typedef $$DpsTransactionsTableUpdateCompanionBuilder = DpsTransactionsCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  Value<String> id,
  Value<String> userId,
  Value<String> dpsAccountId,
  Value<String> txnDate,
  Value<int> txnAt,
  Value<int> amountPaisa,
  Value<String> paymentMethod,
  Value<String?> walletId,
  Value<String?> note,
  Value<int> rowid,
});

class $$DpsTransactionsTableFilterComposer
    extends Composer<_$AppDatabase, $DpsTransactionsTable> {
  $$DpsTransactionsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get dpsAccountId => $composableBuilder(
      column: $table.dpsAccountId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get txnDate => $composableBuilder(
      column: $table.txnDate, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get txnAt => $composableBuilder(
      column: $table.txnAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get paymentMethod => $composableBuilder(
      column: $table.paymentMethod, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get walletId => $composableBuilder(
      column: $table.walletId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnFilters(column));
}

class $$DpsTransactionsTableOrderingComposer
    extends Composer<_$AppDatabase, $DpsTransactionsTable> {
  $$DpsTransactionsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get dpsAccountId => $composableBuilder(
      column: $table.dpsAccountId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get txnDate => $composableBuilder(
      column: $table.txnDate, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get txnAt => $composableBuilder(
      column: $table.txnAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get paymentMethod => $composableBuilder(
      column: $table.paymentMethod,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get walletId => $composableBuilder(
      column: $table.walletId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnOrderings(column));
}

class $$DpsTransactionsTableAnnotationComposer
    extends Composer<_$AppDatabase, $DpsTransactionsTable> {
  $$DpsTransactionsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<String> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<String> get deletedAt =>
      $composableBuilder(column: $table.deletedAt, builder: (column) => column);

  GeneratedColumn<int> get version =>
      $composableBuilder(column: $table.version, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get dpsAccountId => $composableBuilder(
      column: $table.dpsAccountId, builder: (column) => column);

  GeneratedColumn<String> get txnDate =>
      $composableBuilder(column: $table.txnDate, builder: (column) => column);

  GeneratedColumn<int> get txnAt =>
      $composableBuilder(column: $table.txnAt, builder: (column) => column);

  GeneratedColumn<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => column);

  GeneratedColumn<String> get paymentMethod => $composableBuilder(
      column: $table.paymentMethod, builder: (column) => column);

  GeneratedColumn<String> get walletId =>
      $composableBuilder(column: $table.walletId, builder: (column) => column);

  GeneratedColumn<String> get note =>
      $composableBuilder(column: $table.note, builder: (column) => column);
}

class $$DpsTransactionsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $DpsTransactionsTable,
    DpsTransaction,
    $$DpsTransactionsTableFilterComposer,
    $$DpsTransactionsTableOrderingComposer,
    $$DpsTransactionsTableAnnotationComposer,
    $$DpsTransactionsTableCreateCompanionBuilder,
    $$DpsTransactionsTableUpdateCompanionBuilder,
    (
      DpsTransaction,
      BaseReferences<_$AppDatabase, $DpsTransactionsTable, DpsTransaction>
    ),
    DpsTransaction,
    PrefetchHooks Function()> {
  $$DpsTransactionsTableTableManager(
      _$AppDatabase db, $DpsTransactionsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$DpsTransactionsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$DpsTransactionsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$DpsTransactionsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<String> id = const Value.absent(),
            Value<String> userId = const Value.absent(),
            Value<String> dpsAccountId = const Value.absent(),
            Value<String> txnDate = const Value.absent(),
            Value<int> txnAt = const Value.absent(),
            Value<int> amountPaisa = const Value.absent(),
            Value<String> paymentMethod = const Value.absent(),
            Value<String?> walletId = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              DpsTransactionsCompanion(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            dpsAccountId: dpsAccountId,
            txnDate: txnDate,
            txnAt: txnAt,
            amountPaisa: amountPaisa,
            paymentMethod: paymentMethod,
            walletId: walletId,
            note: note,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            required String id,
            required String userId,
            required String dpsAccountId,
            required String txnDate,
            Value<int> txnAt = const Value.absent(),
            required int amountPaisa,
            Value<String> paymentMethod = const Value.absent(),
            Value<String?> walletId = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              DpsTransactionsCompanion.insert(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            dpsAccountId: dpsAccountId,
            txnDate: txnDate,
            txnAt: txnAt,
            amountPaisa: amountPaisa,
            paymentMethod: paymentMethod,
            walletId: walletId,
            note: note,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$DpsTransactionsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $DpsTransactionsTable,
    DpsTransaction,
    $$DpsTransactionsTableFilterComposer,
    $$DpsTransactionsTableOrderingComposer,
    $$DpsTransactionsTableAnnotationComposer,
    $$DpsTransactionsTableCreateCompanionBuilder,
    $$DpsTransactionsTableUpdateCompanionBuilder,
    (
      DpsTransaction,
      BaseReferences<_$AppDatabase, $DpsTransactionsTable, DpsTransaction>
    ),
    DpsTransaction,
    PrefetchHooks Function()>;
typedef $$LoanPersonsTableCreateCompanionBuilder = LoanPersonsCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  required String id,
  required String userId,
  required String name,
  Value<String?> phone,
  Value<String?> address,
  Value<String?> avatarPath,
  Value<String?> note,
  Value<int> rowid,
});
typedef $$LoanPersonsTableUpdateCompanionBuilder = LoanPersonsCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  Value<String> id,
  Value<String> userId,
  Value<String> name,
  Value<String?> phone,
  Value<String?> address,
  Value<String?> avatarPath,
  Value<String?> note,
  Value<int> rowid,
});

class $$LoanPersonsTableFilterComposer
    extends Composer<_$AppDatabase, $LoanPersonsTable> {
  $$LoanPersonsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get phone => $composableBuilder(
      column: $table.phone, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get address => $composableBuilder(
      column: $table.address, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get avatarPath => $composableBuilder(
      column: $table.avatarPath, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnFilters(column));
}

class $$LoanPersonsTableOrderingComposer
    extends Composer<_$AppDatabase, $LoanPersonsTable> {
  $$LoanPersonsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get phone => $composableBuilder(
      column: $table.phone, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get address => $composableBuilder(
      column: $table.address, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get avatarPath => $composableBuilder(
      column: $table.avatarPath, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnOrderings(column));
}

class $$LoanPersonsTableAnnotationComposer
    extends Composer<_$AppDatabase, $LoanPersonsTable> {
  $$LoanPersonsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<String> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<String> get deletedAt =>
      $composableBuilder(column: $table.deletedAt, builder: (column) => column);

  GeneratedColumn<int> get version =>
      $composableBuilder(column: $table.version, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);

  GeneratedColumn<String> get phone =>
      $composableBuilder(column: $table.phone, builder: (column) => column);

  GeneratedColumn<String> get address =>
      $composableBuilder(column: $table.address, builder: (column) => column);

  GeneratedColumn<String> get avatarPath => $composableBuilder(
      column: $table.avatarPath, builder: (column) => column);

  GeneratedColumn<String> get note =>
      $composableBuilder(column: $table.note, builder: (column) => column);
}

class $$LoanPersonsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $LoanPersonsTable,
    LoanPerson,
    $$LoanPersonsTableFilterComposer,
    $$LoanPersonsTableOrderingComposer,
    $$LoanPersonsTableAnnotationComposer,
    $$LoanPersonsTableCreateCompanionBuilder,
    $$LoanPersonsTableUpdateCompanionBuilder,
    (LoanPerson, BaseReferences<_$AppDatabase, $LoanPersonsTable, LoanPerson>),
    LoanPerson,
    PrefetchHooks Function()> {
  $$LoanPersonsTableTableManager(_$AppDatabase db, $LoanPersonsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$LoanPersonsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$LoanPersonsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$LoanPersonsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<String> id = const Value.absent(),
            Value<String> userId = const Value.absent(),
            Value<String> name = const Value.absent(),
            Value<String?> phone = const Value.absent(),
            Value<String?> address = const Value.absent(),
            Value<String?> avatarPath = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              LoanPersonsCompanion(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            name: name,
            phone: phone,
            address: address,
            avatarPath: avatarPath,
            note: note,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            required String id,
            required String userId,
            required String name,
            Value<String?> phone = const Value.absent(),
            Value<String?> address = const Value.absent(),
            Value<String?> avatarPath = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              LoanPersonsCompanion.insert(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            name: name,
            phone: phone,
            address: address,
            avatarPath: avatarPath,
            note: note,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$LoanPersonsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $LoanPersonsTable,
    LoanPerson,
    $$LoanPersonsTableFilterComposer,
    $$LoanPersonsTableOrderingComposer,
    $$LoanPersonsTableAnnotationComposer,
    $$LoanPersonsTableCreateCompanionBuilder,
    $$LoanPersonsTableUpdateCompanionBuilder,
    (LoanPerson, BaseReferences<_$AppDatabase, $LoanPersonsTable, LoanPerson>),
    LoanPerson,
    PrefetchHooks Function()>;
typedef $$LoansTableCreateCompanionBuilder = LoansCompanion Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  required String id,
  required String userId,
  required String personId,
  Value<String> type,
  required int principalPaisa,
  required String txnDate,
  Value<String?> dueDate,
  Value<String?> walletId,
  Value<String?> note,
  Value<int> rowid,
});
typedef $$LoansTableUpdateCompanionBuilder = LoansCompanion Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  Value<String> id,
  Value<String> userId,
  Value<String> personId,
  Value<String> type,
  Value<int> principalPaisa,
  Value<String> txnDate,
  Value<String?> dueDate,
  Value<String?> walletId,
  Value<String?> note,
  Value<int> rowid,
});

class $$LoansTableFilterComposer extends Composer<_$AppDatabase, $LoansTable> {
  $$LoansTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get personId => $composableBuilder(
      column: $table.personId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get type => $composableBuilder(
      column: $table.type, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get principalPaisa => $composableBuilder(
      column: $table.principalPaisa,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get txnDate => $composableBuilder(
      column: $table.txnDate, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get dueDate => $composableBuilder(
      column: $table.dueDate, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get walletId => $composableBuilder(
      column: $table.walletId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnFilters(column));
}

class $$LoansTableOrderingComposer
    extends Composer<_$AppDatabase, $LoansTable> {
  $$LoansTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get personId => $composableBuilder(
      column: $table.personId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get type => $composableBuilder(
      column: $table.type, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get principalPaisa => $composableBuilder(
      column: $table.principalPaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get txnDate => $composableBuilder(
      column: $table.txnDate, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get dueDate => $composableBuilder(
      column: $table.dueDate, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get walletId => $composableBuilder(
      column: $table.walletId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnOrderings(column));
}

class $$LoansTableAnnotationComposer
    extends Composer<_$AppDatabase, $LoansTable> {
  $$LoansTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<String> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<String> get deletedAt =>
      $composableBuilder(column: $table.deletedAt, builder: (column) => column);

  GeneratedColumn<int> get version =>
      $composableBuilder(column: $table.version, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get personId =>
      $composableBuilder(column: $table.personId, builder: (column) => column);

  GeneratedColumn<String> get type =>
      $composableBuilder(column: $table.type, builder: (column) => column);

  GeneratedColumn<int> get principalPaisa => $composableBuilder(
      column: $table.principalPaisa, builder: (column) => column);

  GeneratedColumn<String> get txnDate =>
      $composableBuilder(column: $table.txnDate, builder: (column) => column);

  GeneratedColumn<String> get dueDate =>
      $composableBuilder(column: $table.dueDate, builder: (column) => column);

  GeneratedColumn<String> get walletId =>
      $composableBuilder(column: $table.walletId, builder: (column) => column);

  GeneratedColumn<String> get note =>
      $composableBuilder(column: $table.note, builder: (column) => column);
}

class $$LoansTableTableManager extends RootTableManager<
    _$AppDatabase,
    $LoansTable,
    Loan,
    $$LoansTableFilterComposer,
    $$LoansTableOrderingComposer,
    $$LoansTableAnnotationComposer,
    $$LoansTableCreateCompanionBuilder,
    $$LoansTableUpdateCompanionBuilder,
    (Loan, BaseReferences<_$AppDatabase, $LoansTable, Loan>),
    Loan,
    PrefetchHooks Function()> {
  $$LoansTableTableManager(_$AppDatabase db, $LoansTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$LoansTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$LoansTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$LoansTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<String> id = const Value.absent(),
            Value<String> userId = const Value.absent(),
            Value<String> personId = const Value.absent(),
            Value<String> type = const Value.absent(),
            Value<int> principalPaisa = const Value.absent(),
            Value<String> txnDate = const Value.absent(),
            Value<String?> dueDate = const Value.absent(),
            Value<String?> walletId = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              LoansCompanion(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            personId: personId,
            type: type,
            principalPaisa: principalPaisa,
            txnDate: txnDate,
            dueDate: dueDate,
            walletId: walletId,
            note: note,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            required String id,
            required String userId,
            required String personId,
            Value<String> type = const Value.absent(),
            required int principalPaisa,
            required String txnDate,
            Value<String?> dueDate = const Value.absent(),
            Value<String?> walletId = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              LoansCompanion.insert(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            personId: personId,
            type: type,
            principalPaisa: principalPaisa,
            txnDate: txnDate,
            dueDate: dueDate,
            walletId: walletId,
            note: note,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$LoansTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $LoansTable,
    Loan,
    $$LoansTableFilterComposer,
    $$LoansTableOrderingComposer,
    $$LoansTableAnnotationComposer,
    $$LoansTableCreateCompanionBuilder,
    $$LoansTableUpdateCompanionBuilder,
    (Loan, BaseReferences<_$AppDatabase, $LoansTable, Loan>),
    Loan,
    PrefetchHooks Function()>;
typedef $$LoanPaymentsTableCreateCompanionBuilder = LoanPaymentsCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  required String id,
  required String userId,
  required String loanId,
  required String txnDate,
  required int amountPaisa,
  Value<String?> walletId,
  Value<String?> note,
  Value<int> rowid,
});
typedef $$LoanPaymentsTableUpdateCompanionBuilder = LoanPaymentsCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  Value<String> id,
  Value<String> userId,
  Value<String> loanId,
  Value<String> txnDate,
  Value<int> amountPaisa,
  Value<String?> walletId,
  Value<String?> note,
  Value<int> rowid,
});

class $$LoanPaymentsTableFilterComposer
    extends Composer<_$AppDatabase, $LoanPaymentsTable> {
  $$LoanPaymentsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get loanId => $composableBuilder(
      column: $table.loanId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get txnDate => $composableBuilder(
      column: $table.txnDate, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get walletId => $composableBuilder(
      column: $table.walletId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnFilters(column));
}

class $$LoanPaymentsTableOrderingComposer
    extends Composer<_$AppDatabase, $LoanPaymentsTable> {
  $$LoanPaymentsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get loanId => $composableBuilder(
      column: $table.loanId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get txnDate => $composableBuilder(
      column: $table.txnDate, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get walletId => $composableBuilder(
      column: $table.walletId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnOrderings(column));
}

class $$LoanPaymentsTableAnnotationComposer
    extends Composer<_$AppDatabase, $LoanPaymentsTable> {
  $$LoanPaymentsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<String> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<String> get deletedAt =>
      $composableBuilder(column: $table.deletedAt, builder: (column) => column);

  GeneratedColumn<int> get version =>
      $composableBuilder(column: $table.version, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get loanId =>
      $composableBuilder(column: $table.loanId, builder: (column) => column);

  GeneratedColumn<String> get txnDate =>
      $composableBuilder(column: $table.txnDate, builder: (column) => column);

  GeneratedColumn<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => column);

  GeneratedColumn<String> get walletId =>
      $composableBuilder(column: $table.walletId, builder: (column) => column);

  GeneratedColumn<String> get note =>
      $composableBuilder(column: $table.note, builder: (column) => column);
}

class $$LoanPaymentsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $LoanPaymentsTable,
    LoanPayment,
    $$LoanPaymentsTableFilterComposer,
    $$LoanPaymentsTableOrderingComposer,
    $$LoanPaymentsTableAnnotationComposer,
    $$LoanPaymentsTableCreateCompanionBuilder,
    $$LoanPaymentsTableUpdateCompanionBuilder,
    (
      LoanPayment,
      BaseReferences<_$AppDatabase, $LoanPaymentsTable, LoanPayment>
    ),
    LoanPayment,
    PrefetchHooks Function()> {
  $$LoanPaymentsTableTableManager(_$AppDatabase db, $LoanPaymentsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$LoanPaymentsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$LoanPaymentsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$LoanPaymentsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<String> id = const Value.absent(),
            Value<String> userId = const Value.absent(),
            Value<String> loanId = const Value.absent(),
            Value<String> txnDate = const Value.absent(),
            Value<int> amountPaisa = const Value.absent(),
            Value<String?> walletId = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              LoanPaymentsCompanion(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            loanId: loanId,
            txnDate: txnDate,
            amountPaisa: amountPaisa,
            walletId: walletId,
            note: note,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            required String id,
            required String userId,
            required String loanId,
            required String txnDate,
            required int amountPaisa,
            Value<String?> walletId = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              LoanPaymentsCompanion.insert(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            loanId: loanId,
            txnDate: txnDate,
            amountPaisa: amountPaisa,
            walletId: walletId,
            note: note,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$LoanPaymentsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $LoanPaymentsTable,
    LoanPayment,
    $$LoanPaymentsTableFilterComposer,
    $$LoanPaymentsTableOrderingComposer,
    $$LoanPaymentsTableAnnotationComposer,
    $$LoanPaymentsTableCreateCompanionBuilder,
    $$LoanPaymentsTableUpdateCompanionBuilder,
    (
      LoanPayment,
      BaseReferences<_$AppDatabase, $LoanPaymentsTable, LoanPayment>
    ),
    LoanPayment,
    PrefetchHooks Function()>;
typedef $$FuelLogsTableCreateCompanionBuilder = FuelLogsCompanion Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  required String id,
  required String userId,
  required String txnDate,
  required double odometerKm,
  required int amountPaisa,
  Value<double?> litre,
  Value<int?> pricePerLitrePaisa,
  Value<bool> isFullTank,
  Value<String?> pumpName,
  Value<String?> walletId,
  Value<String?> note,
  Value<int> rowid,
});
typedef $$FuelLogsTableUpdateCompanionBuilder = FuelLogsCompanion Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  Value<String> id,
  Value<String> userId,
  Value<String> txnDate,
  Value<double> odometerKm,
  Value<int> amountPaisa,
  Value<double?> litre,
  Value<int?> pricePerLitrePaisa,
  Value<bool> isFullTank,
  Value<String?> pumpName,
  Value<String?> walletId,
  Value<String?> note,
  Value<int> rowid,
});

class $$FuelLogsTableFilterComposer
    extends Composer<_$AppDatabase, $FuelLogsTable> {
  $$FuelLogsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get txnDate => $composableBuilder(
      column: $table.txnDate, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get odometerKm => $composableBuilder(
      column: $table.odometerKm, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get litre => $composableBuilder(
      column: $table.litre, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get pricePerLitrePaisa => $composableBuilder(
      column: $table.pricePerLitrePaisa,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isFullTank => $composableBuilder(
      column: $table.isFullTank, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get pumpName => $composableBuilder(
      column: $table.pumpName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get walletId => $composableBuilder(
      column: $table.walletId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnFilters(column));
}

class $$FuelLogsTableOrderingComposer
    extends Composer<_$AppDatabase, $FuelLogsTable> {
  $$FuelLogsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get txnDate => $composableBuilder(
      column: $table.txnDate, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get odometerKm => $composableBuilder(
      column: $table.odometerKm, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get litre => $composableBuilder(
      column: $table.litre, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get pricePerLitrePaisa => $composableBuilder(
      column: $table.pricePerLitrePaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isFullTank => $composableBuilder(
      column: $table.isFullTank, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get pumpName => $composableBuilder(
      column: $table.pumpName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get walletId => $composableBuilder(
      column: $table.walletId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnOrderings(column));
}

class $$FuelLogsTableAnnotationComposer
    extends Composer<_$AppDatabase, $FuelLogsTable> {
  $$FuelLogsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<String> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<String> get deletedAt =>
      $composableBuilder(column: $table.deletedAt, builder: (column) => column);

  GeneratedColumn<int> get version =>
      $composableBuilder(column: $table.version, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get txnDate =>
      $composableBuilder(column: $table.txnDate, builder: (column) => column);

  GeneratedColumn<double> get odometerKm => $composableBuilder(
      column: $table.odometerKm, builder: (column) => column);

  GeneratedColumn<int> get amountPaisa => $composableBuilder(
      column: $table.amountPaisa, builder: (column) => column);

  GeneratedColumn<double> get litre =>
      $composableBuilder(column: $table.litre, builder: (column) => column);

  GeneratedColumn<int> get pricePerLitrePaisa => $composableBuilder(
      column: $table.pricePerLitrePaisa, builder: (column) => column);

  GeneratedColumn<bool> get isFullTank => $composableBuilder(
      column: $table.isFullTank, builder: (column) => column);

  GeneratedColumn<String> get pumpName =>
      $composableBuilder(column: $table.pumpName, builder: (column) => column);

  GeneratedColumn<String> get walletId =>
      $composableBuilder(column: $table.walletId, builder: (column) => column);

  GeneratedColumn<String> get note =>
      $composableBuilder(column: $table.note, builder: (column) => column);
}

class $$FuelLogsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $FuelLogsTable,
    FuelLog,
    $$FuelLogsTableFilterComposer,
    $$FuelLogsTableOrderingComposer,
    $$FuelLogsTableAnnotationComposer,
    $$FuelLogsTableCreateCompanionBuilder,
    $$FuelLogsTableUpdateCompanionBuilder,
    (FuelLog, BaseReferences<_$AppDatabase, $FuelLogsTable, FuelLog>),
    FuelLog,
    PrefetchHooks Function()> {
  $$FuelLogsTableTableManager(_$AppDatabase db, $FuelLogsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$FuelLogsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$FuelLogsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$FuelLogsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<String> id = const Value.absent(),
            Value<String> userId = const Value.absent(),
            Value<String> txnDate = const Value.absent(),
            Value<double> odometerKm = const Value.absent(),
            Value<int> amountPaisa = const Value.absent(),
            Value<double?> litre = const Value.absent(),
            Value<int?> pricePerLitrePaisa = const Value.absent(),
            Value<bool> isFullTank = const Value.absent(),
            Value<String?> pumpName = const Value.absent(),
            Value<String?> walletId = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              FuelLogsCompanion(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            txnDate: txnDate,
            odometerKm: odometerKm,
            amountPaisa: amountPaisa,
            litre: litre,
            pricePerLitrePaisa: pricePerLitrePaisa,
            isFullTank: isFullTank,
            pumpName: pumpName,
            walletId: walletId,
            note: note,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            required String id,
            required String userId,
            required String txnDate,
            required double odometerKm,
            required int amountPaisa,
            Value<double?> litre = const Value.absent(),
            Value<int?> pricePerLitrePaisa = const Value.absent(),
            Value<bool> isFullTank = const Value.absent(),
            Value<String?> pumpName = const Value.absent(),
            Value<String?> walletId = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              FuelLogsCompanion.insert(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            txnDate: txnDate,
            odometerKm: odometerKm,
            amountPaisa: amountPaisa,
            litre: litre,
            pricePerLitrePaisa: pricePerLitrePaisa,
            isFullTank: isFullTank,
            pumpName: pumpName,
            walletId: walletId,
            note: note,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$FuelLogsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $FuelLogsTable,
    FuelLog,
    $$FuelLogsTableFilterComposer,
    $$FuelLogsTableOrderingComposer,
    $$FuelLogsTableAnnotationComposer,
    $$FuelLogsTableCreateCompanionBuilder,
    $$FuelLogsTableUpdateCompanionBuilder,
    (FuelLog, BaseReferences<_$AppDatabase, $FuelLogsTable, FuelLog>),
    FuelLog,
    PrefetchHooks Function()>;
typedef $$BikeMaintenanceTableCreateCompanionBuilder = BikeMaintenanceCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  required String id,
  required String userId,
  required String txnDate,
  Value<String> type,
  required String itemName,
  required int costPaisa,
  Value<double?> odometerKm,
  Value<double?> nextServiceKm,
  Value<String?> nextServiceDate,
  Value<String?> walletId,
  Value<String?> note,
  Value<int> rowid,
});
typedef $$BikeMaintenanceTableUpdateCompanionBuilder = BikeMaintenanceCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  Value<String> id,
  Value<String> userId,
  Value<String> txnDate,
  Value<String> type,
  Value<String> itemName,
  Value<int> costPaisa,
  Value<double?> odometerKm,
  Value<double?> nextServiceKm,
  Value<String?> nextServiceDate,
  Value<String?> walletId,
  Value<String?> note,
  Value<int> rowid,
});

class $$BikeMaintenanceTableFilterComposer
    extends Composer<_$AppDatabase, $BikeMaintenanceTable> {
  $$BikeMaintenanceTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get txnDate => $composableBuilder(
      column: $table.txnDate, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get type => $composableBuilder(
      column: $table.type, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get itemName => $composableBuilder(
      column: $table.itemName, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get costPaisa => $composableBuilder(
      column: $table.costPaisa, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get odometerKm => $composableBuilder(
      column: $table.odometerKm, builder: (column) => ColumnFilters(column));

  ColumnFilters<double> get nextServiceKm => $composableBuilder(
      column: $table.nextServiceKm, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get nextServiceDate => $composableBuilder(
      column: $table.nextServiceDate,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get walletId => $composableBuilder(
      column: $table.walletId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnFilters(column));
}

class $$BikeMaintenanceTableOrderingComposer
    extends Composer<_$AppDatabase, $BikeMaintenanceTable> {
  $$BikeMaintenanceTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get txnDate => $composableBuilder(
      column: $table.txnDate, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get type => $composableBuilder(
      column: $table.type, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get itemName => $composableBuilder(
      column: $table.itemName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get costPaisa => $composableBuilder(
      column: $table.costPaisa, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get odometerKm => $composableBuilder(
      column: $table.odometerKm, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<double> get nextServiceKm => $composableBuilder(
      column: $table.nextServiceKm,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get nextServiceDate => $composableBuilder(
      column: $table.nextServiceDate,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get walletId => $composableBuilder(
      column: $table.walletId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnOrderings(column));
}

class $$BikeMaintenanceTableAnnotationComposer
    extends Composer<_$AppDatabase, $BikeMaintenanceTable> {
  $$BikeMaintenanceTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<String> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<String> get deletedAt =>
      $composableBuilder(column: $table.deletedAt, builder: (column) => column);

  GeneratedColumn<int> get version =>
      $composableBuilder(column: $table.version, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get txnDate =>
      $composableBuilder(column: $table.txnDate, builder: (column) => column);

  GeneratedColumn<String> get type =>
      $composableBuilder(column: $table.type, builder: (column) => column);

  GeneratedColumn<String> get itemName =>
      $composableBuilder(column: $table.itemName, builder: (column) => column);

  GeneratedColumn<int> get costPaisa =>
      $composableBuilder(column: $table.costPaisa, builder: (column) => column);

  GeneratedColumn<double> get odometerKm => $composableBuilder(
      column: $table.odometerKm, builder: (column) => column);

  GeneratedColumn<double> get nextServiceKm => $composableBuilder(
      column: $table.nextServiceKm, builder: (column) => column);

  GeneratedColumn<String> get nextServiceDate => $composableBuilder(
      column: $table.nextServiceDate, builder: (column) => column);

  GeneratedColumn<String> get walletId =>
      $composableBuilder(column: $table.walletId, builder: (column) => column);

  GeneratedColumn<String> get note =>
      $composableBuilder(column: $table.note, builder: (column) => column);
}

class $$BikeMaintenanceTableTableManager extends RootTableManager<
    _$AppDatabase,
    $BikeMaintenanceTable,
    BikeMaintenanceData,
    $$BikeMaintenanceTableFilterComposer,
    $$BikeMaintenanceTableOrderingComposer,
    $$BikeMaintenanceTableAnnotationComposer,
    $$BikeMaintenanceTableCreateCompanionBuilder,
    $$BikeMaintenanceTableUpdateCompanionBuilder,
    (
      BikeMaintenanceData,
      BaseReferences<_$AppDatabase, $BikeMaintenanceTable, BikeMaintenanceData>
    ),
    BikeMaintenanceData,
    PrefetchHooks Function()> {
  $$BikeMaintenanceTableTableManager(
      _$AppDatabase db, $BikeMaintenanceTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$BikeMaintenanceTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$BikeMaintenanceTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$BikeMaintenanceTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<String> id = const Value.absent(),
            Value<String> userId = const Value.absent(),
            Value<String> txnDate = const Value.absent(),
            Value<String> type = const Value.absent(),
            Value<String> itemName = const Value.absent(),
            Value<int> costPaisa = const Value.absent(),
            Value<double?> odometerKm = const Value.absent(),
            Value<double?> nextServiceKm = const Value.absent(),
            Value<String?> nextServiceDate = const Value.absent(),
            Value<String?> walletId = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              BikeMaintenanceCompanion(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            txnDate: txnDate,
            type: type,
            itemName: itemName,
            costPaisa: costPaisa,
            odometerKm: odometerKm,
            nextServiceKm: nextServiceKm,
            nextServiceDate: nextServiceDate,
            walletId: walletId,
            note: note,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            required String id,
            required String userId,
            required String txnDate,
            Value<String> type = const Value.absent(),
            required String itemName,
            required int costPaisa,
            Value<double?> odometerKm = const Value.absent(),
            Value<double?> nextServiceKm = const Value.absent(),
            Value<String?> nextServiceDate = const Value.absent(),
            Value<String?> walletId = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              BikeMaintenanceCompanion.insert(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            txnDate: txnDate,
            type: type,
            itemName: itemName,
            costPaisa: costPaisa,
            odometerKm: odometerKm,
            nextServiceKm: nextServiceKm,
            nextServiceDate: nextServiceDate,
            walletId: walletId,
            note: note,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$BikeMaintenanceTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $BikeMaintenanceTable,
    BikeMaintenanceData,
    $$BikeMaintenanceTableFilterComposer,
    $$BikeMaintenanceTableOrderingComposer,
    $$BikeMaintenanceTableAnnotationComposer,
    $$BikeMaintenanceTableCreateCompanionBuilder,
    $$BikeMaintenanceTableUpdateCompanionBuilder,
    (
      BikeMaintenanceData,
      BaseReferences<_$AppDatabase, $BikeMaintenanceTable, BikeMaintenanceData>
    ),
    BikeMaintenanceData,
    PrefetchHooks Function()>;
typedef $$CashTalliesTableCreateCompanionBuilder = CashTalliesCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  required String id,
  required String userId,
  required String txnDate,
  Value<String?> walletId,
  Value<String?> sessionId,
  Value<int> countedTotalPaisa,
  Value<int?> expectedPaisa,
  Value<int?> differencePaisa,
  Value<String?> note,
  Value<int> rowid,
});
typedef $$CashTalliesTableUpdateCompanionBuilder = CashTalliesCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  Value<String> id,
  Value<String> userId,
  Value<String> txnDate,
  Value<String?> walletId,
  Value<String?> sessionId,
  Value<int> countedTotalPaisa,
  Value<int?> expectedPaisa,
  Value<int?> differencePaisa,
  Value<String?> note,
  Value<int> rowid,
});

class $$CashTalliesTableFilterComposer
    extends Composer<_$AppDatabase, $CashTalliesTable> {
  $$CashTalliesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get txnDate => $composableBuilder(
      column: $table.txnDate, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get walletId => $composableBuilder(
      column: $table.walletId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get sessionId => $composableBuilder(
      column: $table.sessionId, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get countedTotalPaisa => $composableBuilder(
      column: $table.countedTotalPaisa,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get expectedPaisa => $composableBuilder(
      column: $table.expectedPaisa, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get differencePaisa => $composableBuilder(
      column: $table.differencePaisa,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnFilters(column));
}

class $$CashTalliesTableOrderingComposer
    extends Composer<_$AppDatabase, $CashTalliesTable> {
  $$CashTalliesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get txnDate => $composableBuilder(
      column: $table.txnDate, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get walletId => $composableBuilder(
      column: $table.walletId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get sessionId => $composableBuilder(
      column: $table.sessionId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get countedTotalPaisa => $composableBuilder(
      column: $table.countedTotalPaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get expectedPaisa => $composableBuilder(
      column: $table.expectedPaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get differencePaisa => $composableBuilder(
      column: $table.differencePaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnOrderings(column));
}

class $$CashTalliesTableAnnotationComposer
    extends Composer<_$AppDatabase, $CashTalliesTable> {
  $$CashTalliesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<String> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<String> get deletedAt =>
      $composableBuilder(column: $table.deletedAt, builder: (column) => column);

  GeneratedColumn<int> get version =>
      $composableBuilder(column: $table.version, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get txnDate =>
      $composableBuilder(column: $table.txnDate, builder: (column) => column);

  GeneratedColumn<String> get walletId =>
      $composableBuilder(column: $table.walletId, builder: (column) => column);

  GeneratedColumn<String> get sessionId =>
      $composableBuilder(column: $table.sessionId, builder: (column) => column);

  GeneratedColumn<int> get countedTotalPaisa => $composableBuilder(
      column: $table.countedTotalPaisa, builder: (column) => column);

  GeneratedColumn<int> get expectedPaisa => $composableBuilder(
      column: $table.expectedPaisa, builder: (column) => column);

  GeneratedColumn<int> get differencePaisa => $composableBuilder(
      column: $table.differencePaisa, builder: (column) => column);

  GeneratedColumn<String> get note =>
      $composableBuilder(column: $table.note, builder: (column) => column);
}

class $$CashTalliesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $CashTalliesTable,
    CashTally,
    $$CashTalliesTableFilterComposer,
    $$CashTalliesTableOrderingComposer,
    $$CashTalliesTableAnnotationComposer,
    $$CashTalliesTableCreateCompanionBuilder,
    $$CashTalliesTableUpdateCompanionBuilder,
    (CashTally, BaseReferences<_$AppDatabase, $CashTalliesTable, CashTally>),
    CashTally,
    PrefetchHooks Function()> {
  $$CashTalliesTableTableManager(_$AppDatabase db, $CashTalliesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$CashTalliesTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$CashTalliesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$CashTalliesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<String> id = const Value.absent(),
            Value<String> userId = const Value.absent(),
            Value<String> txnDate = const Value.absent(),
            Value<String?> walletId = const Value.absent(),
            Value<String?> sessionId = const Value.absent(),
            Value<int> countedTotalPaisa = const Value.absent(),
            Value<int?> expectedPaisa = const Value.absent(),
            Value<int?> differencePaisa = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              CashTalliesCompanion(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            txnDate: txnDate,
            walletId: walletId,
            sessionId: sessionId,
            countedTotalPaisa: countedTotalPaisa,
            expectedPaisa: expectedPaisa,
            differencePaisa: differencePaisa,
            note: note,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            required String id,
            required String userId,
            required String txnDate,
            Value<String?> walletId = const Value.absent(),
            Value<String?> sessionId = const Value.absent(),
            Value<int> countedTotalPaisa = const Value.absent(),
            Value<int?> expectedPaisa = const Value.absent(),
            Value<int?> differencePaisa = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              CashTalliesCompanion.insert(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            txnDate: txnDate,
            walletId: walletId,
            sessionId: sessionId,
            countedTotalPaisa: countedTotalPaisa,
            expectedPaisa: expectedPaisa,
            differencePaisa: differencePaisa,
            note: note,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$CashTalliesTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $CashTalliesTable,
    CashTally,
    $$CashTalliesTableFilterComposer,
    $$CashTalliesTableOrderingComposer,
    $$CashTalliesTableAnnotationComposer,
    $$CashTalliesTableCreateCompanionBuilder,
    $$CashTalliesTableUpdateCompanionBuilder,
    (CashTally, BaseReferences<_$AppDatabase, $CashTalliesTable, CashTally>),
    CashTally,
    PrefetchHooks Function()>;
typedef $$CashTallyItemsTableCreateCompanionBuilder = CashTallyItemsCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  required String id,
  required String userId,
  required String tallyId,
  required int denominationPaisa,
  Value<int> quantity,
  Value<int> lineTotalPaisa,
  Value<int> rowid,
});
typedef $$CashTallyItemsTableUpdateCompanionBuilder = CashTallyItemsCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  Value<String> id,
  Value<String> userId,
  Value<String> tallyId,
  Value<int> denominationPaisa,
  Value<int> quantity,
  Value<int> lineTotalPaisa,
  Value<int> rowid,
});

class $$CashTallyItemsTableFilterComposer
    extends Composer<_$AppDatabase, $CashTallyItemsTable> {
  $$CashTallyItemsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get tallyId => $composableBuilder(
      column: $table.tallyId, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get denominationPaisa => $composableBuilder(
      column: $table.denominationPaisa,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get quantity => $composableBuilder(
      column: $table.quantity, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get lineTotalPaisa => $composableBuilder(
      column: $table.lineTotalPaisa,
      builder: (column) => ColumnFilters(column));
}

class $$CashTallyItemsTableOrderingComposer
    extends Composer<_$AppDatabase, $CashTallyItemsTable> {
  $$CashTallyItemsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get tallyId => $composableBuilder(
      column: $table.tallyId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get denominationPaisa => $composableBuilder(
      column: $table.denominationPaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get quantity => $composableBuilder(
      column: $table.quantity, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get lineTotalPaisa => $composableBuilder(
      column: $table.lineTotalPaisa,
      builder: (column) => ColumnOrderings(column));
}

class $$CashTallyItemsTableAnnotationComposer
    extends Composer<_$AppDatabase, $CashTallyItemsTable> {
  $$CashTallyItemsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<String> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<String> get deletedAt =>
      $composableBuilder(column: $table.deletedAt, builder: (column) => column);

  GeneratedColumn<int> get version =>
      $composableBuilder(column: $table.version, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get tallyId =>
      $composableBuilder(column: $table.tallyId, builder: (column) => column);

  GeneratedColumn<int> get denominationPaisa => $composableBuilder(
      column: $table.denominationPaisa, builder: (column) => column);

  GeneratedColumn<int> get quantity =>
      $composableBuilder(column: $table.quantity, builder: (column) => column);

  GeneratedColumn<int> get lineTotalPaisa => $composableBuilder(
      column: $table.lineTotalPaisa, builder: (column) => column);
}

class $$CashTallyItemsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $CashTallyItemsTable,
    CashTallyItem,
    $$CashTallyItemsTableFilterComposer,
    $$CashTallyItemsTableOrderingComposer,
    $$CashTallyItemsTableAnnotationComposer,
    $$CashTallyItemsTableCreateCompanionBuilder,
    $$CashTallyItemsTableUpdateCompanionBuilder,
    (
      CashTallyItem,
      BaseReferences<_$AppDatabase, $CashTallyItemsTable, CashTallyItem>
    ),
    CashTallyItem,
    PrefetchHooks Function()> {
  $$CashTallyItemsTableTableManager(
      _$AppDatabase db, $CashTallyItemsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$CashTallyItemsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$CashTallyItemsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$CashTallyItemsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<String> id = const Value.absent(),
            Value<String> userId = const Value.absent(),
            Value<String> tallyId = const Value.absent(),
            Value<int> denominationPaisa = const Value.absent(),
            Value<int> quantity = const Value.absent(),
            Value<int> lineTotalPaisa = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              CashTallyItemsCompanion(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            tallyId: tallyId,
            denominationPaisa: denominationPaisa,
            quantity: quantity,
            lineTotalPaisa: lineTotalPaisa,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            required String id,
            required String userId,
            required String tallyId,
            required int denominationPaisa,
            Value<int> quantity = const Value.absent(),
            Value<int> lineTotalPaisa = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              CashTallyItemsCompanion.insert(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            tallyId: tallyId,
            denominationPaisa: denominationPaisa,
            quantity: quantity,
            lineTotalPaisa: lineTotalPaisa,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$CashTallyItemsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $CashTallyItemsTable,
    CashTallyItem,
    $$CashTallyItemsTableFilterComposer,
    $$CashTallyItemsTableOrderingComposer,
    $$CashTallyItemsTableAnnotationComposer,
    $$CashTallyItemsTableCreateCompanionBuilder,
    $$CashTallyItemsTableUpdateCompanionBuilder,
    (
      CashTallyItem,
      BaseReferences<_$AppDatabase, $CashTallyItemsTable, CashTallyItem>
    ),
    CashTallyItem,
    PrefetchHooks Function()>;
typedef $$DailyClosingsTableCreateCompanionBuilder = DailyClosingsCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  required String id,
  required String userId,
  required String txnDate,
  Value<int> expectedCashPaisa,
  Value<int?> countedCashPaisa,
  Value<int?> differencePaisa,
  Value<String?> note,
  Value<int> closedAt,
  Value<int> rowid,
});
typedef $$DailyClosingsTableUpdateCompanionBuilder = DailyClosingsCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  Value<String> id,
  Value<String> userId,
  Value<String> txnDate,
  Value<int> expectedCashPaisa,
  Value<int?> countedCashPaisa,
  Value<int?> differencePaisa,
  Value<String?> note,
  Value<int> closedAt,
  Value<int> rowid,
});

class $$DailyClosingsTableFilterComposer
    extends Composer<_$AppDatabase, $DailyClosingsTable> {
  $$DailyClosingsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get txnDate => $composableBuilder(
      column: $table.txnDate, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get expectedCashPaisa => $composableBuilder(
      column: $table.expectedCashPaisa,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get countedCashPaisa => $composableBuilder(
      column: $table.countedCashPaisa,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get differencePaisa => $composableBuilder(
      column: $table.differencePaisa,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get closedAt => $composableBuilder(
      column: $table.closedAt, builder: (column) => ColumnFilters(column));
}

class $$DailyClosingsTableOrderingComposer
    extends Composer<_$AppDatabase, $DailyClosingsTable> {
  $$DailyClosingsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get txnDate => $composableBuilder(
      column: $table.txnDate, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get expectedCashPaisa => $composableBuilder(
      column: $table.expectedCashPaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get countedCashPaisa => $composableBuilder(
      column: $table.countedCashPaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get differencePaisa => $composableBuilder(
      column: $table.differencePaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get closedAt => $composableBuilder(
      column: $table.closedAt, builder: (column) => ColumnOrderings(column));
}

class $$DailyClosingsTableAnnotationComposer
    extends Composer<_$AppDatabase, $DailyClosingsTable> {
  $$DailyClosingsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<String> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<String> get deletedAt =>
      $composableBuilder(column: $table.deletedAt, builder: (column) => column);

  GeneratedColumn<int> get version =>
      $composableBuilder(column: $table.version, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get txnDate =>
      $composableBuilder(column: $table.txnDate, builder: (column) => column);

  GeneratedColumn<int> get expectedCashPaisa => $composableBuilder(
      column: $table.expectedCashPaisa, builder: (column) => column);

  GeneratedColumn<int> get countedCashPaisa => $composableBuilder(
      column: $table.countedCashPaisa, builder: (column) => column);

  GeneratedColumn<int> get differencePaisa => $composableBuilder(
      column: $table.differencePaisa, builder: (column) => column);

  GeneratedColumn<String> get note =>
      $composableBuilder(column: $table.note, builder: (column) => column);

  GeneratedColumn<int> get closedAt =>
      $composableBuilder(column: $table.closedAt, builder: (column) => column);
}

class $$DailyClosingsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $DailyClosingsTable,
    DailyClosing,
    $$DailyClosingsTableFilterComposer,
    $$DailyClosingsTableOrderingComposer,
    $$DailyClosingsTableAnnotationComposer,
    $$DailyClosingsTableCreateCompanionBuilder,
    $$DailyClosingsTableUpdateCompanionBuilder,
    (
      DailyClosing,
      BaseReferences<_$AppDatabase, $DailyClosingsTable, DailyClosing>
    ),
    DailyClosing,
    PrefetchHooks Function()> {
  $$DailyClosingsTableTableManager(_$AppDatabase db, $DailyClosingsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$DailyClosingsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$DailyClosingsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$DailyClosingsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<String> id = const Value.absent(),
            Value<String> userId = const Value.absent(),
            Value<String> txnDate = const Value.absent(),
            Value<int> expectedCashPaisa = const Value.absent(),
            Value<int?> countedCashPaisa = const Value.absent(),
            Value<int?> differencePaisa = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> closedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              DailyClosingsCompanion(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            txnDate: txnDate,
            expectedCashPaisa: expectedCashPaisa,
            countedCashPaisa: countedCashPaisa,
            differencePaisa: differencePaisa,
            note: note,
            closedAt: closedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            required String id,
            required String userId,
            required String txnDate,
            Value<int> expectedCashPaisa = const Value.absent(),
            Value<int?> countedCashPaisa = const Value.absent(),
            Value<int?> differencePaisa = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> closedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              DailyClosingsCompanion.insert(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            txnDate: txnDate,
            expectedCashPaisa: expectedCashPaisa,
            countedCashPaisa: countedCashPaisa,
            differencePaisa: differencePaisa,
            note: note,
            closedAt: closedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$DailyClosingsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $DailyClosingsTable,
    DailyClosing,
    $$DailyClosingsTableFilterComposer,
    $$DailyClosingsTableOrderingComposer,
    $$DailyClosingsTableAnnotationComposer,
    $$DailyClosingsTableCreateCompanionBuilder,
    $$DailyClosingsTableUpdateCompanionBuilder,
    (
      DailyClosing,
      BaseReferences<_$AppDatabase, $DailyClosingsTable, DailyClosing>
    ),
    DailyClosing,
    PrefetchHooks Function()>;
typedef $$AttachmentsTableCreateCompanionBuilder = AttachmentsCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  required String id,
  required String userId,
  required String ownerType,
  required String ownerId,
  required String localPath,
  Value<String?> remotePath,
  Value<String?> mime,
  Value<int?> sizeBytes,
  Value<int> rowid,
});
typedef $$AttachmentsTableUpdateCompanionBuilder = AttachmentsCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  Value<String> id,
  Value<String> userId,
  Value<String> ownerType,
  Value<String> ownerId,
  Value<String> localPath,
  Value<String?> remotePath,
  Value<String?> mime,
  Value<int?> sizeBytes,
  Value<int> rowid,
});

class $$AttachmentsTableFilterComposer
    extends Composer<_$AppDatabase, $AttachmentsTable> {
  $$AttachmentsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get ownerType => $composableBuilder(
      column: $table.ownerType, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get ownerId => $composableBuilder(
      column: $table.ownerId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get localPath => $composableBuilder(
      column: $table.localPath, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get remotePath => $composableBuilder(
      column: $table.remotePath, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get mime => $composableBuilder(
      column: $table.mime, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get sizeBytes => $composableBuilder(
      column: $table.sizeBytes, builder: (column) => ColumnFilters(column));
}

class $$AttachmentsTableOrderingComposer
    extends Composer<_$AppDatabase, $AttachmentsTable> {
  $$AttachmentsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get ownerType => $composableBuilder(
      column: $table.ownerType, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get ownerId => $composableBuilder(
      column: $table.ownerId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get localPath => $composableBuilder(
      column: $table.localPath, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get remotePath => $composableBuilder(
      column: $table.remotePath, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get mime => $composableBuilder(
      column: $table.mime, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get sizeBytes => $composableBuilder(
      column: $table.sizeBytes, builder: (column) => ColumnOrderings(column));
}

class $$AttachmentsTableAnnotationComposer
    extends Composer<_$AppDatabase, $AttachmentsTable> {
  $$AttachmentsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<String> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<String> get deletedAt =>
      $composableBuilder(column: $table.deletedAt, builder: (column) => column);

  GeneratedColumn<int> get version =>
      $composableBuilder(column: $table.version, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get ownerType =>
      $composableBuilder(column: $table.ownerType, builder: (column) => column);

  GeneratedColumn<String> get ownerId =>
      $composableBuilder(column: $table.ownerId, builder: (column) => column);

  GeneratedColumn<String> get localPath =>
      $composableBuilder(column: $table.localPath, builder: (column) => column);

  GeneratedColumn<String> get remotePath => $composableBuilder(
      column: $table.remotePath, builder: (column) => column);

  GeneratedColumn<String> get mime =>
      $composableBuilder(column: $table.mime, builder: (column) => column);

  GeneratedColumn<int> get sizeBytes =>
      $composableBuilder(column: $table.sizeBytes, builder: (column) => column);
}

class $$AttachmentsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $AttachmentsTable,
    Attachment,
    $$AttachmentsTableFilterComposer,
    $$AttachmentsTableOrderingComposer,
    $$AttachmentsTableAnnotationComposer,
    $$AttachmentsTableCreateCompanionBuilder,
    $$AttachmentsTableUpdateCompanionBuilder,
    (Attachment, BaseReferences<_$AppDatabase, $AttachmentsTable, Attachment>),
    Attachment,
    PrefetchHooks Function()> {
  $$AttachmentsTableTableManager(_$AppDatabase db, $AttachmentsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$AttachmentsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$AttachmentsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$AttachmentsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<String> id = const Value.absent(),
            Value<String> userId = const Value.absent(),
            Value<String> ownerType = const Value.absent(),
            Value<String> ownerId = const Value.absent(),
            Value<String> localPath = const Value.absent(),
            Value<String?> remotePath = const Value.absent(),
            Value<String?> mime = const Value.absent(),
            Value<int?> sizeBytes = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              AttachmentsCompanion(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            ownerType: ownerType,
            ownerId: ownerId,
            localPath: localPath,
            remotePath: remotePath,
            mime: mime,
            sizeBytes: sizeBytes,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            required String id,
            required String userId,
            required String ownerType,
            required String ownerId,
            required String localPath,
            Value<String?> remotePath = const Value.absent(),
            Value<String?> mime = const Value.absent(),
            Value<int?> sizeBytes = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              AttachmentsCompanion.insert(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            ownerType: ownerType,
            ownerId: ownerId,
            localPath: localPath,
            remotePath: remotePath,
            mime: mime,
            sizeBytes: sizeBytes,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$AttachmentsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $AttachmentsTable,
    Attachment,
    $$AttachmentsTableFilterComposer,
    $$AttachmentsTableOrderingComposer,
    $$AttachmentsTableAnnotationComposer,
    $$AttachmentsTableCreateCompanionBuilder,
    $$AttachmentsTableUpdateCompanionBuilder,
    (Attachment, BaseReferences<_$AppDatabase, $AttachmentsTable, Attachment>),
    Attachment,
    PrefetchHooks Function()>;
typedef $$MonthlyBudgetsTableCreateCompanionBuilder = MonthlyBudgetsCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  required String id,
  required String userId,
  required String category,
  required String month,
  Value<int> limitPaisa,
  Value<int> rowid,
});
typedef $$MonthlyBudgetsTableUpdateCompanionBuilder = MonthlyBudgetsCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  Value<String> id,
  Value<String> userId,
  Value<String> category,
  Value<String> month,
  Value<int> limitPaisa,
  Value<int> rowid,
});

class $$MonthlyBudgetsTableFilterComposer
    extends Composer<_$AppDatabase, $MonthlyBudgetsTable> {
  $$MonthlyBudgetsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get category => $composableBuilder(
      column: $table.category, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get month => $composableBuilder(
      column: $table.month, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get limitPaisa => $composableBuilder(
      column: $table.limitPaisa, builder: (column) => ColumnFilters(column));
}

class $$MonthlyBudgetsTableOrderingComposer
    extends Composer<_$AppDatabase, $MonthlyBudgetsTable> {
  $$MonthlyBudgetsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get category => $composableBuilder(
      column: $table.category, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get month => $composableBuilder(
      column: $table.month, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get limitPaisa => $composableBuilder(
      column: $table.limitPaisa, builder: (column) => ColumnOrderings(column));
}

class $$MonthlyBudgetsTableAnnotationComposer
    extends Composer<_$AppDatabase, $MonthlyBudgetsTable> {
  $$MonthlyBudgetsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<String> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<String> get deletedAt =>
      $composableBuilder(column: $table.deletedAt, builder: (column) => column);

  GeneratedColumn<int> get version =>
      $composableBuilder(column: $table.version, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get category =>
      $composableBuilder(column: $table.category, builder: (column) => column);

  GeneratedColumn<String> get month =>
      $composableBuilder(column: $table.month, builder: (column) => column);

  GeneratedColumn<int> get limitPaisa => $composableBuilder(
      column: $table.limitPaisa, builder: (column) => column);
}

class $$MonthlyBudgetsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $MonthlyBudgetsTable,
    MonthlyBudget,
    $$MonthlyBudgetsTableFilterComposer,
    $$MonthlyBudgetsTableOrderingComposer,
    $$MonthlyBudgetsTableAnnotationComposer,
    $$MonthlyBudgetsTableCreateCompanionBuilder,
    $$MonthlyBudgetsTableUpdateCompanionBuilder,
    (
      MonthlyBudget,
      BaseReferences<_$AppDatabase, $MonthlyBudgetsTable, MonthlyBudget>
    ),
    MonthlyBudget,
    PrefetchHooks Function()> {
  $$MonthlyBudgetsTableTableManager(
      _$AppDatabase db, $MonthlyBudgetsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$MonthlyBudgetsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$MonthlyBudgetsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$MonthlyBudgetsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<String> id = const Value.absent(),
            Value<String> userId = const Value.absent(),
            Value<String> category = const Value.absent(),
            Value<String> month = const Value.absent(),
            Value<int> limitPaisa = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              MonthlyBudgetsCompanion(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            category: category,
            month: month,
            limitPaisa: limitPaisa,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            required String id,
            required String userId,
            required String category,
            required String month,
            Value<int> limitPaisa = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              MonthlyBudgetsCompanion.insert(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            category: category,
            month: month,
            limitPaisa: limitPaisa,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$MonthlyBudgetsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $MonthlyBudgetsTable,
    MonthlyBudget,
    $$MonthlyBudgetsTableFilterComposer,
    $$MonthlyBudgetsTableOrderingComposer,
    $$MonthlyBudgetsTableAnnotationComposer,
    $$MonthlyBudgetsTableCreateCompanionBuilder,
    $$MonthlyBudgetsTableUpdateCompanionBuilder,
    (
      MonthlyBudget,
      BaseReferences<_$AppDatabase, $MonthlyBudgetsTable, MonthlyBudget>
    ),
    MonthlyBudget,
    PrefetchHooks Function()>;
typedef $$SavingsGoalsTableCreateCompanionBuilder = SavingsGoalsCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  required String id,
  required String userId,
  required String name,
  required int targetPaisa,
  Value<int> currentPaisa,
  Value<String?> deadline,
  Value<String?> note,
  Value<int> rowid,
});
typedef $$SavingsGoalsTableUpdateCompanionBuilder = SavingsGoalsCompanion
    Function({
  Value<String> createdAt,
  Value<String> updatedAt,
  Value<String?> deletedAt,
  Value<int> version,
  Value<String> syncStatus,
  Value<String> id,
  Value<String> userId,
  Value<String> name,
  Value<int> targetPaisa,
  Value<int> currentPaisa,
  Value<String?> deadline,
  Value<String?> note,
  Value<int> rowid,
});

class $$SavingsGoalsTableFilterComposer
    extends Composer<_$AppDatabase, $SavingsGoalsTable> {
  $$SavingsGoalsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get targetPaisa => $composableBuilder(
      column: $table.targetPaisa, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get currentPaisa => $composableBuilder(
      column: $table.currentPaisa, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get deadline => $composableBuilder(
      column: $table.deadline, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnFilters(column));
}

class $$SavingsGoalsTableOrderingComposer
    extends Composer<_$AppDatabase, $SavingsGoalsTable> {
  $$SavingsGoalsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deletedAt => $composableBuilder(
      column: $table.deletedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get version => $composableBuilder(
      column: $table.version, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get userId => $composableBuilder(
      column: $table.userId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get targetPaisa => $composableBuilder(
      column: $table.targetPaisa, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get currentPaisa => $composableBuilder(
      column: $table.currentPaisa,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get deadline => $composableBuilder(
      column: $table.deadline, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get note => $composableBuilder(
      column: $table.note, builder: (column) => ColumnOrderings(column));
}

class $$SavingsGoalsTableAnnotationComposer
    extends Composer<_$AppDatabase, $SavingsGoalsTable> {
  $$SavingsGoalsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<String> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);

  GeneratedColumn<String> get deletedAt =>
      $composableBuilder(column: $table.deletedAt, builder: (column) => column);

  GeneratedColumn<int> get version =>
      $composableBuilder(column: $table.version, builder: (column) => column);

  GeneratedColumn<String> get syncStatus => $composableBuilder(
      column: $table.syncStatus, builder: (column) => column);

  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);

  GeneratedColumn<int> get targetPaisa => $composableBuilder(
      column: $table.targetPaisa, builder: (column) => column);

  GeneratedColumn<int> get currentPaisa => $composableBuilder(
      column: $table.currentPaisa, builder: (column) => column);

  GeneratedColumn<String> get deadline =>
      $composableBuilder(column: $table.deadline, builder: (column) => column);

  GeneratedColumn<String> get note =>
      $composableBuilder(column: $table.note, builder: (column) => column);
}

class $$SavingsGoalsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $SavingsGoalsTable,
    SavingsGoal,
    $$SavingsGoalsTableFilterComposer,
    $$SavingsGoalsTableOrderingComposer,
    $$SavingsGoalsTableAnnotationComposer,
    $$SavingsGoalsTableCreateCompanionBuilder,
    $$SavingsGoalsTableUpdateCompanionBuilder,
    (
      SavingsGoal,
      BaseReferences<_$AppDatabase, $SavingsGoalsTable, SavingsGoal>
    ),
    SavingsGoal,
    PrefetchHooks Function()> {
  $$SavingsGoalsTableTableManager(_$AppDatabase db, $SavingsGoalsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$SavingsGoalsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$SavingsGoalsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$SavingsGoalsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            Value<String> id = const Value.absent(),
            Value<String> userId = const Value.absent(),
            Value<String> name = const Value.absent(),
            Value<int> targetPaisa = const Value.absent(),
            Value<int> currentPaisa = const Value.absent(),
            Value<String?> deadline = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SavingsGoalsCompanion(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            name: name,
            targetPaisa: targetPaisa,
            currentPaisa: currentPaisa,
            deadline: deadline,
            note: note,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            Value<String> createdAt = const Value.absent(),
            Value<String> updatedAt = const Value.absent(),
            Value<String?> deletedAt = const Value.absent(),
            Value<int> version = const Value.absent(),
            Value<String> syncStatus = const Value.absent(),
            required String id,
            required String userId,
            required String name,
            required int targetPaisa,
            Value<int> currentPaisa = const Value.absent(),
            Value<String?> deadline = const Value.absent(),
            Value<String?> note = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SavingsGoalsCompanion.insert(
            createdAt: createdAt,
            updatedAt: updatedAt,
            deletedAt: deletedAt,
            version: version,
            syncStatus: syncStatus,
            id: id,
            userId: userId,
            name: name,
            targetPaisa: targetPaisa,
            currentPaisa: currentPaisa,
            deadline: deadline,
            note: note,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$SavingsGoalsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $SavingsGoalsTable,
    SavingsGoal,
    $$SavingsGoalsTableFilterComposer,
    $$SavingsGoalsTableOrderingComposer,
    $$SavingsGoalsTableAnnotationComposer,
    $$SavingsGoalsTableCreateCompanionBuilder,
    $$SavingsGoalsTableUpdateCompanionBuilder,
    (
      SavingsGoal,
      BaseReferences<_$AppDatabase, $SavingsGoalsTable, SavingsGoal>
    ),
    SavingsGoal,
    PrefetchHooks Function()>;
typedef $$SyncQueueTableCreateCompanionBuilder = SyncQueueCompanion Function({
  Value<int> id,
  required String targetTable,
  required String rowId,
  required String operation,
  Value<String> payloadJson,
  Value<int> attempts,
  Value<String?> lastError,
  Value<int> createdAt,
});
typedef $$SyncQueueTableUpdateCompanionBuilder = SyncQueueCompanion Function({
  Value<int> id,
  Value<String> targetTable,
  Value<String> rowId,
  Value<String> operation,
  Value<String> payloadJson,
  Value<int> attempts,
  Value<String?> lastError,
  Value<int> createdAt,
});

class $$SyncQueueTableFilterComposer
    extends Composer<_$AppDatabase, $SyncQueueTable> {
  $$SyncQueueTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get targetTable => $composableBuilder(
      column: $table.targetTable, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get rowId => $composableBuilder(
      column: $table.rowId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get operation => $composableBuilder(
      column: $table.operation, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get payloadJson => $composableBuilder(
      column: $table.payloadJson, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get attempts => $composableBuilder(
      column: $table.attempts, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get lastError => $composableBuilder(
      column: $table.lastError, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));
}

class $$SyncQueueTableOrderingComposer
    extends Composer<_$AppDatabase, $SyncQueueTable> {
  $$SyncQueueTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get targetTable => $composableBuilder(
      column: $table.targetTable, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get rowId => $composableBuilder(
      column: $table.rowId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get operation => $composableBuilder(
      column: $table.operation, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get payloadJson => $composableBuilder(
      column: $table.payloadJson, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get attempts => $composableBuilder(
      column: $table.attempts, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get lastError => $composableBuilder(
      column: $table.lastError, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));
}

class $$SyncQueueTableAnnotationComposer
    extends Composer<_$AppDatabase, $SyncQueueTable> {
  $$SyncQueueTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get targetTable => $composableBuilder(
      column: $table.targetTable, builder: (column) => column);

  GeneratedColumn<String> get rowId =>
      $composableBuilder(column: $table.rowId, builder: (column) => column);

  GeneratedColumn<String> get operation =>
      $composableBuilder(column: $table.operation, builder: (column) => column);

  GeneratedColumn<String> get payloadJson => $composableBuilder(
      column: $table.payloadJson, builder: (column) => column);

  GeneratedColumn<int> get attempts =>
      $composableBuilder(column: $table.attempts, builder: (column) => column);

  GeneratedColumn<String> get lastError =>
      $composableBuilder(column: $table.lastError, builder: (column) => column);

  GeneratedColumn<int> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);
}

class $$SyncQueueTableTableManager extends RootTableManager<
    _$AppDatabase,
    $SyncQueueTable,
    SyncQueueData,
    $$SyncQueueTableFilterComposer,
    $$SyncQueueTableOrderingComposer,
    $$SyncQueueTableAnnotationComposer,
    $$SyncQueueTableCreateCompanionBuilder,
    $$SyncQueueTableUpdateCompanionBuilder,
    (
      SyncQueueData,
      BaseReferences<_$AppDatabase, $SyncQueueTable, SyncQueueData>
    ),
    SyncQueueData,
    PrefetchHooks Function()> {
  $$SyncQueueTableTableManager(_$AppDatabase db, $SyncQueueTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$SyncQueueTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$SyncQueueTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$SyncQueueTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<int> id = const Value.absent(),
            Value<String> targetTable = const Value.absent(),
            Value<String> rowId = const Value.absent(),
            Value<String> operation = const Value.absent(),
            Value<String> payloadJson = const Value.absent(),
            Value<int> attempts = const Value.absent(),
            Value<String?> lastError = const Value.absent(),
            Value<int> createdAt = const Value.absent(),
          }) =>
              SyncQueueCompanion(
            id: id,
            targetTable: targetTable,
            rowId: rowId,
            operation: operation,
            payloadJson: payloadJson,
            attempts: attempts,
            lastError: lastError,
            createdAt: createdAt,
          ),
          createCompanionCallback: ({
            Value<int> id = const Value.absent(),
            required String targetTable,
            required String rowId,
            required String operation,
            Value<String> payloadJson = const Value.absent(),
            Value<int> attempts = const Value.absent(),
            Value<String?> lastError = const Value.absent(),
            Value<int> createdAt = const Value.absent(),
          }) =>
              SyncQueueCompanion.insert(
            id: id,
            targetTable: targetTable,
            rowId: rowId,
            operation: operation,
            payloadJson: payloadJson,
            attempts: attempts,
            lastError: lastError,
            createdAt: createdAt,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$SyncQueueTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $SyncQueueTable,
    SyncQueueData,
    $$SyncQueueTableFilterComposer,
    $$SyncQueueTableOrderingComposer,
    $$SyncQueueTableAnnotationComposer,
    $$SyncQueueTableCreateCompanionBuilder,
    $$SyncQueueTableUpdateCompanionBuilder,
    (
      SyncQueueData,
      BaseReferences<_$AppDatabase, $SyncQueueTable, SyncQueueData>
    ),
    SyncQueueData,
    PrefetchHooks Function()>;
typedef $$SyncMetaTableCreateCompanionBuilder = SyncMetaCompanion Function({
  required String key,
  Value<String?> value,
  Value<int> rowid,
});
typedef $$SyncMetaTableUpdateCompanionBuilder = SyncMetaCompanion Function({
  Value<String> key,
  Value<String?> value,
  Value<int> rowid,
});

class $$SyncMetaTableFilterComposer
    extends Composer<_$AppDatabase, $SyncMetaTable> {
  $$SyncMetaTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get key => $composableBuilder(
      column: $table.key, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get value => $composableBuilder(
      column: $table.value, builder: (column) => ColumnFilters(column));
}

class $$SyncMetaTableOrderingComposer
    extends Composer<_$AppDatabase, $SyncMetaTable> {
  $$SyncMetaTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get key => $composableBuilder(
      column: $table.key, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get value => $composableBuilder(
      column: $table.value, builder: (column) => ColumnOrderings(column));
}

class $$SyncMetaTableAnnotationComposer
    extends Composer<_$AppDatabase, $SyncMetaTable> {
  $$SyncMetaTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get key =>
      $composableBuilder(column: $table.key, builder: (column) => column);

  GeneratedColumn<String> get value =>
      $composableBuilder(column: $table.value, builder: (column) => column);
}

class $$SyncMetaTableTableManager extends RootTableManager<
    _$AppDatabase,
    $SyncMetaTable,
    SyncMetaData,
    $$SyncMetaTableFilterComposer,
    $$SyncMetaTableOrderingComposer,
    $$SyncMetaTableAnnotationComposer,
    $$SyncMetaTableCreateCompanionBuilder,
    $$SyncMetaTableUpdateCompanionBuilder,
    (SyncMetaData, BaseReferences<_$AppDatabase, $SyncMetaTable, SyncMetaData>),
    SyncMetaData,
    PrefetchHooks Function()> {
  $$SyncMetaTableTableManager(_$AppDatabase db, $SyncMetaTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$SyncMetaTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$SyncMetaTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$SyncMetaTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> key = const Value.absent(),
            Value<String?> value = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SyncMetaCompanion(
            key: key,
            value: value,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String key,
            Value<String?> value = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SyncMetaCompanion.insert(
            key: key,
            value: value,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$SyncMetaTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $SyncMetaTable,
    SyncMetaData,
    $$SyncMetaTableFilterComposer,
    $$SyncMetaTableOrderingComposer,
    $$SyncMetaTableAnnotationComposer,
    $$SyncMetaTableCreateCompanionBuilder,
    $$SyncMetaTableUpdateCompanionBuilder,
    (SyncMetaData, BaseReferences<_$AppDatabase, $SyncMetaTable, SyncMetaData>),
    SyncMetaData,
    PrefetchHooks Function()>;
typedef $$AppSettingsTableCreateCompanionBuilder = AppSettingsCompanion
    Function({
  required String key,
  Value<String?> value,
  Value<int> rowid,
});
typedef $$AppSettingsTableUpdateCompanionBuilder = AppSettingsCompanion
    Function({
  Value<String> key,
  Value<String?> value,
  Value<int> rowid,
});

class $$AppSettingsTableFilterComposer
    extends Composer<_$AppDatabase, $AppSettingsTable> {
  $$AppSettingsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get key => $composableBuilder(
      column: $table.key, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get value => $composableBuilder(
      column: $table.value, builder: (column) => ColumnFilters(column));
}

class $$AppSettingsTableOrderingComposer
    extends Composer<_$AppDatabase, $AppSettingsTable> {
  $$AppSettingsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get key => $composableBuilder(
      column: $table.key, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get value => $composableBuilder(
      column: $table.value, builder: (column) => ColumnOrderings(column));
}

class $$AppSettingsTableAnnotationComposer
    extends Composer<_$AppDatabase, $AppSettingsTable> {
  $$AppSettingsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get key =>
      $composableBuilder(column: $table.key, builder: (column) => column);

  GeneratedColumn<String> get value =>
      $composableBuilder(column: $table.value, builder: (column) => column);
}

class $$AppSettingsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $AppSettingsTable,
    AppSetting,
    $$AppSettingsTableFilterComposer,
    $$AppSettingsTableOrderingComposer,
    $$AppSettingsTableAnnotationComposer,
    $$AppSettingsTableCreateCompanionBuilder,
    $$AppSettingsTableUpdateCompanionBuilder,
    (AppSetting, BaseReferences<_$AppDatabase, $AppSettingsTable, AppSetting>),
    AppSetting,
    PrefetchHooks Function()> {
  $$AppSettingsTableTableManager(_$AppDatabase db, $AppSettingsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$AppSettingsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$AppSettingsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$AppSettingsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> key = const Value.absent(),
            Value<String?> value = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              AppSettingsCompanion(
            key: key,
            value: value,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String key,
            Value<String?> value = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              AppSettingsCompanion.insert(
            key: key,
            value: value,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$AppSettingsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $AppSettingsTable,
    AppSetting,
    $$AppSettingsTableFilterComposer,
    $$AppSettingsTableOrderingComposer,
    $$AppSettingsTableAnnotationComposer,
    $$AppSettingsTableCreateCompanionBuilder,
    $$AppSettingsTableUpdateCompanionBuilder,
    (AppSetting, BaseReferences<_$AppDatabase, $AppSettingsTable, AppSetting>),
    AppSetting,
    PrefetchHooks Function()>;

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$ProfilesTableTableManager get profiles =>
      $$ProfilesTableTableManager(_db, _db.profiles);
  $$WalletsTableTableManager get wallets =>
      $$WalletsTableTableManager(_db, _db.wallets);
  $$HatsTableTableManager get hats => $$HatsTableTableManager(_db, _db.hats);
  $$HatSessionsTableTableManager get hatSessions =>
      $$HatSessionsTableTableManager(_db, _db.hatSessions);
  $$HatPurchaseItemsTableTableManager get hatPurchaseItems =>
      $$HatPurchaseItemsTableTableManager(_db, _db.hatPurchaseItems);
  $$IncomeHatTableTableManager get incomeHat =>
      $$IncomeHatTableTableManager(_db, _db.incomeHat);
  $$IncomePersonalTableTableManager get incomePersonal =>
      $$IncomePersonalTableTableManager(_db, _db.incomePersonal);
  $$CategoriesTableTableManager get categories =>
      $$CategoriesTableTableManager(_db, _db.categories);
  $$ProductsTableTableManager get products =>
      $$ProductsTableTableManager(_db, _db.products);
  $$ExpensesTableTableManager get expenses =>
      $$ExpensesTableTableManager(_db, _db.expenses);
  $$MotherPaymentsTableTableManager get motherPayments =>
      $$MotherPaymentsTableTableManager(_db, _db.motherPayments);
  $$DpsAccountsTableTableManager get dpsAccounts =>
      $$DpsAccountsTableTableManager(_db, _db.dpsAccounts);
  $$DpsTransactionsTableTableManager get dpsTransactions =>
      $$DpsTransactionsTableTableManager(_db, _db.dpsTransactions);
  $$LoanPersonsTableTableManager get loanPersons =>
      $$LoanPersonsTableTableManager(_db, _db.loanPersons);
  $$LoansTableTableManager get loans =>
      $$LoansTableTableManager(_db, _db.loans);
  $$LoanPaymentsTableTableManager get loanPayments =>
      $$LoanPaymentsTableTableManager(_db, _db.loanPayments);
  $$FuelLogsTableTableManager get fuelLogs =>
      $$FuelLogsTableTableManager(_db, _db.fuelLogs);
  $$BikeMaintenanceTableTableManager get bikeMaintenance =>
      $$BikeMaintenanceTableTableManager(_db, _db.bikeMaintenance);
  $$CashTalliesTableTableManager get cashTallies =>
      $$CashTalliesTableTableManager(_db, _db.cashTallies);
  $$CashTallyItemsTableTableManager get cashTallyItems =>
      $$CashTallyItemsTableTableManager(_db, _db.cashTallyItems);
  $$DailyClosingsTableTableManager get dailyClosings =>
      $$DailyClosingsTableTableManager(_db, _db.dailyClosings);
  $$AttachmentsTableTableManager get attachments =>
      $$AttachmentsTableTableManager(_db, _db.attachments);
  $$MonthlyBudgetsTableTableManager get monthlyBudgets =>
      $$MonthlyBudgetsTableTableManager(_db, _db.monthlyBudgets);
  $$SavingsGoalsTableTableManager get savingsGoals =>
      $$SavingsGoalsTableTableManager(_db, _db.savingsGoals);
  $$SyncQueueTableTableManager get syncQueue =>
      $$SyncQueueTableTableManager(_db, _db.syncQueue);
  $$SyncMetaTableTableManager get syncMeta =>
      $$SyncMetaTableTableManager(_db, _db.syncMeta);
  $$AppSettingsTableTableManager get appSettings =>
      $$AppSettingsTableTableManager(_db, _db.appSettings);
}
