import 'package:drift/drift.dart';
import 'package:drift_flutter/drift_flutter.dart';

export 'package:drift/drift.dart' show Value, Constant, Expression, CustomExpression, Variable;
import 'tables/all_tables.dart';

part 'app_database.g.dart';

@DriftDatabase(
  tables: [
    Profiles,
    Wallets,
    Hats,
    HatSessions,
    HatPurchaseItems,
    IncomeHat,
    IncomePersonal,
    Categories,
    Products,
    Expenses,
    MotherPayments,
    DpsAccounts,
    DpsTransactions,
    LoanPersons,
    Loans,
    LoanPayments,
    FuelLogs,
    BikeMaintenance,
    CashTallies,
    CashTallyItems,
    DailyClosings,
    Attachments,
    MonthlyBudgets,
    SavingsGoals,
    SyncQueue,
    SyncMeta,
    AppSettings,
  ],
)
class AppDatabase extends _$AppDatabase {
  AppDatabase() : super(_open());

  /// টেস্টের জন্য ইন-মেমোরি এক্সিকিউটর
  AppDatabase.withExecutor(super.e);

  /// ফাইল-পাথ দিয়ে (ব্যাকআপ রিস্টোর ইত্যাদি)
  AppDatabase.withFile(super.e);

  @override
  int get schemaVersion => 6;

  @override
  MigrationStrategy get migration => MigrationStrategy(
        onCreate: (m) async {
          await m.createAll();
          await _dailyClosingUniqueIndex(m);
        },
        onUpgrade: (m, from, to) async {
          if (from < 2) {
            await m.addColumn(dpsAccounts, dpsAccounts.frequency);
          }
          if (from < 3) {
            await m.createTable(products);
          }
          if (from < 4) {
            await _dailyClosingUniqueIndex(m);
          }
          if (from < 5) {
            // V1.3: বাদ-কেজি/মোট কেজি/আসল মণ-দর (docs/07) + difference কারণ নোট
            await m.addColumn(hatPurchaseItems, hatPurchaseItems.grossKg);
            await m.addColumn(hatPurchaseItems, hatPurchaseItems.deductionKg);
            await m.addColumn(hatPurchaseItems, hatPurchaseItems.ratePaisaPerMaund);
            await m.addColumn(hatSessions, hatSessions.differenceNote);
          }
          if (from < 6) {
            // V1.4 FinTrack মার্জ: বাজেট + সেভিংস গোল (লোকাল-অনলি টেবিল)
            await m.createTable(monthlyBudgets);
            await m.createTable(savingsGoals);
          }
        },
      );

  /// FIX H-1: daily_closings-এ (user_id, txn_date) unique — একই দিন
  /// দুবার বন্ধ করলে getDailyClosing() "Too many elements"-এ ভাঙত।
  /// পুরনো ডাটায় ডুপ্লিকেট থাকলে index তৈরি ব্যর্থ হবে — তখন অ্যাপ
  /// চলবে, শুধু সুরক্ষাটা থাকবে না (crash করা যাবে না)।
  Future<void> _dailyClosingUniqueIndex(Migrator m) async {
    try {
      await m.database.customStatement(
        'CREATE UNIQUE INDEX IF NOT EXISTS idx_daily_closings_user_date '
        'ON daily_closings (user_id, txn_date)',
      );
    } catch (_) {}
  }

  static QueryExecutor _open() => driftDatabase(name: 'hat_hisab');
}
