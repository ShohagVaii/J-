import 'package:drift/drift.dart';

/// সব টেবিল — 05_Schema অনুযায়ী (কলাম নাম snake_case-এ যায়)
/// টাকা সবসময় *_paisa INTEGER। তারিখ TEXT 'YYYY-MM-DD'। সময় INTEGER epoch ms।

mixin GlobalCols on Table {
  TextColumn get createdAt => text().withDefault(const Constant(''))();
  TextColumn get updatedAt => text().withDefault(const Constant(''))();
  TextColumn get deletedAt => text().nullable()();
  IntColumn get version => integer().withDefault(const Constant(1))();
  TextColumn get syncStatus => text().withDefault(const Constant('pending'))();
}

/// লোকাল সময়/মেটা helpers ডাটাবেজ ক্লাসে সেট হবে (epoch ms TEXT হিসেবে রাখা
/// সরল ও Postgres timestamptz-এ ISO স্ট্রিং হিসেবে সরাসরি যায়)

class Profiles extends Table with GlobalCols {
  TextColumn get id => text()(); // = auth uid বা 'local'
  TextColumn get displayName => text().withDefault(const Constant(''))();
  TextColumn get phone => text().nullable()();
  IntColumn get defaultMotherAmountPaisa => integer().withDefault(const Constant(50000))();
  TextColumn get numberStyle => text().withDefault(const Constant('bn'))();
  TextColumn get themeMode => text().withDefault(const Constant('system'))();
  TextColumn get dailyClosingTime => text().withDefault(const Constant('21:30'))();
  @override
  Set<Column> get primaryKey => {id};
}

class Wallets extends Table with GlobalCols {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get name => text()();
  TextColumn get type => text().withDefault(const Constant('cash'))();
  IntColumn get openingBalancePaisa => integer().withDefault(const Constant(0))();
  BoolColumn get isArchived => boolean().withDefault(const Constant(false))();
  @override
  Set<Column> get primaryKey => {id};
}

class Hats extends Table with GlobalCols {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get name => text()();
  TextColumn get location => text().nullable()();
  TextColumn get hatDays => text().withDefault(const Constant('[]'))(); // JSON [0..6]
  TextColumn get colorHex => text().withDefault(const Constant('#1B7A43'))();
  TextColumn get icon => text().withDefault(const Constant('storefront'))();
  TextColumn get defaultOwnerName => text().nullable()();
  BoolColumn get isArchived => boolean().withDefault(const Constant(false))();
  @override
  Set<Column> get primaryKey => {id};
}

class HatSessions extends Table with GlobalCols {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get hatId => text()();
  TextColumn get txnDate => text()();
  TextColumn get ownerName => text().nullable()();
  TextColumn get status => text().withDefault(const Constant('draft'))();
  IntColumn get openingCashPaisa => integer().withDefault(const Constant(0))();
  IntColumn get ownerCashReceivedPaisa => integer().withDefault(const Constant(0))();
  IntColumn get wagePaisa => integer().withDefault(const Constant(0))();
  IntColumn get chotaPaisa => integer().withDefault(const Constant(0))();
  IntColumn get slipChargePaisa => integer().withDefault(const Constant(0))();
  IntColumn get memoChargePaisa => integer().withDefault(const Constant(0))();
  IntColumn get returnedToOwnerPaisa => integer().withDefault(const Constant(0))();
  IntColumn get countedCashPaisa => integer().nullable()();
  IntColumn get expectedCashPaisa => integer().nullable()();
  IntColumn get cashDifferencePaisa => integer().nullable()();
  TextColumn get residualHolder => text().nullable()();
  TextColumn get walletId => text().nullable()();
  TextColumn get note => text().nullable()();
  // V1.3 (ফিচার ৬): বড় difference-এর কারণ — closing-এর সময় লেখা হয়
  TextColumn get differenceNote => text().nullable()();
  @override
  Set<Column> get primaryKey => {id};
}

class HatPurchaseItems extends Table with GlobalCols {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get sessionId => text()();
  TextColumn get productName => text().withDefault(const Constant('পেঁয়াজ'))();
  RealColumn get kg => real()();
  // V1.3 (docs/07): বস্তা-যোগে মোট কেজি ও পচা/খারাপ বাদ — kg-ই নেট (gross − deduction)
  RealColumn get grossKg => real().nullable()();
  RealColumn get deductionKg => real().withDefault(const Constant(0))();
  IntColumn get ratePaisaPerKg => integer()();
  // V1.3 (F-11): আসল মণ-দর সংরক্ষণ — per-kg round করা দর দেখালে drift হতো
  IntColumn get ratePaisaPerMaund => integer().nullable()();
  IntColumn get totalPaisa => integer()();
  TextColumn get sellerName => text().nullable()();
  IntColumn get paidPaisa => integer().withDefault(const Constant(0))();
  TextColumn get note => text().nullable()();
  @override
  Set<Column> get primaryKey => {id};
}

class IncomeHat extends Table with GlobalCols {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get hatId => text().nullable()();
  TextColumn get sessionId => text().nullable()();
  TextColumn get txnDate => text()();
  IntColumn get amountPaisa => integer()();
  TextColumn get paymentMethod => text().withDefault(const Constant('cash'))();
  TextColumn get walletId => text().nullable()();
  TextColumn get note => text().nullable()();
  @override
  Set<Column> get primaryKey => {id};
}

class IncomePersonal extends Table with GlobalCols {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get title => text()();
  TextColumn get category => text().nullable()();
  TextColumn get txnDate => text()();
  IntColumn get amountPaisa => integer()();
  TextColumn get paymentMethod => text().withDefault(const Constant('cash'))();
  TextColumn get walletId => text().nullable()();
  TextColumn get note => text().nullable()();
  @override
  Set<Column> get primaryKey => {id};
}

/// মাস্টার-ডাটা: পন্য তালিকা (সেটিংস থেকে ব্যবস্থাপনা + সেশনে ড্রপডাউন)
class Products extends Table with GlobalCols {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get name => text()();
  IntColumn get lastRatePaisaPerKg => integer().nullable()(); // শেষ ব্যবহৃত দর
  TextColumn get unit => text().withDefault(const Constant('kg'))();
  @override
  Set<Column> get primaryKey => {id};
}

class Categories extends Table with GlobalCols {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get name => text()();
  TextColumn get icon => text().nullable()();
  TextColumn get colorHex => text().nullable()();
  TextColumn get scope => text().withDefault(const Constant('expense'))();
  BoolColumn get isSystem => boolean().withDefault(const Constant(false))();
  IntColumn get sortOrder => integer().withDefault(const Constant(0))();
  @override
  Set<Column> get primaryKey => {id};
}

class Expenses extends Table with GlobalCols {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get scope => text().withDefault(const Constant('personal'))();
  TextColumn get hatId => text().nullable()();
  TextColumn get sessionId => text().nullable()();
  TextColumn get categoryId => text().nullable()();
  TextColumn get txnDate => text()();
  IntColumn get amountPaisa => integer()();
  TextColumn get paymentMethod => text().withDefault(const Constant('cash'))();
  TextColumn get walletId => text().nullable()();
  TextColumn get note => text().nullable()();
  @override
  Set<Column> get primaryKey => {id};
}

class MotherPayments extends Table with GlobalCols {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get txnDate => text()();
  IntColumn get amountPaisa => integer()();
  TextColumn get paymentMethod => text().withDefault(const Constant('cash'))();
  TextColumn get walletId => text().nullable()();
  TextColumn get note => text().nullable()();
  @override
  Set<Column> get primaryKey => {id};
}

class DpsAccounts extends Table with GlobalCols {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get institutionName => text()();
  IntColumn get monthlyInstallmentPaisa => integer()();
  /// v1.1: daily | weekly | monthly
  TextColumn get frequency => text().withDefault(const Constant('monthly'))();
  /// monthly → ১–২৮ তারিখ; weekly → DateTime.weekday (১=সোম..৭=রবি); daily → উপেক্ষিত
  IntColumn get dueDay => integer().withDefault(const Constant(1))();
  TextColumn get startDate => text()();
  IntColumn get durationMonths => integer().nullable()();
  IntColumn get targetPaisa => integer().nullable()();
  TextColumn get status => text().withDefault(const Constant('active'))();
  TextColumn get note => text().nullable()();
  @override
  Set<Column> get primaryKey => {id};
}

class DpsTransactions extends Table with GlobalCols {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get dpsAccountId => text()();
  TextColumn get txnDate => text()();
  IntColumn get txnAt => integer().withDefault(const Constant(0))(); // সঠিক সময় (epoch ms)
  IntColumn get amountPaisa => integer()();
  TextColumn get paymentMethod => text().withDefault(const Constant('cash'))();
  TextColumn get walletId => text().nullable()();
  TextColumn get note => text().nullable()();
  @override
  Set<Column> get primaryKey => {id};
}

class LoanPersons extends Table with GlobalCols {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get name => text()();
  TextColumn get phone => text().nullable()();
  TextColumn get address => text().nullable()();
  TextColumn get avatarPath => text().nullable()();
  TextColumn get note => text().nullable()();
  @override
  Set<Column> get primaryKey => {id};
}

class Loans extends Table with GlobalCols {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get personId => text()();
  TextColumn get type => text().withDefault(const Constant('given'))(); // given|taken
  IntColumn get principalPaisa => integer()();
  TextColumn get txnDate => text()();
  TextColumn get dueDate => text().nullable()();
  TextColumn get walletId => text().nullable()();
  TextColumn get note => text().nullable()();
  @override
  Set<Column> get primaryKey => {id};
}

class LoanPayments extends Table with GlobalCols {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get loanId => text()();
  TextColumn get txnDate => text()();
  IntColumn get amountPaisa => integer()();
  TextColumn get walletId => text().nullable()();
  TextColumn get note => text().nullable()();
  @override
  Set<Column> get primaryKey => {id};
}

class FuelLogs extends Table with GlobalCols {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get txnDate => text()();
  RealColumn get odometerKm => real()();
  IntColumn get amountPaisa => integer()();
  RealColumn get litre => real().nullable()();
  IntColumn get pricePerLitrePaisa => integer().nullable()();
  BoolColumn get isFullTank => boolean().withDefault(const Constant(false))();
  TextColumn get pumpName => text().nullable()();
  TextColumn get walletId => text().nullable()();
  TextColumn get note => text().nullable()();
  @override
  Set<Column> get primaryKey => {id};
}

class BikeMaintenance extends Table with GlobalCols {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get txnDate => text()();
  TextColumn get type => text().withDefault(const Constant('other'))();
  TextColumn get itemName => text()();
  IntColumn get costPaisa => integer()();
  RealColumn get odometerKm => real().nullable()();
  RealColumn get nextServiceKm => real().nullable()();
  TextColumn get nextServiceDate => text().nullable()();
  TextColumn get walletId => text().nullable()();
  TextColumn get note => text().nullable()();
  @override
  Set<Column> get primaryKey => {id};
}

class CashTallies extends Table with GlobalCols {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get txnDate => text()();
  TextColumn get walletId => text().nullable()();
  TextColumn get sessionId => text().nullable()();
  IntColumn get countedTotalPaisa => integer().withDefault(const Constant(0))();
  IntColumn get expectedPaisa => integer().nullable()();
  IntColumn get differencePaisa => integer().nullable()();
  TextColumn get note => text().nullable()();
  @override
  Set<Column> get primaryKey => {id};
}

class CashTallyItems extends Table with GlobalCols {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get tallyId => text()();
  IntColumn get denominationPaisa => integer()();
  IntColumn get quantity => integer().withDefault(const Constant(0))();
  IntColumn get lineTotalPaisa => integer().withDefault(const Constant(0))();
  @override
  Set<Column> get primaryKey => {id};
}

class DailyClosings extends Table with GlobalCols {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get txnDate => text()();
  IntColumn get expectedCashPaisa => integer().withDefault(const Constant(0))();
  IntColumn get countedCashPaisa => integer().nullable()();
  IntColumn get differencePaisa => integer().nullable()();
  TextColumn get note => text().nullable()();
  IntColumn get closedAt => integer().withDefault(const Constant(0))();
  @override
  Set<Column> get primaryKey => {id};
}

class Attachments extends Table with GlobalCols {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get ownerType => text()(); // expense|hat_session|loan|bike_maintenance
  TextColumn get ownerId => text()();
  TextColumn get localPath => text()();
  TextColumn get remotePath => text().nullable()();
  TextColumn get mime => text().nullable()();
  IntColumn get sizeBytes => integer().nullable()();
  @override
  Set<Column> get primaryKey => {id};
}

// ---------- V1.4 FinTrack মার্জ — V1.4.1 থেকে সার্ভারেও আছে, সিঙ্ক হয় (G-11) ----------

/// FinTracks Budget পোর্ট: ক্যাটাগরি অনুযায়ী মাসিক খরচের লিমিট।
/// category = ক্যাটাগরির নাম (FinTracks-এর Budget মডেল অনুযায়ী নাম-ভিত্তিক),
/// month = 'YYYY-MM'
class MonthlyBudgets extends Table with GlobalCols {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get category => text()();
  TextColumn get month => text()();
  IntColumn get limitPaisa => integer().withDefault(const Constant(0))();
  @override
  Set<Column> get primaryKey => {id};
}

/// FinTracks Goal পোর্ট: সেভিংস গোল (DPS থেকে আলাদা — সাধারণ উদ্দেশ্যের জমানো লক্ষ্য)
class SavingsGoals extends Table with GlobalCols {
  TextColumn get id => text()();
  TextColumn get userId => text()();
  TextColumn get name => text()();
  IntColumn get targetPaisa => integer()();
  IntColumn get currentPaisa => integer().withDefault(const Constant(0))();
  TextColumn get deadline => text().nullable()(); // 'YYYY-MM-DD'
  TextColumn get note => text().nullable()();
  @override
  Set<Column> get primaryKey => {id};
}

// ---------- লোকাল-অনলি (Supabase-এ নেই) ----------

class SyncQueue extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get targetTable => text()();
  TextColumn get rowId => text()();
  TextColumn get operation => text()(); // upsert|delete
  TextColumn get payloadJson => text().withDefault(const Constant('{}'))();
  IntColumn get attempts => integer().withDefault(const Constant(0))();
  TextColumn get lastError => text().nullable()();
  IntColumn get createdAt => integer().withDefault(const Constant(0))();
}

class SyncMeta extends Table {
  TextColumn get key => text()();
  TextColumn get value => text().nullable()();
  @override
  Set<Column> get primaryKey => {key};
}

class AppSettings extends Table {
  TextColumn get key => text()();
  TextColumn get value => text().nullable()();
  @override
  Set<Column> get primaryKey => {key};
}
