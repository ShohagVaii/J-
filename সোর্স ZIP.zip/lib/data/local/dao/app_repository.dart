import 'dart:convert';
import 'package:drift/drift.dart';
import 'package:uuid/uuid.dart';
import '../../../core/sync/sync_payload.dart';
import '../../remote/supabase_client.dart';
import '../app_database.dart';

/// V1.4.1 (G-01): গেস্ট ডাটার গণনা — প্রথম লগইনের সম্মতি-dialog-এর জন্য।
/// [perTable]: টেবিল → জীবিত (deleted_at IS NULL) গেস্ট row সংখ্যা, শুধু
/// যেগুলোতে সংখ্যা > 0। টাকার সারাংশ paisa-তে।
class GuestDataSummary {
  final Map<String, int> perTable;
  final int totalCount;
  final int incomePaisa; // income_hat + income_personal
  final int expensePaisa; // expenses
  final int loanPaisa; // loans-এর principal
  const GuestDataSummary({
    required this.perTable,
    required this.totalCount,
    required this.incomePaisa,
    required this.expensePaisa,
    required this.loanPaisa,
  });
}

/// সব ডাটা-অ্যাক্সেস এক জায়গায়। লোকাল সেভ সবসময় সফল হয় (অফলাইন-ফার্স্ট);
/// সিঙ্ক আলাদা ইঞ্জিনে — লেখা কখনোই নেটওয়ার্কের উপর নির্ভর করে না।
class AppRepository {
  AppRepository(this.db);
  final AppDatabase db;
  final Uuid _uuid = const Uuid();
  void Function()? onLocalChange; // সিঙ্ক ইঞ্জিন ট্রিগার

  static const List<String> userTables = [
    'profiles', 'wallets', 'hats', 'hat_sessions', 'hat_purchase_items',
    'income_hat', 'income_personal', 'categories', 'expenses',
    'mother_payments', 'dps_accounts', 'dps_transactions', 'loan_persons',
    'loans', 'loan_payments', 'fuel_logs', 'bike_maintenance', 'cash_tallies',
    'cash_tally_items', 'daily_closings', 'attachments', 'products',
    // V1.4.1 (G-11): FinTrack বাজেট/গোল — সার্ভার টেবিল তৈরি হয়েছে, এখন
    // এগুলোও sync/migrate/export-এর ভেতরে। শেষে রাখা হলো যাতে parent-first
    // push-ক্রম আগের মতোই থাকে (এদের কোনো FK-নির্ভরতা নেই)।
    'monthly_budgets', 'savings_goals',
  ];

  String get uid => Supa.uidOrDefault;

  // ── FIX C-1 (Audit 2026-10-29) ──────────────────────────────────────────
  // আগের RawValuesInsertable<dynamic> পথটি প্রতিটি লেখায় runtime TypeError
  // ছুড়ত (Insertable<Wallet> ইত্যাদির সাথে মিলত না) — ফলে অ্যাপের সব
  // insert/update/softDelete ভেঙে ছিল। এখন সব জেনেরিক লেখা custom SQL দিয়ে,
  // টাইপ-নিরাপদভাবে হয়।
  Variable _var(Object? v) {
    // null এখানে আসে না — null মান SQL-এ সরাসরি NULL লেখা হয় (নিচে দেখুন)
    if (v == null) return Variable.withString('');
    if (v is bool) return Variable.withBool(v);
    if (v is int) return Variable.withInt(v);
    if (v is double) return Variable.withReal(v);
    if (v is String) return Variable.withString(v);
    return Variable.withString(v.toString());
  }

  /// companion → সরল মানের ম্যাপ। includeNullVariables=true হলে Value(null)-ও
  /// থাকবে (FIX M-4: update-এ nullable ফিল্ড মোছা এখন কাজ করে)।
  Map<String, Object?> _plainValues(Insertable row, {bool includeNullVariables = false}) {
    final out = <String, Object?>{};
    row.toColumns(false).forEach((k, expr) {
      if (expr is Variable) {
        if (expr.value != null || includeNullVariables) out[k] = expr.value;
      } else if (expr is Constant) {
        out[k] = expr.value;
      }
    });
    return out;
  }

  Future<void> _customInsertRow(TableInfo tbl, Map<String, Object?> cols, {bool replace = false}) async {
    final keys = cols.keys.toList();
    final vars = <Variable>[];
    final placeholders = <String>[];
    for (final k in keys) {
      if (cols[k] == null) {
        placeholders.add('NULL');
      } else {
        placeholders.add('?');
        vars.add(_var(cols[k]));
      }
    }
    final sql = '${replace ? 'INSERT OR REPLACE' : 'INSERT'} INTO ${tbl.entityName} '
        '(${keys.join(', ')}) VALUES (${placeholders.join(', ')})';
    await db.customInsert(sql, variables: vars, updates: {tbl});
  }

  Future<void> _customUpdateRow(TableInfo tbl, Map<String, Object?> cols, String id, {bool bumpVersion = false}) async {
    final vars = <Variable>[];
    final sets = <String>[];
    for (final k in cols.keys) {
      if (cols[k] == null) {
        sets.add('$k = NULL');
      } else {
        sets.add('$k = ?');
        vars.add(_var(cols[k]));
      }
    }
    final sql = 'UPDATE ${tbl.entityName} SET ${sets.join(', ')}${bumpVersion ? ', version = version + 1' : ''} WHERE id = ?';
    await db.customUpdate(sql,
        variables: [...vars, Variable.withString(id)],
        updates: {tbl}, updateKind: UpdateKind.update);
  }
  String get _nowIso => DateTime.now().toUtc().toIso8601String();
  String get _newId => _uuid.v4();

  TableInfo _tableByName(String name) {
    switch (name) {
      case 'profiles':
        return db.profiles;
      case 'wallets':
        return db.wallets;
      case 'hats':
        return db.hats;
      case 'hat_sessions':
        return db.hatSessions;
      case 'hat_purchase_items':
        return db.hatPurchaseItems;
      case 'income_hat':
        return db.incomeHat;
      case 'income_personal':
        return db.incomePersonal;
      case 'categories':
        return db.categories;
      case 'products':
        return db.products;
      case 'expenses':
        return db.expenses;
      case 'mother_payments':
        return db.motherPayments;
      case 'dps_accounts':
        return db.dpsAccounts;
      case 'dps_transactions':
        return db.dpsTransactions;
      case 'loan_persons':
        return db.loanPersons;
      case 'loans':
        return db.loans;
      case 'loan_payments':
        return db.loanPayments;
      case 'fuel_logs':
        return db.fuelLogs;
      case 'bike_maintenance':
        return db.bikeMaintenance;
      case 'cash_tallies':
        return db.cashTallies;
      case 'cash_tally_items':
        return db.cashTallyItems;
      case 'daily_closings':
        return db.dailyClosings;
      case 'attachments':
        return db.attachments;
      case 'monthly_budgets':
        return db.monthlyBudgets;
      case 'savings_goals':
        return db.savingsGoals;
      default:
        throw ArgumentError('unknown table $name');
    }
  }

  // ---------- জেনেরিক লেখা ----------

  Future<String> insert(TableInfo tbl, Insertable row, {String? id}) async {
    final rid = id ?? _newId;
    final raw = _plainValues(row, includeNullVariables: true);
    raw['id'] = rid;
    // FIX M-5: profiles-এ user_id কলাম নেই — যেই টেবিলে কলাম আছে শুধু সেখানেই
    if (tbl.$columns.any((c) => c.name == 'user_id')) {
      raw['user_id'] = uid;
    } else {
      raw.remove('user_id');
    }
    raw['created_at'] = _nowIso;
    raw['updated_at'] = _nowIso;
    raw['version'] = 1;
    raw['sync_status'] = 'pending';
    await _customInsertRow(tbl, raw);
    await _enqueueRow(tbl, rid);
    onLocalChange?.call();
    return rid;
  }

  Future<void> update(TableInfo tbl, String id, Insertable patch) async {
    final raw = _plainValues(patch, includeNullVariables: true);
    raw.remove('id');
    raw.remove('user_id');
    raw.remove('created_at');
    raw['updated_at'] = _nowIso;
    raw['sync_status'] = 'pending';
    await _customUpdateRow(tbl, raw, id, bumpVersion: true);
    await _enqueueRow(tbl, id);
    onLocalChange?.call();
  }

  Future<void> softDelete(String tableName, String id) async {
    final tbl = _tableByName(tableName);
    await _customUpdateRow(tbl, {
      'deleted_at': _nowIso,
      'updated_at': _nowIso,
      'sync_status': 'pending',
    }, id, bumpVersion: true);
    await _enqueueRow(tbl, id);
    onLocalChange?.call();
  }

  Future<void> restore(String tableName, String id) async {
    final tbl = _tableByName(tableName);
    await _customUpdateRow(tbl, {
      'deleted_at': null,
      'updated_at': _nowIso,
      'sync_status': 'pending',
    }, id, bumpVersion: true);
    await _enqueueRow(tbl, id);
    onLocalChange?.call();
  }

  Future<void> purge(String tableName, String id) async {
    final tbl = _tableByName(tableName);
    // V1.4.1 (G-08): আগে সার্ভারে সরাসরি 'delete' operation যেত → সার্ভার
    // row hard-delete হয়ে যেত, অন্য ডিভাইসে tombstone কখনো পৌঁছাত না
    // (docs/08 §9 লঙ্ঘন — T9 আংশিক ফেল)। এখন tombstone: deleted_at বসিয়ে
    // upsert enqueue করা হয়, যাতে অন্য ডিভাইস pull-এ row-টা অদৃশ্য হয়।
    // লোকাল hard delete আগের মতোই সঙ্গে সঙ্গে।
    if (Supa.isLoggedIn) {
      final row = await (db.select(tbl)..where((t) => (t as dynamic).id.equals(id)))
          .getSingleOrNull();
      if (row != null) {
        final payload = SyncPayload.of(row, table: tableName);
        payload['deleted_at'] = _nowIso;
        payload['updated_at'] = _nowIso;
        // একই row-র পুরনো queue entry থাকলে সরিয়ে শুধু tombstone-টাই রাখা
        await (db.delete(db.syncQueue)
              ..where((t) => t.targetTable.equals(tableName) & t.rowId.equals(id)))
            .go();
        await db.into(db.syncQueue).insert(SyncQueueCompanion.insert(
              targetTable: tableName,
              rowId: id,
              operation: 'upsert',
              payloadJson: Value(jsonEncode(payload)),
              createdAt: Value(DateTime.now().millisecondsSinceEpoch),
            ));
      }
    }
    await (db.delete(tbl)..where((t) => (t as dynamic).id.equals(id))).go();
    onLocalChange?.call();
  }

  /// V1.4.1 (G-06, docs/08 §7.2): "লোকাল ডাটা মুছে লগআউট"-এর জন্য —
  /// নির্দিষ্ট uid-র সব লোকাল row + তাদের queue entry মোছা। সার্ভারের
  /// ডাটায় হাত দেওয়া হয় না। ফেরত: মোছা row-র মোট সংখ্যা।
  Future<int> wipeLocalDataForUser(String targetUid) async {
    var count = 0;
    await db.transaction(() async {
      for (final name in userTables) {
        if (name == 'profiles') {
          count += await db.customUpdate(
            'DELETE FROM profiles WHERE id = ?',
            variables: [Variable.withString(targetUid)],
            updateKind: UpdateKind.delete,
          );
          continue;
        }
        final rows = await db.customSelect(
          'SELECT id FROM $name WHERE user_id = ?',
          variables: [Variable.withString(targetUid)],
        ).get();
        for (final r in rows) {
          final rid = r.read<String>('id');
          await (db.delete(db.syncQueue)
                ..where((t) => t.targetTable.equals(name) & t.rowId.equals(rid)))
              .go();
        }
        count += await db.customUpdate(
          'DELETE FROM $name WHERE user_id = ?',
          variables: [Variable.withString(targetUid)],
          updateKind: UpdateKind.delete,
        );
      }
    });
    onLocalChange?.call();
    return count;
  }

  Future<void> _enqueueRow(TableInfo tbl, String id) async {
    if (!Supa.isLoggedIn) return;
    final row = await (db.select(tbl)..where((t) => (t as dynamic).id.equals(id)))
        .getSingleOrNull();
    if (row == null) return;
    final payload = SyncPayload.of(row, table: tbl.entityName);
    await db.into(db.syncQueue).insert(SyncQueueCompanion.insert(
          targetTable: tbl.entityName,
          rowId: id,
          operation: 'upsert',
          payloadJson: Value(jsonEncode(payload)),
          createdAt: Value(DateTime.now().millisecondsSinceEpoch),
        ));
  }

  // ---------- সেটিংস ও প্রোফাইল ----------

  Future<String?> getSetting(String key) async {
    final row = await (db.select(db.appSettings)..where((t) => t.key.equals(key)))
        .getSingleOrNull();
    return row?.value;
  }

  Future<void> setSetting(String key, String value) async {
    // FIX C-4: দ্বিতীয়বার একই key লিখলে UNIQUE constraint-এ ভাঙত
    await db.into(db.appSettings).insert(
          AppSettingsCompanion.insert(key: key, value: Value(value)),
          mode: InsertMode.insertOrReplace,
        );
  }

  Stream<Profile?> watchProfile() {
    return (db.select(db.profiles)..where((t) => t.id.equals(uid)))
        .watchSingleOrNull();
  }

  Future<void> saveProfileFields({
    String? displayName,
    String? numberStyle,
    String? themeMode,
    String? dailyClosingTime,
    int? defaultMotherAmountPaisa,
  }) async {
    final existing = await (db.select(db.profiles)..where((t) => t.id.equals(uid)))
        .getSingleOrNull();
    final comp = ProfilesCompanion.insert(
        id: '',
      displayName: Value(displayName ?? existing?.displayName ?? ''), // FIX: প্যারামিটারটাই উপেক্ষা করা হতো — নাম কখনো সেভ হতো না
      numberStyle: Value(numberStyle ?? existing?.numberStyle ?? 'bn'),
      themeMode: Value(themeMode ?? existing?.themeMode ?? 'system'),
      dailyClosingTime: Value(dailyClosingTime ?? existing?.dailyClosingTime ?? '21:30'),
      defaultMotherAmountPaisa: Value(
          defaultMotherAmountPaisa ?? existing?.defaultMotherAmountPaisa ?? 50000),
    );
    if (existing == null) {
      await insert(db.profiles, comp, id: uid);
    } else {
      await update(db.profiles, uid, comp);
    }
  }

  // ---------- ওয়ালেট / ক্যাটাগরি ----------

  /// wallet_balances VIEW-এর সমতুল্য Drift কোয়েরি (05_Schema §4)
  /// ক্রেডিট/ডেবিট ম্যাপিং হুবহু §4 অনুযায়ী; ক্রয়-পরিশোধ এখানে নেই (মালিকের ক্যাশ থেকে যায়)
  Stream<List<QueryRow>> watchWalletBalances() {
    return db.customSelect(
      '''
      SELECT w.id, w.name, w.type, w.opening_balance_paisa,
        (w.opening_balance_paisa
          + IFNULL((SELECT SUM(amount_paisa) FROM income_hat WHERE wallet_id = w.id AND deleted_at IS NULL AND payment_method <> 'baki'), 0)
          + IFNULL((SELECT SUM(amount_paisa) FROM income_personal WHERE wallet_id = w.id AND deleted_at IS NULL AND payment_method <> 'baki'), 0)
          + IFNULL((SELECT SUM(principal_paisa) FROM loans WHERE wallet_id = w.id AND deleted_at IS NULL AND type = 'taken'), 0)
          + IFNULL((SELECT SUM(lp.amount_paisa) FROM loan_payments lp JOIN loans l ON l.id = lp.loan_id WHERE lp.wallet_id = w.id AND lp.deleted_at IS NULL AND l.deleted_at IS NULL AND l.type = 'given'), 0)
          - IFNULL((SELECT SUM(amount_paisa) FROM expenses WHERE wallet_id = w.id AND deleted_at IS NULL), 0)
          - IFNULL((SELECT SUM(amount_paisa) FROM mother_payments WHERE wallet_id = w.id AND deleted_at IS NULL), 0)
          - IFNULL((SELECT SUM(amount_paisa) FROM dps_transactions WHERE wallet_id = w.id AND deleted_at IS NULL), 0)
          - IFNULL((SELECT SUM(principal_paisa) FROM loans WHERE wallet_id = w.id AND deleted_at IS NULL AND type = 'given'), 0)
          - IFNULL((SELECT SUM(lp.amount_paisa) FROM loan_payments lp JOIN loans l ON l.id = lp.loan_id WHERE lp.wallet_id = w.id AND lp.deleted_at IS NULL AND l.deleted_at IS NULL AND l.type = 'taken'), 0)
          - IFNULL((SELECT SUM(amount_paisa) FROM fuel_logs WHERE wallet_id = w.id AND deleted_at IS NULL), 0)
          - IFNULL((SELECT SUM(cost_paisa) FROM bike_maintenance WHERE wallet_id = w.id AND deleted_at IS NULL), 0)
        ) AS balance_paisa
      FROM wallets w
      WHERE w.deleted_at IS NULL AND w.user_id = ?
      ORDER BY w.created_at ASC
      ''',
      variables: [Variable.withString(uid)],
    ).watch();
  }

  Future<int> cashInHand() async {
    final rows = await watchWalletBalances().first;
    var total = 0;
    for (final r in rows) {
      total += r.read<int>('balance_paisa');
    }
    return total;
  }

  Stream<List<Wallet>> watchWallets() {
    return (db.select(db.wallets)
          ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid))
          ..orderBy([(t) => OrderingTerm.asc(t.createdAt)]))
        .watch();
  }

  Future<List<Wallet>> getWallets() async {
    return (db.select(db.wallets)
          ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid)))
        .get();
  }

  Stream<List<Category>> watchCategories() {
    return (db.select(db.categories)
          ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid))
          ..orderBy([(t) => OrderingTerm.asc(t.sortOrder)]))
        .watch();
  }

  /// নির্দিষ্ট স্কোপের খাত (expense/income — 'both' দুটোতেই দেখাবে)
  Stream<List<Category>> watchCategoriesScoped(String scope) {
    return (db.select(db.categories)
          ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid))
          ..where((t) => t.scope.isIn([scope, 'both']))
          ..orderBy([(t) => OrderingTerm.asc(t.sortOrder)]))
        .watch();
  }

  Future<Category> addCategory(String name, {String? icon, String scope = 'expense'}) async {
    final id = _newId;
    await insert(db.categories, CategoriesCompanion.insert(
      id: id, userId: uid,
      name: name,
      icon: Value(icon),
      scope: Value(scope),
    ));
    return (db.select(db.categories)..where((t) => t.id.equals(id))).getSingle();
  }

  Future<void> renameCategory(String id, String name, {String? icon}) async {
    await (db.update(db.categories)..where((t) => t.id.equals(id))).write(
      CategoriesCompanion(name: Value(name), icon: Value(icon),
        updatedAt: Value(_nowIso), syncStatus: const Value('pending')),
    );
    await _enqueueRow(db.categories, id); // FIX H-6: কিউ ছাড়া rename সিঙ্ক হতো না
    onLocalChange?.call();
  }

  // ---------- পন্য ----------

  Stream<List<Product>> watchProducts() {
    return (db.select(db.products)
          ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid))
          ..orderBy([(t) => OrderingTerm.asc(t.name)]))
        .watch();
  }

  Future<List<Product>> getProducts() async {
    return (db.select(db.products)
          ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid))
          ..orderBy([(t) => OrderingTerm.asc(t.name)]))
        .get();
  }

  /// পন্য যোগ/হালনাগাদ — নামে মিল থাকলে শেষ-দর হালনাগাদ, নাহলে নতুন রো
  Future<void> upsertProduct(String name, {int? lastRatePaisaPerKg}) async {
    final q = name.trim().toLowerCase();
    if (q.isEmpty) return;
    final existing = await getProducts();
    Product? hit;
    for (final p in existing) {
      if (p.name.trim().toLowerCase() == q) {
        hit = p;
        break;
      }
    }
    if (hit != null) {
      final hid = hit.id;
      final hver = hit.version;
      if (lastRatePaisaPerKg != null) {
        await (db.update(db.products)..where((t) => t.id.equals(hid))).write(
          ProductsCompanion(
            lastRatePaisaPerKg: Value(lastRatePaisaPerKg),
            updatedAt: Value(_nowIso),
            version: Value(hver + 1),
            syncStatus: const Value('pending'),
          ),
        );
        await _enqueueRow(db.products, hid); // FIX H-6
        onLocalChange?.call();
      }
    } else {
      await insert(db.products, ProductsCompanion.insert(
        id: '', userId: '',
        name: name.trim(),
        lastRatePaisaPerKg: Value(lastRatePaisaPerKg),
      ));
    }
  }

  Future<void> renameProduct(String id, String name) async {
    await (db.update(db.products)..where((t) => t.id.equals(id))).write(
      ProductsCompanion(name: Value(name.trim()),
        updatedAt: Value(_nowIso), syncStatus: const Value('pending')),
    );
    await _enqueueRow(db.products, id); // FIX H-6
    onLocalChange?.call();
  }

  // ---------- হাট ও সেশন ----------

  Stream<List<Hat>> watchHats() {
    return (db.select(db.hats)
          ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid))
          ..orderBy([(t) => OrderingTerm.asc(t.name)]))
        .watch();
  }

  Future<Hat?> getHat(String id) =>
      (db.select(db.hats)..where((t) => t.deletedAt.isNull() & t.id.equals(id))).getSingleOrNull();

  Stream<List<HatSession>> watchSessions({String? hatId}) {
    return (db.select(db.hatSessions)
          ..where((t) =>
              t.deletedAt.isNull() &
              t.userId.equals(uid) &
              (hatId == null ? const Constant(true) : t.hatId.equals(hatId)))
          ..orderBy([(t) => OrderingTerm.desc(t.txnDate)]))
        .watch();
  }

  Future<HatSession?> getSession(String id) =>
      (db.select(db.hatSessions)..where((t) => t.deletedAt.isNull() & t.id.equals(id))).getSingleOrNull();

  Stream<List<HatSession>> watchDraftSessions() {
    return (db.select(db.hatSessions)
          ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid) & t.status.equals('draft'))
          ..orderBy([(t) => OrderingTerm.desc(t.updatedAt)]))
        .watch();
  }

  Stream<List<HatPurchaseItem>> watchPurchaseItems(String sessionId) {
    return (db.select(db.hatPurchaseItems)
          ..where((t) => t.deletedAt.isNull() & t.sessionId.equals(sessionId))
          ..orderBy([(t) => OrderingTerm.asc(t.createdAt)]))
        .watch();
  }

  Future<List<HatPurchaseItem>> getPurchaseItems(String sessionId) =>
      (db.select(db.hatPurchaseItems)
            ..where((t) => t.deletedAt.isNull() & t.sessionId.equals(sessionId)))
          .get();

  // ---------- আয় / খরচ / আম্মু ----------

  Stream<List<IncomeHatData>> watchIncomeHat() {
    return (db.select(db.incomeHat)
          ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid))
          ..orderBy([(t) => OrderingTerm.desc(t.txnDate), (t) => OrderingTerm.desc(t.createdAt)]))
        .watch();
  }

  Stream<List<IncomePersonalData>> watchIncomePersonal() {
    return (db.select(db.incomePersonal)
          ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid))
          ..orderBy([(t) => OrderingTerm.desc(t.txnDate), (t) => OrderingTerm.desc(t.createdAt)]))
        .watch();
  }

  Stream<List<Expense>> watchExpenses({String? scope}) {
    return (db.select(db.expenses)
          ..where((t) =>
              t.deletedAt.isNull() &
              t.userId.equals(uid) &
              (scope == null ? const Constant(true) : t.scope.equals(scope)))
          ..orderBy([(t) => OrderingTerm.desc(t.txnDate), (t) => OrderingTerm.desc(t.createdAt)]))
        .watch();
  }

  Stream<List<MotherPayment>> watchMotherPayments() {
    return (db.select(db.motherPayments)
          ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid))
          ..orderBy([(t) => OrderingTerm.desc(t.txnDate), (t) => OrderingTerm.desc(t.createdAt)]))
        .watch();
  }

  // ---------- DPS ----------

  Stream<List<DpsAccount>> watchDpsAccounts() {
    return (db.select(db.dpsAccounts)
          ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid))
          ..orderBy([(t) => OrderingTerm.asc(t.startDate)]))
        .watch();
  }

  Future<DpsAccount?> getDpsAccount(String id) =>
      (db.select(db.dpsAccounts)..where((t) => t.deletedAt.isNull() & t.id.equals(id))).getSingleOrNull();

  Stream<List<DpsTransaction>> watchDpsTx(String accountId) {
    return (db.select(db.dpsTransactions)
          ..where((t) => t.deletedAt.isNull() & t.dpsAccountId.equals(accountId))
          ..orderBy([(t) => OrderingTerm.desc(t.txnDate), (t) => OrderingTerm.desc(t.txnAt)]))
        .watch();
  }

  // ---------- ধার ----------

  Stream<List<LoanPerson>> watchLoanPersons() {
    return (db.select(db.loanPersons)
          ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid))
          ..orderBy([(t) => OrderingTerm.asc(t.name)]))
        .watch();
  }

  Future<LoanPerson?> getLoanPerson(String id) =>
      (db.select(db.loanPersons)..where((t) => t.deletedAt.isNull() & t.id.equals(id))).getSingleOrNull();

  Stream<List<Loan>> watchLoans() {
    return (db.select(db.loans)
          ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid))
          ..orderBy([(t) => OrderingTerm.desc(t.txnDate)]))
        .watch();
  }

  Future<List<Loan>> getLoansOfPerson(String personId) =>
      (db.select(db.loans)
            ..where((t) => t.deletedAt.isNull() & t.personId.equals(personId))
            ..orderBy([(t) => OrderingTerm.asc(t.txnDate)]))
          .get();

  Stream<List<LoanPayment>> watchLoanPayments() {
    return (db.select(db.loanPayments)
          ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid))
          ..orderBy([(t) => OrderingTerm.desc(t.txnDate)]))
        .watch();
  }

  Future<List<LoanPayment>> getLoanPaymentsOfLoan(String loanId) =>
      (db.select(db.loanPayments)
            ..where((t) => t.deletedAt.isNull() & t.loanId.equals(loanId))
            ..orderBy([(t) => OrderingTerm.asc(t.txnDate)]))
          .get();

  // ---------- বাইক ----------

  Stream<List<FuelLog>> watchFuelLogs() {
    return (db.select(db.fuelLogs)
          ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid))
          ..orderBy([(t) => OrderingTerm.desc(t.txnDate), (t) => OrderingTerm.desc(t.odometerKm)]))
        .watch();
  }

  Future<List<FuelLog>> getFuelLogs() => (db.select(db.fuelLogs)
        ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid))
        ..orderBy([(t) => OrderingTerm.asc(t.txnDate), (t) => OrderingTerm.asc(t.odometerKm)]))
      .get();

  Stream<List<BikeMaintenanceData>> watchMaintenance() {
    return (db.select(db.bikeMaintenance)
          ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid))
          ..orderBy([(t) => OrderingTerm.desc(t.txnDate)]))
        .watch();
  }

  // ---------- হিসাব মেলানো / দৈনিক বন্ধ ----------

  Future<String> saveTallyWithItems({
    required String txnDate,
    String? walletId,
    String? sessionId,
    required int countedTotalPaisa,
    int? expectedPaisa,
    int? differencePaisa,
    String? note,
    required List<Map<String, dynamic>> items,
  }) async {
    // FIX H-5: tally + items এক transaction-এ (মাঝপথে fail হলে আংশিক রেকর্ড নয়)
    return db.transaction(() => _saveTallyInner(
          txnDate: txnDate, walletId: walletId, sessionId: sessionId,
          countedTotalPaisa: countedTotalPaisa, expectedPaisa: expectedPaisa,
          differencePaisa: differencePaisa, note: note, items: items,
        ));
  }

  Future<String> _saveTallyInner({
    required String txnDate,
    String? walletId,
    String? sessionId,
    required int countedTotalPaisa,
    int? expectedPaisa,
    int? differencePaisa,
    String? note,
    required List<Map<String, dynamic>> items,
  }) async {
    final tallyId = await insert(db.cashTallies, CashTalliesCompanion.insert(
        id: '', userId: '',
      txnDate: txnDate,
      walletId: Value(walletId),
      sessionId: Value(sessionId),
      countedTotalPaisa: Value(countedTotalPaisa),
      expectedPaisa: Value(expectedPaisa),
      differencePaisa: Value(differencePaisa),
      note: Value(note),
    ));
    for (final it in items) {
      await insert(db.cashTallyItems, CashTallyItemsCompanion.insert(
        id: '', userId: '',
        tallyId: tallyId,
        denominationPaisa: it['denominationPaisa'] as int,
        quantity: Value(it['quantity'] as int),
        lineTotalPaisa: Value(it['lineTotalPaisa'] as int),
      ));
    }
    return tallyId;
  }

  Future<DailyClosing?> getDailyClosing(String ymd) =>
      (db.select(db.dailyClosings)
            ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid) & t.txnDate.equals(ymd)))
          .getSingleOrNull();

  Stream<List<DailyClosing>> watchDailyClosings() {
    return (db.select(db.dailyClosings)
          ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid))
          ..orderBy([(t) => OrderingTerm.desc(t.txnDate)]))
        .watch();
  }

  // ---------- অ্যাটাচমেন্ট ----------

  Future<String> attach({
    required String ownerType,
    required String ownerId,
    required String localPath,
    String? mime,
    int? sizeBytes,
  }) {
    return insert(db.attachments, AttachmentsCompanion.insert(
        id: '', userId: '',
      ownerType: ownerType,
      ownerId: ownerId,
      localPath: localPath,
      mime: Value(mime),
      sizeBytes: Value(sizeBytes),
    ));
  }

  Future<List<Attachment>> attachmentsFor(String ownerId) =>
      (db.select(db.attachments)
            ..where((t) => t.deletedAt.isNull() & t.ownerId.equals(ownerId)))
          .get();

  // ---------- সিঙ্ক সাপোর্ট ----------

  Future<int> pendingCount() async => (await db.select(db.syncQueue).get()).length;

  /// V1.3.1: sync_status='pending' অথচ কিউতে নেই — এমন এতিম রো আবার
  /// কিউতে তোলা। কোনো রো বারবার ব্যর্থ হয়ে কিউ-ক্যাপে (maxAttempts)
  /// বাদ পড়লেও লোকাল রো pending থেকে যেত; সার্ভার-সমস্যা (যেমন missing
  /// কলাম) ঠিক হওয়ার পর এই sweep-ই সেটাকে আবার সিঙ্কের পথে আনে —
  /// নইলে ডাটা চিরদিন শুধু ফোনেই থেকে যেত।
  Future<int> reenqueueOrphanPending() async {
    if (!Supa.isLoggedIn) return 0;
    var count = 0;
    final queued = await db.select(db.syncQueue).get();
    final queuedKeys = queued.map((q) => '${q.targetTable}:${q.rowId}').toSet();
    for (final name in userTables) {
      final tbl = _tableByName(name);
      final rows = await (db.select(tbl)
            ..where((t) => (t as dynamic).syncStatus.equals('pending')))
          .get();
      for (final row in rows) {
        final rid = (row as dynamic).id as String;
        if (queuedKeys.contains('$name:$rid')) continue;
        await _enqueueRow(tbl, rid);
        count++;
      }
    }
    return count;
  }

  Stream<int> watchPendingCount() =>
      (db.select(db.syncQueue)).watch().map((rows) => rows.length);

  Future<List<SyncQueueData>> pendingBatch({int limit = 100}) =>
      (db.select(db.syncQueue)..orderBy([(t) => OrderingTerm.asc(t.id)])..limit(limit)).get();

  Future<void> removeQueueIds(List<int> ids) {
    final q = db.delete(db.syncQueue);
    return (q..where((t) => t.id.isIn(ids))).go();
  }

  Future<void> markQueueError(int id, int attempts, String error) {
    return (db.update(db.syncQueue)..where((t) => t.id.equals(id))).write(
      SyncQueueCompanion(attempts: Value(attempts), lastError: Value(error)),
    );
  }

  Future<String?> getMeta(String key) async {
    final row = await (db.select(db.syncMeta)..where((t) => t.key.equals(key)))
        .getSingleOrNull();
    return row?.value;
  }

  Future<void> setMeta(String key, String value) async {
    // FIX C-4: insertOrReplace ছাড়া দ্বিতীয় conflict-এই crash হতো
    await db.into(db.syncMeta).insert(
          SyncMetaCompanion.insert(key: key, value: Value(value)),
          mode: InsertMode.insertOrReplace,
        );
  }

  Future<void> incrementConflict(String tableName, String rowId, String serverJson) async {
    final key = 'conflict:$tableName:$rowId';
    // V1.3: একই রো বারবার conflict হলে কাউন্টার বাড়বে না (আগে over-count হতো)
    final isNew = await getMeta(key) == null;
    await setMeta(key, serverJson);
    if (isNew) {
      final cur = await getMeta('conflict_count');
      await setMeta('conflict_count', '${(int.tryParse(cur ?? '0') ?? 0) + 1}');
    }
  }

  // ---------- V1.3: Conflict সমাধান (ফিচার ২, সিদ্ধান্ত: প্রতিবার জিজ্ঞাসা) ----------

  /// জমে থাকা সব conflict — (table, rowId, serverJson)
  Future<List<({String table, String rowId, Map<String, dynamic> server})>> listConflicts() async {
    final rows = await db.select(db.syncMeta).get();
    final out = <({String table, String rowId, Map<String, dynamic> server})>[];
    for (final r in rows) {
      if (!r.key.startsWith('conflict:') || r.key == 'conflict_count') continue;
      final parts = r.key.split(':');
      if (parts.length < 3) continue;
      try {
        final server = Map<String, dynamic>.from(jsonDecode(r.value ?? '{}') as Map);
        out.add((table: parts[1], rowId: parts.sublist(2).join(':'), server: server));
      } catch (_) {}
    }
    return out;
  }

  /// লোকাল রো-র বর্তমান মান (সার্ভার-ফরম্যাটে) — পাশাপাশি তুলনার জন্য
  Future<Map<String, dynamic>?> getLocalRowJson(String tableName, String rowId) async {
    final tbl = _tableByName(tableName);
    final row = await (db.select(tbl)..where((t) => (t as dynamic).id.equals(rowId)))
        .getSingleOrNull();
    if (row == null) return null;
    return SyncPayload.of(row as Insertable<dynamic>, table: tableName);
  }

  Future<void> _deleteMeta(String key) async {
    await (db.delete(db.syncMeta)..where((t) => t.key.equals(key))).go();
  }

  Future<void> _recountConflicts() async {
    final all = await listConflicts();
    await setMeta('conflict_count', '${all.length}');
  }

  /// সিদ্ধান্ত: সার্ভারের কপি রাখা — লোকাল pending বাইপাস করে প্রয়োগ,
  /// ওই রো-র pending queue এন্ট্রি ফেলে দেওয়া হয়।
  Future<void> resolveConflictKeepServer(String tableName, String rowId) async {
    final stored = await getMeta('conflict:$tableName:$rowId');
    if (stored != null) {
      final json = Map<String, dynamic>.from(jsonDecode(stored) as Map);
      final tbl = _tableByName(tableName);
      final cols = SyncPayload.serverRowValues(tbl, json);
      cols['sync_status'] = 'synced';
      if (!cols.containsKey('user_id') && tbl.$columns.any((c) => c.name == 'user_id')) {
        cols['user_id'] = uid;
      }
      await _customInsertRow(tbl, cols, replace: true);
    }
    await (db.delete(db.syncQueue)
          ..where((t) => t.targetTable.equals(tableName) & t.rowId.equals(rowId)))
        .go();
    await _deleteMeta('conflict:$tableName:$rowId');
    await _recountConflicts();
    onLocalChange?.call();
  }

  // ---------- V1.5.0: version reconciliation সাপোর্ট ----------

  /// সার্ভারের version গ্রহণ (adopt): content normalized-ভাবে সমান প্রমাণ
  /// হলে লোকাল row-র version সার্ভারেরটায় বসিয়ে sync_status='synced'
  /// করা হয় — content-এ হাত দেওয়া হয় না, updated_at-ও বদলায় না।
  /// (v1.4.x-এ profiles version 6 বনাম লোকাল কম থাকায় fail-closed
  /// version-check চিরদিন push আটকে রাখত, যদিও content একই ছিল।)
  Future<void> adoptServerVersion(String tableName, String rowId, int serverVersion) async {
    final tbl = _tableByName(tableName);
    await _customUpdateRow(tbl, {
      'version': serverVersion,
      'sync_status': 'synced',
    }, rowId);
  }

  /// জমে থাকা conflict মুছে count ঠিক করা — adopt-এর পর পুরনো (ভুয়া)
  /// conflict পরিষ্কার করতে SyncEngine/pull ব্যবহার করে।
  Future<void> clearConflict(String tableName, String rowId) async {
    await _deleteMeta('conflict:$tableName:$rowId');
    await _recountConflicts();
  }

  /// সিদ্ধান্ত: নিজের (লোকাল) কপি রাখা — version সার্ভারের চেয়ে বাড়িয়ে
  /// queue-তে তোলা হয়, যাতে পরের push-এ version-check পাস করে।
  Future<void> resolveConflictKeepLocal(String tableName, String rowId) async {
    final stored = await getMeta('conflict:$tableName:$rowId');
    var serverVersion = 0;
    if (stored != null) {
      try {
        final json = Map<String, dynamic>.from(jsonDecode(stored) as Map);
        serverVersion = (json['version'] as num?)?.toInt() ?? 0;
      } catch (_) {}
    }
    final tbl = _tableByName(tableName);
    await _customUpdateRow(tbl, {
      'version': serverVersion + 1,
      'updated_at': _nowIso,
      'sync_status': 'pending',
    }, rowId);
    await _enqueueRow(tbl, rowId);
    await _deleteMeta('conflict:$tableName:$rowId');
    await _recountConflicts();
    onLocalChange?.call();
  }

  // ---------- V1.4.1: গেস্ট গণনা ও অ্যাকাউন্ট-উপস্থিতি (docs/08 ফ্লো B/C) ----------

  /// গেস্ট (user_id='local') ডাটার গণনা + টাকার সারাংশ — লগইনের সম্মতি
  /// dialog-এ দেখাতে (docs/08 §4.3)। profiles-এ user_id কলাম নেই; নাম
  /// দেওয়া থাকলেই কেবল লোকাল প্রোফাইলটাকে "এন্ট্রি" ধরা হয় (seed-এর
  /// খালি প্রোফাইল গুনলে dialog ভুলভাবে সবসময় আসত)।
  Future<GuestDataSummary> countLocalGuestData() async {
    final perTable = <String, int>{};
    var total = 0;
    for (final name in userTables) {
      final int c;
      if (name == 'profiles') {
        final rows = await db.customSelect(
          "SELECT COUNT(*) AS c FROM profiles WHERE id = 'local' "
          "AND deleted_at IS NULL AND IFNULL(display_name, '') <> ''",
        ).get();
        c = rows.first.read<int>('c');
      } else {
        final tbl = _tableByName(name);
        final rows = await db.customSelect(
          'SELECT COUNT(*) AS c FROM ${tbl.entityName} '
          'WHERE user_id = ? AND deleted_at IS NULL',
          variables: [Variable.withString('local')],
          readsFrom: {tbl},
        ).get();
        c = rows.first.read<int>('c');
      }
      if (c > 0) perTable[name] = c;
      total += c;
    }

    Future<int> guestSum(String table, String column) async {
      final tbl = _tableByName(table);
      final rows = await db.customSelect(
        'SELECT CAST(COALESCE(SUM($column), 0) AS INTEGER) AS s '
        'FROM ${tbl.entityName} WHERE user_id = ? AND deleted_at IS NULL',
        variables: [Variable.withString('local')],
        readsFrom: {tbl},
      ).get();
      return rows.first.read<int>('s');
    }

    final income = await guestSum('income_hat', 'amount_paisa') +
        await guestSum('income_personal', 'amount_paisa');
    final expense = await guestSum('expenses', 'amount_paisa');
    final loan = await guestSum('loans', 'principal_paisa');
    return GuestDataSummary(
      perTable: perTable,
      totalCount: total,
      incomePaisa: income,
      expensePaisa: expense,
      loanPaisa: loan,
    );
  }

  /// এই ডিভাইসে ওই uid-র কোনো ডাটা আগে থেকেই আছে কিনা — অন্য ফোন থেকে
  /// প্রথম লগইন (ফ্লো C) চেনার জন্য (docs/08 §5)।
  Future<bool> hasLocalDataForUser(String userId) async {
    final p = await db.customSelect(
      'SELECT COUNT(*) AS c FROM profiles WHERE id = ?',
      variables: [Variable.withString(userId)],
    ).get();
    if (p.first.read<int>('c') > 0) return true;
    for (final name in userTables) {
      if (name == 'profiles') continue;
      final tbl = _tableByName(name);
      final rows = await db.customSelect(
        'SELECT COUNT(*) AS c FROM ${tbl.entityName} WHERE user_id = ?',
        variables: [Variable.withString(userId)],
        readsFrom: {tbl},
      ).get();
      if (rows.first.read<int>('c') > 0) return true;
    }
    return false;
  }

  /// সার্ভার থেকে আসা সারি লোকালে প্রয়োগ
  Future<void> applyServerRow(String tableName, Map<String, dynamic> json) async {
    final tbl = _tableByName(tableName);
    final id = json['id'] as String?;
    if (id == null) return;
    // ★ V1.4.1 (F-01): লোকালে row আছে কিনা + pending কিনা — একটাই raw SQL
    // query দিয়ে। আগের কোডে দুটো dynamic select ছিল; দ্বিতীয়টায়
    // `(t as dynamic).id.equals(id) & (t as dynamic).syncStatus...` —
    // Drift-এর Expression<bool>.operator & হলো EXTENSION method, যা
    // dynamic dispatch-এ দেখা যায় না → লোকালে row থাকলেই প্রতিটা টেবিলের
    // pull `NoSuchMethodError: Class '_Zx' has no instance method '&'`
    // দিয়ে ভাঙত (v1.4.0-এর সিঙ্ক-ব্যর্থতার মূল কারণ)। খালি-DB টেস্টে
    // ওই শাখায় ঢোকা হতো না বলে এতদিন ধরা পড়েনি।
    final existing = await db.customSelect(
      'SELECT sync_status FROM ${tbl.entityName} WHERE id = ?',
      variables: [Variable.withString(id)],
      readsFrom: {tbl},
    ).get();
    if (existing.isNotEmpty) {
      // লোকালে অসিঙ্কড পরিবর্তন থাকলে কনফ্লিক্ট — দুটোই রাখা হয় (05_Schema §7)
      final status = existing.first.data['sync_status'] as String?;
      if (status == 'pending') {
        // ★ V1.5.0: pending হলেও content normalized-ভাবে সমান হলে এটা
        // conflict নয় — নিজেরই push করা কপি pull-এ ফিরে এসেছে (শুধু
        // timestamp-ফরম্যাট আলাদা)। সার্ভার কপি প্রয়োগ করে synced করা
        // হয়; জমে থাকা ভুয়া conflict-ও পরিষ্কার হয়।
        final localJson = await getLocalRowJson(tableName, id);
        if (localJson != null && SyncCompare.rowsEqual(json, localJson)) {
          await clearConflict(tableName, id);
          // নিচের সাধারণ apply পথেই যাবে
        } else {
          await incrementConflict(tableName, id, jsonEncode(json));
          return;
        }
      }
    } else if (tableName == 'wallets' || tableName == 'categories') {
      // ★ V1.5.0 (D): natural-key dedupe — সার্ভার row-র id লোকালে নেই,
      // কিন্তু একই natural key-র লোকাল row (ভিন্ন id) থাকলে সেটার উপরেই
      // সার্ভার content বসে, লোকাল id-ই থাকে; নতুন row ঢোকে না। এটাই
      // পুরনো seed-ডুপ্লিকেটগুলোকে pull-এ আবার জন্ম নেওয়া থেকে আটকায়।
      final match = await _findNaturalKeyMatch(tableName, json);
      if (match != null) {
        await _applyOntoLocalRow(tableName, tbl, json, match);
        return;
      }
    }
    final cols = SyncPayload.serverRowValues(tbl, json);
    cols['sync_status'] = 'synced';
    // প্রোফাইলের সার্ভার-রোতে user_id নেই — লোকাল কলাম NOT NULL
    if (!cols.containsKey('user_id') &&
        tbl.$columns.any((c) => c.name == 'user_id')) {
      cols['user_id'] = uid;
    }
    await _customInsertRow(tbl, cols, replace: true);
  }

  /// V1.5.0 (D): wallets/categories-এর natural-key মিল খোঁজা — বর্তমান
  /// scope-এ জীবিত (deleted_at IS NULL) লোকাল row, যার id সার্ভার id
  /// থেকে আলাদা। wallets: শুধু ৪টা default seed (name,type) pair-এর
  /// ক্ষেত্রে (user-তৈরি wallet কখনো জোর করে মেলানো হয় না);
  /// categories: (name, scope)। মিল না থাকলে null।
  Future<dynamic> _findNaturalKeyMatch(String tableName, Map<String, dynamic> json) async {
    final serverId = json['id'] as String?;
    if (tableName == 'wallets') {
      final name = json['name'] as String?;
      final type = json['type'] as String?;
      if (name == null || type == null || seedWalletTypeOf(name, type) == null) {
        return null;
      }
      final rows = await (db.select(db.wallets)
            ..where((t) =>
                t.userId.equals(uid) &
                t.name.equals(name) &
                t.type.equals(type) &
                t.deletedAt.isNull())
            ..orderBy([(t) => OrderingTerm.asc(t.createdAt)]))
          .get();
      for (final r in rows) {
        if (r.id != serverId) return r;
      }
      return null;
    }
    if (tableName == 'categories') {
      final name = json['name'] as String?;
      if (name == null) return null;
      final scope = (json['scope'] as String?) ?? 'expense';
      final rows = await (db.select(db.categories)
            ..where((t) =>
                t.userId.equals(uid) &
                t.name.equals(name) &
                t.scope.equals(scope) &
                t.deletedAt.isNull())
            ..orderBy([(t) => OrderingTerm.asc(t.createdAt)]))
          .get();
      for (final r in rows) {
        if (r.id != serverId) return r;
      }
      return null;
    }
    return null;
  }

  /// V1.5.0 (D): সার্ভার content লোকাল [match] row-র উপর প্রয়োগ — লোকাল
  /// id অক্ষত থাকে। লোকাল row pending হলে আগে normalized তুলনা: সমান
  /// হলে adopt, আলাদা হলে conflict (সার্ভার id-র নামে) — ডুপ্লিকেট
  /// row কোনো অবস্থাতেই ঢোকে না।
  Future<void> _applyOntoLocalRow(
      String tableName, TableInfo tbl, Map<String, dynamic> json, dynamic match) async {
    final localId = (match as dynamic).id as String;
    final localStatus = (match as dynamic).syncStatus as String?;
    if (localStatus == 'pending') {
      final localJson = SyncPayload.of(match as Insertable<dynamic>, table: tableName);
      if (!SyncCompare.rowsEqual(json, localJson)) {
        await incrementConflict(tableName, json['id'] as String, jsonEncode(json));
        return;
      }
    }
    final cols = SyncPayload.serverRowValues(tbl, json);
    cols['id'] = localId;
    cols['sync_status'] = 'synced';
    if (!cols.containsKey('user_id') &&
        tbl.$columns.any((c) => c.name == 'user_id')) {
      cols['user_id'] = uid;
    }
    await _customInsertRow(tbl, cols, replace: true);
    await clearConflict(tableName, localId);
    await clearConflict(tableName, json['id'] as String);
  }

  /// গেস্ট → অ্যাকাউন্ট মাইগ্রেশন (05_Schema §5, docs/08 ফ্লো B)
  /// V1.4.1 (G-13): (ক) UPDATE-এর সঙ্গে sync_status='pending'-ও সেট হয়;
  /// (খ) queue-তে ওঠে শুধু সত্যিকারে migrate হওয়া row (আগে ওই uid-র সব
  /// row — পুরনো synced-সহ — আবার queue-তে যেত ও count ভুল হতো);
  /// (গ) queue-insert-এর আগে ওই row-র পুরনো entry মোছা হয় — re-login-এ
  /// duplicate queue entry জমে না। ফেরত count = migrate হওয়া row সংখ্যা।
  Future<int> migrateLocalDataToUser(String newUid) async {
    var count = 0;
    final migratedIds = <String, List<String>>{};
    var profileMigrated = false;
    await db.transaction(() async {
      for (final name in userTables) {
        // FIX C-3: profiles-এ userId কলাম নেই — generic লুপে crash হতো;
        // প্রোফাইল নিচে আলাদাভাবে সামলানো হয়
        if (name == 'profiles') continue;
        final tbl = _tableByName(name);
        // কোন row গুলো migrate হচ্ছে — UPDATE-এর আগেই ধরে রাখা হয়
        final idRows = await db.customSelect(
          'SELECT id FROM ${tbl.entityName} WHERE user_id = ?',
          variables: [Variable.withString('local')],
          readsFrom: {tbl},
        ).get();
        if (idRows.isEmpty) continue;
        migratedIds[name] =
            idRows.map((r) => r.read<String>('id')).toList();
        await db.customUpdate(
          'UPDATE ${tbl.entityName} SET user_id = ?, sync_status = ? '
          'WHERE user_id = ?',
          variables: [
            Variable.withString(newUid),
            Variable.withString('pending'),
            Variable.withString('local'),
          ],
          updates: {tbl},
          updateKind: UpdateKind.update,
        );
      }
      // প্রোফাইল 'local' রো নতুন uid-তে
      final localProfile = await (db.select(db.profiles)..where((t) => t.id.equals('local')))
          .getSingleOrNull();
      if (localProfile != null) {
        await (db.delete(db.profiles)..where((t) => t.id.equals('local'))).go();
        final existingRemote = await (db.select(db.profiles)..where((t) => t.id.equals(newUid)))
            .getSingleOrNull();
        if (existingRemote == null) {
          await db.into(db.profiles).insert(
                localProfile.toCompanion(false).copyWith(id: Value(newUid)),
              );
          profileMigrated = true;
        }
      }
    });
    // FIX H-3: শুধু এই অ্যাকাউন্টের সারিই কিউতে — আগের অ্যাকাউন্টের ডাটা
    // নতুন অ্যাকাউন্টে উঠে যেত (cross-account leakage)
    if (Supa.isLoggedIn) {
      Future<void> enqueueMigrated(String name, TableInfo tbl, String rid) async {
        final row = await (db.select(tbl)
              ..where((t) => (t as dynamic).id.equals(rid)))
            .getSingleOrNull();
        if (row == null) return;
        final payload = SyncPayload.of(row, table: name);
        if (name != 'profiles') payload['user_id'] = newUid;
        // duplicate রোধ: একই row-র পুরনো queue entry আগে মোছা
        await (db.delete(db.syncQueue)
              ..where((t) => t.targetTable.equals(name) & t.rowId.equals(rid)))
            .go();
        await db.into(db.syncQueue).insert(SyncQueueCompanion.insert(
              targetTable: name,
              rowId: rid,
              operation: 'upsert',
              payloadJson: Value(jsonEncode(payload)),
              createdAt: Value(DateTime.now().millisecondsSinceEpoch),
            ));
        count++;
      }

      for (final entry in migratedIds.entries) {
        final tbl = _tableByName(entry.key);
        for (final rid in entry.value) {
          await enqueueMigrated(entry.key, tbl, rid);
        }
      }
      if (profileMigrated) {
        await enqueueMigrated('profiles', db.profiles, newUid);
      }
    }
    return count;
  }

  // ---------- ব্যাকআপ / রিস্টোর ----------

  Future<Map<String, dynamic>> exportAll() async {
    final out = <String, dynamic>{};
    for (final name in userTables) {
      final tbl = _tableByName(name);
      // FIX M-11: মোছা সারি ব্যাকআপে যাবে না
      final rows = await (db.select(tbl)
            ..where((t) => (t as dynamic).deletedAt.isNull()))
          .get();
      out[name] = rows.map((r) => SyncPayload.of(r, table: name)).toList();
    }
    out['_meta'] = {'exported_at': _nowIso, 'app': 'hat-hisab', 'version': 2};
    return out;
  }

  Future<int> importAll(Map<String, dynamic> data) async {
    var count = 0;
    // FIX H-5/M-11: পুরো import এক transaction-এ; সারির user_id বর্তমান
    // ব্যবহারকারীর করা হয়, নইলে restore করা ডাটা অদৃশ্য থাকত
    await db.transaction(() async {
      for (final name in userTables) {
        if (!data.containsKey(name)) continue;
        final tbl = _tableByName(name);
        final list = data[name] as List<dynamic>? ?? [];
        for (final rawRow in list) {
          final row = Map<String, dynamic>.from(rawRow as Map);
          final cols = SyncPayload.serverRowValues(tbl, row);
          cols['sync_status'] = 'pending';
          if (name == 'profiles') {
            cols['id'] = uid;
          } else if (tbl.$columns.any((c) => c.name == 'user_id')) {
            cols['user_id'] = uid;
          }
          await _customInsertRow(tbl, cols, replace: true);
          count++;
        }
      }
    });
    onLocalChange?.call();
    return count;
  }

  // ---------- V1.5.0 (D): seed natural-key ও ডুপ্লিকেট merge ----------

  /// default seed wallet-এর (name, type) pair — wallets টেবিলে is_system
  /// ফ্ল্যাগ নেই, তাই এই pair-গুলোই seed-এর marker। এর বাইরের wallet
  /// কখনো natural-key dedupe/merge-এর আওতায় আসে না (user নিজে দ্বিতীয়
  /// cash wallet বানালে সেটা তার নিজের, merge হবে না)।
  static const List<(String, String)> seedWalletPairs = [
    ('নগদ', 'cash'),
    ('বিকাশ', 'bkash'),
    ('নগদ (মোবাইল ব্যাংকিং)', 'nagad'),
    ('ব্যাংক', 'bank'),
  ];

  /// (name, type) seed pair হলে type, নাহলে null
  static String? seedWalletTypeOf(String name, String type) {
    for (final (n, t) in seedWalletPairs) {
      if (n == name && t == type) return t;
    }
    return null;
  }

  /// wallet_id কলাম আছে এমন সব টেবিল — merge-এ reference গণনা/repoint-এ লাগে
  static const List<String> walletRefTables = [
    'hat_sessions', 'income_hat', 'income_personal', 'expenses',
    'mother_payments', 'dps_transactions', 'loans', 'loan_payments',
    'fuel_logs', 'bike_maintenance', 'cash_tallies',
  ];

  Future<int> _walletRefCount(String walletId) async {
    var total = 0;
    for (final name in walletRefTables) {
      final tbl = _tableByName(name);
      final rows = await db.customSelect(
        'SELECT COUNT(*) AS c FROM ${tbl.entityName} WHERE wallet_id = ?',
        variables: [Variable.withString(walletId)],
        readsFrom: {tbl},
      ).get();
      total += rows.first.read<int>('c');
    }
    return total;
  }

  Future<void> _repointWalletRefs(String fromId, String toId) async {
    // wallet id globally unique — referencing row-র scope যা-ই হোক repoint নিরাপদ
    for (final name in walletRefTables) {
      final tbl = _tableByName(name);
      await db.customUpdate(
        'UPDATE ${tbl.entityName} SET wallet_id = ? WHERE wallet_id = ?',
        variables: [Variable.withString(toId), Variable.withString(fromId)],
        updates: {tbl},
        updateKind: UpdateKind.update,
      );
    }
  }

  Future<int> _categoryRefCount(String categoryId) async {
    final rows = await db.customSelect(
      'SELECT COUNT(*) AS c FROM expenses WHERE category_id = ?',
      variables: [Variable.withString(categoryId)],
      readsFrom: {db.expenses},
    ).get();
    return rows.first.read<int>('c');
  }

  /// V1.5.0 (D): লোকাল seed-ডুপ্লিকেট merge — অ্যাপ স্টার্টে একবার চলে
  /// (main.dart), idempotent (ডুপ্লিকেট না থাকলে কিছুই করে না)।
  /// বর্তমান scope ও 'local' scope — দুটোতেই: wallets seed-pair অনুযায়ী
  /// type-ভিত্তিক, categories (name, scope) অনুযায়ী group করা হয়।
  /// group > 1 হলে keeper = সবচেয়ে বেশি referenced (tie → earliest
  /// created_at → ছোট id); বাকিগুলোর সব reference keeper-এ repoint করে
  /// dupe soft-delete করা হয় এবং (লগইন থাকলে) tombstone upsert queue-তে
  /// ওঠে — ফলে সার্ভারের কপিগুলোও পরের push-এ soft-delete হয়ে যায়।
  /// পুরোটা এক transaction-এ। ফেরত: merge হওয়া dupe সংখ্যা।
  Future<int> mergeDuplicateSeeds() async {
    var merged = 0;
    final scopes = <String>{uid, 'local'};
    await db.transaction(() async {
      for (final scope in scopes) {
        merged += await _mergeWalletDupes(scope);
        merged += await _mergeCategoryDupes(scope);
      }
    });
    if (merged > 0) onLocalChange?.call();
    return merged;
  }

  Future<int> _mergeWalletDupes(String scope) async {
    final rows = await (db.select(db.wallets)
          ..where((t) => t.userId.equals(scope) & t.deletedAt.isNull()))
        .get();
    final groups = <String, List<Wallet>>{};
    for (final w in rows) {
      final type = seedWalletTypeOf(w.name, w.type);
      if (type == null) continue;
      groups.putIfAbsent(type, () => []).add(w);
    }
    var merged = 0;
    for (final group in groups.values) {
      if (group.length < 2) continue;
      final scored = <(Wallet, int)>[];
      for (final w in group) {
        scored.add((w, await _walletRefCount(w.id)));
      }
      scored.sort((a, b) {
        final byRef = b.$2.compareTo(a.$2); // বেশি referenced আগে
        if (byRef != 0) return byRef;
        final byCreated = a.$1.createdAt.compareTo(b.$1.createdAt);
        if (byCreated != 0) return byCreated;
        return a.$1.id.compareTo(b.$1.id);
      });
      final keeper = scored.first.$1;
      for (final s in scored.skip(1)) {
        final dupe = s.$1;
        await _repointWalletRefs(dupe.id, keeper.id);
        await _customUpdateRow(db.wallets, {
          'deleted_at': _nowIso,
          'updated_at': _nowIso,
          'sync_status': 'pending',
        }, dupe.id, bumpVersion: true);
        await _enqueueRow(db.wallets, dupe.id);
        merged++;
      }
    }
    return merged;
  }

  Future<int> _mergeCategoryDupes(String scope) async {
    final rows = await (db.select(db.categories)
          ..where((t) => t.userId.equals(scope) & t.deletedAt.isNull()))
        .get();
    final groups = <String, List<Category>>{};
    for (final c in rows) {
      groups.putIfAbsent('${c.name}|${c.scope}', () => []).add(c);
    }
    var merged = 0;
    for (final group in groups.values) {
      if (group.length < 2) continue;
      final scored = <(Category, int)>[];
      for (final c in group) {
        scored.add((c, await _categoryRefCount(c.id)));
      }
      scored.sort((a, b) {
        final byRef = b.$2.compareTo(a.$2);
        if (byRef != 0) return byRef;
        final byCreated = a.$1.createdAt.compareTo(b.$1.createdAt);
        if (byCreated != 0) return byCreated;
        return a.$1.id.compareTo(b.$1.id);
      });
      final keeper = scored.first.$1;
      for (final s in scored.skip(1)) {
        final dupe = s.$1;
        await db.customUpdate(
          'UPDATE expenses SET category_id = ? WHERE category_id = ?',
          variables: [Variable.withString(keeper.id), Variable.withString(dupe.id)],
          updates: {db.expenses},
          updateKind: UpdateKind.update,
        );
        await _customUpdateRow(db.categories, {
          'deleted_at': _nowIso,
          'updated_at': _nowIso,
          'sync_status': 'pending',
        }, dupe.id, bumpVersion: true);
        await _enqueueRow(db.categories, dupe.id);
        merged++;
      }
    }
    return merged;
  }

  // ---------- সিড ডাটা (05_Schema §9) ----------

  Future<void> seedIfNeeded() async {
    // ★ V1.5.0 (D): seed-once — টেবিলে যেকোনো scope-এ row থাকলেই আর seed
    // হয় না; আর seed id deterministic (scope+table+natural-key থেকে)।
    // আগে প্রতিটা seeding wave (গেস্ট → লগইন → দ্বিতীয় ডিভাইস) নতুন
    // random id-তে আলাদা row বানাত — সার্ভারে প্রতিটা seed wallet/
    // category ২–৫ কপি হয়ে যেত। emptiness snapshot দুটোই seed শুরুর
    // আগেই নেওয়া হয় (block-গুলো পরপর চলে; মাঝের insert দেখে পরের
    // block ভুলভাবে skip করত)।
    final scope = uid;
    Future<bool> tableEmpty(String name) async {
      final tbl = _tableByName(name);
      final rows = await db.customSelect(
        'SELECT COUNT(*) AS c FROM ${tbl.entityName}',
        readsFrom: {tbl},
      ).get();
      return rows.first.read<int>('c') == 0;
    }

    final walletsEmpty = await tableEmpty('wallets');
    final categoriesEmpty = await tableEmpty('categories');
    // v1.2: আয়ের খাত সিড (পুরনো ইনস্টলে একবার)
    if (await getSetting('seeded_income_v3') != '1') {
      if (categoriesEmpty) {
        final heads = [
          ['বিক্রির আয়', '💵'],
          ['বেতন', '💼'],
          ['ব্যবসার লাভ', '📈'],
          ['বাড়ি ভাড়া', '🏠'],
          ['অন্যান্য আয়', '✨'],
        ];
        for (var i = 0; i < heads.length; i++) {
          await insert(db.categories, CategoriesCompanion.insert(
            id: '', userId: '',
            name: heads[i][0],
            icon: Value(heads[i][1]),
            scope: const Value('income'),
            isSystem: const Value(true),
            sortOrder: Value(100 + i),
          ), id: SyncPayload.deterministicSeedId(scope, 'categories', '${heads[i][0]}|income'));
        }
      }
      await setSetting('seeded_income_v3', '1');
    }
    // V1.3 (docs/07): সেশন-খরচের ধরন — ব্যবহারকারীর নিজের তালিকা
    if (await getSetting('seeded_session_v1') != '1') {
      if (categoriesEmpty) {
        final sessionCats = [
          ['মসজিদের দান', '🕌'],
          ['লেবার', '👷'],
          ['নাস্তা', '🍞'],
          ['সিগারেট', '🚬'],
          ['খাজনা', '🧾'],
          ['সুতলি', '🧵'],
          ['কোমল পানীয়', '🥤'],
        ];
        for (var i = 0; i < sessionCats.length; i++) {
          await insert(db.categories, CategoriesCompanion.insert(
            id: '', userId: '',
            name: sessionCats[i][0],
            icon: Value(sessionCats[i][1]),
            scope: const Value('expense'),
            isSystem: const Value(true),
            sortOrder: Value(200 + i),
          ), id: SyncPayload.deterministicSeedId(scope, 'categories', '${sessionCats[i][0]}|expense'));
        }
      }
      await setSetting('seeded_session_v1', '1');
    }
    // V1.3 (docs/07): পেঁয়াজের ধরনগুলো আগে থেকে তৈরি থাকবে
    if (await getSetting('seeded_products_v1') != '1') {
      for (final typeName in ['দেশি ১', 'দেশী ২', 'সুখসাগর']) {
        await upsertProduct(typeName);
      }
      await setSetting('seeded_products_v1', '1');
    }
    final seeded = await getSetting('seeded_v1');
    if (seeded == '1') return;
    // V1.5.0 (D): seed-once + deterministic id (উপরে দেখুন) — wallet-এর
    // natural key = type, category-র = (name, scope)।
    if (walletsEmpty) {
      final wallets = [
        {'name': 'নগদ', 'type': 'cash'},
        {'name': 'বিকাশ', 'type': 'bkash'},
        {'name': 'নগদ (মোবাইল ব্যাংকিং)', 'type': 'nagad'},
        {'name': 'ব্যাংক', 'type': 'bank'},
      ];
      for (final w in wallets) {
        await insert(db.wallets, WalletsCompanion.insert(
          id: '', userId: '',
          name: w['name'] as String,
          type: Value(w['type'] as String),
        ), id: SyncPayload.deterministicSeedId(scope, 'wallets', w['type'] as String));
      }
    }
    if (categoriesEmpty) {
      final cats = [
        ['খাবার', '🍛', '#1B7A43'],
        ['যাতায়াত', '🛺', '#F2A93B'],
        ['মোবাইল/ইন্টারনেট', '📱', '#0277BD'],
        ['স্বাস্থ্য', '💊', '#C62828'],
        ['কাপড়', '👕', '#6A1B9A'],
        ['বিনোদন', '🎬', '#00838F'],
        ['বাড়ি ভাড়া/ইউটিলিটি', '🏠', '#5D4037'],
        ['বাইক', '🏍️', '#4527A0'],
        ['অন্যান্য', '📦', '#455A64'],
      ];
      for (var i = 0; i < cats.length; i++) {
        await insert(db.categories, CategoriesCompanion.insert(
          id: '', userId: '',
          name: cats[i][0],
          icon: Value(cats[i][1]),
          colorHex: Value(cats[i][2]),
          scope: const Value('both'),
          isSystem: const Value(true),
          sortOrder: Value(i),
        ), id: SyncPayload.deterministicSeedId(scope, 'categories', '${cats[i][0]}|both'));
      }
    }
    await saveProfileFields(displayName: '');
    await setSetting('seeded_v1', '1');
  }
}
