import 'dart:convert';

import 'package:drift/drift.dart';
import 'package:uuid/uuid.dart';

import '../app_database.dart';
import '../../remote/supabase_client.dart';
import '../../../core/sync/sync_payload.dart';

/// V1.4 FinTrack পোর্ট — বাজেট ও সেভিংস গোলের ডাটা-অ্যাক্সেস।
/// V1.4.1 (G-11): টেবিল দুটো এখন সার্ভারেও আছে ও AppRepository.userTables-এ
/// যুক্ত — তাই প্রতিটি লেখায় sync_status='pending' বসে এবং লগইন থাকলে
/// সিঙ্ক-কিউতে ওঠে (AppRepository._enqueueRow-এর হুবহু প্যাটার্ন)। লগইন না
/// থাকলে pending-ই যথেষ্ট: পরের সিঙ্কের reenqueueOrphanPending sweep ধরে।
class FinanceRepository {
  FinanceRepository(this.db);
  final AppDatabase db;
  final Uuid _uuid = const Uuid();

  String get uid => Supa.uidOrDefault;
  String get _nowIso => DateTime.now().toUtc().toIso8601String();

  /// AppRepository._enqueueRow-এর সমতুল্য (finance টেবিলের জন্য)।
  Future<void> _enqueue(String table, String id) async {
    if (!Supa.isLoggedIn) return;
    final TableInfo tbl =
        table == 'monthly_budgets' ? db.monthlyBudgets : db.savingsGoals;
    final row = await (db.select(tbl)..where((t) => (t as dynamic).id.equals(id)))
        .getSingleOrNull();
    if (row == null) return;
    final payload = SyncPayload.of(row, table: table);
    await db.into(db.syncQueue).insert(SyncQueueCompanion.insert(
          targetTable: table,
          rowId: id,
          operation: 'upsert',
          payloadJson: Value(jsonEncode(payload)),
          createdAt: Value(DateTime.now().millisecondsSinceEpoch),
        ));
  }

  // ---------- বাজেট ----------

  Stream<List<MonthlyBudget>> watchBudgets(String month) {
    return (db.select(db.monthlyBudgets)
          ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid) & t.month.equals(month))
          ..orderBy([(t) => OrderingTerm.asc(t.category)]))
        .watch();
  }

  Future<List<MonthlyBudget>> getBudgets(String month) {
    return (db.select(db.monthlyBudgets)
          ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid) & t.month.equals(month)))
        .get();
  }

  /// একই (category, month)-এ আগের লিমিট থাকলে আপডেট, নাহলে নতুন রো
  Future<void> setBudget({
    required String category,
    required String month,
    required int limitPaisa,
  }) async {
    final existing = await (db.select(db.monthlyBudgets)
          ..where((t) =>
              t.deletedAt.isNull() &
              t.userId.equals(uid) &
              t.category.equals(category) &
              t.month.equals(month)))
        .getSingleOrNull();
    if (existing == null) {
      final id = _uuid.v4();
      await db.into(db.monthlyBudgets).insert(MonthlyBudgetsCompanion.insert(
            id: id,
            userId: uid,
            category: category,
            month: month,
            limitPaisa: Value(limitPaisa),
            createdAt: Value(_nowIso),
            updatedAt: Value(_nowIso),
            syncStatus: const Value('pending'),
          ));
      await _enqueue('monthly_budgets', id);
    } else {
      await (db.update(db.monthlyBudgets)..where((t) => t.id.equals(existing.id))).write(
        MonthlyBudgetsCompanion(
          limitPaisa: Value(limitPaisa),
          updatedAt: Value(_nowIso),
          version: Value(existing.version + 1),
          syncStatus: const Value('pending'),
        ),
      );
      await _enqueue('monthly_budgets', existing.id);
    }
  }

  Future<void> deleteBudget(String id) async {
    final existing = await (db.select(db.monthlyBudgets)..where((t) => t.id.equals(id)))
        .getSingleOrNull();
    if (existing == null) return;
    await (db.update(db.monthlyBudgets)..where((t) => t.id.equals(id))).write(
      MonthlyBudgetsCompanion(
        deletedAt: Value(_nowIso),
        updatedAt: Value(_nowIso),
        version: Value(existing.version + 1),
        syncStatus: const Value('pending'),
      ),
    );
    await _enqueue('monthly_budgets', id);
  }

  // ---------- সেভিংস গোল ----------

  Stream<List<SavingsGoal>> watchGoals() {
    return (db.select(db.savingsGoals)
          ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid))
          ..orderBy([(t) => OrderingTerm.asc(t.createdAt)]))
        .watch();
  }

  Future<List<SavingsGoal>> getGoals() {
    return (db.select(db.savingsGoals)
          ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid))
          ..orderBy([(t) => OrderingTerm.asc(t.createdAt)]))
        .get();
  }

  Future<String> addGoal({
    required String name,
    required int targetPaisa,
    String? deadline,
    String? note,
  }) async {
    final id = _uuid.v4();
    await db.into(db.savingsGoals).insert(SavingsGoalsCompanion.insert(
          id: id,
          userId: uid,
          name: name,
          targetPaisa: targetPaisa,
          deadline: Value(deadline),
          note: Value(note),
          createdAt: Value(_nowIso),
          updatedAt: Value(_nowIso),
          syncStatus: const Value('pending'),
        ));
    await _enqueue('savings_goals', id);
    return id;
  }

  /// গোলে টাকা যোগ (ঋণাত্মক amount = তোলা)। ফলাফল কখনো 0-এর নিচে যাবে না।
  Future<void> addToGoal(String id, int amountPaisa) async {
    await db.transaction(() async {
      final goal = await (db.select(db.savingsGoals)..where((t) => t.id.equals(id)))
          .getSingleOrNull();
      if (goal == null) return;
      var next = goal.currentPaisa + amountPaisa;
      if (next < 0) next = 0;
      await (db.update(db.savingsGoals)..where((t) => t.id.equals(id))).write(
        SavingsGoalsCompanion(
          currentPaisa: Value(next),
          updatedAt: Value(_nowIso),
          version: Value(goal.version + 1),
          syncStatus: const Value('pending'),
        ),
      );
    });
    await _enqueue('savings_goals', id);
  }

  Future<void> deleteGoal(String id) async {
    final existing = await (db.select(db.savingsGoals)..where((t) => t.id.equals(id)))
        .getSingleOrNull();
    if (existing == null) return;
    await (db.update(db.savingsGoals)..where((t) => t.id.equals(id))).write(
      SavingsGoalsCompanion(
        deletedAt: Value(_nowIso),
        updatedAt: Value(_nowIso),
        version: Value(existing.version + 1),
        syncStatus: const Value('pending'),
      ),
    );
    await _enqueue('savings_goals', id);
  }

  // ---------- ফাইন্যান্স লেনদেন (বিদ্যমান লেজার থেকে) ----------

  /// income_personal + income_hat + expenses একত্রে — সাম্প্রতিক লেনদেন।
  /// প্রতি সারি: src('income'|'expense'), id, txn_date, created_at,
  /// amount_paisa, payment_method, label, category_name
  Stream<List<QueryRow>> watchRecentTransactions({int limit = 100}) {
    return db.customSelect(
      '''
      SELECT * FROM (
        SELECT 'income' AS src, ip.id AS id, ip.txn_date AS txn_date, ip.created_at AS created_at,
               ip.amount_paisa AS amount_paisa, ip.payment_method AS payment_method,
               ip.title AS label, ip.category AS category_name
        FROM income_personal ip WHERE ip.deleted_at IS NULL AND ip.user_id = ?
        UNION ALL
        SELECT 'income', ih.id, ih.txn_date, ih.created_at,
               ih.amount_paisa, ih.payment_method,
               IFNULL(ih.note, 'হাট আয়'), NULL
        FROM income_hat ih WHERE ih.deleted_at IS NULL AND ih.user_id = ?
        UNION ALL
        SELECT 'expense', e.id, e.txn_date, e.created_at,
               e.amount_paisa, e.payment_method,
               IFNULL(e.note, 'খরচ'), (SELECT c.name FROM categories c WHERE c.id = e.category_id)
        FROM expenses e WHERE e.deleted_at IS NULL AND e.user_id = ?
      )
      ORDER BY txn_date DESC, created_at DESC
      LIMIT ?
      ''',
      variables: [
        Variable.withString(uid),
        Variable.withString(uid),
        Variable.withString(uid),
        Variable.withInt(limit),
      ],
      readsFrom: {db.incomePersonal, db.incomeHat, db.expenses, db.categories},
    ).watch();
  }

  /// এই মাসের খরচ — ক্যাটাগরি নামসহ (বাজেটের spent হিসাবের জন্য)
  Future<List<QueryRow>> monthExpensesWithCategory(String monthKey) {
    return db.customSelect(
      '''
      SELECT e.amount_paisa AS amount_paisa,
             (SELECT c.name FROM categories c WHERE c.id = e.category_id) AS category_name
      FROM expenses e
      WHERE e.deleted_at IS NULL AND e.user_id = ? AND e.txn_date LIKE ?
      ''',
      variables: [Variable.withString(uid), Variable.withString('$monthKey%')],
      readsFrom: {db.expenses, db.categories},
    ).get();
  }
}
