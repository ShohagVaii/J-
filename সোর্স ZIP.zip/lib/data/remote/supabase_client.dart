import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Supabase ক্লায়েন্ট — anon/publishable key শুধু (04_TRD S1)
class Supa {
  Supa._();

  static const String defaultUrl = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: 'https://jwktyqrwloiqwcqiqeti.supabase.co',
  );
  static const String defaultAnonKey = String.fromEnvironment(
    'SUPABASE_ANON_KEY',
    defaultValue: 'sb_publishable_9MIuiHxQt-4LzZ1vC2yYWg_U3cAGWj-',
  );

  static bool _initialized = false;

  static bool get ready => _initialized;

  static Future<void> init() async {
    if (_initialized) return;
    await Supabase.initialize(url: defaultUrl, anonKey: defaultAnonKey);
    _initialized = true;
    // auth পরিবর্তন → SupaAuthWatcher (app.dart থেকে সরিয়ে এখানে — init শেষ হলেই নিজে থেকে জুড়ে যায়)
    Supabase.instance.client.auth.onAuthStateChange.listen((_) {
      SupaAuthWatcher.instance.notify();
    });
  }

  static SupabaseClient get client => Supabase.instance.client;

  static String? get currentUserId {
    if (!_initialized) return null;
    try {
      return client.auth.currentUser?.id;
    } catch (_) {
      return null;
    }
  }

  // ── V1.4.1 (G-05): লগআউট-অবস্থায় আগের uid মনে রাখা ──────────────────
  // signOutKeepingLocal() দিয়ে লগআউট করলে uid-টা SharedPreferences-এ থেকে
  // যায়। ফলে লগআউটের পরও ওই অ্যাকাউন্টের লোকাল ডাটা uid-filter-এ দেখা
  // যায় (docs/08 §7.1 — ডাটা ফোনে থাকে), কিন্তু isLoggedIn=false বলে
  // SyncEngine বন্ধই থাকে — কিছুই সার্ভারে যায় না।

  /// শেষ লগইন-ছিল uid (লগআউটের পর ডাটা দেখানোর জন্য)। main বুটে
  /// [loadLastUid] দিয়ে prefs থেকে লোড হয়।
  static String? lastUid;

  /// লগআউট অবস্থায় আছেন, কিন্তু আগের অ্যাকাউন্টের ডাটা ফোনে আছে
  static bool get isLoggedOutWithData => !isLoggedIn && lastUid != null;

  /// অ্যাপ বুটে একবার — prefs থেকে lastUid পড়া।
  static Future<void> loadLastUid() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      lastUid = prefs.getString('last_uid');
    } catch (_) {
      // পড়া না গেলে গেস্ট হিসেবেই চলবে
    }
  }

  /// লগইন সফল হলে lastUid পরিষ্কার (এখন currentUserId-ই প্রযোজ্য)।
  static Future<void> clearLastUid() async {
    lastUid = null;
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('last_uid');
    } catch (_) {}
  }

  /// ডাটা ফোনে রেখে লগআউট — বর্তমান uid আগে prefs-এ সংরক্ষণ হয়।
  /// (সাধারণ signOut() lastUid ছোঁয় না — সম্মতি-dialog-এ "না" বলার মতো
  /// পথে আগের logged-out অবস্থা অক্ষত রাখতে এটা দরকার।)
  static Future<void> signOutKeepingLocal() async {
    final uid = currentUserId;
    if (uid != null) {
      lastUid = uid;
      try {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('last_uid', uid);
      } catch (_) {}
    }
    await client.auth.signOut();
  }

  /// লগইন না থাকলে: আগের (লগআউট-করা) uid, তাও না থাকলে 'local'
  static String get uidOrDefault => currentUserId ?? lastUid ?? 'local';

  static bool get isLoggedIn => currentUserId != null;
}


/// auth পরিবর্তনের হালকা হুক (UI রিফ্রেশের জন্য)
class SupaAuthWatcher {
  SupaAuthWatcher._();
  static final SupaAuthWatcher instance = SupaAuthWatcher._();
  void Function()? onChange;
  DateTime _last = DateTime.fromMillisecondsSinceEpoch(0);

  void notify() {
    final now = DateTime.now();
    if (now.difference(_last).inMilliseconds < 300) return;
    _last = now;
    onChange?.call();
  }
}
