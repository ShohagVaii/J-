import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/providers/app_providers.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/bangla_digits.dart';
import '../../core/utils/date_utils_bn.dart';
import '../../core/widgets/common.dart';
import '../../data/local/app_database.dart';

enum IncomeType { hat, personal }

/// আয় তালিকা — হাট/পার্সোনাল ট্যাব
class IncomeListScreen extends ConsumerStatefulWidget {
  final String? initialTab;
  const IncomeListScreen({super.key, this.initialTab});

  @override
  ConsumerState<IncomeListScreen> createState() => _IncomeListScreenState();
}

class _IncomeListScreenState extends ConsumerState<IncomeListScreen> {
  late IncomeType _tab;

  @override
  void initState() {
    super.initState();
    _tab = widget.initialTab == 'personal' ? IncomeType.personal : IncomeType.hat;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('আয়')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            child: SegmentedButton<IncomeType>(
              segments: const [
                ButtonSegment(value: IncomeType.hat, label: Text('হাট আয়'), icon: Icon(Icons.storefront, size: 18)),
                ButtonSegment(value: IncomeType.personal, label: Text('পার্সোনাল আয়'), icon: Icon(Icons.person, size: 18)),
              ],
              selected: {_tab},
              onSelectionChanged: (v) => setState(() => _tab = v.first),
            ),
          ),
          Expanded(
            child: _tab == IncomeType.hat ? const _HatIncomeList() : const _PersonalIncomeList(),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        heroTag: 'income_add',
        onPressed: () => context.push('/income/new?type=${_tab == IncomeType.hat ? 'hat' : 'personal'}'),
        backgroundColor: AppColors.income,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('আয় যোগ', style: TextStyle(color: Colors.white)),
      ),
    );
  }
}

class _HatIncomeList extends ConsumerWidget {
  const _HatIncomeList();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final items = ref.watch(_hatIncomeProvider).asData?.value ?? const <IncomeHatData>[];
    if (items.isEmpty) {
      return const EmptyState(
        icon: Icons.storefront,
        title: 'হাট আয় নেই',
        subtitle: 'পারিশ্রমিক বা কমিশন পেলে এখানে যোগ করুন',
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
      itemCount: items.length,
      itemBuilder: (c, i) {
        final it = items[i];
        return EntryTile(
          icon: Icons.storefront,
          title: it.note ?? 'হাট আয়',
          subtitle: '${relativeDayBn(it.txnDate)} • ${it.paymentMethod == 'baki' ? 'বাকি' : 'নগদ'}',
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              AmountTrailing(it.amountPaisa, color: AppColors.income),
              PopupMenuButton<String>(
                onSelected: (v) async {
                  if (v == 'edit') context.push('/income/${it.id}/edit?type=hat');
                  if (v == 'del') {
                    if (await confirmDialog(context, 'মুছে ফেলবেন?', 'এই আয় আবর্জনায় যাবে')) {
                      await repo.softDelete('income_hat', it.id);
                    }
                  }
                },
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'edit', child: Text('এডিট')),
                  PopupMenuItem(value: 'del', child: Text('ডিলিট')),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

class _PersonalIncomeList extends ConsumerWidget {
  const _PersonalIncomeList();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final items = ref.watch(_personalIncomeProvider).asData?.value ?? const <IncomePersonalData>[];
    if (items.isEmpty) {
      return const EmptyState(
        icon: Icons.person,
        title: 'পার্সোনাল আয় নেই',
        subtitle: 'অন্য কোনো আয় পেলে এখানে যোগ করুন',
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
      itemCount: items.length,
      itemBuilder: (c, i) {
        final it = items[i];
        return EntryTile(
          icon: Icons.person,
          iconColor: AppColors.savings,
          title: it.title,
          subtitle: '${relativeDayBn(it.txnDate)} • ${it.paymentMethod == 'baki' ? 'বাকি' : 'নগদ'}',
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              AmountTrailing(it.amountPaisa, color: AppColors.savings),
              PopupMenuButton<String>(
                onSelected: (v) async {
                  if (v == 'edit') context.push('/income/${it.id}/edit?type=personal');
                  if (v == 'del') {
                    if (await confirmDialog(context, 'মুছে ফেলবেন?', 'এই আয় আবর্জনায় যাবে')) {
                      await repo.softDelete('income_personal', it.id);
                    }
                  }
                },
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'edit', child: Text('এডিট')),
                  PopupMenuItem(value: 'del', child: Text('ডিলিট')),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

final _hatIncomeProvider = StreamProvider.autoDispose((ref) { ref.watch(authStateProvider); return repo.watchIncomeHat(); });
final _personalIncomeProvider = StreamProvider.autoDispose((ref) { ref.watch(authStateProvider); return repo.watchIncomePersonal(); });

/// আয় ফর্ম (হাট/পার্সোনাল এক স্ক্রিনে — টাইপ প্যারাম)
class IncomeFormScreen extends ConsumerStatefulWidget {
  final IncomeType type;
  final String? editId;
  final String? prefillAmountPaisa;
  final String? prefillNote;
  const IncomeFormScreen({
    super.key,
    required this.type,
    this.editId,
    this.prefillAmountPaisa,
    this.prefillNote,
  });

  @override
  ConsumerState<IncomeFormScreen> createState() => _IncomeFormScreenState();
}

class _IncomeFormScreenState extends ConsumerState<IncomeFormScreen> {
  late IncomeType _type;
  final _amount = TextEditingController();
  final _title = TextEditingController();
  final _note = TextEditingController();
  final _date = TextEditingController(text: ymdOf(DateTime.now()));
  String _method = 'cash';
  String? _walletId;
  String? _head;
  bool _loaded = false;
  List<Wallet> _wallets = [];
  List<Category> _heads = [];

  @override
  void initState() {
    super.initState();
    _type = widget.type;
    if (widget.prefillAmountPaisa != null) {
      _amount.text = _paisaToEdit(int.tryParse(widget.prefillAmountPaisa!) ?? 0);
    }
    if (widget.prefillNote != null) _note.text = widget.prefillNote!;
    _init();
  }

  String _paisaToEdit(int paisa) {
    // V2-N4 (v1.4.2): এডিট-prefill-ও বাংলা ডিজিটে (formatter প্রোগ্রাম-সেট
    // মানে চলে না, তাই এখানেই রূপান্তর)।
    if (paisa == 0) return '';
    final taka = paisa / 100;
    return toBanglaDigits(taka == taka.roundToDouble() ? taka.round().toString() : taka.toStringAsFixed(2));
  }

  Future<void> _init() async {
    final wallets = await repo.getWallets();
    _heads = await repo.watchCategoriesScoped('income').first;
    if (widget.editId != null) {
      if (_type == IncomeType.hat) {
        final rows = await repo.watchIncomeHat().first;
        final it = rows.where((r) => r.id == widget.editId).firstOrNull;
        if (it != null) _fill(it.txnDate, it.amountPaisa, it.paymentMethod, it.walletId, it.note ?? '', it.note ?? 'হাট আয়');
      } else {
        final rows = await repo.watchIncomePersonal().first;
        final it = rows.where((r) => r.id == widget.editId).firstOrNull;
        if (it != null) {
          _head = it.category;
          _fill(it.txnDate, it.amountPaisa, it.paymentMethod, it.walletId, it.title, it.note ?? '');
        }
      }
    }
    if (!mounted) return;
    setState(() {
      _wallets = wallets;
      _walletId = wallets.isNotEmpty ? _walletId ?? wallets.first.id : null;
      _loaded = true;
    });
  }

  void _fill(String date, int amount, String method, String? walletId, String title, String note) {
    _date.text = date;
    _amount.text = _paisaToEdit(amount);
    _method = method;
    _walletId = walletId;
    _title.text = title;
    _note.text = note;
    setState(() => _loaded = true);
  }

  Future<void> _save() async {
    final amount = AmountInput.readPaisa(_amount) ?? 0;
    if (amount <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('টাকার পরিমাণ দিন')));
      return;
    }
    if (_type == IncomeType.personal && _title.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('আয়ের খাতা/বিষয় লিখুন')));
      return;
    }
    final method = _method;
    final wallet = method == 'baki' ? null : _walletId;
    if (_type == IncomeType.hat) {
      if (widget.editId != null) {
        await repo.update(dbRef.incomeHat, widget.editId!, IncomeHatCompanion(
          txnDate: Value(_date.text),
          amountPaisa: Value(amount),
          paymentMethod: Value(method),
          walletId: Value(wallet),
          note: Value(_note.text.trim().isEmpty ? null : _note.text.trim()),
        ));
      } else {
        await repo.insert(dbRef.incomeHat, IncomeHatCompanion.insert(
        id: '', userId: '',
          txnDate: _date.text,
          amountPaisa: amount,
          paymentMethod: Value(method),
          walletId: Value(wallet),
          note: Value(_note.text.trim().isEmpty ? null : _note.text.trim()),
        ));
      }
    } else {
      if (widget.editId != null) {
        await repo.update(dbRef.incomePersonal, widget.editId!, IncomePersonalCompanion(
          title: Value(_title.text.trim()),
          category: Value(_head),
          txnDate: Value(_date.text),
          amountPaisa: Value(amount),
          paymentMethod: Value(method),
          walletId: Value(wallet),
          note: Value(_note.text.trim().isEmpty ? null : _note.text.trim()),
        ));
      } else {
        await repo.insert(dbRef.incomePersonal, IncomePersonalCompanion.insert(
        id: '', userId: '',
          title: _title.text.trim(),
          category: Value(_head),
          txnDate: _date.text,
          amountPaisa: amount,
          paymentMethod: Value(method),
          walletId: Value(wallet),
          note: Value(_note.text.trim().isEmpty ? null : _note.text.trim()),
        ));
      }
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('সেভ হয়েছে ✓')));
      context.pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.editId != null
            ? 'আয় এডিট'
            : _type == IncomeType.hat ? 'হাট আয়' : 'পার্সোনাল আয়'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (widget.editId == null)
            SegmentedButton<IncomeType>(
              segments: const [
                ButtonSegment(value: IncomeType.hat, label: Text('হাট আয়')),
                ButtonSegment(value: IncomeType.personal, label: Text('পার্সোনাল আয়')),
              ],
              selected: {_type},
              // V2-N1 (v1.4.2): টাইপ বদলালে আগের টাইপের লেখা (পরিমাণ/
              // বিষয়/নোট/খাত) মুছে ফেলা — নইলে পার্সোনালের এন্ট্রি
              // হাট আয়ে (বা উল্টোটা) ভুল টেবিলে সেভ হয়ে যেত।
              onSelectionChanged: (v) {
                if (v.first != _type) {
                  _amount.clear();
                  _title.clear();
                  _note.clear();
                  _head = null;
                }
                setState(() => _type = v.first);
              },
            ),
          const SizedBox(height: 12),
          if (_type == IncomeType.personal)
            AppTextField(controller: _title, label: 'বিষয়/খাতা', hint: 'যেমন: দোকানের মজুরি'),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _head,
              decoration: const InputDecoration(
                labelText: 'আয়ের খাত (ঐচ্ছিক)',
                border: OutlineInputBorder(),
              ),
              items: [
                const DropdownMenuItem(value: null, child: Text('— না দিলেও চলবে —')),
                for (final h in _heads)
                  DropdownMenuItem(
                      value: h.name,
                      child: Text('${h.icon == null ? '' : '${h.icon!} '}${h.name}',
                          maxLines: 1, overflow: TextOverflow.ellipsis)),
              ],
              onChanged: (v) => setState(() => _head = v),
            ),
          if (_type == IncomeType.personal) const SizedBox(height: 12),
          AmountInput(controller: _amount, label: 'টাকার পরিমাণ', autofocus: widget.editId == null),
          const SizedBox(height: 12),
          DateField(controller: _date, label: 'তারিখ'),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: _method,
            decoration: const InputDecoration(labelText: 'মাধ্যম', border: OutlineInputBorder()),
            items: const [
              DropdownMenuItem(value: 'cash', child: Text('নগদ')),
              DropdownMenuItem(value: 'bkash', child: Text('বিকাশ')),
              DropdownMenuItem(value: 'nagad', child: Text('নগদ (মোবাইল)')),
              DropdownMenuItem(value: 'bank', child: Text('ব্যাংক')),
              DropdownMenuItem(value: 'baki', child: Text('বাকি')),
            ],
            onChanged: (v) => setState(() => _method = v ?? 'cash'),
          ),
          if (_method != 'baki') ...[
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _walletId,
              decoration: const InputDecoration(labelText: 'ওয়ালেট', border: OutlineInputBorder()),
              items: [
                for (final w in _wallets)
                  DropdownMenuItem(value: w.id, child: Text(w.name, maxLines: 1, overflow: TextOverflow.ellipsis)),
              ],
              onChanged: (v) => setState(() => _walletId = v),
            ),
          ],
          const SizedBox(height: 12),
          AppTextField(controller: _note, label: 'নোট (ঐচ্ছিক)', maxLines: 2),
          const SizedBox(height: 20),
          FilledButton(onPressed: _save, child: const Text('সেভ করুন')),
        ],
      ),
    );
  }
}
