import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_colors.dart';
import '../../core/widgets/quick_add_sheet.dart';

/// বটম নেভিগেশন শেল — ব্যাক বাটন ধাপে ধাপে (v1.5.0, Agent E):
/// ১) root navigator-এ আলাদা পেজ থাকলে সেটা pop → ২) ট্যাবের ভেতরের
/// গভীর পেজ থাকলে ট্যাব-রুটে ফেরত → ৩) অন্য ট্যাবে থাকলে হোম ট্যাব →
/// ৪) হোম-রুটে থাকলে এক্সিট কনফার্ম ডায়ালগ ("অ্যাপ থেকে বের হবেন?")
/// (v1.1 ফিক্স ১-এর কনফার্ম ডায়ালগ আগের মতোই আছে)
class HomeShell extends ConsumerWidget {
  final StatefulNavigationShell shell;
  const HomeShell({super.key, required this.shell});

  /// ট্যাব ইনডেক্স অনুযায়ী ব্রাঞ্চ-রুট পাথ (router.dart-এর ব্রাঞ্চ ক্রম)
  static const _branchRoots = ['/', '/hats', '/expenses', '/finance', '/more'];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final index = shell.currentIndex;
    return PopScope<Object?>(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;
        final router = GoRouter.of(context);
        // ধাপ ১: root navigator-এ পুশ করা পেজ থাকলে (ফর্ম, সেশন স্টেপার,
        // সেটিংস পেজ ইত্যাদি) আগে সেটাই এক ধাপ pop — সাধারণত
        // ফ্রেমওয়ার্ক নিজেই এটা করে, তবে শেলের PopScope আগে ডাক
        // পেলে এখান থেকেই সঠিক pop নিশ্চিত হয়।
        if (router.canPop()) {
          router.pop();
          return;
        }
        // ধাপ ২: বর্তমান ট্যাবের ভেতরে গভীর পেজ থাকলে (যেমন
        // /hats/:id) শুধু ওই ট্যাবের রুটে ফেরত — এক ধাপ পেছনে।
        final path = router.routerDelegate.currentConfiguration.uri.path;
        final branchRoot = _branchRoots[index];
        if (index != 0 && path != branchRoot && path.startsWith('$branchRoot/')) {
          shell.goBranch(index, initialLocation: true);
          return;
        }
        // ধাপ ৩: অন্য ট্যাবের রুটে থাকলে হোম ট্যাবে ফেরত
        if (index != 0) {
          shell.goBranch(0, initialLocation: true);
          return;
        }
        // ধাপ ৪: হোম-রুট — এক্সিট কনফার্ম
        final exit = await showExitConfirm(context);
        if (exit == true && context.mounted) {
          // অ্যাপ বন্ধ — মিনিমাইজ (স্ট্যান্ডার্ড ব্যাক বিহেভিয়ার)
          SystemNavigator.pop();
        }
      },
      child: Scaffold(
        body: shell,
        floatingActionButton: SizedBox(
          width: 56,
          height: 56,
          child: FloatingActionButton(
            heroTag: 'quick_add_fab',
            onPressed: () => QuickAddSheet.show(context),
            shape: const CircleBorder(),
            backgroundColor: AppColors.primary,
            child: const Icon(Icons.add, size: 30, color: Colors.white),
          ),
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
        bottomNavigationBar: BottomAppBar(
          color: Theme.of(context).cardTheme.color,
          shape: const CircularNotchedRectangle(),
          notchMargin: 8,
          child: Row(
            children: [
              _Tab(icon: Icons.home_outlined, activeIcon: Icons.home, label: 'হোম',
                  selected: index == 0, onTap: () => _goBranch(0)),
              _Tab(icon: Icons.storefront_outlined, activeIcon: Icons.storefront, label: 'হাট',
                  selected: index == 1, onTap: () => _goBranch(1)),
              const SizedBox(width: 56),
              _Tab(icon: Icons.receipt_long_outlined, activeIcon: Icons.receipt_long, label: 'খরচ',
                  selected: index == 2, onTap: () => _goBranch(2)),
              _Tab(icon: Icons.account_balance_wallet_outlined, activeIcon: Icons.account_balance_wallet, label: 'ফাইন্যান্স',
                  selected: index == 3, onTap: () => _goBranch(3)),
              _Tab(icon: Icons.menu, activeIcon: Icons.menu, label: 'আরও',
                  selected: index == 4, onTap: () => _goBranch(4)),
            ],
          ),
        ),
      ),
    );
  }

  void _goBranch(int i) {
    // F-05 (v1.4.1): ট্যাব বদলের সময় কীবোর্ড বন্ধ — নইলে আগের ট্যাবের
    // ফর্মের কীবোর্ড নতুন ট্যাবের লিস্ট/empty state-এর ওপর খোলা থেকে যেত
    FocusManager.instance.primaryFocus?.unfocus();
    shell.goBranch(i, initialLocation: shell.currentIndex == i);
  }
}

class _Tab extends StatelessWidget {
  final IconData icon;
  final IconData activeIcon;
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _Tab({
    required this.icon,
    required this.activeIcon,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final color = selected ? AppColors.primary : AppColors.onSurfaceVariant;
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(selected ? activeIcon : icon, color: color, size: 22),
            const SizedBox(height: 2),
            Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontFamily: 'HindSiliguri',
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// "অ্যাপ থেকে বের হবেন?" — রুটে ব্যাক চাপলে
Future<bool?> showExitConfirm(BuildContext context) {
  return showDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      title: const Text('অ্যাপ থেকে বের হবেন?'),
      content: const Text('FinTrack হাট হিসাব বন্ধ করতে চান? আপনার সব ডাটা ফোনেই সেভ থাকবে।'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('না, থাকব')),
        FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('হ্যাঁ, বের হব')),
      ],
    ),
  );
}
