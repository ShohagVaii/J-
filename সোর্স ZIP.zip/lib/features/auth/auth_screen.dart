import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:path_provider/path_provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../core/providers/app_providers.dart';
import '../../core/utils/bangla_digits.dart';
import '../../core/utils/money_format.dart';
import '../../core/widgets/common.dart';
import '../../core/theme/app_colors.dart';
import '../../data/local/dao/app_repository.dart';
import '../../data/remote/supabase_client.dart';

/// লগইন / রেজিস্টার — গেস্ট ডাটা মাইগ্রেশন সহ (05_Schema §5)
class AuthScreen extends ConsumerStatefulWidget {
  const AuthScreen({super.key});

  @override
  ConsumerState<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends ConsumerState<AuthScreen> {
  bool _isLogin = true;
  bool _busy = false;
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _name = TextEditingController();
  String? _error;

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    _name.dispose();
    super.dispose();
  }

  /// সম্মতি dialog-এ টেবিলের বাংলা নাম
  static const Map<String, String> _tableLabels = {
    'profiles': 'প্রোফাইল',
    'wallets': 'ওয়ালেট',
    'hats': 'হাট',
    'hat_sessions': 'হাট সেশন',
    'hat_purchase_items': 'কেনা আইটেম',
    'income_hat': 'হাট আয়',
    'income_personal': 'ব্যক্তিগত আয়',
    'categories': 'খাত',
    'expenses': 'খরচ',
    'mother_payments': 'আম্মুকে দেওয়া',
    'dps_accounts': 'DPS অ্যাকাউন্ট',
    'dps_transactions': 'DPS লেনদেন',
    'loan_persons': 'ঋণের ব্যক্তি',
    'loans': 'ঋণ',
    'loan_payments': 'ঋণ পরিশোধ',
    'fuel_logs': 'জ্বালানি হিসাব',
    'bike_maintenance': 'বাইক মেরামত',
    'cash_tallies': 'নগদ গণনা',
    'cash_tally_items': 'নগদ গণনার আইটেম',
    'daily_closings': 'দৈনিক হিসাব মেলানো',
    'attachments': 'সংযুক্তি',
    'products': 'পণ্য',
    'monthly_budgets': 'মাসিক বাজেট',
    'savings_goals': 'সেভিংস গোল',
  };

  /// V1.4.1 (G-03, docs/08 §6.1): আগের অ্যাকাউন্টের pending থাকলে
  /// অ্যাকাউন্ট বদল block — সিঙ্ক/ব্যাকআপের পরামর্শসহ।
  Future<void> _showPendingBlock(int pending) {
    return showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('আগে সিঙ্ক করুন'),
        content: Text(
          'আগের অ্যাকাউন্টের ${toBanglaDigits('$pending')}টি এন্ট্রি এখনো সিঙ্ক হয়নি। '
          'আগে সিঙ্ক করুন, অথবা Export/Backup নিয়ে রাখুন।',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(c),
            child: const Text('ঠিক আছে'),
          ),
          FilledButton(
            onPressed: () {
              Navigator.pop(c);
              syncEngine.runSync(force: true);
            },
            child: const Text('সিঙ্ক করুন'),
          ),
        ],
      ),
    );
  }

  /// V1.4.1 (G-02, docs/08 §4.1): লগইন-মার্জের আগে পুরো লোকাল ডাটার
  /// snapshot — app documents-এর backup/pre-login-<epochMs>.json।
  /// লিখতে ব্যর্থ হলেও লগইন আটকায় না (সম্মতি dialog তার পরেই আসে)।
  Future<void> _writePreLoginBackup() async {
    try {
      final data = await repo.exportAll();
      final dir = await getApplicationDocumentsDirectory();
      final backupDir = Directory('${dir.path}/backup');
      if (!await backupDir.exists()) {
        await backupDir.create(recursive: true);
      }
      final file = File(
          '${backupDir.path}/pre-login-${DateTime.now().millisecondsSinceEpoch}.json');
      await file.writeAsString(jsonEncode(data));
    } catch (e) {
      debugPrint('pre-login backup failed: $e');
    }
  }

  /// V1.4.1 (G-01, docs/08 §4.4): সম্মতি dialog — সংখ্যা + টাকার সারাংশ +
  /// টার্গেট ইমেইল দেখিয়ে হ্যাঁ/না। বাইরে ট্যাপে বন্ধ হয় না; উত্তর
  /// না এলে (null) "না" ধরা হয় — নীরব মার্জ কখনো নয়।
  Future<bool> _askGuestMergeConsent(GuestDataSummary guest, String email) async {
    final lines = guest.perTable.entries
        .map((e) => '${_tableLabels[e.key] ?? e.key}: ${toBanglaDigits('${e.value}')}টি')
        .join('\n');
    final answer = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (c) => AlertDialog(
        title: const Text('গেস্ট ডাটা যোগ করবেন?'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('এই ফোনে গেস্ট হিসেবে ${toBanglaDigits('${guest.totalCount}')}টি এন্ট্রি আছে'),
              const SizedBox(height: 8),
              Text(lines, style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 13)),
              const SizedBox(height: 8),
              Text(
                'আয়: ${MoneyFmt.taka(guest.incomePaisa)} · খরচ: ${MoneyFmt.taka(guest.expensePaisa)} · ঋণ: ${MoneyFmt.taka(guest.loanPaisa)}',
                style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 13),
              ),
              const SizedBox(height: 8),
              Text('এগুলো $email-এ যোগ করবো?'),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(c, false),
            child: const Text('না, গেস্ট হিসেবেই থাকুক'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(c, true),
            child: const Text('হ্যাঁ, যোগ করো'),
          ),
        ],
      ),
    );
    return answer ?? false;
  }

  Future<void> _submit() async {
    if (_busy) return;
    final email = _email.text.trim();
    final pass = _password.text;
    if (email.isEmpty || !email.contains('@') || pass.length < 6) {
      setState(() => _error = 'সঠিক ইমেইল ও ৬+ অক্ষরের পাসওয়ার্ড দিন');
      return;
    }

    // V1.4.1 (G-03): ইতিমধ্যে লগইন থাকা অবস্থায় অন্য অ্যাকাউন্টে যেতে
    // চাইলে এবং pending থাকলে আগেই block (সাইন-ইনের চেষ্টাই হবে না)।
    final prevUid = Supa.currentUserId ?? Supa.lastUid;
    final pendingBefore = await repo.pendingCount();
    if (!mounted) return;
    if (Supa.currentUserId != null && pendingBefore > 0) {
      await _showPendingBlock(pendingBefore);
      return;
    }

    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      String? signUpName;
      if (_isLogin) {
        await Supa.client.auth.signInWithPassword(email: email, password: pass);
      } else {
        await Supa.client.auth.signUp(email: email, password: pass);
        signUpName = _name.text.trim();
      }
      final uid = Supa.currentUserId;
      if (uid == null) {
        // signUp-এ ইমেইল নিশ্চিতকরণ লাগলে session থাকে না — migrate নয়
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('অ্যাকাউন্ট তৈরি হয়েছে — ইমেইল নিশ্চিত করে লগইন করুন'),
          ));
        }
        return;
      }

      // G-03 (দ্বিতীয় পথ): লগআউট-অবস্থা (lastUid) থেকে অন্য অ্যাকাউন্টে
      // লগইন হয়ে গেছে, অথচ আগের অ্যাকাউন্টের pending বাকি — session
      // ফিরিয়ে দিয়ে block জানানো হয় (ডাটা মেশে না)।
      if (prevUid != null && prevUid != uid && pendingBefore > 0) {
        await Supa.client.auth.signOut();
        if (mounted) await _showPendingBlock(pendingBefore);
        return;
      }

      // ফ্লো C (G-16): এই uid-র ডাটা এই ডিভাইসে আগে ছিল কিনা —
      // migrate কিছু বদলানোর আগেই মাপতে হয়।
      final hadAccountData = await repo.hasLocalDataForUser(uid);

      // ── ফ্লো B (docs/08 §4): গেস্ট ডাটা থাকলে backup → সম্মতি → migrate
      final guest = await repo.countLocalGuestData();
      if (guest.totalCount > 0) {
        await _writePreLoginBackup();
        if (!mounted) return;
        final proceed = await _askGuestMergeConsent(guest, email);
        if (!proceed) {
          // "না" → লগইন বাতিল, গেস্টেই ফেরা, ডাটা অক্ষত (§4.4)।
          // সাধারণ signOut — lastUid সেট করা হয় না, যাতে আগের
          // logged-out অবস্থা (যদি থাকে) হুবহু থেকে যায়।
          await Supa.client.auth.signOut();
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
              content: Text('লগইন বাতিল — গেস্ট হিসেবেই আছেন, ডাটা এই ফোনেই থাকবে'),
            ));
          }
          return;
        }
      }

      await Supa.clearLastUid();
      if (signUpName != null && signUpName.isNotEmpty) {
        await repo.saveProfileFields(displayName: signUpName);
      }
      // গেস্ট ডাটা অ্যাকাউন্টে নেওয়া (count==0 হলে migrate এমনিতেই 0)
      final n = await repo.migrateLocalDataToUser(uid);
      syncEngine.start();
      syncEngine.runSync();
      if (mounted) {
        final messenger = ScaffoldMessenger.of(context);
        messenger.showSnackBar(SnackBar(
          content: Text(n > 0 ? 'স্বাগতম! ${toBanglaDigits('$n')}টি এন্ট্রি অ্যাকাউন্টে যুক্ত হয়েছে ✓' : 'স্বাগতম! ✓'),
        ));
        if (_isLogin && !hadAccountData) {
          // G-16 (docs/08 §5.3): প্রথম pull-এ শুধু সার্ভারের ডাটাই আসে
          messenger.showSnackBar(const SnackBar(
            content: Text('অন্য ডিভাইসে সিঙ্ক হয়নি এমন এন্ট্রি এখানে দেখা যাবে না।'),
          ));
        }
        context.go('/');
      }
    } on AuthException catch (e) {
      setState(() => _error = e.message.contains('Invalid login')
          ? 'ইমেইল বা পাসওয়ার্ড ভুল'
          : e.message.contains('already registered')
              ? 'এই ইমেইলে অ্যাকাউন্ট আছে — লগইন করুন'
              : 'সমস্যা: ${e.message}');
    } catch (_) {
      setState(() => _error = 'ইন্টারনেট সংযোগ দেখে আবার চেষ্টা করুন');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () => context.pop(),
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const CircleAvatar(
                radius: 30,
                backgroundColor: AppColors.primaryLight,
                child: Icon(Icons.storefront, color: AppColors.primary, size: 28),
              ),
              const SizedBox(height: 12),
              Text(
                _isLogin ? 'লগইন করুন' : 'নতুন অ্যাকাউন্ট',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 4),
              const Text(
                'লগইন করলে আপনার সব হিসাব নিরাপদে সিঙ্ক হবে',
                textAlign: TextAlign.center,
                style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 13, color: AppColors.onSurfaceVariant),
              ),
              const SizedBox(height: 22),
              if (!_isLogin)
                AppTextField(controller: _name, label: 'আপনার নাম (ঐচ্ছিক)'),
              if (!_isLogin) const SizedBox(height: 12),
              AppTextField(
                controller: _email,
                label: 'ইমেইল',
                hint: 'you@example.com',
              ),
              const SizedBox(height: 12),
              AppTextField(
                controller: _password,
                label: 'পাসওয়ার্ড',
                hint: 'কমপক্ষে ৬ অক্ষর',
                obscureText: true, // FIX C-4: পাসওয়ার্ড খোলা দেখাত
              ),
              if (_error != null) ...[
                const SizedBox(height: 10),
                Text(
                  _error!,
                  style: const TextStyle(fontFamily: 'HindSiliguri', color: AppColors.expense, fontSize: 13),
                ),
              ],
              const SizedBox(height: 18),
              FilledButton(
                onPressed: _busy ? null : _submit,
                child: _busy
                    ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : Text(_isLogin ? 'লগইন' : 'অ্যাকাউন্ট খুলুন'),
              ),
              const SizedBox(height: 10),
              TextButton(
                onPressed: () => setState(() {
                  _isLogin = !_isLogin;
                  _error = null;
                }),
                child: Text(_isLogin ? 'নতুন অ্যাকাউন্ট খুলতে চান?' : 'আগে থেকেই অ্যাকাউন্ট আছে? লগইন করুন'),
              ),
              const SizedBox(height: 6),
              TextButton(
                onPressed: () => context.pop(),
                child: const Text('এখন না, অতিথি হিসেবে থাকব'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
