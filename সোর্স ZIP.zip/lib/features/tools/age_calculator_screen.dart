import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/utils/bangla_digits.dart';
import '../../core/utils/date_utils_bn.dart';
import '../../core/widgets/amount_input.dart';

/// বয়স ক্যালকুলেটর — জন্মতারিখ থেকে সঠিক বয়স, মোট দিন/মাস/সপ্তাহ,
/// জন্মবার ও পরের জন্মদিনের কাউন্টডাউন। সব সংখ্যা বাংলা ডিজিটে।
class AgeCalculatorScreen extends StatefulWidget {
  const AgeCalculatorScreen({super.key});

  @override
  State<AgeCalculatorScreen> createState() => _AgeCalculatorScreenState();
}

class _AgeCalculatorScreenState extends State<AgeCalculatorScreen> {
  final _dob = TextEditingController(); // ISO 'YYYY-MM-DD'
  late final _asOf = TextEditingController(text: ymdOf(DateTime.now()));

  @override
  void initState() {
    super.initState();
    _dob.addListener(_refresh);
    _asOf.addListener(_refresh);
  }

  void _refresh() => setState(() {});

  @override
  void dispose() {
    _dob.dispose();
    _asOf.dispose();
    super.dispose();
  }

  DateTime? _parse(String iso) {
    final s = iso.trim();
    if (s.isEmpty) return null;
    final p = s.split('-');
    if (p.length != 3) return null;
    final y = int.tryParse(p[0]), m = int.tryParse(p[1]), d = int.tryParse(p[2]);
    if (y == null || m == null || d == null) return null;
    return DateTime(y, m, d);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final dob = _parse(_dob.text);
    final asOf = _parse(_asOf.text) ?? DateTime.now();

    return Scaffold(
      appBar: AppBar(title: const Text('বয়স ক্যালকুলেটর')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
        children: [
          DateField(controller: _dob, label: 'জন্মতারিখ'),
          const SizedBox(height: 12),
          DateField(controller: _asOf, label: 'যে তারিখে হিসাব (সাধারণত আজ)'),
          const SizedBox(height: 18),
          if (dob == null)
            const _HintCard(
              icon: Icons.cake_outlined,
              text: 'জন্মতারিখ বাছলে এখানে পুরো বয়সের হিসাব দেখা যাবে — '
                  'বছর-মাস-দিন, মোট দিন, আর পরের জন্মদিনের কাউন্টডাউন।',
            )
          else if (!dob.isBefore(asOf) && ymdOf(dob) != ymdOf(asOf))
            const _HintCard(
              icon: Icons.error_outline,
              text: 'জন্মতারিখ হিসাবের তারিখের পরে হতে পারে না — তারিখ দুটো দেখে নিন।',
            )
          else
            ..._results(context, dob, asOf, dark),
          const SizedBox(height: 8),
          Text(
            'টিপস: কারও জন্মতারিখ মনে না থাকলে জাতীয় পরিচয়পত্র/জন্মসনদে '
            'যে তারিখ আছে সেটাই বসান।',
            style: TextStyle(
              fontFamily: 'HindSiliguri',
              fontSize: 11.5,
              color: cs.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }

  List<Widget> _results(BuildContext context, DateTime dob, DateTime asOf, bool dark) {
    final cs = Theme.of(context).colorScheme;
    final age = _ageParts(dob, asOf);
    final totalDays = DateTime(asOf.year, asOf.month, asOf.day)
        .difference(DateTime(dob.year, dob.month, dob.day))
        .inDays;
    final totalMonths = age.y * 12 + age.m;
    final totalWeeks = totalDays ~/ 7;
    final weekRemainDays = totalDays % 7;

    // পরের জন্মদিন — এই বছরেরটা পেরিয়ে গেলে সামনের বছরের
    var nextBday = _birthdayIn(dob, asOf.year);
    final asOfDay = DateTime(asOf.year, asOf.month, asOf.day);
    if (nextBday.isBefore(asOfDay)) nextBday = _birthdayIn(dob, asOf.year + 1);
    final daysToBday = nextBday.difference(asOfDay).inDays;
    final turningAge = nextBday.year - dob.year;

    String bn(num n) => toBanglaDigits('$n');

    return [
      // প্রধান বয়স — গ্রেডিয়েন্ট হেডার কার্ড
      Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: dark
                ? [AppColors.dPrimary, AppColors.dPrimaryDark]
                : [AppColors.primary, AppColors.primaryDark],
          ),
          boxShadow: [
            BoxShadow(
              color: cs.primary.withAlpha(64),
              blurRadius: 14,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.cake, color: Colors.white, size: 20),
                SizedBox(width: 8),
                Text(
                  'আপনার বয়স',
                  style: TextStyle(
                    fontFamily: 'HindSiliguri',
                    fontSize: 13,
                    color: Colors.white70,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              '${bn(age.y)} বছর  ${bn(age.m)} মাস  ${bn(age.d)} দিন',
              style: const TextStyle(
                fontFamily: 'HindSiliguri',
                fontSize: 27,
                fontWeight: FontWeight.w800,
                color: Colors.white,
                height: 1.25,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'জন্ম: ${formatDateBn(ymdOf(dob))} — ${weekdayNameBn(dob)}',
              style: const TextStyle(
                fontFamily: 'HindSiliguri',
                fontSize: 13,
                color: Colors.white70,
              ),
            ),
          ],
        ),
      ),
      const SizedBox(height: 14),
      // স্ট্যাট গ্রিড
      Row(
        children: [
          Expanded(
            child: _StatCard(
              icon: Icons.calendar_month_outlined,
              label: 'মোট দিন',
              value: '${bn(totalDays)} দিন',
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: _StatCard(
              icon: Icons.date_range_outlined,
              label: 'মোট মাস',
              value: '${bn(totalMonths)} মাস',
            ),
          ),
        ],
      ),
      const SizedBox(height: 10),
      Row(
        children: [
          Expanded(
            child: _StatCard(
              icon: Icons.view_week_outlined,
              label: 'মোট সপ্তাহ',
              value: '${bn(totalWeeks)} সপ্তাহ',
              sub: weekRemainDays > 0 ? 'আরও ${bn(weekRemainDays)} দিন' : null,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: _StatCard(
              icon: Icons.wb_sunny_outlined,
              label: 'জন্মবার',
              value: weekdayNameBn(dob),
            ),
          ),
        ],
      ),
      const SizedBox(height: 10),
      // পরের জন্মদিন
      Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: (dark ? AppColors.dSecondary : AppColors.secondary).withAlpha(41),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.celebration_outlined,
                  color: dark ? AppColors.dSecondary : AppColors.secondary,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      daysToBday == 0
                          ? 'আজই জন্মদিন! 🎉'
                          : 'পরের জন্মদিনে বাকি ${bn(daysToBday)} দিন',
                      style: const TextStyle(
                        fontFamily: 'HindSiliguri',
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${formatDateBn(ymdOf(nextBday))} — ${weekdayNameBn(nextBday)} '
                      '• ${bn(turningAge)} বছর পূর্ণ হবে',
                      style: TextStyle(
                        fontFamily: 'HindSiliguri',
                        fontSize: 12.5,
                        color: cs.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    ];
  }

  /// বছর-মাস-দিন ভাঙা বয়স (ধার করা দিন/মাসের স্ট্যান্ডার্ড নিয়ম)
  ({int y, int m, int d}) _ageParts(DateTime dob, DateTime asOf) {
    var y = asOf.year - dob.year;
    var m = asOf.month - dob.month;
    var d = asOf.day - dob.day;
    if (d < 0) {
      m -= 1;
      // আগের মাসের দিনসংখ্যা ধার
      final prevMonthDays = DateTime(asOf.year, asOf.month, 0).day;
      d += prevMonthDays;
      if (d < 0) d = 0; // জন্মদিন মাসের শেষ দিন হলে ধারের হিসাব সীমা ছাড়ায়
    }
    if (m < 0) {
      y -= 1;
      m += 12;
    }
    return (y: y, m: m, d: d);
  }

  /// নির্দিষ্ট বছরে জন্মদিন (২৯ ফেব্রুয়ারি হলে ওই বছরে ২৮ ফেব্রুয়ারি ধরা হয়)
  DateTime _birthdayIn(DateTime dob, int year) {
    final daysInMonth = DateTime(year, dob.month + 1, 0).day;
    final day = dob.day <= daysInMonth ? dob.day : daysInMonth;
    return DateTime(year, dob.month, day);
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final String? sub;
  const _StatCard({required this.icon, required this.label, required this.value, this.sub});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 19, color: cs.primary),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                fontFamily: 'HindSiliguri',
                fontSize: 11.5,
                color: cs.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              value,
              style: const TextStyle(
                fontFamily: 'HindSiliguri',
                fontSize: 17,
                fontWeight: FontWeight.w700,
              ),
            ),
            if (sub != null)
              Text(
                sub!,
                style: TextStyle(
                  fontFamily: 'HindSiliguri',
                  fontSize: 11,
                  color: cs.onSurfaceVariant,
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _HintCard extends StatelessWidget {
  final IconData icon;
  final String text;
  const _HintCard({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: cs.primary, size: 22),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                text,
                style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 13.5, height: 1.45),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
