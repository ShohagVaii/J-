import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/calculations/session_calc.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/bangla_digits.dart';
import '../../core/utils/money_format.dart';
import '../../core/widgets/common.dart'; // BanglaDigitFormatter-সহ (re-export)

/// স্মার্ট দর-পড়তা ক্যালকুলেটর — হাটের ব্যবসার প্রতিদিনের হিসাব এক স্ক্রিনে:
/// দর রূপান্তর (৳/মণ ↔ ৳/কেজি), কেনার হিসাব (docs/07-এর পূর্ণ-টাকায়
/// নামানোর নিয়মে — SessionCalc.lineTotalMaund), পড়তা বের করা,
/// আর বস্তার হিসাব। প্রতিটি ফলাফল কার্ডে কপি বোতাম।
class RateCalculatorScreen extends StatefulWidget {
  const RateCalculatorScreen({super.key});

  @override
  State<RateCalculatorScreen> createState() => _RateCalculatorScreenState();
}

class _RateCalculatorScreenState extends State<RateCalculatorScreen> {
  // দর রূপান্তর
  final _rateMaund = TextEditingController();
  final _rateKg = TextEditingController();
  // কেনার হিসাব
  final _buyRate = TextEditingController();
  final _buyKg = TextEditingController();
  // পড়তা
  final _sumTaka = TextEditingController();
  final _sumKg = TextEditingController();
  // বস্তা
  final _bagCount = TextEditingController();
  final _bagAvg = TextEditingController();

  bool _syncing = false; // রূপান্তরের প্রোগ্রাম-সেটে লুপ ঠেকাতে

  @override
  void dispose() {
    for (final c in [
      _rateMaund, _rateKg, _buyRate, _buyKg, _sumTaka, _sumKg, _bagCount, _bagAvg,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  double? _num(TextEditingController c) {
    final v = double.tryParse(fromBanglaDigits(c.text.trim()).replaceAll(',', ''));
    return (v == null || v.isNaN || v.isInfinite) ? null : v;
  }

  String _fmt(num v, {int decimals = 2}) {
    var s = v.toStringAsFixed(decimals);
    if (s.contains('.')) {
      s = s.replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
    }
    return toBanglaDigits(MoneyFmt.groupBangla(s));
  }

  void _onMaundChanged(String _) {
    if (_syncing) return;
    _syncing = true;
    final v = _num(_rateMaund);
    _rateKg.text = v == null ? '' : _fmt(v / SessionCalc.kgPerMaund, decimals: 4);
    _syncing = false;
    setState(() {});
  }

  void _onKgChanged(String _) {
    if (_syncing) return;
    _syncing = true;
    final v = _num(_rateKg);
    _rateMaund.text = v == null ? '' : _fmt(v * SessionCalc.kgPerMaund);
    _syncing = false;
    setState(() {});
  }

  void _copy(String text) {
    Clipboard.setData(ClipboardData(text: fromBanglaDigits(text)));
    showFloatingSnackBar(context, 'কপি হয়েছে ✓', bottomMargin: 24);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;

    // কেনার হিসাব — docs/07 নিয়ম: মোট = floor(দর ÷ ৪০ × কেজি) পূর্ণ টাকায়
    final buyRate = _num(_buyRate);
    final buyKg = _num(_buyKg);
    int? buyTotalPaisa;
    double? buyRawTaka;
    if (buyRate != null && buyKg != null && buyRate > 0 && buyKg > 0) {
      buyTotalPaisa = SessionCalc.lineTotalMaund(
        kg: buyKg,
        ratePaisaPerMaund: (buyRate * 100).round(),
      );
      buyRawTaka = buyRate / SessionCalc.kgPerMaund * buyKg;
    }

    // পড়তা = মোট টাকা ÷ মোট কেজি × ৪০
    final sumTaka = _num(_sumTaka);
    final sumKg = _num(_sumKg);
    double? porta;
    if (sumTaka != null && sumKg != null && sumKg > 0) {
      porta = sumTaka / sumKg * SessionCalc.kgPerMaund;
    }

    // বস্তা
    final bags = _num(_bagCount);
    final avg = _num(_bagAvg);
    double? bagTotalKg;
    if (bags != null && avg != null && bags > 0 && avg > 0) {
      bagTotalKg = bags * avg;
    }

    return Scaffold(
      appBar: AppBar(title: const Text('দর-পড়তা ক্যালকুলেটর')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
        children: [
          // হেডার
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: dark
                    ? [AppColors.dPrimaryDark, AppColors.dPrimary]
                    : [AppColors.primaryDark, AppColors.primary],
              ),
            ),
            padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.scale_outlined, color: Colors.white, size: 22),
                    SizedBox(width: 9),
                    Text(
                      'হাটের দর-পড়তা, এক স্ক্রিনে',
                      style: TextStyle(
                        fontFamily: 'HindSiliguri',
                        fontSize: 17,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 5),
                Text(
                  'দর বদলানো, কেনার মোট, পড়তা আর বস্তার ওজন — '
                  'সেশনের হিসাবের একই নিয়মে (১ মণ = ৪০ কেজি)।',
                  style: TextStyle(
                    fontFamily: 'HindSiliguri',
                    fontSize: 12.5,
                    color: Colors.white70,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // ১) দর রূপান্তর
          _SectionCard(
            icon: Icons.swap_horiz,
            title: 'দর রূপান্তর',
            child: Column(
              children: [
                _NumField(
                  controller: _rateMaund,
                  label: 'দর (৳/মণ)',
                  suffix: '৳/মণ',
                  onChanged: _onMaundChanged,
                ),
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 6),
                  child: Icon(Icons.swap_vert, size: 20),
                ),
                _NumField(
                  controller: _rateKg,
                  label: 'দর (৳/কেজি)',
                  suffix: '৳/কেজি',
                  onChanged: _onKgChanged,
                ),
                if (_num(_rateMaund) != null && _num(_rateKg) != null) ...[
                  const SizedBox(height: 12),
                  _ResultRow(
                    text: '${MoneyFmt.rateMaundDirect((_num(_rateMaund)! * 100).round())}'
                        ' = ৳${_fmt(_num(_rateKg)!, decimals: 4)}/কেজি',
                    onCopy: () => _copy(
                        '৳${_fmt(_num(_rateMaund)!)} = প্রতি কেজি ৳${_fmt(_num(_rateKg)!, decimals: 4)}'),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 12),

          // ২) কেনার হিসাব
          _SectionCard(
            icon: Icons.shopping_basket_outlined,
            title: 'কেনার হিসাব',
            child: Column(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: _NumField(
                        controller: _buyRate,
                        label: 'দর (৳/মণ)',
                        suffix: '৳/মণ',
                        onChanged: (_) => setState(() {}),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _NumField(
                        controller: _buyKg,
                        label: 'ওজন (কেজি)',
                        suffix: 'কেজি',
                        onChanged: (_) => setState(() {}),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                if (buyTotalPaisa != null)
                  _ResultRow(
                    big: true,
                    text: 'মোট ${MoneyFmt.taka(buyTotalPaisa)}',
                    sub: buyRawTaka != null && (buyRawTaka * 100).round() != buyTotalPaisa
                        ? 'আসল অঙ্ক ৳${_fmt(buyRawTaka)} — হাটের নিয়মে পূর্ণ টাকায় নামানো'
                        : 'পূর্ণ টাকার হিসাব (হাটের নিয়ম)',
                    onCopy: () => _copy(
                        'দর ৳${_fmt(buyRate!)}/মণ × ${_fmt(buyKg!)} কেজি = ${MoneyFmt.taka(buyTotalPaisa!)}'),
                  )
                else
                  const _EmptyHint(text: 'দর আর ওজন লিখলেই মোট টাকা বেরিয়ে যাবে'),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // ৩) পড়তা
          _SectionCard(
            icon: Icons.functions_outlined,
            title: 'পড়তা বের করুন',
            child: Column(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: _NumField(
                        controller: _sumTaka,
                        label: 'মোট টাকা',
                        suffix: '৳',
                        onChanged: (_) => setState(() {}),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _NumField(
                        controller: _sumKg,
                        label: 'মোট ওজন (কেজি)',
                        suffix: 'কেজি',
                        onChanged: (_) => setState(() {}),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                if (porta != null)
                  _ResultRow(
                    big: true,
                    text: 'পড়তা ৳${_fmt(porta)}/মণ',
                    sub: 'মোট টাকা ÷ মোট কেজি × ৪০',
                    onCopy: () => _copy('পড়তা ৳${_fmt(porta!)}/মণ'),
                  )
                else
                  const _EmptyHint(text: 'মোট টাকা আর মোট ওজন লিখলে পড়তা বের হবে'),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // ৪) বস্তা হিসাব
          _SectionCard(
            icon: Icons.inventory_2_outlined,
            title: 'বস্তার হিসাব',
            child: Column(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: _NumField(
                        controller: _bagCount,
                        label: 'বস্তার সংখ্যা',
                        suffix: 'টি',
                        integerOnly: true,
                        onChanged: (_) => setState(() {}),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _NumField(
                        controller: _bagAvg,
                        label: 'গড় ওজন (কেজি/বস্তা)',
                        suffix: 'কেজি',
                        onChanged: (_) => setState(() {}),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                if (bagTotalKg != null)
                  _ResultRow(
                    big: true,
                    text: 'মোট ${MoneyFmt.kg(bagTotalKg)}',
                    sub: '= ${_fmt(bagTotalKg / SessionCalc.kgPerMaund)} মণ',
                    onCopy: () => _copy(
                        '${_fmt(bags!)} বস্তা × ${_fmt(avg!)} কেজি = মোট ${MoneyFmt.kg(bagTotalKg!)} (${_fmt(bagTotalKg / SessionCalc.kgPerMaund)} মণ)'),
                  )
                else
                  const _EmptyHint(text: 'বস্তার সংখ্যা আর গড় ওজন লিখলেই মোট ওজন বের হবে'),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Text(
            'কেনার হিসাব সেশনের লাইন-মোটের একই সূত্রে হয় — ভগ্নাংশ টাকা '
            'সবসময় নিচে নামিয়ে পূর্ণ টাকা (docs/07-এর নিয়ম)।',
            style: TextStyle(
              fontFamily: 'HindSiliguri',
              fontSize: 11.5,
              color: cs.onSurfaceVariant,
              height: 1.45,
            ),
          ),
        ],
      ),
    );
  }
}

/// সেকশন কার্ড — শিরোনাম + আইকনসহ
class _SectionCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final Widget child;
  const _SectionCard({required this.icon, required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: cs.primary.withAlpha(31),
                    borderRadius: BorderRadius.circular(9),
                  ),
                  child: Icon(icon, size: 18, color: cs.primary),
                ),
                const SizedBox(width: 10),
                Text(
                  title,
                  style: const TextStyle(
                    fontFamily: 'HindSiliguri',
                    fontSize: 15.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            child,
          ],
        ),
      ),
    );
  }
}

/// সংখ্যার ইনপুট — বাংলা ডিজিট ডিসপ্লে, দুটো স্ক্রিপ্টই parse হয়
class _NumField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final String suffix;
  final bool integerOnly;
  final ValueChanged<String>? onChanged;
  const _NumField({
    required this.controller,
    required this.label,
    required this.suffix,
    this.integerOnly = false,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      keyboardType: TextInputType.numberWithOptions(decimal: !integerOnly),
      inputFormatters: [
        FilteringTextInputFormatter.allow(
          RegExp(integerOnly ? r'[0-9০-৯]' : r'[0-9০-৯.]'),
        ),
        const BanglaDigitFormatter(),
      ],
      onChanged: onChanged,
      decoration: InputDecoration(
        labelText: label,
        suffixText: suffix,
        border: const OutlineInputBorder(),
      ),
      style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 15.5),
    );
  }
}

/// ফলাফলের সারি — বড় সবুজ ব্যান্ড + কপি বোতাম
class _ResultRow extends StatelessWidget {
  final String text;
  final String? sub;
  final bool big;
  final VoidCallback onCopy;
  const _ResultRow({required this.text, required this.onCopy, this.sub, this.big = false});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: cs.primary.withAlpha(26),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: cs.primary.withAlpha(89)),
      ),
      padding: const EdgeInsets.fromLTRB(14, 10, 6, 10),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  text,
                  style: TextStyle(
                    fontFamily: 'HindSiliguri',
                    fontSize: big ? 19 : 15,
                    fontWeight: FontWeight.w800,
                    color: cs.primary,
                  ),
                ),
                if (sub != null)
                  Text(
                    sub!,
                    style: TextStyle(
                      fontFamily: 'HindSiliguri',
                      fontSize: 11.5,
                      color: cs.onSurfaceVariant,
                    ),
                  ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.copy_outlined, size: 19),
            tooltip: 'কপি করুন',
            onPressed: onCopy,
          ),
        ],
      ),
    );
  }
}

class _EmptyHint extends StatelessWidget {
  final String text;
  const _EmptyHint({required this.text});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: cs.surfaceContainerHighest.withAlpha(102),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontFamily: 'HindSiliguri',
          fontSize: 12.5,
          color: cs.onSurfaceVariant,
        ),
      ),
    );
  }
}
