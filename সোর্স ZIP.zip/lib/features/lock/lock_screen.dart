import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/security/lock_controller.dart';
import '../../core/theme/app_colors.dart';

/// লক স্ক্রিন — PIN / বায়োমেট্রিক
class LockScreen extends StatefulWidget {
  const LockScreen({super.key});

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  final _pin = TextEditingController();

  @override
  void initState() {
    super.initState();
    LockController.instance.load().then((_) async {
      if (LockController.instance.biometricEnabled && mounted) {
        // FIX M-8: ফলাফল ফেলে দেওয়া হতো — fingerprint সফল হলেও ঢোকা যেত না
        final ok = await LockController.instance.authenticateBiometric();
        if (ok && mounted) context.go('/');
      }
    });
  }

  @override
  void dispose() {
    _pin.dispose();
    super.dispose();
  }

  String? _errorText;

  Future<void> _submit() async {
    final cool = LockController.instance.cooldownRemainingSeconds;
    if (cool > 0) {
      setState(() => _errorText = 'অনেকবার ভুল হয়েছে — $cool সেকেন্ড পরে আবার চেষ্টা করুন');
      return;
    }
    final ok = await LockController.instance.verifyPin(_pin.text);
    if (ok) {
      if (mounted) context.go('/');
    } else {
      final c2 = LockController.instance.cooldownRemainingSeconds;
      setState(() => _errorText =
          c2 > 0 ? 'অনেকবার ভুল হয়েছে — $c2 সেকেন্ড পরে আবার চেষ্টা করুন' : 'ভুল PIN — আবার চেষ্টা করুন');
      _pin.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const CircleAvatar(
                  radius: 34,
                  backgroundColor: AppColors.primaryLight,
                  child: Icon(Icons.lock, color: AppColors.primary, size: 30),
                ),
                const SizedBox(height: 14),
                const Text(
                  'হাট হিসাব লক করা আছে',
                  style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 18, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 4),
                const Text(
                  'PIN দিন',
                  style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 13, color: AppColors.onSurfaceVariant),
                ),
                const SizedBox(height: 18),
                SizedBox(
                  width: 200,
                  child: TextField(
                    controller: _pin,
                    keyboardType: TextInputType.number,
                    obscureText: true,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 22, letterSpacing: 8, fontFamily: 'Inter'),
                    decoration: InputDecoration(
                      errorText: _errorText,
                      border: const OutlineInputBorder(),
                    ),
                    onSubmitted: (_) => _submit(),
                  ),
                ),
                const SizedBox(height: 16),
                FilledButton(onPressed: _submit, child: const Text('খুলুন')),
                if (LockController.instance.biometricEnabled) ...[
                  const SizedBox(height: 10),
                  OutlinedButton.icon(
                    onPressed: () async {
                      final ok = await LockController.instance.authenticateBiometric();
                      if (ok && mounted) context.go('/');
                    },
                    icon: const Icon(Icons.fingerprint),
                    label: const Text('ফিঙ্গারপ্রিন্ট'),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
