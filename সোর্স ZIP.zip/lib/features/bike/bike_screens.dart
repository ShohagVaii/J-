import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/calculations/mileage_calc.dart';
import '../../core/notifications/reminder_scheduler.dart';
import '../../core/providers/app_providers.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/bangla_digits.dart';
import '../../core/utils/date_utils_bn.dart';
import '../../core/utils/money_format.dart';
import '../../core/widgets/common.dart';
import '../../data/local/app_database.dart';

/// বাইক হাব — তেল / মেইনটেন্যান্স ট্যাব + মাইলেজ সারাংশ
class BikeScreen extends ConsumerWidget {
  const BikeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final fuel = ref.watch(_fuelProvider).asData?.value ?? const <FuelLog>[];
    final maint = ref.watch(_maintProvider).asData?.value ?? const <BikeMaintenanceData>[];
    final views = fuel
        .map((f) => FuelEntryView(
              id: f.id,
              txnDate: f.txnDate,
              odometerKm: f.odometerKm,
              amountPaisa: f.amountPaisa,
              litre: f.litre,
              pricePerLitrePaisa: f.pricePerLitrePaisa,
              isFullTank: f.isFullTank,
            ))
        .toList();
    final avg = averageMileage(views);
    final results = {for (final r in computeMileage(views)) r.entryId: r};
    final totalBikeCost = fuel.fold<int>(0, (a, f) => a + f.amountPaisa) +
        maint.fold<int>(0, (a, m) => a + m.costPaisa);

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('বাইক'),
          bottom: const TabBar(
            tabs: [Tab(text: 'তেল'), Tab(text: 'মেইনটেন্যান্স')],
          ),
        ),
        body: TabBarView(
          children: [
            fuel.isEmpty
                ? EmptyState(
                    icon: Icons.local_gas_station_outlined,
                    title: 'তেলের এন্ট্রি নেই',
                    subtitle: 'ফুল ট্যাংক ভরলে মাইলেজ হিসাব হবে (কিমি/লিটার)',
                    actionLabel: 'তেল ভরা যোগ করুন',
                    // V2-N3 (v1.4.2): onAction ছিল না — বোতামটা মৃত ছিল,
                    // খালি অবস্থা থেকে তেল যোগের পথই ছিল না।
                    onAction: () => context.push('/bike/fuel/new'),
                  )
                : ListView(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
                    children: [
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(14),
                          child: Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('গড় মাইলেজ', style: Theme.of(context).textTheme.bodySmall),
                                    const SizedBox(height: 2),
                                    Text(
                                      avg == null ? '—' : '${toBanglaDigits(avg.toStringAsFixed(1))} কিমি/লি',
                                      style: const TextStyle(
                                        fontFamily: 'HindSiliguri',
                                        fontSize: 20,
                                        fontWeight: FontWeight.w700,
                                        color: AppColors.bike,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('মোট বাইক খরচ', style: Theme.of(context).textTheme.bodySmall),
                                    const SizedBox(height: 2),
                                    MoneyText(totalBikeCost, color: AppColors.bike, fontSize: 18, fontWeight: FontWeight.w700, compact: true),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                      // V1.3 (ফিচার ৮): পরের সার্ভিসের পূর্বাভাস
                      Builder(builder: (context) {
                        final est = bikeServiceEstimate(fuelLogs: fuel, maintenances: maint);
                        if (est == null) return const SizedBox.shrink();
                        final rem = est.remainingKm;
                        return Card(
                          color: AppColors.bike.withAlpha(18),
                          child: ListTile(
                            leading: const Icon(Icons.build_circle_outlined, color: AppColors.bike),
                            title: Text(
                              rem <= 0
                                  ? 'সার্ভিসের সময় পেরিয়ে গেছে!'
                                  : 'পরের সার্ভিস: আর ${toBanglaDigits(rem.toStringAsFixed(0))} কিমি বাকি',
                              style: const TextStyle(fontFamily: 'HindSiliguri', fontWeight: FontWeight.w600, fontSize: 13.5),
                            ),
                            subtitle: Text(
                              est.estimatedDate == null
                                  ? 'আনুমানিক তারিখের জন্য আরো তেলের এন্ট্রি লাগবে'
                                  : 'আনুমানিক তারিখ: ${formatDateBn(ymdOf(est.estimatedDate!))} (আনুমানিক)',
                              style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 12),
                            ),
                          ),
                        );
                      }),
                      const SizedBox(height: 8),
                      ...fuel.map((f) {
                        final r = results[f.id];
                        final mpl = r?.kmPerLitre;
                        return EntryTile(
                          icon: Icons.local_gas_station_outlined,
                          iconColor: AppColors.bike,
                          title: '${relativeDayBn(f.txnDate)} • ${MoneyFmt.taka(f.amountPaisa)}',
                          subtitle:
                              'ওডোমিটার ${toBanglaDigits(f.odometerKm.toStringAsFixed(0))} কিমি${f.isFullTank ? ' • ফুল ট্যাংক' : ''}',
                          trailing: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                mpl == null ? '—' : '${toBanglaDigits(mpl.toStringAsFixed(1))} কিমি/লি',
                                style: const TextStyle(fontFamily: 'HindSiliguri', fontWeight: FontWeight.w700, fontSize: 13),
                              ),
                              if (r?.approximate == true)
                                const Text(
                                  'আনুমানিক',
                                  style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 10.5, color: AppColors.warning),
                                ),
                            ],
                          ),
                          onLongPress: () async {
                            if (await confirmDialog(context, 'মুছে ফেলবেন?', 'তেলের এন্ট্রি আবর্জনায় যাবে')) {
                              await repo.softDelete('fuel_logs', f.id);
                            }
                          },
                        );
                      }),
                    ],
                  ),
            maint.isEmpty
                ? EmptyState(
                    icon: Icons.build_outlined,
                    title: 'মেইনটেন্যান্স নেই',
                    subtitle: 'মোবিল, সার্ভিস, পার্টস খরচ এখানে রাখুন',
                    actionLabel: 'মেইনটেন্যান্স যোগ করুন',
                    // V2-N3 (v1.4.2): onAction ছিল না — বোতামটা মৃত ছিল।
                    onAction: () => context.push('/bike/maintenance/new'),
                  )
                : ListView(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
                    children: [
                      for (final m in maint)
                        EntryTile(
                          icon: Icons.build_outlined,
                          iconColor: AppColors.bike,
                          title: '${_typeLabel(m.type)} — ${m.itemName}',
                          subtitle: '${relativeDayBn(m.txnDate)}${m.odometerKm != null ? ' • ${toBanglaDigits(m.odometerKm!.toStringAsFixed(0))} কিমি' : ''}',
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              AmountTrailing(m.costPaisa, color: AppColors.bike),
                              PopupMenuButton<String>(
                                onSelected: (v) async {
                                  if (v == 'edit') context.push('/bike/maintenance/${m.id}/edit');
                                  if (v == 'del') {
                                    if (await confirmDialog(context, 'মুছবেন?', 'আবর্জনায় যাবে')) {
                                      await repo.softDelete('bike_maintenance', m.id);
                                    }
                                  }
                                },
                                itemBuilder: (_) => const [
                                  PopupMenuItem(value: 'edit', child: Text('এডিট')),
                                  PopupMenuItem(value: 'del', child: Text('ডিলিট')),
                                ],
                              ),
                            ],
                          ),
                        ),
                    ],
                  ),
          ],
        ),
      ),
    );
  }

  String _typeLabel(String t) {
    switch (t) {
      case 'mobil':
        return 'মোবিল';
      case 'service':
        return 'সার্ভিস';
      case 'parts':
        return 'পার্টস';
      case 'tyre':
        return 'টায়ার';
      case 'chain':
        return 'চেইন';
      default:
        return 'অন্যান্য';
    }
  }
}

final _fuelProvider = StreamProvider.autoDispose((ref) { ref.watch(authStateProvider); return repo.watchFuelLogs(); });
final _maintProvider = StreamProvider.autoDispose((ref) { ref.watch(authStateProvider); return repo.watchMaintenance(); });

String _paisaToEdit(int paisa) {
  if (paisa == 0) return '';
  final taka = paisa / 100;
  return taka == taka.roundToDouble() ? taka.round().toString() : taka.toStringAsFixed(2);
}

/// তেল ভরা ফর্ম
class FuelFormScreen extends ConsumerStatefulWidget {
  final String? editId;
  const FuelFormScreen({super.key, this.editId});

  @override
  ConsumerState<FuelFormScreen> createState() => _FuelFormScreenState();
}

class _FuelFormScreenState extends ConsumerState<FuelFormScreen> {
  final _amount = TextEditingController();
  final _odometer = TextEditingController();
  final _litre = TextEditingController();
  final _price = TextEditingController();
  final _pump = TextEditingController();
  final _note = TextEditingController();
  final _date = TextEditingController(text: ymdOf(DateTime.now()));
  bool _fullTank = true;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (widget.editId != null) {
      final rows = await repo.getFuelLogs();
      final f = rows.where((x) => x.id == widget.editId).firstOrNull;
      if (f != null && mounted) {
        setState(() {
          _amount.text = _paisaToEdit(f.amountPaisa);
          _odometer.text = f.odometerKm.toString();
          _litre.text = f.litre?.toString() ?? '';
          _price.text = f.pricePerLitrePaisa == null ? '' : (f.pricePerLitrePaisa! / 100).toString();
          _pump.text = f.pumpName ?? '';
          _note.text = f.note ?? '';
          _date.text = f.txnDate;
          _fullTank = f.isFullTank;
          _loaded = true;
        });
        return;
      }
    }
    setState(() => _loaded = true);
  }

  Future<void> _save() async {
    final amount = AmountInput.readPaisa(_amount) ?? 0;
    final odo = double.tryParse(fromBanglaDigits(_odometer.text)) ?? 0;
    if (amount <= 0 || odo <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('টাকা ও ওডোমিটার (কিমি) দিন')),
      );
      return;
    }
    final litre = double.tryParse(fromBanglaDigits(_litre.text));
    final price = AmountInput.readPaisa(_price);
    if ((litre == null || litre <= 0) && (price == null || price <= 0)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('লিটার অথবা দাম (৳/লিটার) — একটি দিন')),
      );
      return;
    }
    if (widget.editId != null) {
      await repo.update(dbRef.fuelLogs, widget.editId!, FuelLogsCompanion(
        txnDate: Value(_date.text),
        odometerKm: Value(odo),
        amountPaisa: Value(amount),
        litre: Value(litre),
        pricePerLitrePaisa: Value(price),
        isFullTank: Value(_fullTank),
        pumpName: Value(_pump.text.trim().isEmpty ? null : _pump.text.trim()),
        note: Value(_note.text.trim().isEmpty ? null : _note.text.trim()),
      ));
    } else {
      await repo.insert(dbRef.fuelLogs, FuelLogsCompanion.insert(
        id: '', userId: '',
        txnDate: _date.text,
        odometerKm: odo,
        amountPaisa: amount,
        litre: Value(litre),
        pricePerLitrePaisa: Value(price),
        isFullTank: Value(_fullTank),
        pumpName: Value(_pump.text.trim().isEmpty ? null : _pump.text.trim()),
        note: Value(_note.text.trim().isEmpty ? null : _note.text.trim()),
      ));
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('সেভ হয়েছে ✓')));
      context.pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(title: Text(widget.editId != null ? 'তেল এডিট' : 'তেল ভরা')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          DateField(controller: _date, label: 'তারিখ'),
          const SizedBox(height: 12),
          TextFormField(
            controller: _odometer,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'ওডোমিটার (কিমি)', border: OutlineInputBorder(), suffixText: 'কিমি'),
          ),
          const SizedBox(height: 12),
          AmountInput(controller: _amount, label: 'টাকা খরচ'),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextFormField(
                  controller: _litre,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(labelText: 'লিটার', border: OutlineInputBorder()),
                ),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 6),
                child: Text('অথবা'),
              ),
              Expanded(
                child: AmountInput(controller: _price, label: 'দাম', suffixText: '৳/লি'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          const Text(
            'দুটির একটি দিলেই হবে — অন্যটি নিজে থেকে হিসাব হবে',
            style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 12, color: AppColors.onSurfaceVariant),
          ),
          const SizedBox(height: 12),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('ফুল ট্যাংক করেছি'),
            subtitle: const Text('মাইলেজ হিসাবের জন্য ফুল ট্যাংক জরুরি'),
            value: _fullTank,
            onChanged: (v) => setState(() => _fullTank = v),
          ),
          const SizedBox(height: 6),
          AppTextField(controller: _pump, label: 'পাম্পের নাম (ঐচ্ছিক)'),
          const SizedBox(height: 12),
          AppTextField(controller: _note, label: 'নোট/রুট (ঐচ্ছিক)'),
          const SizedBox(height: 20),
          FilledButton(onPressed: _save, child: const Text('সেভ করুন')),
        ],
      ),
    );
  }
}

/// মেইনটেন্যান্স ফর্ম
class MaintenanceFormScreen extends ConsumerStatefulWidget {
  final String? editId;
  const MaintenanceFormScreen({super.key, this.editId});

  @override
  ConsumerState<MaintenanceFormScreen> createState() => _MaintenanceFormScreenState();
}

class _MaintenanceFormScreenState extends ConsumerState<MaintenanceFormScreen> {
  final _itemName = TextEditingController();
  final _cost = TextEditingController();
  final _odometer = TextEditingController();
  final _nextKm = TextEditingController();
  final _note = TextEditingController();
  final _date = TextEditingController(text: ymdOf(DateTime.now()));
  String _type = 'service';
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (widget.editId != null) {
      final rows = await (dbRef.select(dbRef.bikeMaintenance)
            ..where((t) => t.id.equals(widget.editId!)))
          .getSingleOrNull();
      if (rows != null && mounted) {
        setState(() {
          _itemName.text = rows.itemName;
          _cost.text = _paisaToEdit(rows.costPaisa);
          _odometer.text = rows.odometerKm?.toString() ?? '';
          _nextKm.text = rows.nextServiceKm?.toString() ?? '';
          _note.text = rows.note ?? '';
          _date.text = rows.txnDate;
          _type = rows.type;
          _loaded = true;
        });
        return;
      }
    }
    setState(() => _loaded = true);
  }

  Future<void> _save() async {
    final cost = AmountInput.readPaisa(_cost) ?? 0;
    if (cost <= 0 || _itemName.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('আইটেমের নাম ও খরচ দিন')),
      );
      return;
    }
    final odo = double.tryParse(fromBanglaDigits(_odometer.text));
    final nextKm = double.tryParse(fromBanglaDigits(_nextKm.text));
    if (widget.editId != null) {
      await repo.update(dbRef.bikeMaintenance, widget.editId!, BikeMaintenanceCompanion(
        txnDate: Value(_date.text),
        type: Value(_type),
        itemName: Value(_itemName.text.trim()),
        costPaisa: Value(cost),
        odometerKm: Value(odo),
        nextServiceKm: Value(nextKm),
        note: Value(_note.text.trim().isEmpty ? null : _note.text.trim()),
      ));
    } else {
      await repo.insert(dbRef.bikeMaintenance, BikeMaintenanceCompanion.insert(
        id: '', userId: '',
        txnDate: _date.text,
        type: Value(_type),
        itemName: _itemName.text.trim(),
        costPaisa: cost,
        odometerKm: Value(odo),
        nextServiceKm: Value(nextKm),
        note: Value(_note.text.trim().isEmpty ? null : _note.text.trim()),
      ));
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('সেভ হয়েছে ✓')));
      context.pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(title: Text(widget.editId != null ? 'মেইনটেন্যান্স এডিট' : 'মেইনটেন্যান্স')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          DropdownButtonFormField<String>(
            value: _type,
            decoration: const InputDecoration(labelText: 'ধরন', border: OutlineInputBorder()),
            items: const [
              DropdownMenuItem(value: 'mobil', child: Text('মোবিল')),
              DropdownMenuItem(value: 'service', child: Text('সার্ভিস')),
              DropdownMenuItem(value: 'parts', child: Text('পার্টস')),
              DropdownMenuItem(value: 'tyre', child: Text('টায়ার')),
              DropdownMenuItem(value: 'chain', child: Text('চেইন')),
              DropdownMenuItem(value: 'other', child: Text('অন্যান্য')),
            ],
            onChanged: (v) => setState(() => _type = v ?? 'other'),
          ),
          const SizedBox(height: 12),
          AppTextField(controller: _itemName, label: 'আইটেম/কাজ'),
          const SizedBox(height: 12),
          AmountInput(controller: _cost, label: 'খরচ'),
          const SizedBox(height: 12),
          DateField(controller: _date, label: 'তারিখ'),
          const SizedBox(height: 12),
          TextFormField(
            controller: _odometer,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'ওডোমিটার (ঐচ্ছিক)', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _nextKm,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'পরের সার্ভিস কত কিমিতে (ঐচ্ছিক)', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 12),
          AppTextField(controller: _note, label: 'নোট (ঐচ্ছিক)'),
          const SizedBox(height: 20),
          FilledButton(onPressed: _save, child: const Text('সেভ করুন')),
        ],
      ),
    );
  }
}
