import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/providers/app_providers.dart';
import '../../core/widgets/amount_input.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/bangla_digits.dart';
import '../../core/utils/date_utils_bn.dart';
import '../../core/utils/money_format.dart';

const List<int> _denomsTaka = [1000, 500, 200, 100, 50, 20, 10, 5, 2, 1];

/// টাকা গুনার যন্ত্র (হিসাব মেলানো)
class TallyScreen extends ConsumerStatefulWidget {
  /// সেশন মোডে খুললে ফলাফল সেশনে ফেরত যায়
  final String? sessionId;
  const TallyScreen({super.key, this.sessionId});

  @override
  ConsumerState<TallyScreen> createState() => _TallyScreenState();
}

class _TallyScreenState extends ConsumerState<TallyScreen> {
  final Map<int, TextEditingController> _qty = {};
  final _loose = TextEditingController();

  @override
  void dispose() {
    for (final c in _qty.values) {
      c.dispose();
    }
    _loose.dispose();
    super.dispose();
  }

  int get _total {
    var total = 0;
    for (final d in _denomsTaka) {
      final q = int.tryParse(fromBanglaDigits(_qty[d]?.text ?? '0').trim()) ?? 0;
      total += d * q * 100;
    }
    final loose = int.tryParse(fromBanglaDigits(_loose.text).trim()) ?? 0;
    return total + loose * 100;
  }

  Future<void> _save() async {
    try {
      await _doSave();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('সেভ হয়নি — আবার চেষ্টা করুন'),
          backgroundColor: AppColors.expense,
        ));
      }
    }
  }

  Future<void> _doSave() async {
    final items = <Map<String, dynamic>>[];
    for (final d in _denomsTaka) {
      final q = int.tryParse(fromBanglaDigits(_qty[d]?.text ?? '0').trim()) ?? 0;
      if (q > 0) {
        items.add({'denominationPaisa': d * 100, 'quantity': q, 'lineTotalPaisa': d * q * 100});
      }
    }
    final loose = int.tryParse(fromBanglaDigits(_loose.text).trim()) ?? 0;
    if (loose > 0) {
      items.add({'denominationPaisa': 0, 'quantity': loose, 'lineTotalPaisa': loose * 100});
    }
    await repo.saveTallyWithItems(
      txnDate: ymdOf(DateTime.now()),
      sessionId: widget.sessionId,
      countedTotalPaisa: _total,
      items: items,
      note: widget.sessionId == null ? null : 'সেশন ট্যালি',
    );
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('মোট গোনা হলো: ${MoneyFmt.taka(_total)} ✓')),
      );
      if (widget.sessionId != null) {
        context.pop(_total); // V1.3: মোট টাকা সেশনে ফেরত (শুরুর/গোনা ক্যাশে বসবে)
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.sessionId != null ? 'টাকা গুনুন (সেশন)' : 'টাকা গণক'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            'প্রতিটি নোটের সংখ্যা লিখুন — মোট নিজে থেকে হিসাব হবে',
            style: Theme.of(context).textTheme.bodySmall,
          ),
          const SizedBox(height: 12),
          for (final d in _denomsTaka)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                children: [
                  SizedBox(
                    width: 84,
                    child: Text(
                      '৳${toBanglaDigits('$d')}',
                      style: const TextStyle(fontFamily: 'HindSiliguri', fontWeight: FontWeight.w700, fontSize: 15),
                    ),
                  ),
                  Expanded(
                    child: TextFormField(
                      controller: _qty.putIfAbsent(d, () => TextEditingController()),
                      keyboardType: TextInputType.number,
                      inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9০-৯]')), const BanglaDigitFormatter()],
                      decoration: const InputDecoration(
                        labelText: 'সংখ্যা',
                        isDense: true,
                        border: OutlineInputBorder(),
                      ),
                      onChanged: (_) => setState(() {}),
                    ),
                  ),
                  const SizedBox(width: 10),
                  SizedBox(
                    width: 96,
                    child: Text(
                      MoneyFmt.taka(d * (int.tryParse(fromBanglaDigits(_qty[d]?.text ?? '0').trim()) ?? 0) * 100),
                      textAlign: TextAlign.right,
                      style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 13, color: AppColors.onSurfaceVariant),
                    ),
                  ),
                ],
              ),
            ),
          const Divider(),
          Row(
            children: [
              const SizedBox(
                width: 84,
                child: Text('খুচরা', style: TextStyle(fontFamily: 'HindSiliguri', fontWeight: FontWeight.w600)),
              ),
              Expanded(
                child: TextFormField(
                  controller: _loose,
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9০-৯]')), const BanglaDigitFormatter()],
                  decoration: const InputDecoration(
                    labelText: 'মোট খুচরা টাকা',
                    suffixText: '৳',
                    isDense: true,
                    border: OutlineInputBorder(),
                  ),
                  onChanged: (_) => setState(() {}),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.primaryLight,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'মোট গোনা হলো',
                  style: TextStyle(fontFamily: 'HindSiliguri', color: AppColors.primary, fontSize: 13),
                ),
                const SizedBox(height: 4),
                Text(
                  MoneyFmt.taka(_total),
                  style: const TextStyle(
                    fontFamily: 'Inter',
                    fontSize: 26,
                    fontWeight: FontWeight.w700,
                    color: AppColors.primary,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: _total > 0 ? _save : null,
            child: Text(widget.sessionId != null ? 'সেশনে ব্যবহার করুন' : 'ট্যালি সেভ করুন'),
          ),
        ],
      ),
    );
  }
}
