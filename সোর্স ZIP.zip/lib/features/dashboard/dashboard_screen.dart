import 'package:drift/drift.dart' hide Column;
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/calculations/streak_calc.dart';
import '../../core/providers/app_providers.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/bangla_digits.dart';
import '../../core/utils/date_utils_bn.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/info_banner.dart';
import '../../data/local/app_database.dart';
import '../../data/remote/supabase_client.dart';

/// হোম ড্যাশবোর্ড — ৯ সেকশন (02_AppFlow §3.4)
class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  String _greeting() {
    final h = DateTime.now().hour;
    if (h < 12) return 'শুভ সকাল';
    if (h < 17) return 'শুভ দুপুর';
    return 'শুভ সন্ধ্যা';
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profile = ref.watch(profileProvider).asData?.value;
    final loggedIn = ref.watch(authStateProvider).loggedIn;
    final name = (profile?.displayName ?? '').trim();
    final balances = ref.watch(_balancesProvider).asData?.value ?? const [];
    final cashIn = balances.fold<int>(0, (a, r) => a + r.read<int>('balance_paisa'));
    final todaySum = ref.watch(_todaySummaryProvider).asData?.value;
    final monthSum = ref.watch(_monthSummaryProvider).asData?.value;
    final drafts = ref.watch(_draftsProvider).asData?.value ?? const <HatSession>[];
    final closingTime = profile?.dailyClosingTime ?? '21:30';
    final now = DateTime.now();
    final todayYmd = ymdOf(now);

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
        children: [
          // ১. হেডার: শুভেচ্ছা + লগইন বাটন (v1.1 ফিক্স ৫ — উপরেই লগইন)
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${_greeting()}${name.isEmpty ? '' : ', $name'}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.headlineSmall,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${formatDateBn(todayYmd)}, ${weekdayNameBn(now)}',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              IconButton(
                onPressed: () {
                  final p = ref.read(privacyProvider.notifier);
                  p.state = !p.state;
                },
                icon: Icon(
                  ref.watch(privacyProvider)
                      ? Icons.visibility_off_outlined
                      : Icons.visibility_outlined,
                  size: 22,
                ),
              ),
              const SyncBadge(),
              const SizedBox(width: 2),
              _LoginChip(loggedIn: loggedIn),
            ],
          ),
          const SizedBox(height: 12),

          // ২. হাতের ক্যাশ
          _CashCard(paisa: cashIn),
          const SizedBox(height: 12),

          // ৩. লগআউট ব্যানার (G-05) / অতিথি ব্যানার / সিঙ্ক অবস্থা
          if (!loggedIn && Supa.isLoggedOutWithData) ...[
            InfoBanner(
              icon: Icons.cloud_off_outlined,
              color: AppColors.warning,
              background: AppColors.secondaryLight,
              message: 'লগআউট অবস্থায় আছেন — ডাটা এই ফোনে আছে, সিঙ্ক হচ্ছে না। '
                  'আবার লগইন করলে সিঙ্ক শুরু হবে।',
              action: TextButton(
                onPressed: () => context.push('/auth'),
                style: TextButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  minimumSize: Size.zero,
                ),
                child: const Text('লগইন'),
              ),
            ),
            const SizedBox(height: 12),
          ] else if (!loggedIn) ...[
            InfoBanner(
              icon: Icons.lock_outline,
              color: AppColors.warning,
              background: AppColors.secondaryLight,
              message: 'আপনি অতিথি মোডে আছেন — ডাটা শুধু এই ফোনে থাকবে। '
                  'লগইন করলে অন্য ফোনেও সিঙ্ক হবে।',
              action: TextButton(
                onPressed: () => context.push('/auth'),
                style: TextButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  minimumSize: Size.zero,
                ),
                child: const Text('লগইন'),
              ),
            ),
            const SizedBox(height: 12),
          ],

          // ৪. অসমাপ্ত সেশন / হাট শুরু
          if (drafts.isNotEmpty) ...[
            _DraftSessionCard(draft: drafts.first),
            const SizedBox(height: 12),
          ],

          // ৫. আজকের সারাংশ
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.today_outlined, size: 16, color: AppColors.onSurfaceVariant),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text('আজকের হিসাব',
                            style: Theme.of(context).textTheme.titleMedium),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: StatCard(
                          label: 'আয়',
                          paisa: (todaySum?.hatIncome ?? 0) + (todaySum?.personalIncome ?? 0), // FIX C-5: ?? -এর precedence-এ পার্সোনাল আয় বাদ যেত
                          color: AppColors.income,
                          icon: Icons.trending_up,
                          compact: true,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: StatCard(
                          label: 'খরচ',
                          paisa: todaySum?.totalExpense ?? 0,
                          color: AppColors.expense,
                          icon: Icons.trending_down,
                          compact: true,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),

          // ৬. দ্রুত অ্যাক্সেস
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _chip(context, Icons.favorite, 'আম্মু', AppColors.mother, () => context.push('/mother')),
              _chip(context, Icons.savings, 'DPS', AppColors.savings, () => context.push('/dps')),
              _chip(context, Icons.handshake_outlined, 'ধার', AppColors.loan, () => context.push('/loans')),
              _chip(context, Icons.account_balance_wallet_outlined, 'ফাইন্যান্স', AppColors.savings, () => context.go('/finance')),
              _chip(context, Icons.two_wheeler, 'বাইক', AppColors.bike, () => context.push('/bike')),
              _chip(context, Icons.balance_outlined, 'হিসাব মেলানো', AppColors.info, () => context.push('/tally')),
              _chip(context, Icons.nightlight_round, 'দৈনিক বন্ধ', AppColors.primary, () => context.push('/daily-closing')),
            ],
          ),

          // V1.3 (ফিচার ৫): আম্মুকে দেওয়ার ধারাবাহিকতা
          const _MotherStreakCard(),
          const SizedBox(height: 4),

          // ৭. এই মাসের সারাংশ + চার্ট
          SectionHeader(
            title: 'এই মাসে (${monthYearBn(now.year, now.month)})',
            trailing: TextButton(
              onPressed: () => context.push('/reports'),
              child: const Text('রিপোর্ট'),
            ),
          ),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: StatCard(
                            label: 'আয়',
                            paisa: (monthSum?.hatIncome ?? 0) + (monthSum?.personalIncome ?? 0),
                            color: AppColors.income,
                            icon: Icons.arrow_downward,
                            compact: true),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: StatCard(
                            label: 'খরচ',
                            paisa: monthSum?.totalExpense ?? 0,
                            color: AppColors.expense,
                            icon: Icons.arrow_upward,
                            compact: true),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: StatCard(
                            label: 'নিট',
                            paisa: (monthSum?.hatIncome ?? 0) +
                                (monthSum?.personalIncome ?? 0) -
                                (monthSum?.totalExpense ?? 0),
                            color: (monthSum == null ||
                                    (monthSum.hatIncome + monthSum.personalIncome - monthSum.totalExpense) >= 0)
                                ? AppColors.income
                                : AppColors.expense,
                            icon: Icons.calculate_outlined,
                            compact: true),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  SizedBox(
                    height: 130,
                    child: _MonthChart(summary: monthSum),
                  ),
                ],
              ),
            ),
          ),

          // ৮. দৈনিক বন্ধ কার্ড
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              onTap: () => context.push('/daily-closing'),
              leading: const CircleAvatar(
                backgroundColor: AppColors.primaryLight,
                child: Icon(Icons.nightlight_round, color: AppColors.primary, size: 20),
              ),
              title: const Text(
                'দিনের হিসাব মেলান',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              subtitle: const Text(
                'দিন শেষে টাকা মিলিয়ে দিন বন্ধ করুন',
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              trailing: Text(
                formatTimeBn(closingTime),
                style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 12),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _chip(BuildContext context, IconData icon, String label, Color color, VoidCallback onTap) {
    return ActionChip(
      onPressed: onTap,
      backgroundColor: color.withAlpha(24),
      side: BorderSide.none,
      avatar: Icon(icon, size: 18, color: color),
      label: Text(
        label,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          fontFamily: 'HindSiliguri',
          fontSize: 12.5,
          color: color,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

class _LoginChip extends ConsumerWidget {
  final bool loggedIn;
  const _LoginChip({required this.loggedIn});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (loggedIn) {
      return PopupMenuButton<String>(
        icon: const CircleAvatar(
          radius: 14,
          backgroundColor: AppColors.primaryLight,
          child: Icon(Icons.person, size: 17, color: AppColors.primary),
        ),
        onSelected: (v) {
          if (v == 'settings') context.push('/settings');
          if (v == 'logout') _logout(context, ref);
        },
        itemBuilder: (_) => const [
          PopupMenuItem(value: 'settings', child: Text('সেটিংস')),
          PopupMenuItem(value: 'logout', child: Text('লগআউট')),
        ],
      );
    }
    return FilledButton.tonal(
      onPressed: () => context.push('/auth'),
      style: FilledButton.styleFrom(
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        minimumSize: const Size(0, 36),
        padding: const EdgeInsets.symmetric(horizontal: 14),
      ),
      child: const Text(
        'লগইন',
        maxLines: 1,
        style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 13.5),
      ),
    );
  }

  Future<void> _logout(BuildContext context, WidgetRef ref) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('লগআউট করবেন?'),
        content: const Text('ডাটা ফোনেই থাকবে; পরে লগইন করলে আবার সিঙ্ক হবে।'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('বাতিল')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('লগআউট')),
        ],
      ),
    );
    if (ok == true) {
      // V1.4.1 (G-05): uid রেখে লগআউট — ডাটা logged-out অবস্থায়ও দেখা
      // যাবে (read/local-only), সিঙ্ক বন্ধ থাকবে (docs/08 §7.1)।
      await Supa.signOutKeepingLocal();
      SupaAuthWatcher.instance.notify();
      ref.read(authStateProvider).refresh();
    }
  }
}

class _CashCard extends ConsumerWidget {
  final int paisa;
  const _CashCard({required this.paisa});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final balances = ref.watch(_balancesProvider).asData?.value ?? const [];
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.primary, AppColors.primaryDark],
        ),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'হাতের ক্যাশ',
            style: TextStyle(
              fontFamily: 'HindSiliguri',
              color: Colors.white70,
              fontSize: 13.5,
            ),
          ),
          const SizedBox(height: 6),
          // U-11: বড় ব্যালান্সে ellipsis-এ কাটা না পড়ে scale-down হবে
          SizedBox(
            width: double.infinity,
            child: FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerLeft,
              child: MoneyText(paisa, color: Colors.white, fontSize: 30, fontWeight: FontWeight.w700),
            ),
          ),
          if (balances.isNotEmpty) ...[
            const SizedBox(height: 10),
            Wrap(
              spacing: 14,
              runSpacing: 4,
              children: [
                for (final r in balances)
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        '${r.read<String>('name')}: ',
                        style: const TextStyle(fontFamily: 'HindSiliguri', color: Colors.white70, fontSize: 12),
                      ),
                      MoneyText(r.read<int>('balance_paisa'),
                          color: Colors.white, fontSize: 12, fontWeight: FontWeight.w500),
                    ],
                  ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

class _DraftSessionCard extends StatelessWidget {
  final HatSession draft;
  const _DraftSessionCard({required this.draft});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: AppColors.secondaryLight,
      child: ListTile(
        onTap: () => context.push('/sessions/${draft.id}'),
        leading: const CircleAvatar(
          backgroundColor: AppColors.secondary,
          child: Icon(Icons.pause_circle_outline, color: Colors.white, size: 22),
        ),
        title: const Text(
          'অসমাপ্ত হাট সেশন',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(color: AppColors.warning, fontWeight: FontWeight.w700),
        ),
        subtitle: Text(
          'চালিয়ে যান — ${formatDateShortBn(draft.txnDate)}',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(color: AppColors.warning),
        ),
        trailing: const Icon(Icons.chevron_right, color: AppColors.warning),
      ),
    );
  }
}

class _MonthChart extends StatelessWidget {
  final dynamic summary;
  const _MonthChart({required this.summary});

  @override
  Widget build(BuildContext context) {
    // সরল ২-বার তুলনা: আয় বনাম খরচ
    final income = ((summary?.hatIncome ?? 0) + (summary?.personalIncome ?? 0)) / 100.0;
    final expense = (summary?.totalExpense ?? 0) / 100.0;
    final maxV = [income, expense, 1.0].reduce((a, b) => a > b ? a : b);
    return BarChart(
      BarChartData(
        maxY: maxV * 1.2,
        barGroups: [
          BarChartGroupData(x: 0, barRods: [
            BarChartRodData(
              toY: income,
              color: AppColors.income,
              width: 26,
              borderRadius: BorderRadius.circular(6),
            ),
          ]),
          BarChartGroupData(x: 1, barRods: [
            BarChartRodData(
              toY: expense,
              color: AppColors.expense,
              width: 26,
              borderRadius: BorderRadius.circular(6),
            ),
          ]),
        ],
        titlesData: FlTitlesData(
          leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              getTitlesWidget: (v, _) {
                final labels = ['আয়', 'খরচ'];
                final i = v.toInt();
                return Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(
                    (i >= 0 && i < labels.length) ? labels[i] : '',
                    style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 12),
                  ),
                );
              },
            ),
          ),
        ),
        gridData: const FlGridData(show: false),
        borderData: FlBorderData(show: false),
      ),
    );
  }
}

// ---------- প্রোভাইডার ----------

final _draftsProvider = StreamProvider.autoDispose((ref) { ref.watch(authStateProvider); return repo.watchDraftSessions(); });

final _balancesProvider = StreamProvider.autoDispose<List<QueryRow>>(
  (ref) { ref.watch(authStateProvider); return repo.watchWalletBalances(); },
);

class TodaySummary {
  final int hatIncome;
  final int personalIncome;
  final int expense;
  final int mother;
  int get totalExpense => expense + mother;
  const TodaySummary({required this.hatIncome, required this.personalIncome, required this.expense, required this.mother});
}

final _todaySummaryProvider = StreamProvider.autoDispose<TodaySummary>((ref) async* {
  ref.watch(authStateProvider); // V1.4.1: uid বদলালে নতুন uid দিয়ে স্ট্রিম (F-02 প্যাটার্ন)
  final today = ymdOf(DateTime.now());
  yield await _sumFor(today);
  await for (final _ in Stream<void>.periodic(const Duration(minutes: 1))) {
    yield await _sumFor(today);
  }
});

Future<TodaySummary> _sumFor(String ymd) async {
  final db = dbRef;
  // G-12 (v1.4.1): user_id filter ছিল না — লগআউট/অন্য অ্যাকাউন্টের
  // টাকাও মোটে যোগ হতো। এখন শুধু বর্তমান ব্যবহারকারীর সারি।
  final uid = Supa.uidOrDefault;
  final hatQ = await (db.select(db.incomeHat)
        ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid) & t.txnDate.equals(ymd)))
      .get();
  final perQ = await (db.select(db.incomePersonal)
        ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid) & t.txnDate.equals(ymd)))
      .get();
  final expQ = await (db.select(db.expenses)
        ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid) & t.txnDate.equals(ymd)))
      .get();
  final motherQ = await (db.select(db.motherPayments)
        ..where((t) => t.deletedAt.isNull() & t.userId.equals(uid) & t.txnDate.equals(ymd)))
      .get();
  return TodaySummary(
    hatIncome: hatQ.fold(0, (a, r) => a + r.amountPaisa),
    personalIncome: perQ.fold(0, (a, r) => a + r.amountPaisa),
    expense: expQ.fold(0, (a, r) => a + r.amountPaisa),
    mother: motherQ.fold(0, (a, r) => a + r.amountPaisa),
  );
}

class MonthSummary {
  final int hatIncome;
  final int personalIncome;
  final int expense;
  final int mother;
  final int dps;
  final int bikeFuel;
  final int bikeMaintenance;
  int get totalExpense => expense + mother + dps + bikeFuel + bikeMaintenance;
  const MonthSummary({
    required this.hatIncome,
    required this.personalIncome,
    required this.expense,
    required this.mother,
    required this.dps,
    required this.bikeFuel,
    required this.bikeMaintenance,
  });
}

final _monthSummaryProvider = StreamProvider.autoDispose<MonthSummary>((ref) async* {
  ref.watch(authStateProvider); // V1.4.1: uid বদলালে নতুন uid দিয়ে স্ট্রিম (F-02 প্যাটার্ন)
  final now = DateTime.now();
  final prefix = '${now.year.toString().padLeft(4, '0')}-${now.month.toString().padLeft(2, '0')}';
  yield await _sumMonth(prefix);
  while (true) {
    await Future<void>.delayed(const Duration(minutes: 1));
    yield await _sumMonth(prefix);
  }
});

Future<MonthSummary> _sumMonth(String ymPrefix) async {
  final db = dbRef;
  final hat = await db.customSelect(
      "SELECT IFNULL(SUM(amount_paisa),0) s FROM income_hat WHERE deleted_at IS NULL AND user_id = ? AND txn_date LIKE ?",
      variables: [Variable.withString(Supa.uidOrDefault), Variable.withString('$ymPrefix%')]).getSingle();
  final per = await db.customSelect(
      "SELECT IFNULL(SUM(amount_paisa),0) s FROM income_personal WHERE deleted_at IS NULL AND user_id = ? AND txn_date LIKE ?",
      variables: [Variable.withString(Supa.uidOrDefault), Variable.withString('$ymPrefix%')]).getSingle();
  final exp = await db.customSelect(
      "SELECT IFNULL(SUM(amount_paisa),0) s FROM expenses WHERE deleted_at IS NULL AND user_id = ? AND txn_date LIKE ?",
      variables: [Variable.withString(Supa.uidOrDefault), Variable.withString('$ymPrefix%')]).getSingle();
  final mother = await db.customSelect(
      "SELECT IFNULL(SUM(amount_paisa),0) s FROM mother_payments WHERE deleted_at IS NULL AND user_id = ? AND txn_date LIKE ?",
      variables: [Variable.withString(Supa.uidOrDefault), Variable.withString('$ymPrefix%')]).getSingle();
  final dps = await db.customSelect(
      "SELECT IFNULL(SUM(amount_paisa),0) s FROM dps_transactions WHERE deleted_at IS NULL AND user_id = ? AND txn_date LIKE ?",
      variables: [Variable.withString(Supa.uidOrDefault), Variable.withString('$ymPrefix%')]).getSingle();
  final fuel = await db.customSelect(
      "SELECT IFNULL(SUM(amount_paisa),0) s FROM fuel_logs WHERE deleted_at IS NULL AND user_id = ? AND txn_date LIKE ?",
      variables: [Variable.withString(Supa.uidOrDefault), Variable.withString('$ymPrefix%')]).getSingle();
  final bm = await db.customSelect(
      "SELECT IFNULL(SUM(cost_paisa),0) s FROM bike_maintenance WHERE deleted_at IS NULL AND user_id = ? AND txn_date LIKE ?",
      variables: [Variable.withString(Supa.uidOrDefault), Variable.withString('$ymPrefix%')]).getSingle();
  return MonthSummary(
    hatIncome: hat.read<int>('s'),
    personalIncome: per.read<int>('s'),
    expense: exp.read<int>('s'),
    mother: mother.read<int>('s'),
    dps: dps.read<int>('s'),
    bikeFuel: fuel.read<int>('s'),
    bikeMaintenance: bm.read<int>('s'),
  );
}

/// V1.3 (ফিচার ৫): পরপর কত হাটে আম্মুকে টাকা দেওয়া হয়েছে —
/// বন্ধ সেশনের তারিখের সাথে পেমেন্টের তারিখ মিলিয়ে গণনা।
class _MotherStreakCard extends StatelessWidget {
  const _MotherStreakCard();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<HatSession>>(
      stream: repo.watchSessions(),
      builder: (c, sSnap) {
        return StreamBuilder<List<MotherPayment>>(
          stream: repo.watchMotherPayments(),
          builder: (c2, mSnap) {
            final sessions = (sSnap.data ?? const <HatSession>[])
                .where((x) => x.status == 'closed')
                .map((x) => x.txnDate)
                .toList();
            final payDates = (mSnap.data ?? const <MotherPayment>[])
                .map((x) => x.txnDate)
                .toSet();
            if (sessions.isEmpty) return const SizedBox.shrink();
            final streak = motherStreak(
              closedSessionDatesYmd: sessions,
              motherPaymentDatesYmd: payDates,
            );
            return Card(
              color: AppColors.mother.withAlpha(18),
              child: ListTile(
                leading: const Icon(Icons.favorite, color: AppColors.mother),
                title: Text(
                  streak > 0
                      ? 'আম্মুকে পরপর ${toBanglaDigits('$streak')} হাটে টাকা দেওয়া হয়েছে ❤️'
                      : 'এই হাটে আম্মুকে টাকা দেওয়া হয়নি এখনো',
                  style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 13.5, fontWeight: FontWeight.w600),
                ),
                subtitle: const Text(
                  'হাটের দিনেই দেওয়ার হিসাব (তারিখ মিলিয়ে)',
                  style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 11.5),
                ),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => context.push('/mother'),
              ),
            );
          },
        );
      },
    );
  }
}
