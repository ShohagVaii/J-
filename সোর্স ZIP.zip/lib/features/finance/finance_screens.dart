import 'package:drift/drift.dart' hide Column;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/calculations/finance_calc.dart';
import '../../core/providers/app_providers.dart';
import '../../data/remote/supabase_client.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/bangla_digits.dart';
import '../../core/utils/date_utils_bn.dart';
import '../../core/utils/money_format.dart';
import '../../core/widgets/common.dart';
import '../../data/local/app_database.dart';

/// V1.4 FinTrack পোর্ট — ফাইন্যান্স সেকশন (ড্যাশবোর্ড / লেনদেন / বাজেট / গোল)
/// ডাটা: বিদ্যমান wallet ledger + income/expense টেবিল (নতুন transaction
/// সিস্টেম নয়) + লোকাল-অনলি monthly_budgets / savings_goals।

final _finBalancesProvider =
    StreamProvider.autoDispose<List<QueryRow>>((ref) { ref.watch(authStateProvider); return repo.watchWalletBalances(); });

final _finTxProvider =
    StreamProvider.autoDispose<List<QueryRow>>((ref) { ref.watch(authStateProvider); return finRepo.watchRecentTransactions(); });

final _finBudgetsProvider = StreamProvider.autoDispose<List<MonthlyBudget>>(
    (ref) { ref.watch(authStateProvider); return finRepo.watchBudgets(monthKeyOf(DateTime.now())); });

final _finGoalsProvider =
    StreamProvider.autoDispose<List<SavingsGoal>>((ref) { ref.watch(authStateProvider); return finRepo.watchGoals(); });

/// এই মাসের ক্যাটাগরি-ভিত্তিক খরচ (বাজেটের spent)
final _finMonthSpentProvider = FutureProvider.autoDispose<Map<String, int>>((ref) async {
  ref.watch(authStateProvider); // V1.4.1: uid বদলালে নতুন uid দিয়ে স্ট্রিম (F-02 প্যাটার্ন)
  ref.watch(dataRevisionProvider); // V1.5.0: যেকোনো লোকাল write-এ ইনস্ট্যান্ট রি-কম্পিউট
  final rows = await finRepo.monthExpensesWithCategory(monthKeyOf(DateTime.now()));
  return spentByCategory([
    for (final r in rows)
      CategorySpend(
        category: r.readNullable<String>('category_name') ?? 'অন্যান্য',
        amountPaisa: r.read<int>('amount_paisa'),
      ),
  ]);
});

class FinMonthSummary {
  final int incomePaisa;
  final int expensePaisa;
  int get netPaisa => incomePaisa - expensePaisa;
  const FinMonthSummary({required this.incomePaisa, required this.expensePaisa});
}

final _finMonthProvider = FutureProvider.autoDispose<FinMonthSummary>((ref) async {
  ref.watch(authStateProvider); // V1.4.1: uid বদলালে নতুন uid দিয়ে স্ট্রিম (F-02 প্যাটার্ন)
  ref.watch(dataRevisionProvider); // V1.5.0: যেকোনো লোকাল write-এ ইনস্ট্যান্ট রি-কম্পিউট
  final db = dbRef;
  final prefix = monthKeyOf(DateTime.now());
  // G-12 (v1.4.1): user_id filter যোগ — আগে সব অ্যাকাউন্টের টাকা যোগ হতো।
  final uid = Supa.uidOrDefault;
  Future<int> sum(String sql) async {
    final r = await db.customSelect(sql, variables: [
      Variable.withString('$prefix%'),
      Variable.withString(uid),
    ]).getSingle();
    return r.read<int>('s');
  }

  final hat = await sum(
      "SELECT IFNULL(SUM(amount_paisa),0) s FROM income_hat WHERE deleted_at IS NULL AND txn_date LIKE ? AND user_id = ?");
  final per = await sum(
      "SELECT IFNULL(SUM(amount_paisa),0) s FROM income_personal WHERE deleted_at IS NULL AND txn_date LIKE ? AND user_id = ?");
  final exp = await sum(
      "SELECT IFNULL(SUM(amount_paisa),0) s FROM expenses WHERE deleted_at IS NULL AND txn_date LIKE ? AND user_id = ?");
  final mother = await sum(
      "SELECT IFNULL(SUM(amount_paisa),0) s FROM mother_payments WHERE deleted_at IS NULL AND txn_date LIKE ? AND user_id = ?");
  final dps = await sum(
      "SELECT IFNULL(SUM(amount_paisa),0) s FROM dps_transactions WHERE deleted_at IS NULL AND txn_date LIKE ? AND user_id = ?");
  final fuel = await sum(
      "SELECT IFNULL(SUM(amount_paisa),0) s FROM fuel_logs WHERE deleted_at IS NULL AND txn_date LIKE ? AND user_id = ?");
  final bm = await sum(
      "SELECT IFNULL(SUM(cost_paisa),0) s FROM bike_maintenance WHERE deleted_at IS NULL AND txn_date LIKE ? AND user_id = ?");
  return FinMonthSummary(
    incomePaisa: hat + per,
    expensePaisa: exp + mother + dps + fuel + bm,
  );
});

// ---------- রুট স্ক্রিন (৪ ট্যাব) ----------

class FinanceScreen extends ConsumerStatefulWidget {
  const FinanceScreen({super.key});

  @override
  ConsumerState<FinanceScreen> createState() => _FinanceScreenState();
}

class _FinanceScreenState extends ConsumerState<FinanceScreen> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ফাইন্যান্স')),
      body: Column(
        children: [
          // U-2/F-09 (v1.4.1): SegmentedButton ছোট স্ক্রিনে চাপা হয়ে
          // শেষ সেগমেন্ট কেটে যেত — এখন horizontally scrollable চিপ-সারি
          Padding(
            padding: const EdgeInsets.fromLTRB(0, 8, 0, 4),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  for (final (i, label, icon) in <(int, String, IconData)>[
                    (0, 'ড্যাশবোর্ড', Icons.dashboard_outlined),
                    (1, 'লেনদেন', Icons.swap_horiz),
                    (2, 'বাজেট', Icons.track_changes_outlined),
                    (3, 'গোল', Icons.flag_outlined),
                  ]) ...[
                    ChoiceChip(
                      avatar: Icon(icon, size: 16),
                      label: Text(label),
                      selected: _tab == i,
                      showCheckmark: false,
                      onSelected: (_) {
                        FocusManager.instance.primaryFocus?.unfocus();
                        setState(() => _tab = i);
                      },
                    ),
                    const SizedBox(width: 8),
                  ],
                ],
              ),
            ),
          ),
          Expanded(
            child: switch (_tab) {
              0 => _FinDashboard(onGoTab: (i) => setState(() => _tab = i)),
              1 => const _FinTransactions(),
              2 => const _FinBudgets(),
              _ => const _FinGoals(),
            },
          ),
        ],
      ),
    );
  }
}

// ---------- ড্যাশবোর্ড ট্যাব ----------

class _FinDashboard extends ConsumerWidget {
  final void Function(int) onGoTab;
  const _FinDashboard({required this.onGoTab});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final balances = ref.watch(_finBalancesProvider).asData?.value ?? const [];
    final total = balances.fold<int>(0, (a, r) => a + r.read<int>('balance_paisa'));
    final month = ref.watch(_finMonthProvider).asData?.value;
    final txns = ref.watch(_finTxProvider).asData?.value ?? const [];
    final budgets = ref.watch(_finBudgetsProvider).asData?.value ?? const <MonthlyBudget>[];
    final spent = ref.watch(_finMonthSpentProvider).asData?.value ?? const <String, int>{};
    final goals = ref.watch(_finGoalsProvider).asData?.value ?? const <SavingsGoal>[];
    final now = DateTime.now();

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [AppColors.savings, Color(0xFF0D47A1)],
            ),
            borderRadius: BorderRadius.circular(18),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('মোট ব্যালান্স (সব ওয়ালেট)',
                  style: TextStyle(fontFamily: 'HindSiliguri', color: Colors.white70, fontSize: 13.5)),
              const SizedBox(height: 6),
              // U-11: বড় অঙ্কে ellipsis-এ কাটা না পড়ে scale-down হবে
              SizedBox(
                width: double.infinity,
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  alignment: Alignment.centerLeft,
                  child: MoneyText(total, color: Colors.white, fontSize: 30, fontWeight: FontWeight.w700),
                ),
              ),
              if (balances.isNotEmpty) ...[
                const SizedBox(height: 10),
                Wrap(
                  spacing: 14,
                  runSpacing: 4,
                  children: [
                    for (final r in balances)
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text('${r.read<String>('name')}: ',
                              style: const TextStyle(fontFamily: 'HindSiliguri', color: Colors.white70, fontSize: 12)),
                          MoneyText(r.read<int>('balance_paisa'),
                              color: Colors.white, fontSize: 12, fontWeight: FontWeight.w500),
                        ],
                      ),
                  ],
                ),
              ],
            ],
          ),
        ),
        const SizedBox(height: 12),
        SectionHeader(title: 'এই মাসে (${monthYearBn(now.year, now.month)})'),
        Row(
          children: [
            Expanded(
              child: StatCard(
                label: 'আয়',
                paisa: month?.incomePaisa ?? 0,
                color: AppColors.income,
                icon: Icons.trending_up,
                compact: true,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: StatCard(
                label: 'খরচ',
                paisa: month?.expensePaisa ?? 0,
                color: AppColors.expense,
                icon: Icons.trending_down,
                compact: true,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: StatCard(
                label: 'নিট',
                paisa: month?.netPaisa ?? 0,
                color: (month?.netPaisa ?? 0) >= 0 ? AppColors.income : AppColors.expense,
                icon: Icons.calculate_outlined,
                compact: true,
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: () => context.push('/finance/add?type=income'),
                style: FilledButton.styleFrom(backgroundColor: AppColors.income),
                icon: const Icon(Icons.add, size: 18),
                label: const Text('আয় যোগ'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: FilledButton.icon(
                onPressed: () => context.push('/finance/add?type=expense'),
                style: FilledButton.styleFrom(backgroundColor: AppColors.expense),
                icon: const Icon(Icons.remove, size: 18),
                label: const Text('খরচ যোগ'),
              ),
            ),
          ],
        ),
        SectionHeader(
          title: 'বাজেট ঝলক',
          trailing: TextButton(onPressed: () => onGoTab(2), child: const Text('সব দেখুন')),
        ),
        if (budgets.isEmpty)
          const Card(
            child: ListTile(
              leading: Icon(Icons.track_changes_outlined, color: AppColors.onSurfaceVariant),
              title: Text('এই মাসে কোনো বাজেট সেট করা নেই'),
              subtitle: Text('বাজেট ট্যাব থেকে ক্যাটাগরি অনুযায়ী লিমিট দিন'),
            ),
          )
        else
          for (final b in budgets.take(3))
            _BudgetRow(budget: b, spentPaisa: spent[b.category] ?? 0, onTap: () => onGoTab(2)),
        SectionHeader(
          title: 'সেভিংস গোল',
          trailing: TextButton(onPressed: () => onGoTab(3), child: const Text('সব দেখুন')),
        ),
        if (goals.isEmpty)
          const Card(
            child: ListTile(
              leading: Icon(Icons.flag_outlined, color: AppColors.onSurfaceVariant),
              title: Text('কোনো গোল নেই'),
              subtitle: Text('গোল ট্যাব থেকে নতুন সেভিংস গোল বানান'),
            ),
          )
        else
          for (final g in goals.take(2)) _GoalRow(goal: g, onTap: () => onGoTab(3)),
        SectionHeader(
          title: 'সাম্প্রতিক লেনদেন',
          trailing: TextButton(onPressed: () => onGoTab(1), child: const Text('সব দেখুন')),
        ),
        if (txns.isEmpty)
          const EmptyState(
            icon: Icons.swap_horiz,
            title: 'এখনো কোনো লেনদেন নেই',
            subtitle: 'আয় বা খরচ যোগ করলেই এখানে দেখা যাবে',
          )
        else
          for (final r in txns.take(5)) _TxnTile(row: r),
      ],
    );
  }
}

// ---------- লেনদেন ট্যাব ----------

class _FinTransactions extends ConsumerWidget {
  const _FinTransactions();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final txns = ref.watch(_finTxProvider).asData?.value ?? const [];
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 6, 16, 0),
          child: Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => context.push('/finance/add?type=income'),
                  icon: const Icon(Icons.add, size: 17, color: AppColors.income),
                  label: const Text('আয় যোগ', style: TextStyle(color: AppColors.income)),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => context.push('/finance/add?type=expense'),
                  icon: const Icon(Icons.remove, size: 17, color: AppColors.expense),
                  label: const Text('খরচ যোগ', style: TextStyle(color: AppColors.expense)),
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: txns.isEmpty
              ? const EmptyState(
                  icon: Icons.swap_horiz,
                  title: 'এখনো কোনো লেনদেন নেই',
                  subtitle: 'হাট আয়, পার্সোনাল আয় আর খরচ এখানে একসাথে দেখা যাবে',
                )
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
                  itemCount: txns.length,
                  itemBuilder: (c, i) => _TxnTile(row: txns[i]),
                ),
        ),
      ],
    );
  }
}

class _TxnTile extends StatelessWidget {
  final QueryRow row;
  const _TxnTile({required this.row});

  @override
  Widget build(BuildContext context) {
    final isIncome = row.read<String>('src') == 'income';
    final amount = row.read<int>('amount_paisa');
    final category = row.readNullable<String>('category_name');
    final method = row.read<String>('payment_method');
    final date = row.read<String>('txn_date');
    return EntryTile(
      icon: isIncome ? Icons.arrow_downward : Icons.arrow_upward,
      iconColor: isIncome ? AppColors.income : AppColors.expense,
      title: row.read<String>('label'),
      subtitle: [
        relativeDayBn(date),
        if (category != null && category.isNotEmpty) category,
        paymentModeLabel(method),
      ].join(' • '),
      trailing: AmountTrailing(
        isIncome ? amount : -amount,
        color: isIncome ? AppColors.income : AppColors.expense,
      ),
    );
  }
}

// ---------- বাজেট ট্যাব ----------

Color _budgetColor(BudgetStatus s) => switch (s) {
      BudgetStatus.over => AppColors.expense,
      BudgetStatus.warn => AppColors.warning,
      BudgetStatus.ok => AppColors.income,
      BudgetStatus.noLimit => AppColors.onSurfaceVariant,
    };

class _BudgetRow extends StatelessWidget {
  final MonthlyBudget budget;
  final int spentPaisa;
  final VoidCallback? onTap;
  const _BudgetRow({required this.budget, required this.spentPaisa, this.onTap});

  @override
  Widget build(BuildContext context) {
    final status = budgetStatus(spentPaisa: spentPaisa, limitPaisa: budget.limitPaisa);
    final pct = budgetUsedPercent(spentPaisa: spentPaisa, limitPaisa: budget.limitPaisa);
    final color = _budgetColor(status);
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(budget.category,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.titleMedium),
                  ),
                  Text(
                    '${MoneyFmt.taka(spentPaisa)} / ${MoneyFmt.taka(budget.limitPaisa)}',
                    style: TextStyle(
                        fontFamily: 'HindSiliguri',
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: color),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: LinearProgressIndicator(
                  value: (pct / 100).clamp(0, 1).toDouble(),
                  minHeight: 9,
                  backgroundColor: AppColors.surfaceVariant,
                  valueColor: AlwaysStoppedAnimation<Color>(color),
                ),
              ),
              const SizedBox(height: 6),
              Text(
                status == BudgetStatus.over
                    ? 'লিমিট ছাড়িয়ে গেছে ${MoneyFmt.taka(spentPaisa - budget.limitPaisa)}!'
                    : 'বাকি ${MoneyFmt.taka(budgetRemaining(spentPaisa: spentPaisa, limitPaisa: budget.limitPaisa))} • ${toBanglaDigits(pct.toStringAsFixed(0))}% ব্যবহৃত',
                style: const TextStyle(
                    fontFamily: 'HindSiliguri', fontSize: 12, color: AppColors.onSurfaceVariant),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FinBudgets extends ConsumerWidget {
  const _FinBudgets();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final now = DateTime.now();
    final monthKey = monthKeyOf(now);
    final cats = ref.watch(expenseHeadsProvider).asData?.value ?? const <Category>[];
    final budgets = ref.watch(_finBudgetsProvider).asData?.value ?? const <MonthlyBudget>[];
    final spent = ref.watch(_finMonthSpentProvider).asData?.value ?? const <String, int>{};
    final byCategory = {for (final b in budgets) b.category: b};

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
      children: [
        Text(
          '${monthYearBn(now.year, now.month)} — ক্যাটাগরি অনুযায়ী লিমিট',
          style: Theme.of(context).textTheme.titleSmall,
        ),
        const SizedBox(height: 4),
        const Text(
          'লিমিট শুধু এই মাসের জন্য। কার্ডে চাপ দিয়ে লিমিট সেট/বদল করুন।',
          style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 12.5, color: AppColors.onSurfaceVariant),
        ),
        const SizedBox(height: 10),
        if (cats.isEmpty)
          const EmptyState(
            icon: Icons.category_outlined,
            title: 'কোনো খরচের ক্যাটাগরি নেই',
            subtitle: 'সেটিংস থেকে ক্যাটাগরি যোগ করুন',
          )
        else
          for (final c in cats)
            _BudgetCategoryCard(
              categoryName: c.name,
              icon: c.icon,
              budget: byCategory[c.name],
              spentPaisa: spent[c.name] ?? 0,
              onEdit: () => _editLimit(context, c.name, byCategory[c.name], monthKey),
            ),
        // ক্যাটাগরি মোছা গেলেও বাজেট থাকলে দেখাও (orphan)
        for (final b in budgets)
          if (!cats.any((c) => c.name == b.category))
            _BudgetRow(budget: b, spentPaisa: spent[b.category] ?? 0),
      ],
    );
  }

  Future<void> _editLimit(
      BuildContext context, String categoryName, MonthlyBudget? existing, String monthKey) async {
    final controller = TextEditingController(
      text: existing == null || existing.limitPaisa == 0
          ? ''
          : (existing.limitPaisa / 100).toStringAsFixed(0),
    );
    final saved = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        scrollable: true, // U-8
        title: Text('$categoryName — মাসিক লিমিট'),
        content: AmountInput(controller: controller, label: 'লিমিট (টাকা)', autofocus: true),
        actions: [
          if (existing != null)
            TextButton(
              onPressed: () async {
                await finRepo.deleteBudget(existing.id);
                if (c.mounted) Navigator.pop(c, true);
              },
              child: const Text('লিমিট মুছুন', style: TextStyle(color: AppColors.expense)),
            ),
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('বাতিল')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('সেভ')),
        ],
      ),
    );
    if (saved == true) {
      final paisa = AmountInput.readPaisa(controller);
      if (paisa != null && paisa > 0) {
        await finRepo.setBudget(category: categoryName, month: monthKey, limitPaisa: paisa);
      }
    }
    controller.dispose();
  }
}

class _BudgetCategoryCard extends StatelessWidget {
  final String categoryName;
  final String? icon;
  final MonthlyBudget? budget;
  final int spentPaisa;
  final VoidCallback onEdit;
  const _BudgetCategoryCard({
    required this.categoryName,
    required this.icon,
    required this.budget,
    required this.spentPaisa,
    required this.onEdit,
  });

  @override
  Widget build(BuildContext context) {
    if (budget == null) {
      return Card(
        child: ListTile(
          onTap: onEdit,
          leading: CircleAvatar(
            backgroundColor: AppColors.surfaceVariant,
            child: Text(icon ?? '📦', style: const TextStyle(fontSize: 17)),
          ),
          title: Text(categoryName, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text('এই মাসে খরচ ${MoneyFmt.taka(spentPaisa)} • লিমিট নেই'),
          trailing: const Icon(Icons.add_circle_outline, color: AppColors.savings),
        ),
      );
    }
    return Stack(
      children: [
        _BudgetRow(budget: budget!, spentPaisa: spentPaisa, onTap: onEdit),
        const Positioned(
          top: 8,
          right: 8,
          child: Icon(Icons.edit_outlined, size: 15, color: AppColors.onSurfaceVariant),
        ),
      ],
    );
  }
}

// ---------- গোল ট্যাব ----------

class _GoalRow extends StatelessWidget {
  final SavingsGoal goal;
  final VoidCallback? onTap;
  const _GoalRow({required this.goal, this.onTap});

  @override
  Widget build(BuildContext context) {
    final pct = goalProgressPercent(currentPaisa: goal.currentPaisa, targetPaisa: goal.targetPaisa);
    final reached = goalReached(currentPaisa: goal.currentPaisa, targetPaisa: goal.targetPaisa);
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.flag, size: 18, color: AppColors.savings),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(goal.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.titleMedium),
                  ),
                  if (reached)
                    const Chip(
                      label: Text('পূরণ হয়েছে 🎉', style: TextStyle(fontSize: 11)),
                      backgroundColor: AppColors.primaryLight,
                      visualDensity: VisualDensity.compact,
                    )
                  else
                    Text('${toBanglaDigits(pct.toStringAsFixed(0))}%',
                        style: const TextStyle(
                            fontFamily: 'HindSiliguri',
                            fontWeight: FontWeight.w700,
                            color: AppColors.savings)),
                ],
              ),
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: LinearProgressIndicator(
                  value: pct / 100,
                  minHeight: 9,
                  backgroundColor: AppColors.surfaceVariant,
                  valueColor: const AlwaysStoppedAnimation<Color>(AppColors.savings),
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'জমেছে ${MoneyFmt.taka(goal.currentPaisa)} / টার্গেট ${MoneyFmt.taka(goal.targetPaisa)}'
                '${goal.deadline == null ? '' : ' • শেষ তারিখ ${formatDateBn(goal.deadline!)}'}',
                style: const TextStyle(
                    fontFamily: 'HindSiliguri', fontSize: 12, color: AppColors.onSurfaceVariant),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FinGoals extends ConsumerWidget {
  const _FinGoals();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final goals = ref.watch(_finGoalsProvider).asData?.value ?? const <SavingsGoal>[];
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
      children: [
        FilledButton.icon(
          onPressed: () => _addGoalDialog(context),
          style: FilledButton.styleFrom(backgroundColor: AppColors.savings),
          icon: const Icon(Icons.add, size: 18),
          label: const Text('নতুন সেভিংস গোল'),
        ),
        const SizedBox(height: 6),
        const Text(
          'DPS থেকে আলাদা — যেকোনো উদ্দেশ্যে (ল্যাপটপ, বাইক, জরুরি তহবিল) টাকা জমানোর লক্ষ্য।',
          style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 12.5, color: AppColors.onSurfaceVariant),
        ),
        const SizedBox(height: 10),
        if (goals.isEmpty)
          const EmptyState(
            icon: Icons.flag_outlined,
            title: 'কোনো গোল নেই',
            subtitle: 'উপরের বাটন থেকে প্রথম গোল বানান',
          )
        else
          for (final g in goals)
            Stack(
              children: [
                _GoalRow(goal: g),
                Positioned(
                  bottom: 10,
                  right: 10,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      TextButton(
                        onPressed: () => _addMoneyDialog(context, g),
                        child: const Text('টাকা জমান'),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete_outline, size: 19, color: AppColors.expense),
                        onPressed: () async {
                          if (await confirmDialog(context, 'গোল মুছবেন?', '"${g.name}" গোলটি মুছে যাবে')) {
                            await finRepo.deleteGoal(g.id);
                          }
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
      ],
    );
  }

  Future<void> _addGoalDialog(BuildContext context) async {
    final name = TextEditingController();
    final target = TextEditingController();
    final deadline = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('নতুন সেভিংস গোল'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              AppTextField(controller: name, label: 'গোলের নাম', hint: 'যেমন: নতুন ল্যাপটপ'),
              const SizedBox(height: 12),
              AmountInput(controller: target, label: 'টার্গেট (টাকা)'),
              const SizedBox(height: 12),
              DateField(controller: deadline, label: 'শেষ তারিখ (ঐচ্ছিক)'),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('বাতিল')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('তৈরি করুন')),
        ],
      ),
    );
    if (ok == true) {
      final paisa = AmountInput.readPaisa(target) ?? 0;
      if (name.text.trim().isEmpty || paisa <= 0) {
        if (context.mounted) {
          ScaffoldMessenger.of(context)
              .showSnackBar(const SnackBar(content: Text('নাম আর টার্গেট টাকা দিন')));
        }
      } else {
        await finRepo.addGoal(
          name: name.text.trim(),
          targetPaisa: paisa,
          deadline: deadline.text.trim().isEmpty ? null : deadline.text.trim(),
        );
      }
    }
    name.dispose();
    target.dispose();
    deadline.dispose();
  }

  Future<void> _addMoneyDialog(BuildContext context, SavingsGoal goal) async {
    final amount = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        scrollable: true, // U-8
        title: Text('"${goal.name}" — টাকা জমান'),
        content: AmountInput(controller: amount, label: 'পরিমাণ (টাকা)', autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('বাতিল')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('যোগ করুন')),
        ],
      ),
    );
    if (ok == true) {
      final paisa = AmountInput.readPaisa(amount) ?? 0;
      if (paisa > 0) await finRepo.addToGoal(goal.id, paisa);
    }
    amount.dispose();
  }
}

// ---------- দ্রুত আয়/খরচ যোগ ----------

class FinanceQuickAddScreen extends ConsumerStatefulWidget {
  final String type; // 'income' | 'expense'
  const FinanceQuickAddScreen({super.key, required this.type});

  @override
  ConsumerState<FinanceQuickAddScreen> createState() => _FinanceQuickAddScreenState();
}

class _FinanceQuickAddScreenState extends ConsumerState<FinanceQuickAddScreen> {
  final _amount = TextEditingController();
  final _title = TextEditingController();
  final _note = TextEditingController();
  final _date = TextEditingController(text: ymdOf(DateTime.now()));
  String _mode = 'cash';
  String? _walletId;
  String? _categoryId; // expense: categories.id
  String? _categoryName; // income: নাম-ভিত্তিক
  List<Wallet> _wallets = [];
  List<Category> _cats = [];
  bool _loaded = false;

  bool get _isIncome => widget.type == 'income';

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    _wallets = await repo.getWallets();
    _cats = await repo.watchCategoriesScoped(_isIncome ? 'income' : 'expense').first;
    if (!mounted) return;
    setState(() {
      _walletId = _walletForMode(_mode);
      _loaded = true;
    });
  }

  String? _walletForMode(String mode) {
    for (final w in _wallets) {
      if (w.type == mode) return w.id;
    }
    return _wallets.isNotEmpty ? _wallets.first.id : null;
  }

  Future<void> _save() async {
    final amount = AmountInput.readPaisa(_amount) ?? 0;
    if (amount <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('টাকার পরিমাণ দিন')));
      return;
    }
    if (_isIncome) {
      if (_title.text.trim().isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('আয়ের বিষয় লিখুন')));
        return;
      }
      await repo.insert(dbRef.incomePersonal, IncomePersonalCompanion.insert(
        id: '', userId: '',
        title: _title.text.trim(),
        category: Value(_categoryName),
        txnDate: _date.text,
        amountPaisa: amount,
        paymentMethod: Value(_mode),
        walletId: Value(_walletId),
        note: Value(_note.text.trim().isEmpty ? null : _note.text.trim()),
      ));
    } else {
      await repo.insert(dbRef.expenses, ExpensesCompanion.insert(
        id: '', userId: '',
        scope: const Value('personal'),
        categoryId: Value(_categoryId),
        txnDate: _date.text,
        amountPaisa: amount,
        paymentMethod: Value(_mode),
        walletId: Value(_walletId),
        note: Value(_note.text.trim().isEmpty ? null : _note.text.trim()),
      ));
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('সেভ হয়েছে ✓')));
      context.pop();
    }
  }

  @override
  void dispose() {
    _amount.dispose();
    _title.dispose();
    _note.dispose();
    _date.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) {
      return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
    }
    return Scaffold(
      appBar: AppBar(title: Text(_isIncome ? 'আয় যোগ (ফাইন্যান্স)' : 'খরচ যোগ (ফাইন্যান্স)')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 96), // U-4
        children: [
          if (_isIncome) ...[
            AppTextField(controller: _title, label: 'বিষয়', hint: 'যেমন: ফ্রিল্যান্সিং পেমেন্ট'),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _categoryName,
              decoration: const InputDecoration(labelText: 'ক্যাটাগরি (ঐচ্ছিক)', border: OutlineInputBorder()),
              items: [
                const DropdownMenuItem(value: null, child: Text('— না দিলেও চলবে —')),
                for (final c in _cats)
                  DropdownMenuItem(
                    value: c.name,
                    child: Text('${c.icon == null ? '' : '${c.icon!} '}${c.name}',
                        maxLines: 1, overflow: TextOverflow.ellipsis),
                  ),
              ],
              onChanged: (v) => setState(() => _categoryName = v),
            ),
            const SizedBox(height: 12),
          ] else ...[
            DropdownButtonFormField<String>(
              value: _categoryId,
              decoration: const InputDecoration(labelText: 'ক্যাটাগরি', border: OutlineInputBorder()),
              items: [
                const DropdownMenuItem(value: null, child: Text('— অন্যান্য —')),
                for (final c in _cats)
                  DropdownMenuItem(
                    value: c.id,
                    child: Text('${c.icon == null ? '' : '${c.icon!} '}${c.name}',
                        maxLines: 1, overflow: TextOverflow.ellipsis),
                  ),
              ],
              onChanged: (v) => setState(() => _categoryId = v),
            ),
            const SizedBox(height: 12),
          ],
          AmountInput(controller: _amount, label: 'টাকার পরিমাণ', autofocus: true),
          const SizedBox(height: 12),
          DateField(controller: _date, label: 'তারিখ'),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: _mode,
            decoration: const InputDecoration(labelText: 'পেমেন্ট মাধ্যম', border: OutlineInputBorder()),
            items: [
              for (final m in finPaymentModes)
                DropdownMenuItem(value: m.$1, child: Text(m.$2)),
            ],
            onChanged: (v) => setState(() {
              _mode = v ?? 'cash';
              _walletId = _walletForMode(_mode);
            }),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: _walletId,
            decoration: const InputDecoration(labelText: 'ওয়ালেট', border: OutlineInputBorder()),
            items: [
              for (final w in _wallets)
                DropdownMenuItem(
                    value: w.id, child: Text(w.name, maxLines: 1, overflow: TextOverflow.ellipsis)),
            ],
            onChanged: (v) => setState(() => _walletId = v),
          ),
          const SizedBox(height: 12),
          AppTextField(controller: _note, label: 'নোট (ঐচ্ছিক)', maxLines: 2),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: _save,
            style: FilledButton.styleFrom(
                backgroundColor: _isIncome ? AppColors.income : AppColors.expense),
            child: const Text('সেভ করুন'),
          ),
        ],
      ),
    );
  }
}
