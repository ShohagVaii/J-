import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../../core/providers/app_providers.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/date_utils_bn.dart';
import '../../core/utils/money_format.dart';
import '../../core/widgets/common.dart';
import '../../data/local/app_database.dart';

/// খরচ তালিকা (মাসিক সারাংশসহ)
class ExpensesScreen extends ConsumerWidget {
  const ExpensesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final items = ref.watch(_expensesProvider).asData?.value ?? const <Expense>[];
    final cats = ref.watch(categoriesProvider).asData?.value ?? const <Category>[];
    final now = DateTime.now();
    final prefix = '${now.year}-${now.month.toString().padLeft(2, '0')}';
    final monthItems = items.where((e) => e.txnDate.startsWith(prefix)).toList();
    final monthTotal = monthItems.fold<int>(0, (a, r) => a + r.amountPaisa);

    final byCat = <String, int>{};
    for (final e in monthItems) {
      final cat = cats.where((c) => c.id == e.categoryId).firstOrNull;
      final name = cat?.name ?? (e.scope == 'hat' ? 'হাট খরচ' : 'খরচ');
      byCat[name] = (byCat[name] ?? 0) + e.amountPaisa;
    }
    final topCats = byCat.entries.toList()..sort((a, b) => b.value.compareTo(a.value));

    return Scaffold(
      appBar: AppBar(title: const Text('খরচ')),
      body: items.isEmpty
          ? const EmptyState(
              icon: Icons.receipt_long,
              title: 'কোনো খরচ নেই',
              subtitle: 'দৈনন্দিন খরচ এখানে যোগ করুন',
            )
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.calendar_month, size: 16, color: AppColors.onSurfaceVariant),
                            const SizedBox(width: 6),
                            Expanded(
                              child: Text(
                                '${monthYearBn(now.year, now.month)} — মোট খরচ',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: Theme.of(context).textTheme.titleMedium,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: MoneyText(monthTotal, color: AppColors.expense, fontSize: 22, fontWeight: FontWeight.w700),
                        ),
                        if (topCats.isNotEmpty) ...[
                          const SizedBox(height: 10),
                          Wrap(
                            spacing: 8,
                            runSpacing: 6,
                            children: [
                              for (final c in topCats.take(5))
                                Chip(
                                  label: Text(
                                    '${c.key}: ${MoneyFmt.compact(c.value)}',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 12),
                                  ),
                                ),
                            ],
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                for (final e in items.take(200))
                  EntryTile(
                    icon: Icons.receipt_long,
                    iconColor: AppColors.expense,
                    title: e.note?.isEmpty ?? true
                        ? (cats.where((c) => c.id == e.categoryId).firstOrNull?.name ?? 'খরচ')
                        : e.note!,
                    subtitle: '${relativeDayBn(e.txnDate)} • ${e.scope == 'hat' ? 'হাট' : e.scope == 'bike' ? 'বাইক' : 'ব্যক্তিগত'}',
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        AmountTrailing(e.amountPaisa, color: AppColors.expense),
                        PopupMenuButton<String>(
                          onSelected: (v) async {
                            if (v == 'edit') context.push('/expenses/${e.id}/edit');
                            if (v == 'del') {
                              if (await confirmDialog(context, 'মুছে ফেলবেন?', 'খরচটি আবর্জনায় যাবে')) {
                                await repo.softDelete('expenses', e.id);
                              }
                            }
                          },
                          itemBuilder: (_) => const [
                            PopupMenuItem(value: 'edit', child: Text('এডিট')),
                            PopupMenuItem(value: 'del', child: Text('ডিলিট')),
                          ],
                        ),
                      ],
                    ),
                  ),
              ],
            ),
      floatingActionButton: FloatingActionButton.extended(
        heroTag: 'expense_add',
        onPressed: () => context.push('/expenses/new'),
        backgroundColor: AppColors.expense,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('খরচ যোগ', style: TextStyle(color: Colors.white)),
      ),
    );
  }
}

final _expensesProvider = StreamProvider.autoDispose((ref) { ref.watch(authStateProvider); return repo.watchExpenses(); });

/// খরচ ফর্ম — রসিদ ছবি অ্যাটাচ সহ (v1.1: আগের বাকি কাজ)
class ExpenseFormScreen extends ConsumerStatefulWidget {
  final String? editId;
  const ExpenseFormScreen({super.key, this.editId});

  @override
  ConsumerState<ExpenseFormScreen> createState() => _ExpenseFormScreenState();
}

class _ExpenseFormScreenState extends ConsumerState<ExpenseFormScreen> {
  final _amount = TextEditingController();
  final _note = TextEditingController();
  final _date = TextEditingController(text: ymdOf(DateTime.now()));
  String _scope = 'personal';
  String _method = 'cash';
  String? _categoryId;
  String? _walletId;
  String? _receiptPath;
  List<Category> _cats = [];
  List<Wallet> _wallets = [];
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final cats = await repo.watchCategories().first;
    final wallets = await repo.getWallets();
    if (widget.editId != null) {
      final items = await repo.watchExpenses().first;
      final e = items.where((x) => x.id == widget.editId).firstOrNull;
      if (e != null) {
        _amount.text = e.amountPaisa == 0 ? '' : (e.amountPaisa / 100).toString();
        _note.text = e.note ?? '';
        _date.text = e.txnDate;
        _scope = e.scope;
        _method = e.paymentMethod;
        _categoryId = e.categoryId;
        _walletId = e.walletId;
        final atts = await repo.attachmentsFor(e.id);
        if (atts.isNotEmpty) _receiptPath = atts.first.localPath;
      }
    }
    if (!mounted) return;
    setState(() {
      _cats = cats;
      _wallets = wallets;
      _categoryId ??= cats.isNotEmpty ? cats.first.id : null;
      _walletId ??= wallets.isNotEmpty ? wallets.first.id : null;
      _loaded = true;
    });
  }

  Future<void> _pickReceipt() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.camera, imageQuality: 70);
    final file = picked ?? await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 70);
    if (file == null) return;
    try {
      final dir = await getApplicationDocumentsDirectory();
      final attDir = Directory('${dir.path}/receipts');
      if (!await attDir.exists()) await attDir.create(recursive: true);
      final target = p.join(attDir.path, '${DateTime.now().millisecondsSinceEpoch}.jpg');
      final compressed = await FlutterImageCompress.compressAndGetFile(
        file.path, target, quality: 60,
      );
      setState(() => _receiptPath = compressed?.path ?? target);
    } catch (_) {
      setState(() => _receiptPath = file.path);
    }
  }

  Future<void> _save() async {
    final amount = AmountInput.readPaisa(_amount) ?? 0;
    if (amount <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('টাকার পরিমাণ দিন')));
      return;
    }
    String id;
    if (widget.editId != null) {
      id = widget.editId!;
      await repo.update(dbRef.expenses, id, ExpensesCompanion(
        scope: Value(_scope),
        categoryId: Value(_categoryId),
        txnDate: Value(_date.text),
        amountPaisa: Value(amount),
        paymentMethod: Value(_method),
        walletId: Value(_method == 'baki' ? null : _walletId),
        note: Value(_note.text.trim().isEmpty ? null : _note.text.trim()),
      ));
    } else {
      id = await repo.insert(dbRef.expenses, ExpensesCompanion.insert(
        id: '', userId: '',
        scope: Value(_scope),
        categoryId: Value(_categoryId),
        txnDate: _date.text,
        amountPaisa: amount,
        paymentMethod: Value(_method),
        walletId: Value(_method == 'baki' ? null : _walletId),
        note: Value(_note.text.trim().isEmpty ? null : _note.text.trim()),
      ));
    }
    if (_receiptPath != null) {
      final f = File(_receiptPath!);
      await repo.attach(
        ownerType: 'expense',
        ownerId: id,
        localPath: _receiptPath!,
        mime: 'image/jpeg',
        sizeBytes: await f.length(),
      );
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('সেভ হয়েছে ✓')));
      context.pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(title: Text(widget.editId != null ? 'খরচ এডিট' : 'নতুন খরচ')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'personal', label: Text('ব্যক্তিগত')),
              ButtonSegment(value: 'hat', label: Text('হাট')),
            ],
            selected: {_scope},
            onSelectionChanged: (v) => setState(() => _scope = v.first),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: _categoryId,
            decoration: const InputDecoration(labelText: 'খাত', border: OutlineInputBorder()),
            items: [
              for (final c in _cats)
                DropdownMenuItem(
                  value: c.id,
                  child: Text('${c.icon ?? ''} ${c.name}', maxLines: 1, overflow: TextOverflow.ellipsis),
                ),
            ],
            onChanged: (v) => setState(() => _categoryId = v),
          ),
          const SizedBox(height: 12),
          AmountInput(controller: _amount, label: 'টাকার পরিমাণ', autofocus: widget.editId == null),
          const SizedBox(height: 12),
          DateField(controller: _date, label: 'তারিখ'),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: _method,
            decoration: const InputDecoration(labelText: 'মাধ্যম', border: OutlineInputBorder()),
            items: const [
              DropdownMenuItem(value: 'cash', child: Text('নগদ')),
              DropdownMenuItem(value: 'bkash', child: Text('বিকাশ')),
              DropdownMenuItem(value: 'nagad', child: Text('নগদ (মোবাইল)')),
              DropdownMenuItem(value: 'bank', child: Text('ব্যাংক')),
              DropdownMenuItem(value: 'baki', child: Text('বাকি')),
            ],
            onChanged: (v) => setState(() => _method = v ?? 'cash'),
          ),
          if (_method != 'baki') ...[
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _walletId,
              decoration: const InputDecoration(labelText: 'ওয়ালেট', border: OutlineInputBorder()),
              items: [
                for (final w in _wallets)
                  DropdownMenuItem(value: w.id, child: Text(w.name, maxLines: 1, overflow: TextOverflow.ellipsis)),
              ],
              onChanged: (v) => setState(() => _walletId = v),
            ),
          ],
          const SizedBox(height: 12),
          AppTextField(controller: _note, label: 'নোট (ঐচ্ছিক)', maxLines: 2),
          const SizedBox(height: 12),
          // রসিদ ছবি
          Row(
            children: [
              OutlinedButton.icon(
                onPressed: _pickReceipt,
                icon: const Icon(Icons.photo_camera_outlined, size: 18),
                label: const Text('রসিদের ছবি'),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  _receiptPath == null ? 'কোনো ছবি নেই' : 'ছবি যুক্ত হয়েছে ✓',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontFamily: 'HindSiliguri',
                    fontSize: 13,
                    color: _receiptPath == null ? AppColors.onSurfaceVariant : AppColors.income,
                  ),
                ),
              ),
              if (_receiptPath != null)
                IconButton(
                  icon: const Icon(Icons.close, size: 18),
                  onPressed: () => setState(() => _receiptPath = null),
                ),
            ],
          ),
          if (_receiptPath != null) ...[
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.file(File(_receiptPath!), height: 140, fit: BoxFit.cover),
            ),
          ],
          const SizedBox(height: 20),
          FilledButton(onPressed: _save, child: const Text('সেভ করুন')),
        ],
      ),
    );
  }
}
