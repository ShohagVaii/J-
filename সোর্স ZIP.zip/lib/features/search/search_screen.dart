import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:drift/drift.dart' show Variable;

import '../../core/providers/app_providers.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/date_utils_bn.dart';
import '../../core/utils/money_format.dart';
import '../../data/local/app_database.dart';

/// গ্লোবাল খুঁজুন — সব এন্ট্রি জুড়ে (v1.1 ফিক্স ৮: সাদা স্ক্রিন ঠিক)
class SearchScreen extends ConsumerStatefulWidget {
  const SearchScreen({super.key});

  @override
  ConsumerState<SearchScreen> createState() => _SearchScreenState();
}

class _SearchResult {
  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final int paisa;
  final VoidCallback onTap;
  const _SearchResult({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    required this.paisa,
    required this.onTap,
  });
}

class _SearchScreenState extends ConsumerState<SearchScreen> {
  final _q = TextEditingController();
  String _query = '';
  bool _searching = false;
  List<_SearchResult> _results = [];
  Object? _error;

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  Future<void> _run(String q) async {
    if (q.isEmpty) return;
    _query = q;
    setState(() {
      _searching = true;
      _error = null;
    });
    try {
      final like = '%$q%';
      final db = dbRef;
      final out = <_SearchResult>[];

      // V2-N2 (v1.4.2): ক্যাটাগরি-শব্দে খুঁজলে ওই সেকশনের সব এন্ট্রি —
      // আগে শুধু নাম/নোটে LIKE ম্যাচ হতো, তাই "dps" লিখলে কোনো DPS
      // অ্যাকাউন্টের নামে dps না থাকলে ফলাফল শূন্য আসত, যদিও নিচের
      // হিন্ট ঠিক এগুলোর নাম ধরেই খোঁজার প্রতিশ্রুতি দেয়।
      final ql = q.trim().toLowerCase();
      bool aliasOf(List<String> words) =>
          words.any((w) => ql == w || ql.startsWith('$w '));
      final allDps = aliasOf(['dps', 'ডিপিএস', 'সঞ্চয়', 'সঞ্চয় হিসাব']);
      final allMother = aliasOf(['আম্মু', 'মা', 'mother', 'আম্মুকে দেওয়া']);
      final allLoans = aliasOf(['ধার', 'দেনা', 'লোন', 'loan', 'ঋণ', 'ধার-দেনা']);
      final allFuel = aliasOf(['তেল', 'fuel', 'বাইক', 'bike', 'পেট্রোল', 'পেট্রল']);

      final hats = await db.customSelect(
        "SELECT * FROM hats WHERE deleted_at IS NULL AND (name LIKE ? OR location LIKE ?) LIMIT 10",
        variables: [Variable.withString(like), Variable.withString(like)],
      ).get();
      for (final r in hats) {
        final id = r.read<String>('id');
        out.add(_SearchResult(
          icon: Icons.storefront,
          color: AppColors.primary,
          title: r.read<String>('name'),
          subtitle: 'হাট',
          paisa: 0,
          onTap: () => context.push('/sessions/new?hatId=$id'),
        ));
      }

      final incomes = await db.customSelect(
        // FIX M-1: বন্ধনী ছাড়া deleted সারিও আসত (AND/OR precedence)
        "SELECT * FROM income_hat WHERE deleted_at IS NULL AND (IFNULL(note,'') LIKE ? OR txn_date LIKE ?) LIMIT 20",
        variables: [Variable.withString(like), Variable.withString(like)],
      ).get();
      for (final r in incomes) {
        final id = r.read<String>('id');
        out.add(_SearchResult(
          icon: Icons.storefront,
          color: AppColors.income,
          title: r.read<String?>('note') ?? 'হাট আয়',
          subtitle: formatDateBn(r.read<String>('txn_date')),
          paisa: r.read<int>('amount_paisa'),
          onTap: () => context.push('/income/$id/edit?type=hat'),
        ));
      }

      final personal = await db.customSelect(
        "SELECT * FROM income_personal WHERE deleted_at IS NULL AND (title LIKE ? OR IFNULL(note,'') LIKE ? OR txn_date LIKE ?) LIMIT 20",
        variables: [Variable.withString(like), Variable.withString(like), Variable.withString(like)],
      ).get();
      for (final r in personal) {
        final id = r.read<String>('id');
        out.add(_SearchResult(
          icon: Icons.person,
          color: AppColors.savings,
          title: r.read<String>('title'),
          subtitle: formatDateBn(r.read<String>('txn_date')),
          paisa: r.read<int>('amount_paisa'),
          onTap: () => context.push('/income/$id/edit?type=personal'),
        ));
      }

      final expenses = await db.customSelect(
        "SELECT * FROM expenses WHERE deleted_at IS NULL AND (IFNULL(note,'') LIKE ? OR txn_date LIKE ?) LIMIT 20",
        variables: [Variable.withString(like), Variable.withString(like)],
      ).get();
      for (final r in expenses) {
        final id = r.read<String>('id');
        out.add(_SearchResult(
          icon: Icons.receipt_long,
          color: AppColors.expense,
          title: r.read<String?>('note') ?? 'খরচ',
          subtitle: formatDateBn(r.read<String>('txn_date')),
          paisa: r.read<int>('amount_paisa'),
          onTap: () => context.push('/expenses/$id/edit'),
        ));
      }

      final mother = await db.customSelect(
        allMother
            ? "SELECT * FROM mother_payments WHERE deleted_at IS NULL ORDER BY txn_date DESC LIMIT 20"
            : "SELECT * FROM mother_payments WHERE deleted_at IS NULL AND (IFNULL(note,'') LIKE ? OR txn_date LIKE ?) LIMIT 20",
        variables:
            allMother ? [] : [Variable.withString(like), Variable.withString(like)],
      ).get();
      for (final r in mother) {
        out.add(_SearchResult(
          icon: Icons.favorite,
          color: AppColors.mother,
          title: r.read<String?>('note') ?? 'আম্মুকে দেওয়া',
          subtitle: formatDateBn(r.read<String>('txn_date')),
          paisa: r.read<int>('amount_paisa'),
          onTap: () => context.push('/mother'),
        ));
      }

      final persons = await db.customSelect(
        allLoans
            ? "SELECT * FROM loan_persons WHERE deleted_at IS NULL LIMIT 10"
            : "SELECT * FROM loan_persons WHERE deleted_at IS NULL AND name LIKE ? LIMIT 10",
        variables: allLoans ? [] : [Variable.withString(like)],
      ).get();
      for (final r in persons) {
        final id = r.read<String>('id');
        out.add(_SearchResult(
          icon: Icons.handshake_outlined,
          color: AppColors.loan,
          title: r.read<String>('name'),
          subtitle: 'ধারের ব্যক্তি',
          paisa: 0,
          onTap: () => context.push('/loans/person/$id'),
        ));
      }

      final dps = await db.customSelect(
        allDps
            ? "SELECT * FROM dps_accounts WHERE deleted_at IS NULL LIMIT 10"
            : "SELECT * FROM dps_accounts WHERE deleted_at IS NULL AND institution_name LIKE ? LIMIT 10",
        variables: allDps ? [] : [Variable.withString(like)],
      ).get();
      for (final r in dps) {
        final id = r.read<String>('id');
        out.add(_SearchResult(
          icon: Icons.savings,
          color: AppColors.savings,
          title: r.read<String>('institution_name'),
          subtitle: 'DPS/সঞ্চয়',
          paisa: r.read<int>('monthly_installment_paisa'),
          onTap: () => context.push('/dps/$id'),
        ));
      }

      final fuel = await db.customSelect(
        allFuel
            ? "SELECT * FROM fuel_logs WHERE deleted_at IS NULL ORDER BY txn_date DESC LIMIT 20"
            : "SELECT * FROM fuel_logs WHERE deleted_at IS NULL AND (IFNULL(pump_name,'') LIKE ? OR IFNULL(note,'') LIKE ? OR txn_date LIKE ?) LIMIT 20",
        variables: allFuel
            ? []
            : [Variable.withString(like), Variable.withString(like), Variable.withString(like)],
      ).get();
      for (final r in fuel) {
        out.add(_SearchResult(
          icon: Icons.local_gas_station_outlined,
          color: AppColors.bike,
          title: r.read<String?>('pump_name') ?? 'তেল ভরা',
          subtitle: formatDateBn(r.read<String>('txn_date')),
          paisa: r.read<int>('amount_paisa'),
          onTap: () => context.push('/bike'),
        ));
      }

      if (!mounted) return;
      setState(() {
        _results = out;
        _searching = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e;
        _searching = false;
        _results = [];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _q,
          autofocus: true,
          decoration: const InputDecoration(
            hintText: 'নাম, তারিখ বা নোট লিখে খুঁজুন…',
            border: InputBorder.none,
          ),
          style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 16),
          textInputAction: TextInputAction.search,
          onSubmitted: _run,
          onChanged: (v) {
            if (v.trim().length >= 3) _run(v.trim());
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () => _run(_q.text.trim()),
          ),
        ],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_searching) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.error_outline, size: 48, color: AppColors.expense),
              const SizedBox(height: 8),
              const Text(
                'খোঁজায় সমস্যা হয়েছে — আবার চেষ্টা করুন',
                textAlign: TextAlign.center,
                style: TextStyle(fontFamily: 'HindSiliguri'),
              ),
              const SizedBox(height: 12),
              OutlinedButton(
                onPressed: () => _run(_q.text.trim()),
                child: const Text('আবার চেষ্টা'),
              ),
            ],
          ),
        ),
      );
    }
    if (_query.isEmpty && _q.text.trim().isEmpty) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.search, size: 52, color: AppColors.onSurfaceVariant),
            SizedBox(height: 8),
            Text(
              'যা খুঁজতে চান লিখুন — হাট, আয়, খরচ, আম্মু,\nDPS, ধার, তেল — সব একসাথে খোঁজা হবে',
              textAlign: TextAlign.center,
              style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 13.5, height: 1.5),
            ),
          ],
        ),
      );
    }
    if (_results.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.search_off, size: 52, color: AppColors.onSurfaceVariant),
            const SizedBox(height: 8),
            Text(
              '"${_q.text.trim()}" এর জন্য কিছু পাওয়া যায়নি',
              textAlign: TextAlign.center,
              style: const TextStyle(fontFamily: 'HindSiliguri'),
            ),
          ],
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
      itemCount: _results.length,
      itemBuilder: (c, i) {
        final r = _results[i];
        return Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: ListTile(
            onTap: r.onTap,
            leading: CircleAvatar(
              backgroundColor: r.color.withAlpha(28),
              child: Icon(r.icon, color: r.color, size: 20),
            ),
            title: Text(r.title, maxLines: 1, overflow: TextOverflow.ellipsis),
            subtitle: Text(r.subtitle, maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 12)),
            trailing: r.paisa > 0
                ? Text(
                    MoneyFmt.taka(r.paisa),
                    style: TextStyle(fontFamily: 'HindSiliguri', fontWeight: FontWeight.w700, fontSize: 13, color: r.color),
                  )
                : null,
          ),
        );
      },
    );
  }
}
