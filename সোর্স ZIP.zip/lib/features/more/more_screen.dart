import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/providers/app_providers.dart';
import '../../core/sync/sync_engine.dart';
import '../../core/theme/app_colors.dart';
import '../../data/remote/supabase_client.dart';

/// আরও — সব সেকশনের মেনু + উপরে অ্যাকাউন্ট কার্ড (v1.1 ফিক্স ৫)
class MoreScreen extends ConsumerWidget {
  const MoreScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final loggedIn = ref.watch(authStateProvider).loggedIn;
    final profile = ref.watch(profileProvider).asData?.value;
    final syncState = ref.watch(syncStatusProvider).status;
    final name = (profile?.displayName ?? '').trim();

    final items = <_MoreItem>[
      _MoreItem(Icons.calculate_outlined, 'টাকা গণক', AppColors.info, () => context.push('/tally')),
      _MoreItem(Icons.scale_outlined, 'দর-পড়তা', AppColors.primary, () => context.push('/tools/rate')),
      _MoreItem(Icons.cake_outlined, 'বয়স হিসাব', AppColors.mother, () => context.push('/tools/age')),
      _MoreItem(Icons.balance_outlined, 'হিসাব মেলানো', AppColors.primary, () => context.push('/daily-closing')),
      _MoreItem(Icons.bar_chart, 'রিপোর্ট', AppColors.savings, () => context.push('/reports')),
      _MoreItem(Icons.calendar_month, 'ক্যালেন্ডার', AppColors.secondary, () => context.push('/calendar')),
      _MoreItem(Icons.search, 'খুঁজুন', AppColors.info, () => context.push('/search')),
      _MoreItem(Icons.account_balance_wallet_outlined, 'ফাইন্যান্স', AppColors.savings, () => context.go('/finance')),
      _MoreItem(Icons.trending_up, 'আয়', AppColors.income, () => context.push('/income')),
      _MoreItem(Icons.favorite, 'আম্মু', AppColors.mother, () => context.push('/mother')),
      _MoreItem(Icons.savings, 'DPS/সঞ্চয়', AppColors.savings, () => context.push('/dps')),
      _MoreItem(Icons.handshake_outlined, 'ধার-দেনা', AppColors.loan, () => context.push('/loans')),
      _MoreItem(Icons.two_wheeler, 'বাইক', AppColors.bike, () => context.push('/bike')),
      _MoreItem(Icons.delete_outline, 'আবর্জনা', AppColors.onSurfaceVariant, () => context.push('/recycle-bin')),
      _MoreItem(Icons.settings_outlined, 'সেটিংস', AppColors.onSurfaceVariant, () => context.push('/settings')),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('আরও')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
        children: [
          // অ্যাকাউন্ট কার্ড — উপরেই (লগইন খোঁজা যাবে না গভীরে)
          Card(
            color: loggedIn ? AppColors.primaryLight : AppColors.secondaryLight,
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  CircleAvatar(
                    backgroundColor: loggedIn ? AppColors.primary : AppColors.secondary,
                    child: Icon(loggedIn ? Icons.person : Icons.person_outline, color: Colors.white),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          loggedIn ? (name.isEmpty ? 'আমার অ্যাকাউন্ট' : name) : 'অতিথি মোড',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontFamily: 'HindSiliguri', fontWeight: FontWeight.w700, fontSize: 15),
                        ),
                        Text(
                          loggedIn
                              ? (syncState.state == SyncState.synced
                                  ? 'সিঙ্ক সম্পন্ন ✓'
                                  : syncState.message)
                              : 'লগইন করলে ডাটা অন্য ফোনেও যাবে',
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          softWrap: true,
                          style: TextStyle(
                            fontFamily: 'HindSiliguri',
                            fontSize: 12,
                            color: loggedIn ? AppColors.primary : AppColors.warning,
                          ),
                        ),
                      ],
                    ),
                  ),
                  loggedIn
                      ? TextButton(
                          onPressed: () => context.push('/settings'),
                          child: const Text('সেটিংস'),
                        )
                      : FilledButton(
                          onPressed: () => context.push('/auth'),
                          child: const Text('লগইন'),
                        ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          GridView.count(
            crossAxisCount: 3,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            childAspectRatio: 1.05,
            children: [
              for (final it in items)
                InkWell(
                  onTap: it.onTap,
                  borderRadius: BorderRadius.circular(14),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(color: it.color.withAlpha(26), shape: BoxShape.circle),
                        child: Icon(it.icon, color: it.color, size: 21),
                      ),
                      const SizedBox(height: 6),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: Text(
                          it.label,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          // F-11: লেবেল বড় + গাঢ় (আগে 12px ও থিম-ডিফল্ট
                          // ম্লান রঙে দূর থেকে পড়া যেত না)
                          style: TextStyle(
                            fontFamily: 'HindSiliguri',
                            fontSize: 13.5,
                            height: 1.3,
                            fontWeight: FontWeight.w600,
                            color: Theme.of(context).colorScheme.onSurface,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
          if (Supa.isLoggedIn)
            Center(
              child: TextButton(
                // v1.4.1: ড্যাশবোর্ডের মতো এখানেও confirm dialog —
                // আগে confirm ছাড়াই সরাসরি লগআউট হয়ে যেত
                onPressed: () => _logout(context, ref),
                child: const Text('লগআউট'),
              ),
            ),
        ],
      ),
    );
  }
}

/// লগআউট — confirm dialog-সহ (ড্যাশবোর্ডের পপআপ মেনুর সঙ্গে একই আচরণ)।
/// V1.4.1 (G-05): Supa.signOutKeepingLocal() — uid থেকে যায়, ডাটা
/// logged-out অবস্থায়ও দেখা যায়, সিঙ্ক বন্ধ (docs/08 §7.1)।
Future<void> _logout(BuildContext context, WidgetRef ref) async {
  final ok = await showDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      title: const Text('লগআউট করবেন?'),
      content: const Text('ডাটা ফোনেই থাকবে; পরে লগইন করলে আবার সিঙ্ক হবে।'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('বাতিল')),
        FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('লগআউট')),
      ],
    ),
  );
  if (ok == true) {
    await Supa.signOutKeepingLocal();
    SupaAuthWatcher.instance.notify();
    ref.read(authStateProvider).refresh();
  }
}

class _MoreItem {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;
  const _MoreItem(this.icon, this.label, this.color, this.onTap);
}
