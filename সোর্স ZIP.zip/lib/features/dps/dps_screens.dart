import 'package:flutter/material.dart';
import '../../core/notifications/reminder_scheduler.dart';
import 'package:drift/drift.dart' hide Column;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/calculations/dps_calc.dart';
import '../../core/providers/app_providers.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/bangla_digits.dart';
import '../../core/utils/date_utils_bn.dart';
import '../../core/utils/money_format.dart';
import '../../core/widgets/common.dart';
import '../../data/local/app_database.dart';

/// DPS তালিকা — দৈনিক/সাপ্তাহিক/মাসিক ফ্রিকোয়েন্সি সহ (v1.1 ফিক্স ৭)
class DpsScreen extends ConsumerWidget {
  const DpsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final accounts = ref.watch(_dpsProvider).asData?.value ?? const <DpsAccount>[];
    final allTx = ref.watch(_dpsTxAllProvider).asData?.value ?? const <DpsTransaction>[];
    return Scaffold(
      appBar: AppBar(title: const Text('DPS / সঞ্চয়')),
      body: accounts.isEmpty
          ? EmptyState(
              icon: Icons.savings,
              title: 'কোনো সঞ্চয় নেই',
              subtitle: 'ব্যাংক/এনজিও-র DPS বা নিজের সঞ্চয় যোগ করুন — দৈনিক, সাপ্তাহিক বা মাসিক',
              actionLabel: 'সঞ্চয় যোগ করুন',
              onAction: () => context.push('/dps/new'),
            )
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
              itemCount: accounts.length,
              itemBuilder: (c, i) {
                final a = accounts[i];
                final tx = allTx.where((t) => t.dpsAccountId == a.id && t.deletedAt == null).toList();
                final deposited = tx.fold<int>(0, (x, t) => x + t.amountPaisa);
                final progress = a.targetPaisa != null && a.targetPaisa! > 0
                    ? (deposited / a.targetPaisa!).clamp(0.0, 1.0)
                    : null;
                final nextDue = DpsCalcNext.nextDue(
                  frequency: a.frequency,
                  dueDay: a.dueDay,
                  startDateYmd: a.startDate,
                  lastDepositDateYmd: tx.isEmpty ? null : tx.map((t) => t.txnDate).reduce((x, y) => x.compareTo(y) > 0 ? x : y),
                );
                return Card(
                  margin: const EdgeInsets.only(bottom: 10),
                  child: InkWell(
                    onTap: () => context.push('/dps/${a.id}'),
                    borderRadius: BorderRadius.circular(14),
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const CircleAvatar(
                                backgroundColor: Color(0x1A1565C0),
                                child: Icon(Icons.savings, color: AppColors.savings, size: 20),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  a.institutionName,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: Theme.of(context).textTheme.titleMedium,
                                ),
                              ),
                              Chip(
                                label: Text(
                                  DpsFrequency.label(a.frequency),
                                  maxLines: 1,
                                  style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 11.5, color: AppColors.savings),
                                ),
                                backgroundColor: AppColors.savings.withAlpha(20),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  'কিস্তি: ${MoneyFmt.taka(a.monthlyInstallmentPaisa)} • জমা: ${MoneyFmt.taka(deposited)}',
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  softWrap: true,
                                  style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 12.5),
                                ),
                              ),
                            ],
                          ),
                          if (progress != null) ...[
                            const SizedBox(height: 8),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(6),
                              child: LinearProgressIndicator(
                                value: progress,
                                backgroundColor: AppColors.surfaceVariant,
                                color: AppColors.savings,
                                minHeight: 8,
                              ),
                            ),
                          ],
                          const SizedBox(height: 6),
                          Text(
                            'পরবর্তী কিস্তি: ${nextDue == null ? '—' : relativeDayBn(nextDue)} • ${DpsFrequency.dueDayLabel(a.frequency, a.dueDay)}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 12, color: AppColors.onSurfaceVariant),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton.extended(
        heroTag: 'dps_add',
        onPressed: () => context.push('/dps/new'),
        backgroundColor: AppColors.savings,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('সঞ্চয় যোগ', style: TextStyle(color: Colors.white)),
      ),
    );
  }
}

// dps_calc.dart-এর class নাম মনোনীত alias — সরাসরি import ব্যবহার করা ভালো
class DpsCalcNext {
  static String? nextDue({
    required String frequency,
    required int dueDay,
    required String startDateYmd,
    String? lastDepositDateYmd,
    DateTime? today,
  }) {
    return nextDueDate(
      frequency: frequency,
      dueDay: dueDay,
      startDateYmd: startDateYmd,
      lastDepositDateYmd: lastDepositDateYmd,
      today: today,
    );
  }
}

final _dpsProvider = StreamProvider.autoDispose((ref) { ref.watch(authStateProvider); return repo.watchDpsAccounts(); });
final _dpsTxAllProvider = StreamProvider.autoDispose((ref) {
  ref.watch(authStateProvider); // V1.4.1: uid বদলালে নতুন uid দিয়ে স্ট্রিম (F-02 প্যাটার্ন)
  // সব জমা একবারে (কার্ডে সারাংশ দেখাতে)
  return (dbRef.select(dbRef.dpsTransactions)
        ..where((t) => t.deletedAt.isNull() & t.userId.equals(repo.uid)))
      .watch();
});

/// DPS ফর্ম — ফ্রিকোয়েন্সি বাছাই সহ
class DpsFormScreen extends ConsumerStatefulWidget {
  final String? editId;
  const DpsFormScreen({super.key, this.editId});

  @override
  ConsumerState<DpsFormScreen> createState() => _DpsFormScreenState();
}

class _DpsFormScreenState extends ConsumerState<DpsFormScreen> {
  final _institution = TextEditingController();
  final _installment = TextEditingController();
  final _target = TextEditingController();
  final _startDate = TextEditingController(text: ymdOf(DateTime.now()));
  String _frequency = DpsFrequency.monthly;
  int _dueDay = 1;
  int? _durationMonths;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (widget.editId != null) {
      final a = await repo.getDpsAccount(widget.editId!);
      if (a != null && mounted) {
        setState(() {
          _institution.text = a.institutionName;
          _installment.text = (a.monthlyInstallmentPaisa / 100).toString();
          _target.text = a.targetPaisa == null ? '' : (a.targetPaisa! / 100).toString();
          _startDate.text = a.startDate;
          _frequency = a.frequency;
          _dueDay = a.dueDay;
          _durationMonths = a.durationMonths;
          _loaded = true;
        });
        return;
      }
    }
    setState(() => _loaded = true);
  }

  Future<void> _save() async {
    if (_institution.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('প্রতিষ্ঠানের নাম দিন')));
      return;
    }
    final installment = AmountInput.readPaisa(_installment) ?? 0;
    if (installment <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('কিস্তির পরিমাণ দিন')));
      return;
    }
    if (_frequency == DpsFrequency.monthly) {
      _dueDay = _dueDay.clamp(1, 28);
    }
    if (widget.editId != null) {
      await repo.update(dbRef.dpsAccounts, widget.editId!, DpsAccountsCompanion(
        institutionName: Value(_institution.text.trim()),
        monthlyInstallmentPaisa: Value(installment),
        frequency: Value(_frequency),
        dueDay: Value(_dueDay),
        startDate: Value(_startDate.text),
        durationMonths: Value(_durationMonths),
        targetPaisa: Value(AmountInput.readPaisa(_target)),
      ));
    } else {
      await repo.insert(dbRef.dpsAccounts, DpsAccountsCompanion.insert(
        id: '', userId: '',
        institutionName: _institution.text.trim(),
        monthlyInstallmentPaisa: installment,
        frequency: Value(_frequency),
        dueDay: Value(_dueDay),
        startDate: _startDate.text,
        durationMonths: Value(_durationMonths),
        targetPaisa: Value(AmountInput.readPaisa(_target)),
      ));
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('সেভ হয়েছে ✓')));
      context.pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(title: Text(widget.editId != null ? 'সঞ্চয় এডিট' : 'নতুন সঞ্চয়')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          AppTextField(controller: _institution, label: 'প্রতিষ্ঠান/নাম', hint: 'যেমন: গ্রামীণ ব্যাংক DPS'),
          const SizedBox(height: 12),
          AmountInput(controller: _installment, label: 'কিস্তির পরিমাণ'),
          const SizedBox(height: 14),
          Text('কত ঘন ঘন জমা দেবেন?', style: Theme.of(context).textTheme.titleSmall),
          const SizedBox(height: 6),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: DpsFrequency.daily, label: Text('দৈনিক')),
              ButtonSegment(value: DpsFrequency.weekly, label: Text('সাপ্তাহিক')),
              ButtonSegment(value: DpsFrequency.monthly, label: Text('মাসিক')),
            ],
            selected: {_frequency},
            onSelectionChanged: (v) => setState(() => _frequency = v.first),
          ),
          if (_frequency == DpsFrequency.monthly) ...[
            const SizedBox(height: 12),
            DropdownButtonFormField<int>(
              value: _dueDay,
              decoration: const InputDecoration(labelText: 'মাসের কোন তারিখে', border: OutlineInputBorder()),
              items: [
                for (var d = 1; d <= 28; d++)
                  DropdownMenuItem(value: d, child: Text(toBanglaDigits('$d'))),
              ],
              onChanged: (v) => setState(() => _dueDay = v ?? 1),
            ),
          ],
          if (_frequency == DpsFrequency.weekly) ...[
            const SizedBox(height: 12),
            DropdownButtonFormField<int>(
              value: _dueDay,
              decoration: const InputDecoration(labelText: 'কোন বারে', border: OutlineInputBorder()),
              items: const [
                DropdownMenuItem(value: 1, child: Text('সোমবার')),
                DropdownMenuItem(value: 2, child: Text('মঙ্গলবার')),
                DropdownMenuItem(value: 3, child: Text('বুধবার')),
                DropdownMenuItem(value: 4, child: Text('বৃহস্পতিবার')),
                DropdownMenuItem(value: 5, child: Text('শুক্রবার')),
                DropdownMenuItem(value: 6, child: Text('শনিবার')),
                DropdownMenuItem(value: 7, child: Text('রবিবার')),
              ],
              onChanged: (v) => setState(() => _dueDay = v ?? 1),
            ),
          ],
          const SizedBox(height: 12),
          DateField(controller: _startDate, label: 'শুরুর তারিখ'),
          const SizedBox(height: 12),
          DropdownButtonFormField<int>(
            value: _durationMonths,
            decoration: const InputDecoration(labelText: 'মেয়াদ (ঐচ্ছিক)', border: OutlineInputBorder()),
            items: const [
              DropdownMenuItem(value: null, child: Text('নির্দিষ্ট নয়')),
              DropdownMenuItem(value: 12, child: Text('১ বছর')),
              DropdownMenuItem(value: 24, child: Text('২ বছর')),
              DropdownMenuItem(value: 36, child: Text('৩ বছর')),
              DropdownMenuItem(value: 60, child: Text('৫ বছর')),
            ],
            onChanged: (v) => setState(() => _durationMonths = v),
          ),
          const SizedBox(height: 12),
          AmountInput(controller: _target, label: 'লক্ষ্য (ঐচ্ছিক)'),
          const SizedBox(height: 20),
          FilledButton(onPressed: _save, child: const Text('সেভ করুন')),
        ],
      ),
    );
  }
}

/// DPS ডিটেইল — জমার হিস্ট্রি (তারিখ+সময়) + জমা/এডিট/ডিলিট
class DpsDetailScreen extends ConsumerWidget {
  final String accountId;
  const DpsDetailScreen({super.key, required this.accountId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final accountSnap = ref.watch(_accountProvider(accountId));
    final txSnap = ref.watch(_txProvider(accountId));
    final account = accountSnap.asData?.value;
    if (account == null) {
      return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
    }
    final tx = txSnap.asData?.value ?? const <DpsTransaction>[];
    final deposited = tx.fold<int>(0, (a, t) => a + t.amountPaisa);
    return Scaffold(
      appBar: AppBar(
        title: Text(account.institutionName, maxLines: 1, overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit_outlined),
            onPressed: () => context.push('/dps/${account.id}/edit'),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline),
            onPressed: () async {
              if (await confirmDialog(context, 'সঞ্চয় মুছবেন?', 'জমার হিস্ট্রিসহ আবর্জনায় যাবে')) {
                await repo.softDelete('dps_accounts', account.id);
                if (context.mounted) context.pop();
              }
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'মোট জমা',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  const SizedBox(height: 4),
                  MoneyText(deposited, color: AppColors.savings, fontSize: 24, fontWeight: FontWeight.w700),
                  const SizedBox(height: 6),
                  Text(
                    '${DpsFrequency.label(account.frequency)} • কিস্তি ${MoneyFmt.taka(account.monthlyInstallmentPaisa)} • ${tx.length}টি জমা',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 12.5),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          if (tx.isEmpty)
            const EmptyState(
              icon: Icons.savings_outlined,
              title: 'এখনো কোনো জমা নেই',
              subtitle: 'নিচের বাটনে চেপে প্রথম জমা দিন — সাথে সাথেই এন্ট্রি হবে',
            )
          else
            for (final t in tx)
              EntryTile(
                icon: Icons.account_balance_wallet_outlined,
                iconColor: AppColors.savings,
                // V2-N5 (v1.4.2): আগে title-এ "তারিখ • সময়" এক লাইনে
                // ellipsis-এ সময় সবসময় কেটে যেত — এখন title শুধু তারিখ,
                // সময় subtitle-এ (নোট থাকলে তার আগে)।
                title: formatDateBn(t.txnDate),
                subtitle: () {
                  // txnAt==0 মানে সময় রেকর্ড হয়নি — তখন সময় দেখানো নয়
                  final time = t.txnAt == 0 ? '' : timeFromEpochBn(t.txnAt);
                  final parts = <String>[
                    if (time.isNotEmpty) time,
                    if (t.note != null && t.note!.isNotEmpty) t.note!,
                  ];
                  return parts.isEmpty ? null : parts.join(' • ');
                }(),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AmountTrailing(t.amountPaisa, color: AppColors.savings),
                    PopupMenuButton<String>(
                      onSelected: (v) async {
                        if (v == 'edit') _openTxForm(context, account.id, edit: t);
                        if (v == 'del') {
                          if (await confirmDialog(context, 'জমা মুছবেন?', 'এন্ট্রিটি আবর্জনায় যাবে')) {
                            await repo.softDelete('dps_transactions', t.id);
                          }
                        }
                      },
                      itemBuilder: (_) => const [
                        PopupMenuItem(value: 'edit', child: Text('এডিট')),
                        PopupMenuItem(value: 'del', child: Text('ডিলিট')),
                      ],
                    ),
                  ],
                ),
              ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        heroTag: 'dps_tx_add',
        onPressed: () => _openTxForm(context, account.id),
        backgroundColor: AppColors.savings,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('জমা দিন', style: TextStyle(color: Colors.white)),
      ),
    );
  }

  void _openTxForm(BuildContext context, String accountId, {DpsTransaction? edit}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => _DpsTxForm(accountId: accountId, edit: edit),
    );
  }
}

final _accountProvider = StreamProvider.autoDispose.family<DpsAccount?, String>((ref, id) {
  ref.watch(authStateProvider); // V1.4.1: uid বদলালে নতুন uid দিয়ে স্ট্রিম (F-02 প্যাটার্ন)
  return (dbRef.select(dbRef.dpsAccounts)..where((t) => t.id.equals(id))).watchSingleOrNull();
});

final _txProvider = StreamProvider.autoDispose.family<List<DpsTransaction>, String>((ref, id) {
  ref.watch(authStateProvider); // V1.4.1: uid বদলালে নতুন uid দিয়ে স্ট্রিম (F-02 প্যাটার্ন)
  return repo.watchDpsTx(id);
});

class _DpsTxForm extends ConsumerStatefulWidget {
  final String accountId;
  final DpsTransaction? edit;
  const _DpsTxForm({required this.accountId, this.edit});

  @override
  ConsumerState<_DpsTxForm> createState() => _DpsTxFormState();
}

class _DpsTxFormState extends ConsumerState<_DpsTxForm> {
  final _amount = TextEditingController();
  final _note = TextEditingController();
  final _date = TextEditingController(text: ymdOf(DateTime.now()));
  TimeOfDay _time = TimeOfDay.now();
  String? _walletId;
  List<Wallet> _wallets = [];
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    if (widget.edit != null) {
      // V2-N4 (v1.4.2): এডিট-prefill বাংলা ডিজিটে (আম্মুর ফর্মের মতো)
      final taka = widget.edit!.amountPaisa / 100;
      _amount.text = toBanglaDigits(taka == taka.roundToDouble()
          ? taka.round().toString()
          : taka.toStringAsFixed(2));
      _date.text = widget.edit!.txnDate;
      _note.text = widget.edit!.note ?? '';
      _walletId = widget.edit!.walletId;
      if (widget.edit!.txnAt > 0) {
        final dt = DateTime.fromMillisecondsSinceEpoch(widget.edit!.txnAt);
        _time = TimeOfDay(hour: dt.hour, minute: dt.minute);
      }
    }
    _init();
  }

  Future<void> _init() async {
    final wallets = await repo.getWallets();
    if (!mounted) return;
    setState(() {
      _wallets = wallets;
      _walletId ??= wallets.isNotEmpty ? wallets.first.id : null;
    });
  }

  Future<void> _save() async {
    if (_saving) return;
    setState(() => _saving = true);
    final amount = AmountInput.readPaisa(_amount) ?? 0;
    if (amount <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('টাকার পরিমাণ দিন')));
      setState(() => _saving = false);
      return;
    }
    final now = DateTime.now();
    final txnAt = DateTime(now.year, now.month, now.day, _time.hour, _time.minute).millisecondsSinceEpoch;
    if (widget.edit != null) {
      await repo.update(dbRef.dpsTransactions, widget.edit!.id, DpsTransactionsCompanion(
        txnDate: Value(_date.text),
        txnAt: Value(txnAt),
        amountPaisa: Value(amount),
        walletId: Value(_walletId),
        note: Value(_note.text.trim().isEmpty ? null : _note.text.trim()),
      ));
    } else {
      await repo.insert(dbRef.dpsTransactions, DpsTransactionsCompanion.insert(
        id: '', userId: '',
        dpsAccountId: widget.accountId,
        txnDate: _date.text,
        txnAt: Value(txnAt),
        amountPaisa: amount,
        walletId: Value(_walletId),
        note: Value(_note.text.trim().isEmpty ? null : _note.text.trim()),
      ));
    }
    // V1.3: জমা বদলালে DPS রিমাইন্ডার চেইন নতুন due অনুযায়ী সাজাও
    await ReminderScheduler.scheduleAll();
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(widget.edit != null ? 'জমা এডিট' : 'নতুন জমা',
                  style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 12),
              AmountInput(controller: _amount, label: 'জমার পরিমাণ', autofocus: widget.edit == null),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(child: DateField(controller: _date, label: 'তারিখ')),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () async {
                        final t = await showTimePicker(context: context, initialTime: _time);
                        if (t != null) setState(() => _time = t);
                      },
                      child: Text('সময়: ${_time.format(context)}', maxLines: 1, overflow: TextOverflow.ellipsis),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _walletId,
                decoration: const InputDecoration(labelText: 'কোন ওয়ালেট থেকে', border: OutlineInputBorder()),
                items: [
                  for (final w in _wallets)
                    DropdownMenuItem(value: w.id, child: Text(w.name, maxLines: 1, overflow: TextOverflow.ellipsis)),
                ],
                onChanged: (v) => setState(() => _walletId = v),
              ),
              const SizedBox(height: 12),
              AppTextField(controller: _note, label: 'নোট (ঐচ্ছিক)'),
              const SizedBox(height: 16),
              FilledButton(onPressed: _save, child: const Text('জমা দিন — সাথে সাথে এন্ট্রি')),
            ],
          ),
        ),
      ),
    );
  }
}
