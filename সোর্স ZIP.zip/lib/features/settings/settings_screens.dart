import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/notifications/notification_service.dart';
import '../../core/providers/app_providers.dart';
import '../../core/security/lock_controller.dart';
import '../../core/sync/sync_engine.dart';
import '../../core/theme/app_colors.dart';
import '../../core/update/update_service.dart';
import '../../core/utils/bangla_digits.dart';
import '../../core/utils/date_utils_bn.dart';
import '../../core/utils/money_format.dart';
import '../../core/widgets/bangla_time_picker.dart';
import '../../core/widgets/common.dart';
import '../../data/local/app_database.dart';
import '../../data/remote/supabase_client.dart';
import '../reports/export_service.dart';

/// সেটিংস — প্রোফাইল, সিঙ্ক, সিকিউরিটি, আপডেট, ব্যাকআপ
class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  final _name = TextEditingController();
  bool _loaded = false;
  String _closingTime = '21:30';
  // V1.4.1 (G-17): সিঙ্ক tile-এ দেখাতে — বাকি সংখ্যা ও শেষ সিঙ্কের সময়
  int _pendingCount = 0;
  String? _lastSyncedAt;

  /// meta-র ISO সময় → বাংলা প্রদর্শন ("১ নভেম্বর, ১০:৩০ PM")
  String? get _lastSyncedBn {
    final raw = _lastSyncedAt;
    if (raw == null || raw.isEmpty) return null;
    final dt = DateTime.tryParse(raw);
    if (dt == null) return null;
    return dateTimeFromEpochBn(dt.toLocal().millisecondsSinceEpoch);
  }

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final profile = await repo.watchProfile().first;
    var pending = 0;
    String? lastSynced;
    try {
      pending = await repo.pendingCount();
      lastSynced = await repo.getMeta('last_synced_at');
    } catch (_) {
      // সিঙ্ক-তথ্য না পেলেও সেটিংস খুলবে
    }
    if (!mounted) return;
    setState(() {
      _name.text = profile?.displayName ?? '';
      _closingTime = profile?.dailyClosingTime ?? '21:30';
      _pendingCount = pending;
      _lastSyncedAt = lastSynced;
      _loaded = true;
    });
  }

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
    final loggedIn = ref.watch(authStateProvider).loggedIn;
    final upd = ref.watch(updateProvider);
    final sync = ref.watch(syncStatusProvider).status;

    return Scaffold(
      appBar: AppBar(title: const Text('সেটিংস')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: [
          // প্রোফাইল
          AppTextField(
            controller: _name,
            label: 'আপনার নাম',
            hint: 'যেমন: সোহাগ ভাই',
          ),
          const SizedBox(height: 8),
          FilledButton.tonal(
            onPressed: () async {
              final messenger = ScaffoldMessenger.of(context);
              await repo.saveProfileFields(displayName: _name.text.trim());
              messenger.showSnackBar(const SnackBar(content: Text('সেভ হয়েছে ✓')));
            },
            child: const Text('নাম সেভ করুন'),
          ),
          const SizedBox(height: 16),

          // দৈনিক বন্ধের সময়
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.schedule, color: AppColors.primary),
            title: const Text('হিসাব মেলানোর রিমাইন্ডার'),
            subtitle: Text('প্রতিদিন $closingTimeBn', style: const TextStyle(fontFamily: 'HindSiliguri')),
            trailing: const Icon(Icons.chevron_right),
            onTap: () async {
              final t = await showBanglaTimePicker(
                context: context,
                initial: TimeOfDay(
                  hour: int.tryParse(_closingTime.split(':')[0]) ?? 21,
                  minute: int.tryParse(_closingTime.split(':')[1]) ?? 30,
                ),
              );
              if (t != null) {
                final hh = t.hour.toString().padLeft(2, '0');
                final mm = t.minute.toString().padLeft(2, '0');
                setState(() => _closingTime = '$hh:$mm');
                await repo.saveProfileFields(dailyClosingTime: '$hh:$mm');
                await NotificationService.instance.scheduleDaily(
                  id: 3,
                  hour: t.hour,
                  minute: t.minute,
                  title: 'দিনের হিসাব মেলান',
                  body: 'আজকের টাকা মিলিয়ে দিন বন্ধ করুন',
                  route: '/daily-closing',
                );
              }
            },
          ),
          const Divider(),

          // সিঙ্ক
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: Icon(
              sync.state == SyncState.synced
                  ? Icons.cloud_done
                  : sync.state == SyncState.error
                      ? Icons.cloud_off
                      : Icons.cloud_sync_outlined,
              color: sync.state == SyncState.synced ? AppColors.income : AppColors.onSurfaceVariant,
            ),
            title: const Text('সিঙ্ক'),
            // V1.3.1: সমস্যা থাকলে ট্যাপে কারণ দেখায়।
            // V1.4.1 (F-01 UI): উপরে বন্ধুত্বপূর্ণ বাংলা সারাংশ (কোন কোন
            // টেবিলে সমস্যা), কাঁচা কারিগরি বিবরণ শুধু সম্প্রসারণযোগ্য
            // অংশে — আগে পুরো কাঁচা exception-টাই ডায়ালগে দেখাত।
            onTap: sync.state == SyncState.error
                ? () async {
                    final detail = await repo.getMeta('last_sync_error');
                    if (!context.mounted) return;
                    final failedTables = <String>{};
                    if (detail != null) {
                      for (final line in detail.split('\n')) {
                        final m = RegExp(r'^([a-z][a-z0-9_]*):')
                            .firstMatch(line.trim());
                        if (m != null) failedTables.add(m.group(1)!);
                      }
                    }
                    final hasDetail = detail != null && detail.isNotEmpty;
                    await showDialog<void>(
                      context: context,
                      builder: (c) => AlertDialog(
                        title: const Text('সিঙ্কের সমস্যার বিবরণ'),
                        content: SingleChildScrollView(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                !hasDetail
                                    ? 'বিবরণ পাওয়া যায়নি — "সিঙ্ক করুন" চাপ দিয়ে আবার দেখুন'
                                    : failedTables.isEmpty
                                        ? 'সিঙ্কে সমস্যা হয়েছে — নিজে থেকেই আবার চেষ্টা করা হবে।'
                                        : 'কিছু টেবিলের ডাটা সিঙ্ক করতে সমস্যা হয়েছে: ${failedTables.join(', ')}। নিজে থেকেই আবার চেষ্টা করা হবে।',
                                style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 13.5),
                              ),
                              if (hasDetail) ...[
                                const SizedBox(height: 8),
                                ExpansionTile(
                                  tilePadding: EdgeInsets.zero,
                                  title: const Text(
                                    'কারিগরি বিবরণ দেখুন',
                                    style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 12.5),
                                  ),
                                  children: [
                                    Align(
                                      alignment: Alignment.centerLeft,
                                      child: SelectableText(
                                        detail,
                                        style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 11),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ],
                          ),
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(c),
                            child: const Text('ঠিক আছে'),
                          ),
                        ],
                      ),
                    );
                  }
                : null,
            subtitle: Text(
              // V1.4.1 (G-17): লগইন থাকলে বাকি সংখ্যা + শেষ সিঙ্কের সময়ও
              !loggedIn
                  ? (Supa.isLoggedOutWithData
                      ? 'লগআউট অবস্থায় আছেন — ডাটা এই ফোনে আছে, সিঙ্ক হচ্ছে না'
                      : 'অতিথি মোড — লগইন করলে সিঙ্ক চালু হবে')
                  : () {
                      final lines = <String>[
                        sync.message,
                        'বাকি: ${toBanglaDigits('$_pendingCount')}টি',
                      ];
                      final ls = _lastSyncedBn;
                      if (ls != null) lines.add('শেষ সিঙ্ক: $ls');
                      return lines.join('\n');
                    }(),
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontFamily: 'HindSiliguri'),
            ),
            trailing: TextButton(
              onPressed: () => syncEngine.runSync(force: true),
              child: const Text('সিঙ্ক করুন'),
            ),
          ),
          const Divider(),

          // V1.4.1 (G-15, docs/08 §3.4): গেস্ট ঝুঁকি-সতর্কতা — স্থায়ী tile
          if (!loggedIn && !Supa.isLoggedOutWithData) ...[
            const ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(Icons.warning_amber_rounded, color: AppColors.expense),
              title: Text('গেস্ট ডাটার সতর্কতা'),
              subtitle: Text(
                'গেস্ট ডাটার কোনো সার্ভার কপি নেই — অ্যাপ আনইনস্টল বা ফোন হারালে ডাটা ফেরত পাওয়া যাবে না। লগইন করে সিঙ্ক করলেই ডাটা নিরাপদ থাকবে।',
                style: TextStyle(fontFamily: 'HindSiliguri'),
              ),
            ),
            const Divider(),
          ],

          // V1.3 (ফিচার ৭): এক-ট্যাপ ব্যাকআপ — বিদ্যমান ExportService-ই ব্যবহার
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.ios_share, color: AppColors.primary),
            title: const Text('ব্যাকআপ শেয়ার করুন'),
            subtitle: const Text('এক চাপে পুরো ডাটার JSON ব্যাকআপ শেয়ার করুন',
                style: TextStyle(fontFamily: 'HindSiliguri')),
            trailing: const Icon(Icons.chevron_right),
            onTap: () async {
              final messenger = ScaffoldMessenger.of(context);
              try {
                await ExportService.exportJsonBackup();
              } catch (_) {
                messenger.showSnackBar(const SnackBar(
                  content: Text('ব্যাকআপ তৈরি হয়নি — আবার চেষ্টা করুন'),
                  backgroundColor: AppColors.expense,
                ));
              }
            },
          ),
          const Divider(),

          // V1.3 (ফিচার ২): সিঙ্ক গরমিল থাকলে মেলানোর পথ
          FutureBuilder<List<dynamic>>(
            future: repo.listConflicts(),
            builder: (c, snap) {
              final n = snap.data?.length ?? 0;
              if (n == 0) return const SizedBox.shrink();
              return Column(
                children: [
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.warning_amber_rounded, color: AppColors.expense),
                    title: const Text('সিঙ্ক গরমিল মেলানো বাকি'),
                    subtitle: Text('$nটি তথ্য ফোনে ও সার্ভারে আলাদা — বেছে দিন কোনটা ঠিক',
                        style: const TextStyle(fontFamily: 'HindSiliguri')),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => context.push('/settings/conflicts'),
                  ),
                  const Divider(),
                ],
              );
            },
          ),

          // অ্যাকাউন্ট
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.account_circle_outlined, color: AppColors.primary),
            title: Text(loggedIn ? 'লগইন করা আছে' : 'লগইন / অ্যাকাউন্ট'),
            subtitle: Text(
              loggedIn
                  ? () {
                      final email =
                          Supa.ready ? Supa.client.auth.currentUser?.email : null;
                      if (email != null && email.isNotEmpty) return email;
                      final prof = ref.watch(profileProvider).asData?.value;
                      final n = prof?.displayName ?? '';
                      return n.isNotEmpty ? n : 'অ্যাকাউন্ট সংযুক্ত ✓';
                    }()
                  : 'ডাটা সিঙ্ক ও ব্যাকআপের জন্য',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 11.5),
            ),
            trailing: loggedIn
                ? null
                : FilledButton(
                    onPressed: () => context.push('/auth'),
                    child: const Text('লগইন'),
                  ),
          ),
          const Divider(),

          // V1.4.1 (G-06, docs/08 §7.2): লোকাল ডাটা মুছে লগআউট — আলাদা
          // অপশন, double confirm, pending থাকলে আগে সিঙ্ক ছাড়া নয়।
          if (loggedIn)
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.delete_forever_outlined, color: AppColors.error),
              title: const Text('লোকাল ডাটা মুছে লগআউট'),
              subtitle: const Text('এই ফোনের সব হিসাব মুছে যাবে — সার্ভারের ডাটা থাকবে'),
              onTap: _wipeAndLogout,
            ),
          if (loggedIn) const Divider(),

          // সিকিউরিটি
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.lock_outline, color: AppColors.primary),
            title: const Text('নিরাপত্তা (PIN/বায়োমেট্রিক)'),
            subtitle: const Text('অ্যাপ খুলতে লক'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => context.push('/settings/security'),
          ),

          // আপডেট — v1.1 ফিক্স ১২
          const Divider(),
          _UpdateTile(upd: upd),

          const Divider(),
          // ব্যাকআপ
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.backup_outlined, color: AppColors.primary),
            title: const Text('ব্যাকআপ / রিস্টোর'),
            subtitle: const Text('JSON ফাইলে পুরো হিসাব সেভ/ফেরানো'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => context.push('/settings/backup'),
          ),

          // ব্যবস্থাপনা
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.category_outlined, color: AppColors.primary),
            title: const Text('খাত ব্যবস্থাপনা'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => context.push('/settings/categories'),
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.account_balance_wallet_outlined, color: AppColors.primary),
            title: const Text('ওয়ালেট ব্যবস্থাপনা'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => context.push('/settings/wallets'),
          ),

          const Divider(),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.info_outline, color: AppColors.primary),
            title: const Text('সম্পর্কে'),
            subtitle: Text(
              'হাট হিসাব v${toBanglaDigits(upd.state.currentVersion)} — অফলাইন-ফার্স্ট, আপনার ডাটা আপনার',
              style: const TextStyle(fontFamily: 'HindSiliguri'),
            ),
          ),
        ],
      ),
    );
  }

  String get closingTimeBn => toBanglaDigits(_closingTime);

  /// G-06: লোকাল ডাটা মুছে লগআউট — pending থাকলে block, নইলে double
  /// confirm-এর পর এই অ্যাকাউন্টের সব লোকাল row মুছে signOut।
  Future<void> _wipeAndLogout() async {
    final pending = await repo.pendingCount();
    if (!mounted) return;
    if (pending > 0) {
      await showDialog<void>(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('আগে সিঙ্ক করুন'),
          content: Text(
              '${toBanglaDigits('$pending')}টি এন্ট্রি এখনো সিঙ্ক হয়নি। লোকাল ডাটা মুছলে এগুলো চিরদিনের জন্য হারিয়ে যাবে। আগে "সিঙ্ক করুন" দিয়ে সিঙ্ক শেষ করুন।'),
          actions: [
            FilledButton(
                onPressed: () => Navigator.pop(c), child: const Text('ঠিক আছে')),
          ],
        ),
      );
      return;
    }
    final first = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('লোকাল ডাটা মুছে লগআউট?'),
        content: const Text(
            'এই ফোনে থাকা এই অ্যাকাউন্টের সব হিসাব মুছে যাবে। সার্ভারে সিঙ্ক হওয়া ডাটা থাকবে — আবার লগইন করলে নেমে আসবে।'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c, false),
              child: const Text('বাতিল')),
          FilledButton(
              onPressed: () => Navigator.pop(c, true),
              child: const Text('এগিয়ে যান')),
        ],
      ),
    );
    if (first != true || !mounted) return;
    final second = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('সত্যিই মুছবেন?'),
        content: const Text('এটা আর ফেরানো যাবে না। নিশ্চিত হলে "মুছে লগআউট" চাপুন।'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c, false),
              child: const Text('না, থাক')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.error),
            onPressed: () => Navigator.pop(c, true),
            child: const Text('মুছে লগআউট'),
          ),
        ],
      ),
    );
    if (second != true || !mounted) return;
    final uid = Supa.currentUserId;
    if (uid == null) return;
    await repo.wipeLocalDataForUser(uid);
    await Supa.client.auth.signOut();
    Supa.clearLastUid();
    SupaAuthWatcher.instance.notify();
    ref.read(authStateProvider).refresh();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('লোকাল ডাটা মুছে লগআউট হয়েছে')),
    );
    context.go('/');
  }
}

/// আপডেট টাইল — বর্তমান ভার্সন, নতুন ভার্সন, ডাউনলোড প্রগ্রেস, ইনস্টল
class _UpdateTile extends ConsumerWidget {
  final UpdateService upd;
  const _UpdateTile({required this.upd});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = upd.state;
    final String subtitle;
    final Widget trailing;

    switch (s.phase) {
      case UpdatePhase.checking:
        subtitle = 'আপডেট খোঁজা হচ্ছে…';
        trailing = const SizedBox(
          width: 20,
          height: 20,
          child: CircularProgressIndicator(strokeWidth: 2),
        );
        break;
      case UpdatePhase.available:
      case UpdatePhase.downloading:
        subtitle = s.phase == UpdatePhase.available
            ? 'নতুন ভার্সন পাওয়া গেছে: v${toBanglaDigits(s.manifest?.versionName ?? '')}'
            : 'ডাউনলোড হচ্ছে… ${(s.progress * 100).round()}%';
        trailing = s.phase == UpdatePhase.downloading
            ? Text(
                '${(s.progress * 100).round()}%',
                style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 12),
              )
            : FilledButton(
                onPressed: () => upd.download(s.manifest!),
                child: const Text('ডাউনলোড'),
              );
        break;
      case UpdatePhase.ready:
        subtitle = 'v${toBanglaDigits(s.manifest?.versionName ?? '')} প্রস্তুত — ইনস্টল করবেন?';
        trailing = FilledButton(
          onPressed: () => upd.installNow(),
          child: const Text('ইনস্টল'),
        );
        break;
      case UpdatePhase.upToDate:
        subtitle = 'আপনার অ্যাপ সর্বশেষ ভার্সনে আছে ✓';
        trailing = TextButton(
          onPressed: () => upd.manualCheck(),
          child: const Text('আবার দেখুন'),
        );
        break;
      case UpdatePhase.error:
        subtitle = s.error ?? 'সমস্যা হয়েছে';
        trailing = TextButton(
          onPressed: () => upd.manualCheck(),
          child: const Text('আবার চেষ্টা'),
        );
        break;
      default:
        subtitle = 'নতুন আপডেট থাকলে অটো-ডাউনলোড হবে';
        trailing = TextButton(
          onPressed: () => upd.manualCheck(),
          child: const Text('চেক করুন'),
        );
    }

    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: const Icon(Icons.system_update_outlined, color: AppColors.primary),
      title: const Text('অ্যাপ আপডেট'),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'বর্তমান ভার্সন: v${toBanglaDigits(s.currentVersion)}',
            style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 12),
          ),
          Text(
            subtitle,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 12),
          ),
          if (s.phase == UpdatePhase.downloading)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: LinearProgressIndicator(value: s.progress, minHeight: 5, color: AppColors.primary),
            ),
        ],
      ),
      trailing: trailing,
      onTap: () async {
        if (s.phase == UpdatePhase.ready) {
          if (await upd.canInstall()) {
            await upd.installApk(s.filePath!);
          } else {
            await upd.openPermissionSettings();
          }
        } else if (s.phase == UpdatePhase.idle || s.phase == UpdatePhase.error) {
          await upd.manualCheck();
        }
      },
    );
  }
}

/// খাত ব্যবস্থাপনা
class CategoriesScreen extends ConsumerWidget {
  const CategoriesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('পন্য ও খাত ব্যবস্থাপনা'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'পন্য'),
              Tab(text: 'খরচের খাত'),
              Tab(text: 'আয়ের খাত'),
            ],
          ),
        ),
        body: const TabBarView(
          children: [_ProductsTab(), _HeadsTab(scope: 'expense'), _HeadsTab(scope: 'income')],
        ),
      ),
    );
  }
}

/// পন্য তালিকা — সেশনের মাল-ক্রয়ে ড্রপডাউনে আসে; শেষ দর মনে থাকে
class _ProductsTab extends ConsumerWidget {
  const _ProductsTab();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final items = ref.watch(productsProvider).asData?.value ?? const <Product>[];
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        heroTag: 'md_product',
        onPressed: () => _addProduct(context),
        icon: const Icon(Icons.add),
        label: const Text('নতুন পন্য'),
      ),
      body: items.isEmpty
          ? const EmptyState(
              icon: Icons.inventory_2_outlined,
              title: 'পন্য তালিকা খালি',
              subtitle: 'পেঁয়াজ, আলু, লেবু — যা যা বেচেন সব এখানে যোগ করুন। মাল ক্রয়ে ট্যাপ করে সিলেক্ট করা যাবে।',
            )
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
              itemCount: items.length,
              itemBuilder: (c, i) {
                final p = items[i];
                return ListTile(
                  leading: const Icon(Icons.inventory_2_outlined, color: AppColors.primary),
                  title: Text(p.name),
                  subtitle: p.lastRatePaisaPerKg == null
                      ? null
                      : Text(
                          'শেষ দর: ${MoneyFmt.rate(p.lastRatePaisaPerKg!)} · ${MoneyFmt.rateMaund(p.lastRatePaisaPerKg!)}',
                          style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 11.5),
                        ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit_outlined, size: 20),
                        onPressed: () => _renameProduct(context, p),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete_outline, size: 20, color: AppColors.expense),
                        onPressed: () async {
                          if (await confirmDialog(context, 'পন্য মুছবেন?', p.name)) {
                            await repo.softDelete('products', p.id);
                          }
                        },
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }

  void _addProduct(BuildContext context) {
    final name = TextEditingController();
    showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('নতুন পন্য'),
        content: AppTextField(controller: name, label: 'পন্যের নাম', hint: 'যেমন: পেঁয়াজ, আলু'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('বাতিল')),
          FilledButton(
            onPressed: () async {
              if (name.text.trim().isEmpty) return;
              await repo.upsertProduct(name.text.trim());
              if (c.mounted) Navigator.pop(c);
            },
            child: const Text('যোগ করুন'),
          ),
        ],
      ),
    );
  }

  void _renameProduct(BuildContext context, Product p) {
    final name = TextEditingController(text: p.name);
    showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('নাম বদলান'),
        content: AppTextField(controller: name, label: 'পন্যের নাম'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('বাতিল')),
          FilledButton(
            onPressed: () async {
              if (name.text.trim().isEmpty) return;
              await repo.renameProduct(p.id, name.text.trim());
              if (c.mounted) Navigator.pop(c);
            },
            child: const Text('সেভ'),
          ),
        ],
      ),
    );
  }
}

/// খাত তালিকা (খরচ/আয় স্কোপ) — যোগ/নাম-বদল/মুছুন
class _HeadsTab extends ConsumerWidget {
  final String scope;
  const _HeadsTab({required this.scope});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final items = ref.watch(scope == 'expense' ? expenseHeadsProvider : incomeHeadsProvider).asData?.value ?? const <Category>[];
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        heroTag: 'md_head_\$scope',
        onPressed: () => _addHead(context),
        icon: const Icon(Icons.add),
        label: const Text('নতুন খাত'),
      ),
      body: items.isEmpty
          ? EmptyState(
              icon: scope == 'expense' ? Icons.payments_outlined : Icons.savings_outlined,
              title: scope == 'expense' ? 'খরচের খাত নেই' : 'আয়ের খাত নেই',
              subtitle: scope == 'expense' ? 'খাবার, যাতায়াত ইত্যাদি খাত যোগ করুন' : 'বিক্রির আয়, বেতন ইত্যাদি খাত যোগ করুন',
            )
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
              itemCount: items.length,
              itemBuilder: (c, i) {
                final cat = items[i];
                return ListTile(
                  leading: Text(cat.icon ?? (scope == 'expense' ? '📦' : '💰'), style: const TextStyle(fontSize: 20)),
                  title: Text(cat.name),
                  subtitle: Text(cat.scope == 'both' ? 'খরচ ও আয় দুটোতেই' : (cat.isSystem ? 'সিস্টেম খাত' : 'নিজের খাত'),
                      style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 11.5)),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit_outlined, size: 20),
                        onPressed: () => _renameHead(context, cat),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete_outline, size: 20, color: AppColors.expense),
                        onPressed: () async {
                          if (await confirmDialog(context, 'খাত মুছবেন?', cat.name)) {
                            await repo.softDelete('categories', cat.id);
                          }
                        },
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }

  void _addHead(BuildContext context) {
    final name = TextEditingController();
    final icon = TextEditingController();
    showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(scope == 'expense' ? 'নতুন খরচের খাত' : 'নতুন আয়ের খাত'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AppTextField(controller: name, label: 'নাম'),
            const SizedBox(height: 10),
            AppTextField(controller: icon, label: 'ইমোজি (ঐচ্ছিক)', hint: '🍛'),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('বাতিল')),
          FilledButton(
            onPressed: () async {
              if (name.text.trim().isEmpty) return;
              await repo.addCategory(name.text.trim(), icon: icon.text.trim().isEmpty ? null : icon.text.trim(), scope: scope);
              if (c.mounted) Navigator.pop(c);
            },
            child: const Text('যোগ করুন'),
          ),
        ],
      ),
    );
  }

  void _renameHead(BuildContext context, Category cat) {
    final name = TextEditingController(text: cat.name);
    final icon = TextEditingController(text: cat.icon ?? '');
    showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('খাত এডিট'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AppTextField(controller: name, label: 'নাম'),
            const SizedBox(height: 10),
            AppTextField(controller: icon, label: 'ইমোজি (ঐচ্ছিক)', hint: '🍛'),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('বাতিল')),
          FilledButton(
            onPressed: () async {
              if (name.text.trim().isEmpty) return;
              await repo.renameCategory(cat.id, name.text.trim(), icon: icon.text.trim().isEmpty ? null : icon.text.trim());
              if (c.mounted) Navigator.pop(c);
            },
            child: const Text('সেভ'),
          ),
        ],
      ),
    );
  }
}

/// ওয়ালেট ব্যবস্থাপনা
class WalletsScreen extends ConsumerWidget {
  const WalletsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final wallets = ref.watch(walletsProvider).asData?.value ?? const <Wallet>[];
    return Scaffold(
      appBar: AppBar(title: const Text('ওয়ালেট ব্যবস্থাপনা')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          for (final w in wallets)
            ListTile(
              leading: const Icon(Icons.account_balance_wallet_outlined),
              title: Text(w.name),
              subtitle: Text(_typeLabel(w.type), style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 12)),
              // V1.5.0 (Agent E): ট্যাপ বা ⋮ মেনু থেকে এডিট/ডিলিট
              onTap: () => _walletDialog(context, edit: w),
              trailing: PopupMenuButton<String>(
                onSelected: (v) {
                  if (v == 'edit') _walletDialog(context, edit: w);
                  if (v == 'del') _deleteWallet(context, w, wallets.length);
                },
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'edit', child: Text('এডিট')),
                  PopupMenuItem(value: 'del', child: Text('ডিলিট')),
                ],
              ),
            ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () => _walletDialog(context),
            icon: const Icon(Icons.add),
            label: const Text('নতুন ওয়ালেট'),
          ),
        ],
      ),
    );
  }

  String _typeLabel(String t) {
    switch (t) {
      case 'cash':
        return 'নগদ';
      case 'bkash':
        return 'বিকাশ';
      case 'nagad':
        return 'নগদ';
      case 'bank':
        return 'ব্যাংক';
      default:
        return 'অন্যান্য';
    }
  }

  /// V1.5.0 (Agent E): নতুন ওয়ালেট যোগ + বিদ্যমান ওয়ালেট এডিট — একই
  /// ডায়ালগ। এডিটের ক্ষেত্রে [edit] দেওয়া থাকে: নাম/ধরন আগে থেকে
  /// ভরা থাকে, সেভ হলে repo.update (version bump + sync pending)।
  void _walletDialog(BuildContext context, {Wallet? edit}) {
    final name = TextEditingController(text: edit?.name ?? '');
    String type = edit?.type ?? 'cash';
    showDialog<void>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) => AlertDialog(
          title: Text(edit == null ? 'নতুন ওয়ালেট' : 'ওয়ালেট এডিট'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              AppTextField(controller: name, label: 'নাম'),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: type,
                items: const [
                  DropdownMenuItem(value: 'cash', child: Text('নগদ')),
                  DropdownMenuItem(value: 'bkash', child: Text('বিকাশ')),
                  DropdownMenuItem(value: 'nagad', child: Text('নগদ')),
                  DropdownMenuItem(value: 'bank', child: Text('ব্যাংক')),
                  DropdownMenuItem(value: 'other', child: Text('অন্যান্য')),
                ],
                onChanged: (v) => setD(() => type = v ?? 'cash'),
                decoration: const InputDecoration(labelText: 'ধরন', border: OutlineInputBorder()),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c), child: const Text('বাতিল')),
            FilledButton(
              onPressed: () async {
                if (name.text.trim().isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('আগে ওয়ালেটের নাম লিখুন')),
                  );
                  return;
                }
                try {
                  if (edit == null) {
                    await repo.insert(dbRef.wallets, WalletsCompanion.insert(
        id: '', userId: '',
                      name: name.text.trim(),
                      type: Value(type),
                    ));
                  } else {
                    await repo.update(dbRef.wallets, edit.id, WalletsCompanion(
                      name: Value(name.text.trim()),
                      type: Value(type),
                    ));
                  }
                } catch (e) {
                  if (c.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('সেভ হয়নি: আবার চেষ্টা করুন')),
                    );
                  }
                  return;
                }
                if (c.mounted) Navigator.pop(c);
              },
              child: Text(edit == null ? 'যোগ করুন' : 'সেভ করুন'),
            ),
          ],
        ),
      ),
    );
  }

  /// V1.5.0 (Agent E): ওয়ালেট ডিলিট — soft-delete (সিঙ্কে tombstone
  /// হিসেবে যায়)। শেষ ওয়ালেটটা ডিলিট করা যায় না। কোনো এন্ট্রিতে
  /// এই ওয়ালেট ব্যবহার হয়ে থাকলে সংখ্যাটা দেখিয়ে সতর্ক করা হয়,
  /// তবে ডিলিট আটকানো হয় না (এন্ট্রিগুলো ওয়ালেট-ছাড়া হয়ে যাবে)।
  Future<void> _deleteWallet(BuildContext context, Wallet w, int walletCount) async {
    if (walletCount <= 1) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('এটাই একমাত্র ওয়ালেট — ডিলিট করা যাবে না')),
      );
      return;
    }
    // এই ওয়ালেটে লিংক করা সক্রিয় এন্ট্রির সংখ্যা (deleted বাদে —
    // এই ফাইলে drift-এর `&` এক্সটেনশন স্কোপে নেই বলে Dart-এ ফিল্টার)
    var refs = 0;
    Future<void> countRefs<T>(
        Future<List<T>> rows, String? Function(T) deletedAtOf) async {
      final list = await rows;
      refs += list.where((r) => deletedAtOf(r) == null).length;
    }

    await countRefs(
        (dbRef.select(dbRef.expenses)..where((t) => t.walletId.equals(w.id))).get(),
        (r) => r.deletedAt);
    await countRefs(
        (dbRef.select(dbRef.incomeHat)..where((t) => t.walletId.equals(w.id))).get(),
        (r) => r.deletedAt);
    await countRefs(
        (dbRef.select(dbRef.incomePersonal)..where((t) => t.walletId.equals(w.id))).get(),
        (r) => r.deletedAt);
    await countRefs(
        (dbRef.select(dbRef.motherPayments)..where((t) => t.walletId.equals(w.id))).get(),
        (r) => r.deletedAt);
    await countRefs(
        (dbRef.select(dbRef.dpsTransactions)..where((t) => t.walletId.equals(w.id))).get(),
        (r) => r.deletedAt);
    await countRefs(
        (dbRef.select(dbRef.fuelLogs)..where((t) => t.walletId.equals(w.id))).get(),
        (r) => r.deletedAt);
    if (!context.mounted) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('ওয়ালেট ডিলিট করবেন?'),
        content: Text(
          refs > 0
              ? '"${w.name}" ওয়ালেটে ${toBanglaDigits('$refs')}টি এন্ট্রি আছে — ডিলিট করলে সেগুলো ওয়ালেট-ছাড়া হয়ে যাবে। তবু ডিলিট করবেন?'
              : '"${w.name}" ওয়ালেট ডিলিট হয়ে যাবে।',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('বাতিল')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.error),
            onPressed: () => Navigator.pop(c, true),
            child: const Text('ডিলিট'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await repo.softDelete('wallets', w.id);
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('ওয়ালেট ডিলিট হয়েছে')),
    );
  }
}

/// নিরাপত্তা
class SecurityScreen extends ConsumerStatefulWidget {
  const SecurityScreen({super.key});

  @override
  ConsumerState<SecurityScreen> createState() => _SecurityScreenState();
}

class _SecurityScreenState extends ConsumerState<SecurityScreen> {
  final _pin = TextEditingController();
  final _pin2 = TextEditingController();

  @override
  void dispose() {
    _pin.dispose();
    _pin2.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final lock = LockController.instance;
    return Scaffold(
      appBar: AppBar(title: const Text('নিরাপত্তা')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (!lock.isPinSet) ...[
            Text('PIN সেট করুন (৪ বা ৬ সংখ্যা)', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 10),
            AppTextField(controller: _pin, label: 'নতুন PIN'),
            const SizedBox(height: 10),
            AppTextField(controller: _pin2, label: 'আবার লিখুন'),
            const SizedBox(height: 14),
            FilledButton(
              onPressed: () async {
                if (_pin.text.length < 4 || _pin.text != _pin2.text) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('PIN মিলছে না (৪ সংখ্যা দিন)')),
                  );
                  return;
                }
                final messenger = ScaffoldMessenger.of(context);
                final ok = await lock.setPin(_pin.text);
                if (!mounted) return;
                if (ok) {
                  setState(() {});
                  messenger.showSnackBar(const SnackBar(content: Text('PIN সেট হয়েছে ✓')));
                }
              },
              child: const Text('PIN সেট করুন'),
            ),
          ] else ...[
            Card(
              child: ListTile(
                leading: const Icon(Icons.lock, color: AppColors.primary),
                title: const Text('PIN চালু আছে'),
                subtitle: const Text('অ্যাপ খুললেই PIN চাইবে'),
                trailing: TextButton(
                  onPressed: () async {
                    await lock.clearPin();
                    setState(() {});
                  },
                  child: const Text('সরান', style: TextStyle(color: AppColors.expense)),
                ),
              ),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('ফিঙ্গারপ্রিন্ট/ফেস আনলক'),
              value: lock.biometricEnabled,
              onChanged: (v) async {
                await lock.setBiometric(v);
                setState(() {});
              },
            ),
          ],
        ],
      ),
    );
  }
}

/// ব্যাকআপ
class BackupScreen extends ConsumerWidget {
  const BackupScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(title: const Text('ব্যাকআপ / রিস্টোর')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Card(
            child: Padding(
              padding: EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'ব্যাকআপ রাখুন — ফোন হারালেও হিসাব থাকবে',
                    style: TextStyle(fontFamily: 'HindSiliguri', fontWeight: FontWeight.w600, fontSize: 14.5),
                  ),
                  SizedBox(height: 4),
                  Text(
                    'JSON ফাইল শেয়ার করে হোয়াটসঅ্যাপ/ড্রাইভে রাখতে পারেন',
                    softWrap: true,
                    style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 12.5, color: AppColors.onSurfaceVariant),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: () async {
              await ExportService.exportJsonBackup();
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ব্যাকআপ ফাইল শেয়ার করুন')));
              }
            },
            icon: const Icon(Icons.ios_share),
            label: const Text('ব্যাকআপ এক্সপোর্ট (JSON)'),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: () async {
              final picked = await FilePicker.platform.pickFiles(type: FileType.any);
              if (picked == null) return;
              try {
                final text = await File(picked.files.single.path!).readAsString();
                final data = Map<String, dynamic>.from(jsonDecode(text) as Map);
                final n = await repo.importAll(data);
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$n সারি ফেরানো হয়েছে ✓')));
                }
              } catch (_) {
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ফাইল পড়া গেল না')));
                }
              }
            },
            icon: const Icon(Icons.restore),
            label: const Text('ব্যাকআপ থেকে রিস্টোর'),
          ),
        ],
      ),
    );
  }
}
