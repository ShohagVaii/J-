import 'package:flutter/material.dart';

import '../../core/providers/app_providers.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/money_format.dart';
import '../../core/widgets/common.dart';

/// V1.3 (ফিচার ২): Sync conflict সমাধান — সিদ্ধান্ত (docs/07): প্রতিবার
/// ব্যবহারকারীকে জিজ্ঞাসা করা হবে। প্রতিটি conflict-এ লোকাল ও সার্ভার
/// কপির ভিন্ন ফিল্ডগুলো পাশাপাশি দেখানো হয়; টাকার ফিল্ড টাকা হিসেবে।
class ConflictScreen extends StatefulWidget {
  const ConflictScreen({super.key});

  @override
  State<ConflictScreen> createState() => _ConflictScreenState();
}

class _ConflictScreenState extends State<ConflictScreen> {
  bool _loading = true;
  List<({String table, String rowId, Map<String, dynamic> server})> _conflicts = [];
  final Map<String, Map<String, dynamic>?> _locals = {};

  static const _tableLabels = <String, String>{
    'hat_sessions': 'হাট সেশন',
    'hat_purchase_items': 'কেনার আইটেম',
    'hats': 'হাট',
    'expenses': 'খরচ',
    'income_hat': 'হাট আয়',
    'income_personal': 'ব্যক্তিগত আয়',
    'mother_payments': 'আম্মুর টাকা',
    'dps_accounts': 'DPS অ্যাকাউন্ট',
    'dps_transactions': 'DPS জমা',
    'loans': 'ধার',
    'loan_payments': 'ধার পরিশোধ',
    'loan_persons': 'ধারের ব্যক্তি',
    'fuel_logs': 'তেলের হিসাব',
    'bike_maintenance': 'বাইক মেইনটেন্যান্স',
    'wallets': 'ওয়ালেট',
    'daily_closings': 'দৈনিক বন্ধ',
    'categories': 'খাত',
    'products': 'পণ্য',
    'cash_tallies': 'টাকা গণনা',
    'cash_tally_items': 'টাকা গণনার আইটেম',
    'profiles': 'প্রোফাইল',
    'attachments': 'সংযুক্তি',
  };

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final list = await repo.listConflicts();
    _locals.clear();
    for (final c in list) {
      _locals['${c.table}:${c.rowId}'] = await repo.getLocalRowJson(c.table, c.rowId);
    }
    if (!mounted) return;
    setState(() {
      _conflicts = list;
      _loading = false;
    });
  }

  String _fmt(String key, Object? v) {
    if (v == null) return '—';
    if (key.endsWith('_paisa') && v is num) return MoneyFmt.taka(v.toInt());
    if (v is double && v == v.roundToDouble()) return v.round().toString();
    return '$v';
  }

  Future<void> _resolve(bool keepLocal, ({String table, String rowId, Map<String, dynamic> server}) c) async {
    if (keepLocal) {
      await repo.resolveConflictKeepLocal(c.table, c.rowId);
      syncEngine.runSync(force: true);
    } else {
      await repo.resolveConflictKeepServer(c.table, c.rowId);
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(keepLocal ? 'আপনার কপি রাখা হলো — সিঙ্কে পাঠানো হবে' : 'সার্ভারের কপি রাখা হলো'),
    ));
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('সিঙ্ক গরমিল মেলানো')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _conflicts.isEmpty
              ? const EmptyState(
                  icon: Icons.cloud_done_outlined,
                  title: 'কোনো গরমিল নেই',
                  subtitle: 'সব ডাটা মিলে আছে — চিন্তা নেই',
                )
              : ListView(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
                  children: [
                    const Text(
                      'একই তথ্য ফোনে ও সার্ভারে দুই রকম হয়েছে। কোন কপিটা ঠিক, বেছে দিন — টাকার হিসাবে আমরা নিজে থেকে কিছু বদলাই না।',
                      style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 13, height: 1.5),
                    ),
                    const SizedBox(height: 12),
                    ..._conflicts.map(_conflictCard),
                  ],
                ),
    );
  }

  Widget _conflictCard(({String table, String rowId, Map<String, dynamic> server}) c) {
    final local = _locals['${c.table}:${c.rowId}'];
    final keys = <String>{...c.server.keys, ...(local?.keys ?? const <String>{})}
      ..removeWhere((k) => const {'sync_status', 'user_id', 'id'}.contains(k));
    final diffs = keys.where((k) => '${local?[k]}' != '${c.server[k]}').toList()..sort();
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.warning_amber_rounded, color: AppColors.expense, size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _tableLabels[c.table] ?? c.table,
                    style: const TextStyle(fontFamily: 'HindSiliguri', fontWeight: FontWeight.w700, fontSize: 15),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            if (local == null)
              const Text('এই তথ্য ফোনে আর নেই — শুধু সার্ভারের কপি আছে।',
                  style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 12.5))
            else if (diffs.isEmpty)
              const Text('মানগুলো একই — শুধু সংস্করণে গরমিল।',
                  style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 12.5))
            else
              Table(
                columnWidths: const {0: FlexColumnWidth(1.1), 1: FlexColumnWidth(1), 2: FlexColumnWidth(1)},
                children: [
                  const TableRow(children: [
                    Text('ঘর', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12, fontFamily: 'HindSiliguri')),
                    Text('ফোনে (আপনার)', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12, fontFamily: 'HindSiliguri')),
                    Text('সার্ভারে', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12, fontFamily: 'HindSiliguri')),
                  ]),
                  ...diffs.map((k) => TableRow(children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 3),
                          child: Text(k, style: const TextStyle(fontSize: 11.5, fontFamily: 'HindSiliguri')),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 3),
                          child: Text(_fmt(k, local[k]),
                              style: const TextStyle(fontSize: 12, fontFamily: 'HindSiliguri', fontWeight: FontWeight.w600)),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 3),
                          child: Text(_fmt(k, c.server[k]), style: const TextStyle(fontSize: 12, fontFamily: 'HindSiliguri')),
                        ),
                      ])),
                ],
              ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: local == null ? null : () => _resolve(true, c),
                    child: const Text('ফোনেরটা রাখুন'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: FilledButton(
                    onPressed: () => _resolve(false, c),
                    child: const Text('সার্ভারেরটা রাখুন'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
