import 'package:flutter/material.dart';

import '../../core/update/update_service.dart';
import '../../core/utils/bangla_digits.dart';

/// আপডেট প্রস্তুত — পপআপ (ইনস্টল পারমিশন ফ্লো সহ)
Future<void> showUpdateReadyDialog(BuildContext context, UpdateService service) {
  final m = service.state.manifest;
  return showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (c) => AlertDialog(
      title: const Text('নতুন আপডেট প্রস্তুত! 🎉'),
      content: Text(
        m == null
            ? 'নতুন ভার্সন ডাউনলোড হয়েছে।'
            : 'ভার্সন ${toBanglaDigits(m.versionName)} ডাউনলোড হয়ে গেছে।\n\n'
                '${m.notes}\n\n'
                'ইনস্টল করতে চাপ দিন — ফোন প্রথমবার পারমিশন চাইলে "অনুমতি দিন"।',
        style: const TextStyle(fontFamily: 'HindSiliguri', height: 1.5),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(c),
          child: const Text('পরে ইনস্টল করব'),
        ),
        FilledButton(
          onPressed: () {
            Navigator.pop(c);
            service.installNow();
          },
          child: const Text('এখনই ইনস্টল করুন'),
        ),
      ],
    ),
  );
}
