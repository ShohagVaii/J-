import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/app_flags.dart';
import '../../core/theme/app_colors.dart';

/// অনবোর্ডিং — ৩ পেজ, স্কিপ করা যায়
class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _controller = PageController();
  int _page = 0;

  final _pages = const [
    (
      Icons.storefront,
      'হাটের পুরো হিসাব এক জায়গায়',
      'কেজি, দর, ছোতা, স্লিপ, মেমো — সব লিখুন, দিন শেষে টাকা নিজেই মিলে যাবে।'
    ),
    (
      Icons.savings,
      'সঞ্চয়, ধার, বাইক — সবই',
      'আম্মুকে দেওয়া টাকা, DPS কিস্তি, ধার-দেনা, বাইকের মাইলেজ — সব আলাদা করে সাজানো।'
    ),
    (
      Icons.cloud_sync_outlined,
      'অফলাইনে কাজ করে, লগইনে সিঙ্ক',
      'ইন্টারনেট না থাকলেও সব লেখা হবে; লগইন করলে অন্য ফোনেও পাবেন।'
    ),
  ];

  Future<void> _done() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('onboarded', true);
    appOnboarded = true;
    if (mounted) context.go('/');
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Align(
              alignment: Alignment.topRight,
              child: TextButton(
                onPressed: _done,
                // F-07: স্কিপ লেখা বড় ও উজ্জ্বল (আগে ছোট/ম্লান ছিল)
                style: TextButton.styleFrom(
                  foregroundColor: AppColors.primary,
                  textStyle: const TextStyle(
                    fontFamily: 'HindSiliguri',
                    fontSize: 15.5,
                    fontWeight: FontWeight.w700,
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                ),
                child: const Text('স্কিপ'),
              ),
            ),
            Expanded(
              child: PageView.builder(
                controller: _controller,
                itemCount: _pages.length,
                onPageChanged: (i) => setState(() => _page = i),
                itemBuilder: (c, i) {
                  final p = _pages[i];
                  // U-7: ল্যান্ডস্কেপ/ছোট উচ্চতায় avatar ছোট + স্ক্রল ফলব্যাক
                  final isLandscape =
                      MediaQuery.of(context).orientation == Orientation.landscape;
                  return Center(
                    child: SingleChildScrollView(
                      child: Padding(
                        padding: const EdgeInsets.all(32),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            CircleAvatar(
                              radius: isLandscape ? 40 : 56,
                              backgroundColor: AppColors.primaryLight,
                              child: Icon(p.$1,
                                  size: isLandscape ? 38 : 52, color: AppColors.primary),
                            ),
                            const SizedBox(height: 26),
                            Text(
                              p.$2,
                              textAlign: TextAlign.center,
                              style: Theme.of(context).textTheme.headlineSmall,
                            ),
                            const SizedBox(height: 10),
                            Text(
                              p.$3,
                              textAlign: TextAlign.center,
                              softWrap: true,
                              style: TextStyle(
                                fontFamily: 'HindSiliguri',
                                // F-07: আগের হালকা ধূসর (onSurfaceVariant)
                                // ডার্ক ব্যাকগ্রাউন্ডে প্রায় অপাঠ্য ছিল —
                                // এখন থিমের onSurface ৮৭% অস্বচ্ছতায়,
                                // দুই থিমেই পড়া যায়; সাইজও বাড়ানো
                                fontSize: 15.5,
                                height: 1.6,
                                color: Theme.of(context)
                                    .colorScheme
                                    .onSurface
                                    .withAlpha(222),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                for (var i = 0; i < _pages.length; i++)
                  Container(
                    width: _page == i ? 22 : 8,
                    height: 8,
                    margin: const EdgeInsets.symmetric(horizontal: 3),
                    decoration: BoxDecoration(
                      color: _page == i ? AppColors.primary : AppColors.outline,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 18),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () {
                    if (_page < _pages.length - 1) {
                      _controller.nextPage(
                        duration: const Duration(milliseconds: 260),
                        curve: Curves.easeOut,
                      );
                    } else {
                      _done();
                    }
                  },
                  child: Text(_page < _pages.length - 1 ? 'পরেরটা' : 'শুরু করুন'),
                ),
              ),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}
