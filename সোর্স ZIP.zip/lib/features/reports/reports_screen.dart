import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:drift/drift.dart' show Variable;

import '../../core/calculations/summary_calc.dart';
import '../../core/providers/app_providers.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/bangla_digits.dart';
import '../../core/utils/date_utils_bn.dart';
import '../../core/utils/money_format.dart';
import '../../core/widgets/common.dart';
import 'export_service.dart';

/// রিপোর্টের সময়কাল — দৈনিক / সাপ্তাহিক / মাসিক / বার্ষিক (v1.5.0)।
/// সাপ্তাহিক = সোমবার শুরু (ISO) — বাংলাদেশে শুক্র–শনি সাপ্তাহিক ছুটি হলেও
/// সোম-শুরুই আন্তর্জাতিক মান এবং নেভিগেশনে সবচেয়ে অনুমানযোগ্য।
enum ReportPeriodKind { daily, weekly, monthly, yearly }

class ReportPeriod {
  final ReportPeriodKind kind;

  /// অন্তর্ভুক্ত প্রথম দিন (সকাল ০টা)
  final DateTime start;

  /// অ-অন্তর্ভুক্ত শেষ সীমানা (পরের পিরিয়ডের শুরু)
  final DateTime end;

  const ReportPeriod(this.kind, this.start, this.end);

  String get startYmd => ymdOf(start);
  String get endYmd => ymdOf(end);

  /// PDF শিরোনামের ধরন-অংশ: "দৈনিক রিপোর্ট" ইত্যাদি
  String get titleBn => switch (kind) {
        ReportPeriodKind.daily => 'দৈনিক রিপোর্ট',
        ReportPeriodKind.weekly => 'সাপ্তাহিক রিপোর্ট',
        ReportPeriodKind.monthly => 'মাসিক রিপোর্ট',
        ReportPeriodKind.yearly => 'বার্ষিক রিপোর্ট',
      };

  /// ফাইলনাম + PDF ফুটারের "Report:" লাইনের key —
  /// দৈনিক 2026-11-02, সাপ্তাহিক 2026-W44, মাসিক 2026-11, বার্ষিক 2026
  String get key => switch (kind) {
        ReportPeriodKind.daily => startYmd,
        ReportPeriodKind.weekly =>
          '${_isoWeekYear(start)}-W${_isoWeek(start).toString().padLeft(2, '0')}',
        ReportPeriodKind.monthly =>
          '${start.year.toString().padLeft(4, '0')}-${start.month.toString().padLeft(2, '0')}',
        ReportPeriodKind.yearly => '${start.year}',
      };

  /// স্ক্রিনে ও PDF বডিতে দেখানো বাংলা লেবেল
  String get labelBn => switch (kind) {
        ReportPeriodKind.daily => formatDateBn(startYmd),
        ReportPeriodKind.weekly => start.year ==
                end.subtract(const Duration(days: 1)).year
            ? '${formatDateShortBn(startYmd)} – ${formatDateBn(ymdOf(end.subtract(const Duration(days: 1))))}'
            : '${formatDateBn(startYmd)} – ${formatDateBn(ymdOf(end.subtract(const Duration(days: 1))))}',
        ReportPeriodKind.monthly => monthYearBn(start.year, start.month),
        ReportPeriodKind.yearly => toBanglaDigits('${start.year}'),
      };

  /// [delta] ধাপ এগিয়ে/পিছিয়ে নতুন পিরিয়ড (দৈনিক ±১ দিন, সাপ্তাহিক ±৭ দিন…)
  ReportPeriod shift(int delta) => periodOf(kind, _shiftAnchor(delta));

  DateTime _shiftAnchor(int delta) => switch (kind) {
        ReportPeriodKind.daily => start.add(Duration(days: delta)),
        ReportPeriodKind.weekly => start.add(Duration(days: 7 * delta)),
        ReportPeriodKind.monthly => DateTime(start.year, start.month + delta, 1),
        ReportPeriodKind.yearly => DateTime(start.year + delta, 1, 1),
      };

  static ReportPeriod periodOf(ReportPeriodKind kind, DateTime anchor) {
    final d = DateTime(anchor.year, anchor.month, anchor.day);
    return switch (kind) {
      ReportPeriodKind.daily =>
        ReportPeriod(kind, d, d.add(const Duration(days: 1))),
      ReportPeriodKind.weekly => ReportPeriod(
          kind,
          d.subtract(Duration(days: d.weekday - 1)), // সোমবার শুরু
          d.subtract(Duration(days: d.weekday - 1)).add(const Duration(days: 7)),
        ),
      ReportPeriodKind.monthly => ReportPeriod(
          kind, DateTime(d.year, d.month, 1), DateTime(d.year, d.month + 1, 1)),
      ReportPeriodKind.yearly =>
        ReportPeriod(kind, DateTime(d.year, 1, 1), DateTime(d.year + 1, 1, 1)),
    };
  }

  static int _isoWeek(DateTime date) {
    final d = DateTime(date.year, date.month, date.day);
    final thursday = d.add(Duration(days: 4 - d.weekday));
    final jan1 = DateTime(thursday.year, 1, 1);
    final firstThursday = jan1.add(Duration(days: (4 - jan1.weekday + 7) % 7));
    return thursday.difference(firstThursday).inDays ~/ 7 + 1;
  }

  static int _isoWeekYear(DateTime date) {
    final d = DateTime(date.year, date.month, date.day);
    return d.add(Duration(days: 4 - d.weekday)).year;
  }
}

/// রিপোর্ট — সময়কাল বাছাই (দৈনিক/সাপ্তাহিক/মাসিক/বার্ষিক), সারাংশ,
/// দিন-ভিত্তিক চার্ট, এক্সপোর্ট (PDF/এক্সেল/CSV)
class ReportsScreen extends ConsumerStatefulWidget {
  const ReportsScreen({super.key});

  @override
  ConsumerState<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends ConsumerState<ReportsScreen> {
  // v1.5.0: ডিফল্ট মাসিক — আগের আচরণের সঙ্গে মিল রেখে
  ReportPeriod _period =
      ReportPeriod.periodOf(ReportPeriodKind.monthly, DateTime.now());
  bool _exporting = false;

  List<Variable<String>> get _rangeVars =>
      [Variable.withString(_period.startYmd), Variable.withString(_period.endYmd)];

  Future<SummaryBucket> _bucket() async {
    final db = dbRef;
    Future<int> sum(String sql) async {
      final r = await db.customSelect(sql, variables: _rangeVars).getSingle();
      return r.read<int>('s');
    }

    const range = 'txn_date >= ? AND txn_date < ?';
    final b = SummaryBucket();
    b.hatIncomePaisa = await sum(
        "SELECT IFNULL(SUM(amount_paisa),0) s FROM income_hat WHERE deleted_at IS NULL AND $range");
    b.personalIncomePaisa = await sum(
        "SELECT IFNULL(SUM(amount_paisa),0) s FROM income_personal WHERE deleted_at IS NULL AND $range");
    b.expensePaisa = await sum(
        "SELECT IFNULL(SUM(amount_paisa),0) s FROM expenses WHERE deleted_at IS NULL AND $range");
    b.motherPaisa = await sum(
        "SELECT IFNULL(SUM(amount_paisa),0) s FROM mother_payments WHERE deleted_at IS NULL AND $range");
    b.dpsPaisa = await sum(
        "SELECT IFNULL(SUM(amount_paisa),0) s FROM dps_transactions WHERE deleted_at IS NULL AND $range");
    b.bikeFuelPaisa = await sum(
        "SELECT IFNULL(SUM(amount_paisa),0) s FROM fuel_logs WHERE deleted_at IS NULL AND $range");
    b.bikeMaintenancePaisa = await sum(
        "SELECT IFNULL(SUM(cost_paisa),0) s FROM bike_maintenance WHERE deleted_at IS NULL AND $range");
    b.loanGivenPaisa = await sum(
        "SELECT IFNULL(SUM(principal_paisa),0) s FROM loans WHERE deleted_at IS NULL AND type='given' AND $range");
    b.loanTakenPaisa = await sum(
        "SELECT IFNULL(SUM(principal_paisa),0) s FROM loans WHERE deleted_at IS NULL AND type='taken' AND $range");
    return b;
  }

  Future<List<CategorySlice>> _topCats() async {
    final db = dbRef;
    final rows = await db.customSelect(
      "SELECT IFNULL(c.name,'অন্যান্য') name, SUM(e.amount_paisa) s "
      "FROM expenses e LEFT JOIN categories c ON c.id = e.category_id "
      "WHERE e.deleted_at IS NULL AND e.txn_date >= ? AND e.txn_date < ? GROUP BY c.name ORDER BY s DESC LIMIT 8",
      variables: _rangeVars,
    ).get();
    return rows
        .map((r) => CategorySlice(name: r.read<String>('name'), amountPaisa: r.read<int>('s')))
        .toList();
  }

  Future<List<(String, int, int)>> _dailyBars() async {
    final db = dbRef;
    const range = 'txn_date >= ? AND txn_date < ?';
    final inc = await db.customSelect(
      "SELECT txn_date d, SUM(amount_paisa) s FROM income_hat WHERE deleted_at IS NULL AND $range AND payment_method <> 'baki' GROUP BY txn_date",
      variables: _rangeVars,
    ).get();
    final inc2 = await db.customSelect(
      "SELECT txn_date d, SUM(amount_paisa) s FROM income_personal WHERE deleted_at IS NULL AND $range AND payment_method <> 'baki' GROUP BY txn_date",
      variables: _rangeVars,
    ).get();
    final exp = await db.customSelect(
      "SELECT txn_date d, SUM(amount_paisa) s FROM expenses WHERE deleted_at IS NULL AND $range GROUP BY txn_date",
      variables: _rangeVars,
    ).get();
    final mother = await db.customSelect(
      "SELECT txn_date d, SUM(amount_paisa) s FROM mother_payments WHERE deleted_at IS NULL AND $range GROUP BY txn_date",
      variables: _rangeVars,
    ).get();
    final map = <String, (int, int)>{};
    void incAdd(String d, int v) {
      final cur = map[d] ?? (0, 0);
      map[d] = (cur.$1 + v, cur.$2);
    }

    void expAdd(String d, int v) {
      final cur = map[d] ?? (0, 0);
      map[d] = (cur.$1, cur.$2 + v);
    }

    for (final r in inc) {
      incAdd(r.read<String>('d'), r.read<int>('s'));
    }
    for (final r in inc2) {
      incAdd(r.read<String>('d'), r.read<int>('s'));
    }
    for (final r in exp) {
      expAdd(r.read<String>('d'), r.read<int>('s'));
    }
    for (final r in mother) {
      expAdd(r.read<String>('d'), r.read<int>('s'));
    }
    final days = map.keys.toList()..sort();
    return [for (final d in days) (d, map[d]!.$1, map[d]!.$2)];
  }

  /// FIX H-1: Excel/CSV-তে বিস্তারিত সারি — আগে const [] পাঠানো হতো,
  /// ফলে এক্সপোর্ট সবসময় খালি আসত
  Future<({List<Map<String, dynamic>> income, List<Map<String, dynamic>> expense})>
      _exportRows() async {
    bool inRange(String ymd) =>
        ymd.compareTo(_period.startYmd) >= 0 && ymd.compareTo(_period.endYmd) < 0;
    final incH = await repo.watchIncomeHat().first;
    final incP = await repo.watchIncomePersonal().first;
    final exps = await repo.watchExpenses().first;
    final income = <Map<String, dynamic>>[
      for (final r in incH)
        if (inRange(r.txnDate))
          {'date': r.txnDate, 'desc': r.note ?? 'হাট আয়', 'paisa': r.amountPaisa},
      for (final r in incP)
        if (inRange(r.txnDate))
          {'date': r.txnDate, 'desc': r.title, 'paisa': r.amountPaisa},
    ]..sort((a, b) => '${a['date']}'.compareTo('${b['date']}'));
    final expense = <Map<String, dynamic>>[
      for (final r in exps)
        if (inRange(r.txnDate))
          {'date': r.txnDate, 'desc': r.note ?? 'খরচ', 'paisa': r.amountPaisa},
    ]..sort((a, b) => '${a['date']}'.compareTo('${b['date']}'));
    return (income: income, expense: expense);
  }

  Future<void> _doExport(int kind) async {
    setState(() => _exporting = true);
    try {
      final bucket = await _bucket();
      final cats = await _topCats();
      final rows = await _exportRows();
      if (kind == 0) {
        // key শুধু ফাইলনাম/ফুটারের জন্য; PDF-তে প্রদর্শন হবে বাংলা লেবেলে
        await ExportService.exportPdf(
          periodKey: _period.key,
          displayLabel: _period.labelBn,
          reportTitle: _period.titleBn,
          bucket: bucket,
          topCats: cats,
        );
      } else if (kind == 1) {
        await ExportService.exportExcel(
          periodLabel: _period.key,
          bucket: bucket,
          incomeRows: rows.income,
          expenseRows: rows.expense,
        );
      } else if (kind == 2) {
        await ExportService.exportCsv(periodLabel: _period.key, incomeRows: rows.income, expenseRows: rows.expense);
      } else {
        await ExportService.exportJsonBackup();
      }
    } finally {
      if (mounted) setState(() => _exporting = false);
    }
  }

  void _selectKind(ReportPeriodKind kind) {
    if (kind == _period.kind) return;
    setState(() => _period = ReportPeriod.periodOf(kind, _period.start));
  }

  @override
  Widget build(BuildContext context) {
    // v1.5.0 (সিনিয়র): ডাটা বদলালে (এন্ট্রি যোগ/এডিট) রিপোর্টও তখনই
    // নতুন করে হিসাব হয় — revision key-তে যোগ হওয়ায় FutureBuilder
    // রিসেট হয়ে তাজা bucket আসে (আগে স্ক্রিন খোলা থাকলে পুরনো হিসাবই থাকত)।
    final rev = ref.watch(dataRevisionProvider).value;
    return Scaffold(
      appBar: AppBar(title: const Text('রিপোর্ট')),
      body: FutureBuilder<SummaryBucket>(
        // পিরিয়ড বদলালে নতুন হিসাব — key দিয়ে FutureBuilder রিসেট
        key: ValueKey('${_period.key}-$rev'),
        future: _bucket(),
        builder: (c, snap) {
          final b = snap.data;
          return ListView(
            // U-4 (v1.4.1): নিচের প্যাডিং 96 — এক্সপোর্ট বোতাম
            // ভাসমান ক্যালকুলেটর/FAB-এর আড়ালে পড়বে না
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
            children: [
              _periodSelector(),
              const SizedBox(height: 6),
              _periodNav(),
              const SizedBox(height: 10),
              if (b == null)
                const Padding(
                  padding: EdgeInsets.all(40),
                  child: Center(child: CircularProgressIndicator()),
                )
              else ...[
                Row(
                  children: [
                    Expanded(
                      child: StatCard(
                          label: 'মোট আয়', paisa: b.totalIncomePaisa, color: AppColors.income, compact: true),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: StatCard(
                          label: 'মোট খরচ', paisa: b.totalExpensePaisa, color: AppColors.expense, compact: true),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: StatCard(
                          label: 'নিট',
                          paisa: b.netPaisa,
                          color: b.netPaisa >= 0 ? AppColors.income : AppColors.expense,
                          compact: true),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('বিবরণ', style: Theme.of(context).textTheme.titleMedium),
                        const SizedBox(height: 8),
                        _line('হাট আয়', b.hatIncomePaisa, AppColors.income),
                        _line('পার্সোনাল আয়', b.personalIncomePaisa, AppColors.savings),
                        _line('খরচ', b.expensePaisa, AppColors.expense),
                        _line('আম্মুকে দেওয়া', b.motherPaisa, AppColors.mother),
                        _line('DPS জমা', b.dpsPaisa, AppColors.savings),
                        _line('বাইক তেল', b.bikeFuelPaisa, AppColors.bike),
                        _line('বাইক মেইনটেন্যান্স', b.bikeMaintenancePaisa, AppColors.bike),
                        _line('ধার দেওয়া', b.loanGivenPaisa, AppColors.loan),
                        _line('ধার নেওয়া', b.loanTakenPaisa, AppColors.income),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('দিন-ভিত্তিক (আয়/খরচ)', style: Theme.of(context).textTheme.titleMedium),
                        const SizedBox(height: 10),
                        SizedBox(
                          height: 160,
                          child: FutureBuilder<List<(String, int, int)>>(
                            key: ValueKey('bars-${_period.key}-$rev'),
                            future: _dailyBars(),
                            builder: (c, ds) {
                              final bars = ds.data ?? const <(String, int, int)>[];
                              if (bars.isEmpty) {
                                return const Center(child: Text('এই সময়ে ডাটা নেই', style: TextStyle(fontFamily: 'HindSiliguri')));
                              }
                              final maxV = bars
                                  .expand((e) => [e.$2, e.$3])
                                  .reduce((a, x) => a > x ? a : x) /
                              100.0;
                              return BarChart(
                                BarChartData(
                                  maxY: (maxV <= 0 ? 1 : maxV) * 1.15,
                                  barGroups: [
                                    for (var i = 0; i < bars.length; i++) ...[
                                      BarChartGroupData(
                                        x: i,
                                        barRods: [
                                          BarChartRodData(
                                            toY: bars[i].$2 / 100.0,
                                            color: AppColors.income,
                                            width: 5,
                                            borderRadius: BorderRadius.circular(2),
                                          ),
                                          BarChartRodData(
                                            toY: bars[i].$3 / 100.0,
                                            color: AppColors.expense,
                                            width: 5,
                                            borderRadius: BorderRadius.circular(2),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ],
                                  titlesData: FlTitlesData(
                                    leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                                    rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                                    topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                                    bottomTitles: AxisTitles(
                                      sideTitles: SideTitles(
                                        showTitles: bars.length <= 16,
                                        getTitlesWidget: (v, _) {
                                          final i = v.toInt();
                                          if (i < 0 || i >= bars.length) return const SizedBox.shrink();
                                          final d = bars[i].$1.split('-').last;
                                          return Text(toBanglaDigits(d),
                                              style: const TextStyle(fontSize: 9, fontFamily: 'HindSiliguri'));
                                        },
                                      ),
                                    ),
                                  ),
                                  gridData: const FlGridData(show: false),
                                  borderData: FlBorderData(show: false),
                                  barTouchData: BarTouchData(
                                    touchTooltipData: BarTouchTooltipData(
                                      getTooltipItem: (group, gi, rod, ri) => BarTooltipItem(
                                        MoneyFmt.taka(rod.toY.round() * 100),
                                        const TextStyle(fontFamily: 'HindSiliguri', fontSize: 11, color: Colors.white),
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Text('এক্সপোর্ট', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: _exporting ? null : () => _doExport(0),
                        icon: const Icon(Icons.picture_as_pdf, size: 18),
                        label: const Text('PDF'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _exporting ? null : () => _doExport(1),
                        icon: const Icon(Icons.grid_on, size: 18),
                        label: const Text('এক্সেল'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _exporting ? null : () => _doExport(2),
                        icon: const Icon(Icons.table_chart, size: 18),
                        label: const Text('CSV'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _exporting ? null : () => _doExport(3),
                        icon: const Icon(Icons.data_object, size: 18),
                        label: const Text('ব্যাকআপ'),
                      ),
                    ),
                  ],
                ),
              ],
            ],
          );
        },
      ),
    );
  }

  /// সময়কালের ধরন বাছাই — স্ক্রলযোগ্য চিপ সারি (ছোট স্ক্রিনেও ভাঙে না)
  Widget _periodSelector() {
    const kinds = [
      (ReportPeriodKind.daily, 'দৈনিক'),
      (ReportPeriodKind.weekly, 'সাপ্তাহিক'),
      (ReportPeriodKind.monthly, 'মাসিক'),
      (ReportPeriodKind.yearly, 'বার্ষিক'),
    ];
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          for (final (kind, label) in kinds) ...[
            ChoiceChip(
              label: Text(label, style: const TextStyle(fontFamily: 'HindSiliguri')),
              selected: _period.kind == kind,
              onSelected: (_) => _selectKind(kind),
            ),
            const SizedBox(width: 8),
          ],
        ],
      ),
    );
  }

  /// আগের/পরের পিরিয়ড নেভিগেশন — ‹ বাংলা লেবেল ›
  Widget _periodNav() {
    return Row(
      children: [
        IconButton(
          icon: const Icon(Icons.chevron_left),
          tooltip: 'আগের',
          onPressed: () => setState(() => _period = _period.shift(-1)),
        ),
        Expanded(
          child: Text(
            _period.labelBn,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.titleMedium,
          ),
        ),
        IconButton(
          icon: const Icon(Icons.chevron_right),
          tooltip: 'পরের',
          onPressed: () => setState(() => _period = _period.shift(1)),
        ),
      ],
    );
  }

  Widget _line(String label, int paisa, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Container(width: 8, height: 8, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 13.5),
            ),
          ),
          const SizedBox(width: 8),
          // F-13 (v1.4.1): টাকার অঙ্ক কার্ডের ডান প্রান্তে লেগে
          // আংশিক কাটা পড়ত — এখন সীমাবদ্ধ প্রস্থে ডান-ঘেঁষা
          // scale-down, প্রান্ত থেকে ফাঁকসহ
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 130),
            child: FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerRight,
              child: MoneyText(paisa, color: color, fontSize: 13.5, compact: true),
            ),
          ),
          const SizedBox(width: 2),
        ],
      ),
    );
  }
}
