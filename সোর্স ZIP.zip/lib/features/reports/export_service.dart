import 'dart:convert';
import 'dart:io';

import 'package:excel/excel.dart' as xl;
import 'package:flutter/services.dart';
import 'dart:ui' as ui;

import 'package:flutter/material.dart' hide CharacterRange;
import 'package:flutter/rendering.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';

import '../../core/calculations/summary_calc.dart';
import '../../core/utils/money_format.dart';
import '../../core/providers/app_providers.dart';
import '../../core/router.dart';
import '../../core/theme/app_colors.dart';

/// এক্সপোর্ট সার্ভিস — PDF (বাংলা ফন্ট এমবেড), Excel, CSV, JSON (v1.1: আগের বাকি কাজ)
class ExportService {
  ExportService._();

  /// QR কোডের গন্তব্য — স্ক্যান করলেই সর্বশেষ রিলিজের APK সরাসরি ডাউনলোড।
  /// রিলিজের ট্যাগ/ফাইলনাম বদলালে এখানেই বদলাতে হবে (v1.4.1)।
  static const String appDownloadUrl =
      'https://github.com/ShohagVaii/Hat-hisab/releases/download/v1.5.0/hat-hisab-v1.5.0.apk';

  static Future<String> _tmpDir() async {
    final dir = await getTemporaryDirectory();
    final out = Directory('${dir.path}/exports');
    if (!await out.exists()) await out.create(recursive: true);
    return out.path;
  }

  /// রিপোর্ট-উইজেট অফ-স্ক্রিনে রেন্ডার করে ছবি → PDF (হাইব্রিড লেআউট, v1.4.1)।
  /// pdf-প্যাকেজ বাংলা যুক্তাক্ষর ভাঙে; Flutter-এর নিজের রেন্ডারার ভাঙে না।
  /// তাই হিসাবের বডি আগের মতোই Flutter-PNG; শুধু হেডার/ফুটার native pw-তে —
  /// আর pw-স্তরে ছাপা হয় কেবল যুক্তাক্ষর-মুক্ত টেক্সট:
  /// হেডারে "FinTrack হাট হিসাব", ফুটারে ল্যাটিন CREDIT/তারিখ/QR-ক্যাপশন।
  /// শিরোনাম ("রিপোর্ট"-এ র্ট যুক্ত) ও মাসের বাংলা নাম ("নভেম্বর"-এ ম্ব যুক্ত)
  /// বডি-Flutter অংশেই থাকে।
  /// [periodKey] = পিরিয়ড key (ফাইলনাম + ফুটারের Report লাইন) —
  /// দৈনিক 'yyyy-MM-dd', সাপ্তাহিক 'yyyy-Www', মাসিক 'yyyy-MM', বার্ষিক 'yyyy'।
  /// [displayLabel] = বাংলা পিরিয়ড-লেবেল (বডিতে প্রদর্শন),
  /// [reportTitle] = 'দৈনিক রিপোর্ট' / 'সাপ্তাহিক রিপোর্ট' / … (বডির শিরোনাম)।
  static Future<void> exportPdf({
    required String periodKey,
    required String displayLabel,
    required String reportTitle,
    required SummaryBucket bucket,
    required List<CategorySlice> topCats,
  }) async {
    final png =
        await _captureReportPng(displayLabel, reportTitle, bucket, topCats);
    final baseFont =
        pw.Font.ttf(await rootBundle.load('assets/fonts/HindSiliguri-Regular.ttf'));
    final boldFont =
        pw.Font.ttf(await rootBundle.load('assets/fonts/HindSiliguri-Bold.ttf'));
    final theme = pw.ThemeData.withFont(base: baseFont, bold: boldFont);
    final now = DateTime.now();
    final generatedDate =
        '${now.year.toString().padLeft(4, '0')}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
    final pdf = pw.Document();
    pdf.addPage(pw.Page(
      pageFormat: PdfPageFormat.a4,
      theme: theme,
      margin: const pw.EdgeInsets.fromLTRB(40, 32, 40, 28),
      build: (ctx) => pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.stretch,
        children: [
          _pdfHeader(),
          pw.SizedBox(height: 14),
          pw.Image(pw.MemoryImage(png), width: 515.28, fit: pw.BoxFit.contain),
          pw.Spacer(),
          _pdfFooter(periodKey: periodKey, generatedDate: generatedDate),
        ],
      ),
    ));
    final path = await _tmpDir();
    final file = File('$path/hat-hisab-$periodKey.pdf'.replaceAll(' ', '_'));
    await file.writeAsBytes(await pdf.save());
    await Share.shareXFiles([XFile(file.path)], text: 'হাট হিসাব $reportTitle — $displayLabel');
  }

  /// PDF হেডার — সবচেয়ে উপরে মাঝ বরাবর অ্যাপের নাম + দুই-রঙা ব্র্যান্ড ডিভাইডার।
  /// শুধু যুক্তাক্ষর-মুক্ত টেক্সট ("FinTrack" ল্যাটিন + "হাট হিসাব")।
  static pw.Widget _pdfHeader() {
    final primary = PdfColor.fromHex('#1B7A43');
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.stretch,
      children: [
        pw.Text(
          'FinTrack হাট হিসাব',
          textAlign: pw.TextAlign.center,
          style: pw.TextStyle(
            fontSize: 22,
            fontWeight: pw.FontWeight.bold,
            color: primary,
            letterSpacing: 0,
          ),
        ),
        pw.SizedBox(height: 10),
        pw.Row(
          children: [
            pw.Expanded(child: pw.Container(height: 2, color: primary)),
            pw.Container(width: 44, height: 2, color: PdfColor.fromHex('#F2A93B')),
            pw.Expanded(child: pw.Container(height: 2, color: primary)),
          ],
        ),
      ],
    );
  }

  /// PDF ফুটার — বামে তৈরির তারিখ, মাঝে স্টাইলিশ CREDIT, ডানে ডাউনলোড QR।
  /// সব টেক্সট ল্যাটিন — pw-স্তরে যুক্তাক্ষর-ঝুঁকি নেই।
  static pw.Widget _pdfFooter({
    required String periodKey,
    required String generatedDate,
  }) {
    final muted = PdfColor.fromHex('#5C6660');
    final outline = PdfColor.fromHex('#D8DED9');
    final smallStyle = pw.TextStyle(fontSize: 8, color: muted);
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.stretch,
      children: [
        pw.Container(height: 1, color: outline),
        pw.SizedBox(height: 8),
        pw.Row(
          crossAxisAlignment: pw.CrossAxisAlignment.end,
          children: [
            pw.SizedBox(
              width: 150,
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text('Generated: $generatedDate', style: smallStyle),
                  pw.SizedBox(height: 2),
                  pw.Text('Report: $periodKey', style: smallStyle),
                ],
              ),
            ),
            pw.Expanded(
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.center,
                children: [
                  pw.Container(
                      width: 46, height: 1, color: PdfColor.fromHex('#1B7A43')),
                  pw.SizedBox(height: 4),
                  pw.Text(
                    'CREDIT: SHOHAG VAII',
                    textAlign: pw.TextAlign.center,
                    style: pw.TextStyle(
                      fontSize: 13.5,
                      fontWeight: pw.FontWeight.bold,
                      letterSpacing: 1.8,
                      color: PdfColor.fromHex('#145C32'),
                    ),
                  ),
                  pw.SizedBox(height: 2),
                  pw.Text(
                    'DEVELOPER & DESIGNER',
                    textAlign: pw.TextAlign.center,
                    style: pw.TextStyle(fontSize: 7, letterSpacing: 2.4, color: muted),
                  ),
                ],
              ),
            ),
            pw.SizedBox(
              width: 76,
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.center,
                children: [
                  pw.Container(
                    padding: const pw.EdgeInsets.all(4),
                    decoration: pw.BoxDecoration(
                      border: pw.Border.all(color: outline, width: 0.75),
                      borderRadius: pw.BorderRadius.circular(4),
                    ),
                    child: pw.BarcodeWidget(
                      data: appDownloadUrl,
                      barcode: pw.Barcode.qrCode(
                          errorCorrectLevel: pw.BarcodeQRCorrectionLevel.medium),
                      width: 68,
                      height: 68,
                      drawText: false,
                      color: PdfColors.black,
                      backgroundColor: PdfColors.white,
                    ),
                  ),
                  pw.SizedBox(height: 3),
                  pw.Text(
                    'Scan to download the app',
                    textAlign: pw.TextAlign.center,
                    style: pw.TextStyle(fontSize: 7.5, color: muted),
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  static Future<Uint8List> _captureReportPng(
    String displayLabel,
    String reportTitle,
    SummaryBucket bucket,
    List<CategorySlice> topCats,
  ) async {
    final nav = rootNavigatorKey.currentState;
    final overlay = nav?.overlay;
    if (overlay == null) {
      throw StateError('overlay not ready');
    }
    final boundaryKey = GlobalKey();
    late final OverlayEntry entry;
    entry = OverlayEntry(
      builder: (_) => Positioned(
        left: -9999,
        top: 0,
        child: Material(
          color: Colors.white,
          child: SizedBox(
            width: 794,
            child: RepaintBoundary(
              key: boundaryKey,
              child: _reportWidget(displayLabel, reportTitle, bucket, topCats),
            ),
          ),
        ),
      ),
    );
    overlay.insert(entry);
    await Future<void>.delayed(const Duration(milliseconds: 120));
    await WidgetsBinding.instance.endOfFrame;
    final boundary =
        boundaryKey.currentContext?.findRenderObject() as RenderRepaintBoundary?;
    if (boundary == null) {
      entry.remove();
      throw StateError('report boundary missing');
    }
    final image = await boundary.toImage(pixelRatio: 2.0);
    entry.remove();
    final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
    return byteData!.buffer.asUint8List();
  }

  /// A4-প্রস্থের (৭৯৪ লজিকাল px) রিপোর্ট বডি — সব বাংলা, অ্যাপের ডিজাইনেই।
  /// PDF-পেজের হেডার/ফুটার pw-স্তরে; শিরোনাম ও পিরিয়ডের বাংলা লেবেল এখানে
  /// (Flutter রেন্ডারে যুক্তাক্ষর নিরাপদ বলে)।
  /// [exportMode] (v1.5.0): শুধু এক্সপোর্ট বডিতে — ৳০-এর বিবরণ-সারি বাদ
  /// পড়ে (ইউজারের চাওয়া: ফাঁকা খাত PDF-এ দেখাবে না, দেখতে সুন্দর লাগে)।
  /// সেকশন-মোট (মোট আয় / মোট খরচ / নিট সঞ্চয়) সবসময় থাকে; পুরো সেকশন
  /// শূন্য হলে শুধু মোট-সারিটাই আসে। স্ক্রিনের রিপোর্টে সব সারি থাকে —
  /// এই উইজেট শুধু এক্সপোর্টেই ব্যবহৃত হয়।
  static Widget _reportWidget(
    String displayLabel,
    String reportTitle,
    SummaryBucket bucket,
    List<CategorySlice> topCats, {
    bool exportMode = true,
  }) {
    TextStyle rowStyle(bool strong) => TextStyle(
        fontFamily: 'HindSiliguri',
        fontSize: 15,
        fontWeight: strong ? FontWeight.w700 : FontWeight.w400,
        color: const Color(0xFF16211B));
    Widget row(String label, int paisa, {bool strong = false}) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 5),
          child: Row(children: [
            Expanded(child: Text(label, style: rowStyle(strong))),
            Text(MoneyFmt.taka(paisa), style: rowStyle(strong)),
          ]),
        );
    // exportMode-এ ৳০ বিবরণ-সারি বাদ; মোট-সারি কখনো বাদ নয়
    bool show(int paisa, {bool total = false}) =>
        total || !exportMode || paisa != 0;
    final cats = [
      for (final ct in topCats)
        if (show(ct.amountPaisa)) ct,
    ];
    return Container(
      color: Colors.white,
      // পেজ-মার্জিনই এখন একমাত্র মার্জিন (PDF হেডার/ফুটার pw-স্তরে) — এখানে শুধু প্রান্ত-নিরাপত্তা
      padding: const EdgeInsets.all(8),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('হাট হিসাব — $reportTitle',
              textAlign: TextAlign.right,
              style: const TextStyle(
                  fontFamily: 'HindSiliguri',
                  fontSize: 26,
                  fontWeight: FontWeight.w700,
                  color: AppColors.primary)),
          const SizedBox(height: 4),
          Text(displayLabel,
              textAlign: TextAlign.right,
              style: rowStyle(false).copyWith(fontSize: 15, color: const Color(0xFF5C6660))),
          const SizedBox(height: 18),
          if (show(bucket.hatIncomePaisa)) row('হাট আয়', bucket.hatIncomePaisa),
          if (show(bucket.personalIncomePaisa))
            row('পার্সোনাল আয়', bucket.personalIncomePaisa),
          row('মোট আয়', bucket.totalIncomePaisa, strong: true),
          const SizedBox(height: 8),
          if (show(bucket.expensePaisa))
            row('খরচ (ব্যক্তিগত+হাট)', bucket.expensePaisa),
          if (show(bucket.motherPaisa)) row('আম্মুকে দেওয়া', bucket.motherPaisa),
          if (show(bucket.dpsPaisa)) row('DPS জমা', bucket.dpsPaisa),
          if (show(bucket.bikeFuelPaisa)) row('বাইক (তেল)', bucket.bikeFuelPaisa),
          if (show(bucket.bikeMaintenancePaisa))
            row('বাইক (মেইনটেন্যান্স)', bucket.bikeMaintenancePaisa),
          row('মোট খরচ', bucket.totalExpensePaisa, strong: true),
          const Divider(thickness: 1.2),
          row('নিট সঞ্চয়', bucket.netPaisa, strong: true),
          const SizedBox(height: 18),
          if (cats.isNotEmpty) ...[
            Text('খরচের খাত',
                style: rowStyle(true).copyWith(fontSize: 17, color: AppColors.primary)),
            const SizedBox(height: 8),
            for (final ct in cats.take(8)) row(ct.name, ct.amountPaisa),
          ],
          // পুরনো ফুটার লাইন (শুধু দিনের সংখ্যা ছাপার বাগসহ) বাদ —
          // তারিখ/CREDIT/QR এখন PDF ফুটারে (pw-স্তরে)।
        ],
      ),
    );
  }

  static Future<void> exportExcel({
    required String periodLabel,
    required SummaryBucket bucket,
    required List<Map<String, dynamic>> incomeRows,
    required List<Map<String, dynamic>> expenseRows,
  }) async {
    final excel = xl.Excel.createExcel();
    excel.rename('Sheet1', 'সারাংশ');
    final summary = excel.sheets['সারাংশ']!;
    summary.appendRow([xl.TextCellValue('হাট হিসাব — $periodLabel')]);
    summary.appendRow([xl.TextCellValue('খাত'), xl.TextCellValue('টাকা')]);
    summary.appendRow([xl.TextCellValue('হাট আয়'), xl.TextCellValue(MoneyFmt.taka(bucket.hatIncomePaisa))]);
    summary.appendRow([xl.TextCellValue('পার্সোনাল আয়'), xl.TextCellValue(MoneyFmt.taka(bucket.personalIncomePaisa))]);
    summary.appendRow([xl.TextCellValue('মোট আয়'), xl.TextCellValue(MoneyFmt.taka(bucket.totalIncomePaisa))]);
    summary.appendRow([xl.TextCellValue('মোট খরচ'), xl.TextCellValue(MoneyFmt.taka(bucket.totalExpensePaisa))]);
    summary.appendRow([xl.TextCellValue('নিট'), xl.TextCellValue(MoneyFmt.taka(bucket.netPaisa))]);

    final income = excel['আয়'];
    income.appendRow([xl.TextCellValue('তারিখ'), xl.TextCellValue('বিবরণ'), xl.TextCellValue('টাকা')]);
    for (final r in incomeRows) {
      income.appendRow([
        xl.TextCellValue('${r['date']}'),
        xl.TextCellValue('${r['desc']}'),
        xl.TextCellValue(MoneyFmt.taka(r['paisa'] as int)),
      ]);
    }
    final expense = excel['খরচ'];
    expense.appendRow([xl.TextCellValue('তারিখ'), xl.TextCellValue('খাত/বিবরণ'), xl.TextCellValue('টাকা')]);
    for (final r in expenseRows) {
      expense.appendRow([
        xl.TextCellValue('${r['date']}'),
        xl.TextCellValue('${r['desc']}'),
        xl.TextCellValue(MoneyFmt.taka(r['paisa'] as int)),
      ]);
    }
    excel.setDefaultSheet('সারাংশ');
    final bytes = excel.encode()!;
    final path = await _tmpDir();
    final file = File('$path/hat-hisab-$periodLabel.xlsx'.replaceAll(' ', '_'));
    await file.writeAsBytes(bytes);
    await Share.shareXFiles([XFile(file.path)], text: 'হাট হিসাব এক্সেল রিপোর্ট — $periodLabel');
  }

  static Future<void> exportCsv({
    required String periodLabel,
    required List<Map<String, dynamic>> incomeRows,
    required List<Map<String, dynamic>> expenseRows,
  }) async {
    final sb = StringBuffer('type,date,desc,paisa\n');
    for (final r in incomeRows) {
      sb.writeln('income,${r['date']},"${('${r['desc']}').replaceAll('"', "'")}",${r['paisa']}');
    }
    for (final r in expenseRows) {
      sb.writeln('expense,${r['date']},"${('${r['desc']}').replaceAll('"', "'")}",${r['paisa']}');
    }
    final path = await _tmpDir();
    final file = File('$path/hat-hisab-$periodLabel.csv'.replaceAll(' ', '_'));
    await file.writeAsString(sb.toString(), encoding: utf8);
    await Share.shareXFiles([XFile(file.path)], text: 'হাট হিসাব CSV — $periodLabel');
  }

  static Future<void> exportJsonBackup() async {
    final data = await repo.exportAll();
    final path = await _tmpDir();
    final file = File('$path/hat-hisab-backup-${DateTime.now().millisecondsSinceEpoch}.json');
    await file.writeAsString(jsonEncode(data));
    await Share.shareXFiles([XFile(file.path)], text: 'হাট হিসাব ব্যাকআপ (JSON)');
  }
}
