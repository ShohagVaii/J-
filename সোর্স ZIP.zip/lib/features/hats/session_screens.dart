import 'package:flutter/material.dart';
import 'package:drift/drift.dart' hide Column;
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/calculations/session_calc.dart';
import '../../core/providers/app_providers.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/bangla_digits.dart';
import '../../core/utils/date_utils_bn.dart';
import '../../core/utils/money_format.dart';
import '../../core/widgets/common.dart';
import '../../core/widgets/info_banner.dart';
import '../../data/local/app_database.dart';

/// হাট সেশন — ৪ ধাপ স্টেপার (02_AppFlow §3.6)
/// v1.1: প্রতিটি ধাপে ব্যাক = আগের ধাপ; ধাপ ১-এ ব্যাক = নিশ্চিতকরণ → খসড়া সেভ হয়ে থাকে।
class SessionStepperScreen extends ConsumerStatefulWidget {
  final String? sessionId;
  final String? initialHatId;
  const SessionStepperScreen({super.key, this.sessionId, this.initialHatId});

  @override
  ConsumerState<SessionStepperScreen> createState() => _SessionStepperScreenState();
}

class _SessionStepperScreenState extends ConsumerState<SessionStepperScreen> {
  int _step = 0;
  bool _ready = false;
  bool _saving = false;
  HatSession? _session;
  List<Hat> _hats = [];

  late final TextEditingController _date = TextEditingController();
  final _owner = TextEditingController();
  final _opening = TextEditingController();
  final _ownerCash = TextEditingController();
  final _wage = TextEditingController();
  final _chota = TextEditingController();
  final _slip = TextEditingController();
  final _memo = TextEditingController();
  final _returned = TextEditingController();
  final _counted = TextEditingController();
  final _note = TextEditingController();
  String? _hatId;
  String _residual = 'self';
  bool _wageReceivedNow = false;
  bool _closing = false; // FIX V1.3 (F-7): double-tap guard

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    if (widget.sessionId != null) {
      final s = await repo.getSession(widget.sessionId!);
      if (s != null) {
        _session = s;
        _fillFrom(s);
      }
    } else {
      _date.text = ymdOf(DateTime.now());
    }
    final hats = await repo.watchHats().first;
    if (!mounted) return;
    setState(() {
      _hats = hats;
      _hatId ??= widget.initialHatId ?? (hats.isNotEmpty ? hats.first.id : null);
      // V1.3: হাটের default মালিকের নাম prefill (05_Schema §3.4 অনুযায়ী ছিল, ওয়্যারিং ছিল না)
      if (_session == null && _owner.text.trim().isEmpty && _hatId != null) {
        for (final h in hats) {
          if (h.id == _hatId && (h.defaultOwnerName ?? '').trim().isNotEmpty) {
            _owner.text = h.defaultOwnerName!;
          }
        }
      }
      _ready = true;
    });
  }

  void _fillFrom(HatSession s) {
    _date.text = s.txnDate;
    _hatId = s.hatId;
    _owner.text = s.ownerName ?? '';
    _opening.text = paisaToEdit(s.openingCashPaisa);
    _ownerCash.text = paisaToEdit(s.ownerCashReceivedPaisa);
    _wage.text = paisaToEdit(s.wagePaisa);
    _chota.text = paisaToEdit(s.chotaPaisa);
    _slip.text = paisaToEdit(s.slipChargePaisa);
    _memo.text = paisaToEdit(s.memoChargePaisa);
    _returned.text = paisaToEdit(s.returnedToOwnerPaisa);
    _counted.text = s.countedCashPaisa == null ? '' : paisaToEdit(s.countedCashPaisa!);
    _note.text = s.note ?? '';
    _residual = s.residualHolder ?? 'self';
  }

  static String paisaToEdit(int paisa) {
    if (paisa == 0) return '';
    final taka = paisa / 100;
    final s = taka == taka.roundToDouble()
        ? taka.round().toString()
        : taka.toStringAsFixed(2);
    return toBanglaDigits(s);
  }

  bool get _isClosed => _session?.status == 'closed';

  /// FIX V1.3 (F-15): টাকার ঘরে ভুল লেখা থাকলে নীরবে ৳০ সেভ হবে না —
  /// কোন ঘরে ভুল তা জানিয়ে সেভ আটকে দেবে।
  bool _moneyFieldsValid() {
    final fields = <TextEditingController, String>{
      _opening: 'শুরুর ক্যাশ', _ownerCash: 'অতিরিক্ত ক্যাশ', _wage: 'পারিশ্রমিক',
      _chota: 'ছোতা', _slip: 'স্লিপ', _memo: 'মেমো', _returned: 'ফেরত', _counted: 'গোনা ক্যাশ',
    };
    for (final e in fields.entries) {
      final t = e.key.text.trim();
      if (t.isNotEmpty && AmountInput.readPaisa(e.key) == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('"${e.value}" ঘরে টাকার অঙ্কটা ঠিক করে লিখুন'),
            backgroundColor: AppColors.expense,
          ));
        }
        return false;
      }
    }
    return true;
  }

  Future<bool> _persistDraft() async {
    if (_hatId == null || _saving) return _session != null;
    if (!_moneyFieldsValid()) return false;
    _saving = true;
    try {
      final comp = HatSessionsCompanion.insert(
        id: '', userId: '',
        hatId: _hatId!,
        txnDate: _date.text.isEmpty ? ymdOf(DateTime.now()) : _date.text,
        ownerName: Value(_owner.text.trim().isEmpty ? null : _owner.text.trim()),
        openingCashPaisa: Value(AmountInput.readPaisa(_opening) ?? 0),
        ownerCashReceivedPaisa: Value(AmountInput.readPaisa(_ownerCash) ?? 0),
        wagePaisa: Value(AmountInput.readPaisa(_wage) ?? 0),
        chotaPaisa: Value(AmountInput.readPaisa(_chota) ?? 0),
        slipChargePaisa: Value(AmountInput.readPaisa(_slip) ?? 0),
        memoChargePaisa: Value(AmountInput.readPaisa(_memo) ?? 0),
        returnedToOwnerPaisa: Value(AmountInput.readPaisa(_returned) ?? 0),
        note: Value(_note.text.trim().isEmpty ? null : _note.text.trim()),
        residualHolder: Value(_residual),
        countedCashPaisa: Value(AmountInput.readPaisa(_counted)),
      );
      if (_session == null) {
        final id = await repo.insert(dbRef.hatSessions, comp);
        _session = await repo.getSession(id);
      } else {
        await repo.update(dbRef.hatSessions, _session!.id, comp);
        _session = await repo.getSession(_session!.id);
      }
      return true;
    } finally {
      _saving = false;
    }
  }

  Future<bool> _goBack() async {
    if (_step > 0) {
      if (!await _persistDraft()) return false; // ভুল লেখা থাকলে ধাপ বদলাবে না
      if (mounted) setState(() => _step--);
      return false; // আটকে দাও, আমরা নিজেই ধাপ বদলেছি
    }
    await _persistDraft(); // খসড়া সেভ (ব্যর্থ হলেও বের হওয়া যাবে)
    if (mounted) Navigator.of(context).pop();
    return false;
  }

  Future<void> _next() async {
    if (!await _persistDraft()) return;
    if (mounted && _step < 3) setState(() => _step++);
  }

  /// V1.3: তালি (নোট-গোনা) স্ক্রিন থেকে মোট টাকা এনে দেওয়া ঘরে বসায়
  Future<void> _fillFromTally(TextEditingController target) async {
    if (!await _persistDraft()) return;
    final sid = _session?.id;
    if (sid == null || !mounted) return;
    final total = await context.push<int>('/tally/$sid');
    if (total != null && total > 0 && mounted) {
      setState(() => target.text = paisaToEdit(total));
    }
  }

  Future<void> _closeSession() async {
    if (_closing) return;
    _closing = true;
    try {
      await _closeSessionInner();
    } finally {
      _closing = false;
    }
  }

  Future<void> _closeSessionInner() async {
    if (!await _persistDraft()) return;
    final s = _session!;
    // FIX V1.3 (F-13): গোনা ক্যাশ না লিখে বন্ধ করা যাবে না — আগে ফাঁকা
    // থাকলে counted=৳০ ধরে বিশাল ভুয়া ঘাটতি সেভ হয়ে যেত।
    final counted = AmountInput.readPaisa(_counted);
    if (counted == null) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('আগে হাতে গোনা ক্যাশ লিখুন — বা "তালি দিয়ে গুনুন" চাপুন'),
        backgroundColor: AppColors.expense,
      ));
      return;
    }
    final items = await repo.getPurchaseItems(s.id);
    final purchasePaid = items.fold<int>(0, (a, r) => a + r.paidPaisa);
    final expRows = await (dbRef.select(dbRef.expenses)
          ..where((t) => t.deletedAt.isNull() & t.sessionId.equals(s.id)))
        .get();
    final sessionExpense = expRows.fold<int>(0, (a, r) => a + r.amountPaisa);
    final expected = SessionCalc.expectedCash(
      openingCashPaisa: s.openingCashPaisa,
      ownerCashReceivedPaisa: s.ownerCashReceivedPaisa,
      purchasePaidPaisa: purchasePaid,
      sessionExpensePaisa: sessionExpense,
      chotaPaisa: s.chotaPaisa,
      slipChargePaisa: s.slipChargePaisa,
      memoChargePaisa: s.memoChargePaisa,
      returnedToOwnerPaisa: s.returnedToOwnerPaisa,
    );
    final diff = SessionCalc.difference(countedPaisa: counted, expectedPaisa: expected);
    // F-03: ডায়ালগ আসার আগে কীবোর্ড বন্ধ — নইলে ডায়ালগের পেছনে
    // কীবোর্ড খোলা থেকে যেত
    if (mounted) FocusManager.instance.primaryFocus?.unfocus();
    // V1.3 (ফিচার ৬): বড় difference হলে অতিরিক্ত নিশ্চিতকরণ + কারণ নোট
    String? diffNote;
    if (diff.abs() > SessionCalc.differenceAlertThresholdPaisa) {
      diffNote = await _askDifferenceReason(diff);
      if (diffNote == null) return; // ব্যবহারকারী বাতিল করেছেন — বন্ধ হবে না
    }
    await repo.update(dbRef.hatSessions, s.id, HatSessionsCompanion(
      status: const Value('closed'),
      expectedCashPaisa: Value(expected),
      countedCashPaisa: Value(counted),
      cashDifferencePaisa: Value(diff),
      differenceNote: Value(diffNote),
    ));
    // পারিশ্রমিক এখন পেলে income_hat রেকর্ড
    // FIX V1.3 (F-7): একই সেশনের পারিশ্রমিক আগে ঢুকে থাকলে আবার ঢুকবে না
    final wage = s.wagePaisa;
    if (_wageReceivedNow && wage > 0) {
      final existingWage = await (dbRef.select(dbRef.incomeHat)
            ..where((t) => t.deletedAt.isNull() & t.sessionId.equals(s.id)))
          .get();
      if (existingWage.isEmpty) {
        await repo.insert(dbRef.incomeHat, IncomeHatCompanion.insert(
          id: '', userId: '',
          hatId: Value(s.hatId),
          sessionId: Value(s.id),
          txnDate: s.txnDate,
          amountPaisa: wage,
        ));
      }
    }
    if (!mounted) return;
    // F-03: সাফল্য ডায়ালগের আগে আগের এরর স্ন্যাকবার পরিষ্কার + কীবোর্ড
    // বন্ধ — নইলে লাল এরর ব্যানার ডায়ালগের পেছনে আটকে থেকে
    // "হলো না ব্যর্থ হলো" বিভ্রান্তি তৈরি করত
    FocusManager.instance.primaryFocus?.unfocus();
    ScaffoldMessenger.of(context).clearSnackBars();
    await showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('সেশন বন্ধ হয়েছে ✓'),
        content: Text(
          'প্রত্যাশিত: ${MoneyFmt.taka(expected)}\nগোনা হলো: ${MoneyFmt.taka(counted)}\n'
          '${diff == 0 ? 'মিলে গেছে — নিখুঁত!' : diff > 0 ? 'বাড়তি: ${MoneyFmt.taka(diff)}' : 'ঘাটতি: ${MoneyFmt.taka(-diff)}'}',
          style: const TextStyle(fontFamily: 'HindSiliguri', height: 1.5),
        ),
        actions: [
          FilledButton(
            onPressed: () => Navigator.pop(c),
            child: const Text('ঠিক আছে'),
          ),
        ],
      ),
    );
    if (!mounted) return;
    context.go('/hats');
  }

  /// বড় difference-এর জন্য সতর্ক ডায়ালগ: কারণ লিখে নিশ্চিত করলে কারণটি
  /// ফেরত দেয়; বাতিল করলে null (closing থেমে যাবে)।
  Future<String?> _askDifferenceReason(int diff) async {
    final noteCtl = TextEditingController();
    final result = await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (c) => AlertDialog(
        scrollable: true, // U-8: কীবোর্ড খুললে ছোট স্ক্রিনে overflow রোধ
        icon: const Icon(Icons.warning_amber_rounded, color: AppColors.expense, size: 36),
        title: const Text('বড় পার্থক্য!'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              diff > 0
                  ? 'হিসাবের চেয়ে ${MoneyFmt.taka(diff)} বেশি পাওয়া গেছে।'
                  : 'হিসাবের চেয়ে ${MoneyFmt.taka(-diff)} কম পাওয়া গেছে (ঘাটতি)।',
              style: const TextStyle(fontFamily: 'HindSiliguri', height: 1.5),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: noteCtl,
              decoration: const InputDecoration(
                labelText: 'কারণ (ঐচ্ছিক, তবে লিখে রাখা ভালো)',
                hintText: 'যেমন: এক বিক্রেতার বাকি পরে দিয়েছি',
                border: OutlineInputBorder(),
              ),
              maxLines: 2,
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('ফিরে যাই')),
          FilledButton(
            onPressed: () => Navigator.pop(c, noteCtl.text.trim()),
            child: const Text('বুঝেছি, বন্ধ করুন'),
          ),
        ],
      ),
    );
    noteCtl.dispose();
    return result;
  }

  @override
  void dispose() {
    for (final c in [_date, _owner, _opening, _ownerCash, _wage, _chota, _slip, _memo, _returned, _counted, _note]) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_ready) {
      return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
    }
    if (_hats.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('হাট সেশন')),
        body: EmptyState(
          icon: Icons.storefront,
          title: 'আগে হাট যোগ করুন',
          subtitle: 'সেশন শুরু করতে অন্তত একটি হাট দরকার',
          actionLabel: 'হাট যোগ করুন',
          onAction: () => context.push('/hats/new'),
        ),
      );
    }
    return PopScope<bool>(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;
        await _goBack();
      },
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: _goBack, // অ্যাপবার ব্যাকও একই যুক্তি
          ),
          title: Text(
            _isClosed
                ? 'সেশন (বন্ধ)'
                : 'হাট সেশন — ধাপ ${toBanglaDigits('${_step + 1}')}/৪',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ),
        body: _isClosed
            ? _buildClosedView()
            : Column(
                children: [
                  LinearProgressIndicator(value: (_step + 1) / 4, backgroundColor: AppColors.primaryLight),
                  Expanded(
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
                      children: [
                        if (_step == 0) _step1(),
                        if (_step == 1) _step2(),
                        if (_step == 2) _step3(),
                        if (_step == 3) _step4(),
                      ],
                    ),
                  ),
                ],
              ),
        // U-6 (v1.4.1): নেভিগেশন বোতাম ListView-এর ভেতর থেকে বের করে
        // স্থির ফুটারে — লম্বা ধাপ-২ তালিকায় স্ক্রল করে খুঁজতে হবে না
        bottomNavigationBar: _isClosed
            ? null
            : SafeArea(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                  child: _navButtons(),
                ),
              ),
      ),
    );
  }

  Widget _step1() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('মৌলিক তথ্য', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: _hatId,
          decoration: const InputDecoration(labelText: 'হাট', border: OutlineInputBorder()),
          items: [
            for (final h in _hats)
              DropdownMenuItem(value: h.id, child: Text(h.name, maxLines: 1, overflow: TextOverflow.ellipsis)),
          ],
          onChanged: (v) => setState(() => _hatId = v),
        ),
        const SizedBox(height: 12),
        DateField(controller: _date, label: 'তারিখ'),
        const SizedBox(height: 12),
        AppTextField(controller: _owner, label: 'মালিক/মহাজনের নাম', hint: 'ঐচ্ছিক'),
        const SizedBox(height: 12),
        AmountInput(controller: _opening, label: 'শুরুর ক্যাশ (মালিকের দেওয়া)', suffixText: '৳'),
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton.icon(
            onPressed: () => _fillFromTally(_opening),
            icon: const Icon(Icons.calculate_outlined, size: 18),
            label: const Text('তালি দিয়ে গুনুন (নোট অনুযায়ী)'),
          ),
        ),
        AmountInput(controller: _ownerCash, label: 'পরে অতিরিক্ত নেওয়া ক্যাশ (যদি থাকে)', suffixText: '৳'),
        const Padding(
          padding: EdgeInsets.only(top: 4),
          child: Text(
            'শুরুর ক্যাশই মালিকের দেওয়া মূল টাকা — অতিরিক্ত ঘরে একই টাকা আবার বসাবেন না।',
            style: TextStyle(fontSize: 11.5, color: AppColors.onSurfaceVariant, fontFamily: 'HindSiliguri'),
          ),
        ),
      ],
    );
  }

  Widget _step2() {
    final sessionId = _session?.id;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(child: Text('মাল ক্রয়', style: Theme.of(context).textTheme.titleMedium)),
            FilledButton.icon(
              onPressed: sessionId == null ? null : () => _addItemDialog(sessionId),
              icon: const Icon(Icons.add, size: 18),
              label: const Text('আইটেম'),
            ),
          ],
        ),
        const SizedBox(height: 8),
        if (sessionId == null)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 20),
            child: Text('আইটেম যোগ করতে একবার "পরবর্তী" চেপে সেশন সেভ করুন'),
          )
        else
          _purchaseList(sessionId),
      ],
    );
  }

  Widget _purchaseList(String sessionId) {
    return StreamBuilder<List<HatPurchaseItem>>(
      stream: repo.watchPurchaseItems(sessionId),
      builder: (c, snap) {
        final items = snap.data ?? const <HatPurchaseItem>[];
        return StreamBuilder<List<Expense>>(
          stream: (dbRef.select(dbRef.expenses)
                ..where((t) => t.deletedAt.isNull() & t.sessionId.equals(sessionId)))
              .watch(),
          builder: (c2, snap2) {
            final sessionExpense =
                (snap2.data ?? const <Expense>[]).fold<int>(0, (a, r) => a + r.amountPaisa);
            return _purchaseListBody(sessionId, items, sessionExpense);
          },
        );
      },
    );
  }

  Widget _purchaseListBody(String sessionId, List<HatPurchaseItem> items, int sessionExpense) {
    final totalKg = items.fold<double>(0, (a, r) => a + r.kg);
    final totalTk = items.fold<int>(0, (a, r) => a + r.totalPaisa);
    final totalPaid = items.fold<int>(0, (a, r) => a + r.paidPaisa);
    // V1.3 (docs/07): পড়তা সরাসরি প্রতি-মণ হিসাবে
    final avgMaund = SessionCalc.weightedAvgRateMaundPaisa(totalKg: totalKg, totalPaisa: totalTk);
    final avgKg = SessionCalc.weightedAvgRate(totalKg: totalKg, totalPaisa: totalTk);
    // রানিং অবশিষ্ট ক্যাশ: (শুরুর + অতিরিক্ত) − পরিশোধ − সেশন খরচ − ছোতা/স্লিপ/মেমো/ফেরত
    final startCash = (AmountInput.readPaisa(_opening) ?? _session?.openingCashPaisa ?? 0) +
        (AmountInput.readPaisa(_ownerCash) ?? _session?.ownerCashReceivedPaisa ?? 0);
    final otherOut = (AmountInput.readPaisa(_chota) ?? 0) +
        (AmountInput.readPaisa(_slip) ?? 0) +
        (AmountInput.readPaisa(_memo) ?? 0) +
        (AmountInput.readPaisa(_returned) ?? 0);
    final remaining = startCash - totalPaid - sessionExpense - otherOut;
    // টাইপ-ভিত্তিক মোট (docs/07)
    final byType = <String, (double, int)>{};
    for (final it in items) {
      final cur = byType[it.productName] ?? (0.0, 0);
      byType[it.productName] = (cur.$1 + it.kg, cur.$2 + it.totalPaisa);
    }
    return Column(
      children: [
        if (items.isEmpty)
          const EmptyState(
            icon: Icons.shopping_basket_outlined,
            title: 'এখনো কেনা হয়নি',
            subtitle: '+ আইটেম চেপে কেজি ও দর দিন',
          )
        else
          ...items.map((it) {
            final due = it.totalPaisa - it.paidPaisa;
            final rateLabel = it.ratePaisaPerMaund != null
                ? MoneyFmt.rateMaundDirect(it.ratePaisaPerMaund!)
                : MoneyFmt.rateMaund(it.ratePaisaPerKg);
            return Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                title: Text(
                  (it.sellerName ?? '').trim().isNotEmpty ? it.sellerName! : it.productName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
                subtitle: Text(
                  '${it.productName} · ${MoneyFmt.kg(it.kg)} × $rateLabel'
                  '${it.deductionKg > 0 ? ' · বাদ ${MoneyFmt.kg(it.deductionKg)} বাদে' : ''}'
                  '\nপরিশোধ ${MoneyFmt.taka(it.paidPaisa)}'
                  '${due > 0 ? ' · বাকি ${MoneyFmt.taka(due)}' : ' · পরিশোধ ✓'}',
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                ),
                // F-12/U-12: বড় অঙ্কে টাকা প্রান্তে কাটত/title ঠেলে দিত —
                // এখন সর্বোচ্চ প্রস্থে সীমাবদ্ধ + ডান-ঘেঁষা ellipsis
                trailing: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 110),
                  child: Text(
                    MoneyFmt.taka(it.totalPaisa),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.right,
                    style: const TextStyle(fontWeight: FontWeight.w700, fontFamily: 'HindSiliguri'),
                  ),
                ),
                onTap: _isClosed ? null : () => _addItemDialog(sessionId, existing: it),
                onLongPress: _isClosed
                    ? null
                    : () async {
                        final ok = await confirmDialog(context, 'আইটেম মুছবেন?', it.productName);
                        if (ok) await repo.softDelete('hat_purchase_items', it.id);
                      },
              ),
            );
          }),
        // F-04 (v1.4.1): কেনা খালি হলে সারসংক্ষেপ/পড়তা কার্ড লুকানো —
        // আগে "এখনো কেনা হয়নি"-র নিচে আগের/অসংগত সংখ্যাসহ কার্ড থেকে যেত
        if (items.isNotEmpty) ...[
        const SizedBox(height: 8),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: AppColors.primary,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('হাতে অবশিষ্ট ক্যাশ',
                  style: TextStyle(color: Colors.white, fontFamily: 'HindSiliguri', fontSize: 13)),
              Text(MoneyFmt.taka(remaining),
                  style: const TextStyle(
                      color: Colors.white, fontFamily: 'HindSiliguri', fontSize: 17, fontWeight: FontWeight.w800)),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: AppColors.primaryLight,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Wrap(
            spacing: 18,
            runSpacing: 6,
            children: [
              _sumChip('মোট ওজন',
                  '${MoneyFmt.kg(totalKg, suffix: '')} কেজি (${toBanglaDigits((totalKg / SessionCalc.kgPerMaund).toStringAsFixed(1))} মন)'),
              _sumChip('মোট টাকা', MoneyFmt.taka(totalTk)),
              _sumChip('পড়তা/মন', MoneyFmt.rateMaundDirect(avgMaund)),
              _sumChip('গড় দর/কেজি', MoneyFmt.rate(avgKg)),
              _sumChip('মোট বাকি', MoneyFmt.taka(totalTk - totalPaid)),
              _sumChip('সেশন খরচ', MoneyFmt.taka(sessionExpense)),
            ],
          ),
        ),
        ], // F-04: সারসংক্ষেপ ব্লক শেষ (শুধু কেনা থাকলেই)
        if (byType.length > 1) ...[
          const SizedBox(height: 10),
          Align(
            alignment: Alignment.centerLeft,
            child: Text('টাইপ অনুযায়ী', style: Theme.of(context).textTheme.titleSmall),
          ),
          const SizedBox(height: 4),
          ...byType.entries.map((e) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 2),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(e.key, style: const TextStyle(fontFamily: 'HindSiliguri')),
                    Text('${MoneyFmt.kg(e.value.$1)} · ${MoneyFmt.taka(e.value.$2)}',
                        style: const TextStyle(fontFamily: 'HindSiliguri', fontWeight: FontWeight.w600)),
                  ],
                ),
              )),
        ],
      ],
    );
  }

  Widget _sumChip(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(label, style: const TextStyle(fontSize: 11.5, color: AppColors.onSurfaceVariant, fontFamily: 'HindSiliguri')),
        Text(value, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, fontFamily: 'HindSiliguri', color: AppColors.primary)),
      ],
    );
  }

  Widget _step3() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('খরচ ও অন্যান্য', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 12),
        AmountInput(controller: _wage, label: 'পারিশ্রমিক (মালিকের ক্যাশ থেকে)', suffixText: '৳'),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('পারিশ্রমিক এখনই পেয়েছি'),
          subtitle: const Text('চালু করলে বন্ধ করার সময় হাট আয়ে যোগ হবে'),
          value: _wageReceivedNow,
          onChanged: (v) => setState(() => _wageReceivedNow = v),
        ),
        const SizedBox(height: 8),
        AmountInput(controller: _chota, label: 'ছোতা খরচ', suffixText: '৳'),
        const SizedBox(height: 12),
        AmountInput(controller: _slip, label: 'স্লিপ চার্জ', suffixText: '৳'),
        const SizedBox(height: 12),
        AmountInput(controller: _memo, label: 'মেমো চার্জ', suffixText: '৳'),
        const SizedBox(height: 12),
        AmountInput(controller: _returned, label: 'মালিককে ফেরত দিলাম', suffixText: '৳'),
        const SizedBox(height: 12),
        AppTextField(controller: _note, label: 'নোট (ঐচ্ছিক)'),
        // V1.3 (docs/07): সেশনের আলাদা খরচ — আগে এই ডাটা-পথটাই মৃত ছিল (F-5)
        if (_session != null) ...[
          const Divider(height: 32),
          _SessionExpenses(session: _session!),
        ],
      ],
    );
  }

  Widget _step4() {
    if (_session == null) {
      return const Text('আগের ধাপ সেভ হয়নি — "পরবর্তী" চেপে আবার এসুন');
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('টাকা গুনে বন্ধ করুন', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 12),
        AmountInput(
          controller: _counted,
          label: 'হাতে গোনা ক্যাশ',
          suffixText: '৳',
          onChangedPaisa: (_) => setState(() {}),
        ),
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton.icon(
            onPressed: () => _fillFromTally(_counted),
            icon: const Icon(Icons.calculate_outlined, size: 18),
            label: const Text('তালি দিয়ে গুনুন (নোট অনুযায়ী)'),
          ),
        ),
        const SizedBox(height: 12),
        _ExpectedPreview(session: _session!, wageCtl: _wage),
      ],
    );
  }

  Widget _navButtons() {
    final isLast = _step == 3;
    return Row(
      children: [
        if (_step > 0) ...[
          Expanded(
            child: OutlinedButton(
              onPressed: () => _goBack(),
              child: const Text('পূর্ববর্তী'),
            ),
          ),
          const SizedBox(width: 12),
        ],
        Expanded(
          child: FilledButton(
            onPressed: isLast ? _closeSession : _next,
            child: Text(isLast ? 'সেশন বন্ধ করুন' : 'পরবর্তী'),
          ),
        ),
      ],
    );
  }

  Widget _buildClosedView() {
    final s = _session!;
    final expected = s.expectedCashPaisa ?? 0;
    final counted = s.countedCashPaisa ?? 0;
    final diff = SessionCalc.difference(countedPaisa: counted, expectedPaisa: expected);
    return ListView(
      // U-4: নিচের প্যাডিং 96 — শেষ বোতাম ভাসমান ক্যালকুলেটরের আড়ালে নয়
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
      children: [
        const InfoBanner(
          icon: Icons.lock_outline,
          color: AppColors.onSurfaceVariant,
          background: AppColors.primaryLight,
          message: 'এই সেশন বন্ধ হয়ে গেছে — read-only। নিচে হিসাব দেখুন।',
        ),
        const SizedBox(height: 12),
        _purchaseList(s.id),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: StatCard(label: 'প্রত্যাশিত ছিল', paisa: expected, color: AppColors.primary, icon: Icons.receipt_long),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: StatCard(label: 'গোনা হলো', paisa: counted, color: AppColors.primary, icon: Icons.payments),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: diff == 0
                ? AppColors.primaryLight
                : (diff > 0 ? AppColors.income.withOpacity(0.08) : AppColors.expense.withOpacity(0.08)),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                diff == 0
                    ? 'হিসাব মিলে গেছে — নিখুঁত! 🎯'
                    : (diff > 0 ? 'বাড়তি: ${MoneyFmt.taka(diff)}' : 'ঘাটতি: ${MoneyFmt.taka(-diff)}'),
                style: TextStyle(
                  fontFamily: 'HindSiliguri',
                  fontWeight: FontWeight.w700,
                  fontSize: 15,
                  color: diff == 0 ? AppColors.primary : (diff > 0 ? AppColors.income : AppColors.expense),
                ),
              ),
              if (diff.abs() > SessionCalc.differenceAlertThresholdPaisa)
                const Padding(
                  padding: EdgeInsets.only(top: 4),
                  child: Text('⚠️ বড় পার্থক্য — খতিয়ে দেখুন',
                      style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 12.5, color: AppColors.expense, fontWeight: FontWeight.w600)),
                ),
              if ((s.differenceNote ?? '').isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text('কারণ: ${s.differenceNote}',
                      style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 12.5, color: AppColors.onSurfaceVariant)),
                ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        OutlinedButton.icon(
          onPressed: () async {
            await repo.update(dbRef.hatSessions, s.id,
                const HatSessionsCompanion(status: Value('draft')));
            final fresh = await repo.getSession(s.id);
            if (mounted) setState(() => _session = fresh);
          },
          icon: const Icon(Icons.lock_open, size: 18),
          label: const Text('পুনরায় খুলুন (এডিট করতে)'),
        ),
      ],
    );
  }

  /// V1.3: কেনা এন্ট্রি (যোগ + এডিট/বাকি-settle একই ডায়ালগে)
  /// docs/07 ধারা: বিক্রেতা (আগে, বাধ্যতামূলক) → বস্তা-যোগে মোট কেজি →
  /// বাদ কেজি → নেট কেজি → মণ-দর → মোট (পূর্ণ টাকায়) → পরিশোধ/বাকি।
  Future<void> _addItemDialog(String sessionId, {HatPurchaseItem? existing}) async {
    final products = await repo.getProducts();
    if (!mounted) return;
    final name = TextEditingController(text: existing?.productName ?? '');
    final gross = TextEditingController(
        text: existing == null ? '' : _kgText(existing.grossKg ?? existing.kg));
    final deduction = TextEditingController(
        text: (existing?.deductionKg ?? 0) > 0 ? _kgText(existing!.deductionKg) : '');
    final rate = TextEditingController(
        text: existing == null
            ? ''
            : paisaToEdit(existing.ratePaisaPerMaund ??
                (existing.ratePaisaPerKg * SessionCalc.kgPerMaund).round()));
    final paid = TextEditingController(
        text: existing == null ? '' : paisaToEdit(existing.paidPaisa));
    final seller = TextEditingController(text: existing?.sellerName ?? '');
    final bags = <TextEditingController>[];
    final formKey = GlobalKey<FormState>();
    var submitting = false;

    double parseKg(TextEditingController c) =>
        double.tryParse(fromBanglaDigits(c.text.trim())) ?? 0;

    await showDialog<void>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) {
          final grossV = parseKg(gross);
          final dedV = parseKg(deduction);
          final netV = grossV - dedV;
          final rateM = AmountInput.readPaisa(rate) ?? 0;
          final total = (netV > 0 && rateM > 0)
              ? SessionCalc.lineTotalMaund(kg: netV, ratePaisaPerMaund: rateM)
              : 0;
          return AlertDialog(
            title: Text(existing == null ? 'নতুন কেনা' : 'কেনা এডিট / বাকি পরিশোধ'),
            content: Form(
              key: formKey,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    AppTextField(
                      controller: seller,
                      label: 'বিক্রেতার নাম',
                      validator: (v) =>
                          (v ?? '').trim().isEmpty ? 'বিক্রেতার নাম দিন' : null,
                    ),
                    const SizedBox(height: 10),
                    ValueListenableBuilder<TextEditingValue>(
                      valueListenable: name,
                      builder: (c, v, _) {
                        final typed = v.text.trim();
                        final exists = products.any((p) => p.name.trim() == typed);
                        return DropdownMenu<String>(
                          controller: name,
                          label: const Text('পণ্যের টাইপ'),
                          enableFilter: true,
                          trailingIcon: const Icon(Icons.arrow_drop_down),
                          expandedInsets: EdgeInsets.zero,
                          dropdownMenuEntries: [
                            for (final p in products)
                              DropdownMenuEntry(value: p.name, label: p.name),
                            if (typed.isNotEmpty && !exists)
                              DropdownMenuEntry(value: typed, label: '➕ নতুন যোগ: "$typed"'),
                          ],
                          onSelected: (v) {
                            if (v == null) return;
                            Product? hit;
                            for (final p in products) {
                              if (p.name.trim() == v.trim()) {
                                hit = p;
                                break;
                              }
                            }
                            if (hit?.lastRatePaisaPerKg != null && rate.text.trim().isEmpty) {
                              final perMaund =
                                  hit!.lastRatePaisaPerKg! * SessionCalc.kgPerMaund / 100;
                              rate.text = perMaund == perMaund.roundToDouble()
                                  ? perMaund.round().toString()
                                  : perMaund.toStringAsFixed(2);
                            }
                            setD(() {});
                          },
                        );
                      },
                    ),
                    const SizedBox(height: 10),
                    // বস্তা-ভিত্তিক কেজি (docs/07): যোগফল মোট কেজিতে বসে
                    Row(
                      children: [
                        const Expanded(
                          child: Text('বস্তা অনুযায়ী কেজি (যদি লাগে)',
                              style: TextStyle(fontSize: 12.5, fontFamily: 'HindSiliguri', color: AppColors.onSurfaceVariant)),
                        ),
                        TextButton.icon(
                          onPressed: () => setD(() => bags.add(TextEditingController())),
                          icon: const Icon(Icons.add, size: 16),
                          label: const Text('বস্তা'),
                        ),
                      ],
                    ),
                    for (var i = 0; i < bags.length; i++)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 6),
                        child: Row(
                          children: [
                            Expanded(
                              child: TextFormField(
                                controller: bags[i],
                                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                inputFormatters: [androidDigits(), const BanglaDigitFormatter()], // F-08
                                decoration: InputDecoration(
                                    labelText: 'বস্তা ${toBanglaDigits('${i + 1}')} (কেজি)',
                                    border: const OutlineInputBorder(),
                                    isDense: true),
                                onChanged: (_) => setD(() {}),
                              ),
                            ),
                            IconButton(
                              icon: const Icon(Icons.close, size: 18),
                              onPressed: () => setD(() => bags.removeAt(i).dispose()),
                            ),
                          ],
                        ),
                      ),
                    if (bags.isNotEmpty)
                      Align(
                        alignment: Alignment.centerLeft,
                        child: TextButton(
                          onPressed: () {
                            final sum = bags.fold<double>(0, (a, b) => a + parseKg(b));
                            gross.text = _kgText(sum);
                            setD(() {});
                          },
                          child: Text(
                              'বস্তার যোগফল: ${MoneyFmt.kg(bags.fold<double>(0, (a, b) => a + parseKg(b)))} — মোটে বসান'),
                        ),
                      ),
                    TextFormField(
                      controller: gross,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      inputFormatters: [androidDigits(), const BanglaDigitFormatter()], // F-08
                      decoration: const InputDecoration(
                          labelText: 'মোট কেজি (সব বস্তা)', border: OutlineInputBorder()),
                      validator: (v) => parseKg(gross) <= 0 ? 'মোট কেজি > ০ দিন' : null,
                      onChanged: (_) => setD(() {}),
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: deduction,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      inputFormatters: [androidDigits(), const BanglaDigitFormatter()], // F-08
                      decoration: const InputDecoration(
                          labelText: 'বাদ (পচা/খারাপ) কেজি', hintText: 'না থাকলে ফাঁকা রাখুন', border: OutlineInputBorder()),
                      validator: (v) {
                        final d = parseKg(deduction);
                        if (d < 0) return 'বাদ ঋণাত্মক হতে পারে না';
                        if (d >= parseKg(gross) && parseKg(gross) > 0) return 'বাদ মোট কেজির কম হতে হবে';
                        return null;
                      },
                      onChanged: (_) => setD(() {}),
                    ),
                    const SizedBox(height: 10),
                    AmountInput(
                      controller: rate,
                      label: 'দর (৳/মন)',
                      validator: (v) =>
                          (AmountInput.readPaisa(rate) ?? 0) <= 0 ? 'দর > ০ দিন' : null,
                      onChangedPaisa: (_) => setD(() {}),
                    ),
                    const Padding(
                      padding: EdgeInsets.only(top: 4),
                      child: Text('১ মন = ৪০ কেজি · মোট পূর্ণ টাকায় নামিয়ে ধরা হয়',
                          style: TextStyle(fontSize: 11.5, color: AppColors.onSurfaceVariant, fontFamily: 'HindSiliguri')),
                    ),
                    if (netV > 0 && rateM > 0)
                      Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Text(
                          'নেট ${MoneyFmt.kg(netV)} · মোট = ${MoneyFmt.taka(total)}',
                          style: const TextStyle(
                              fontSize: 13.5, color: AppColors.primary, fontWeight: FontWeight.w700, fontFamily: 'HindSiliguri'),
                        ),
                      ),
                    const SizedBox(height: 10),
                    AmountInput(
                      controller: paid,
                      label: 'নগদ পরিশোধ',
                      suffixText: '৳',
                      validator: (v) {
                        final pv = AmountInput.readPaisa(paid);
                        if (pv != null && total > 0 && pv > total) {
                          return 'পরিশোধ মোটের (${MoneyFmt.taka(total)}) বেশি হতে পারে না';
                        }
                        return null;
                      },
                    ),
                    const Padding(
                      padding: EdgeInsets.only(top: 4),
                      child: Text('ফাঁকা রাখলে পুরো টাকা পরিশোধ ধরা হবে; বাকি থাকলে কম লিখুন',
                          style: TextStyle(fontSize: 11.5, color: AppColors.onSurfaceVariant, fontFamily: 'HindSiliguri')),
                    ),
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(c), child: const Text('বাতিল')),
              FilledButton(
                onPressed: submitting
                    ? null
                    : () async {
                        if (!(formKey.currentState?.validate() ?? false)) return;
                        setD(() => submitting = true);
                        final netKg = parseKg(gross) - parseKg(deduction);
                        final rateMaundP = AmountInput.readPaisa(rate)!;
                        final perKg = SessionCalc.paisaPerKgFromMaund(rateMaundP);
                        final totalP = SessionCalc.lineTotalMaund(kg: netKg, ratePaisaPerMaund: rateMaundP);
                        // F-14: paid ফাঁকা = পুরো পরিশোধ
                        var paidP = AmountInput.readPaisa(paid) ?? totalP;
                        if (paidP > totalP) paidP = totalP;
                        if (paidP < 0) paidP = 0;
                        final prodName = name.text.trim().isEmpty ? 'পেঁয়াজ' : name.text.trim();
                        if (existing == null) {
                          await repo.insert(dbRef.hatPurchaseItems, HatPurchaseItemsCompanion.insert(
                            id: '', userId: '',
                            sessionId: sessionId,
                            productName: Value(prodName),
                            kg: netKg,
                            grossKg: Value(parseKg(gross)),
                            deductionKg: Value(parseKg(deduction)),
                            ratePaisaPerKg: perKg,
                            ratePaisaPerMaund: Value(rateMaundP),
                            totalPaisa: totalP,
                            paidPaisa: Value(paidP),
                            sellerName: Value(seller.text.trim()),
                          ));
                        } else {
                          await repo.update(dbRef.hatPurchaseItems, existing.id, HatPurchaseItemsCompanion(
                            productName: Value(prodName),
                            kg: Value(netKg),
                            grossKg: Value(parseKg(gross)),
                            deductionKg: Value(parseKg(deduction)),
                            ratePaisaPerKg: Value(perKg),
                            ratePaisaPerMaund: Value(rateMaundP),
                            totalPaisa: Value(totalP),
                            paidPaisa: Value(paidP),
                            sellerName: Value(seller.text.trim()),
                          ));
                        }
                        await repo.upsertProduct(prodName, lastRatePaisaPerKg: perKg);
                        if (c.mounted) Navigator.pop(c);
                      },
                child: Text(existing == null ? 'যোগ করুন' : 'সেভ করুন'),
              ),
            ],
          );
        },
      ),
    );
    for (final b in bags) {
      b.dispose();
    }
  }

  static String _kgText(double kg) {
    final s = kg == kg.roundToDouble() ? kg.round().toString() : kg.toString();
    return toBanglaDigits(s);
  }
}

/// V1.3: সেশন-লিঙ্কড খরচের তালিকা ও যোগ/এডিট (docs/07 §সেশনের খরচ)
/// খরচগুলো expenses টেবিলে sessionId দিয়ে থাকে — closing-এর expected
/// হিসাব এই খরচগুলোই বাদ দেয়।
class _SessionExpenses extends ConsumerStatefulWidget {
  final HatSession session;
  const _SessionExpenses({required this.session});

  @override
  ConsumerState<_SessionExpenses> createState() => _SessionExpensesState();
}

class _SessionExpensesState extends ConsumerState<_SessionExpenses> {
  Future<void> _addOrEdit({Expense? existing}) async {
    final cats = await repo.watchCategoriesScoped('expense').first;
    if (!mounted) return;
    final amount = TextEditingController(
        text: existing == null ? '' : _SessionStepperScreenState.paisaToEdit(existing.amountPaisa));
    final note = TextEditingController(text: existing?.note ?? '');
    final newCat = TextEditingController();
    String? catId = existing?.categoryId ?? (cats.isNotEmpty ? cats.first.id : null);
    final formKey = GlobalKey<FormState>();
    await showDialog<void>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setD) => AlertDialog(
          title: Text(existing == null ? 'সেশনের খরচ যোগ' : 'খরচ এডিট'),
          content: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  DropdownButtonFormField<String>(
                    value: catId,
                    decoration: const InputDecoration(labelText: 'খরচের ধরন', border: OutlineInputBorder()),
                    items: [
                      for (final cat in cats)
                        DropdownMenuItem(value: cat.id, child: Text(cat.name)),
                    ],
                    onChanged: (v) => setD(() => catId = v),
                    validator: (v) => v == null ? 'ধরন বাছুন' : null,
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: AppTextField(controller: newCat, label: 'নতুন ধরন (যদি লাগে)', hint: 'যেমন: বরফ'),
                      ),
                      IconButton(
                        icon: const Icon(Icons.add_circle_outline),
                        tooltip: 'নতুন ধরন যোগ করুন',
                        onPressed: () async {
                          final n = newCat.text.trim();
                          if (n.isEmpty) return;
                          final created = await repo.addCategory(n, scope: 'expense');
                          final fresh = await repo.watchCategoriesScoped('expense').first;
                          setD(() {
                            cats
                              ..clear()
                              ..addAll(fresh);
                            catId = created.id;
                            newCat.clear();
                          });
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  AmountInput(
                    controller: amount,
                    label: 'টাকা',
                    suffixText: '৳',
                    validator: (v) =>
                        (AmountInput.readPaisa(amount) ?? 0) <= 0 ? 'টাকা > ০ দিন' : null,
                  ),
                  const SizedBox(height: 10),
                  AppTextField(controller: note, label: 'নোট (ঐচ্ছিক)'),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c), child: const Text('বাতিল')),
            FilledButton(
              onPressed: () async {
                if (!(formKey.currentState?.validate() ?? false)) return;
                final amt = AmountInput.readPaisa(amount)!;
                if (existing == null) {
                  await repo.insert(dbRef.expenses, ExpensesCompanion.insert(
                    id: '', userId: '',
                    scope: const Value('hat'),
                    hatId: Value(widget.session.hatId),
                    sessionId: Value(widget.session.id),
                    categoryId: Value(catId),
                    txnDate: widget.session.txnDate,
                    amountPaisa: amt,
                    note: Value(note.text.trim().isEmpty ? null : note.text.trim()),
                  ));
                } else {
                  await repo.update(dbRef.expenses, existing.id, ExpensesCompanion(
                    categoryId: Value(catId),
                    amountPaisa: Value(amt),
                    note: Value(note.text.trim().isEmpty ? null : note.text.trim()),
                  ));
                }
                if (c.mounted) Navigator.pop(c);
              },
              child: const Text('সেভ করুন'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text('সেশনের খরচ (মসজিদ, লেবার, নাস্তা…)',
                  style: Theme.of(context).textTheme.titleSmall),
            ),
            FilledButton.icon(
              onPressed: () => _addOrEdit(),
              icon: const Icon(Icons.add, size: 18),
              label: const Text('খরচ'),
            ),
          ],
        ),
        const SizedBox(height: 8),
        StreamBuilder<List<Category>>(
          stream: repo.watchCategoriesScoped('expense'),
          builder: (c, catSnap) {
            final catName = <String, String>{
              for (final cat in catSnap.data ?? const <Category>[]) cat.id: cat.name,
            };
            return StreamBuilder<List<Expense>>(
              stream: (dbRef.select(dbRef.expenses)
                    ..where((t) => t.deletedAt.isNull() & t.sessionId.equals(widget.session.id))
                    ..orderBy([(t) => OrderingTerm.asc(t.createdAt)]))
                  .watch(),
              builder: (c2, snap) {
                final rows = snap.data ?? const <Expense>[];
                final total = rows.fold<int>(0, (a, r) => a + r.amountPaisa);
                if (rows.isEmpty) {
                  return const Text('এখনো সেশনের খরচ লেখা হয়নি',
                      style: TextStyle(fontFamily: 'HindSiliguri', color: AppColors.onSurfaceVariant, fontSize: 12.5));
                }
                return Column(
                  children: [
                    ...rows.map((e) => ListTile(
                          dense: true,
                          contentPadding: EdgeInsets.zero,
                          title: Text(catName[e.categoryId] ?? 'খরচ',
                              style: const TextStyle(fontFamily: 'HindSiliguri')),
                          subtitle: (e.note ?? '').isEmpty ? null : Text(e.note!),
                          trailing: Text(MoneyFmt.taka(e.amountPaisa),
                              style: const TextStyle(fontFamily: 'HindSiliguri', fontWeight: FontWeight.w700)),
                          onTap: () => _addOrEdit(existing: e),
                          onLongPress: () async {
                            final ok = await confirmDialog(context, 'খরচ মুছবেন?', catName[e.categoryId] ?? 'খরচ');
                            if (ok) await repo.softDelete('expenses', e.id);
                          },
                        )),
                    const Divider(),
                    Align(
                      alignment: Alignment.centerRight,
                      child: Text('মোট সেশন খরচ: ${MoneyFmt.taka(total)}',
                          style: const TextStyle(fontFamily: 'HindSiliguri', fontWeight: FontWeight.w700, color: AppColors.primary)),
                    ),
                  ],
                );
              },
            );
          },
        ),
      ],
    );
  }
}

TextInputFormatter androidDigits() =>
    FilteringTextInputFormatter.allow(RegExp(r'[0-9০-৯.]'));

class _ExpectedPreview extends ConsumerWidget {
  final HatSession session;
  final TextEditingController wageCtl;
  const _ExpectedPreview({required this.session, required this.wageCtl});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return StreamBuilder<List<HatPurchaseItem>>(
      stream: repo.watchPurchaseItems(session.id),
      builder: (c, snap) {
        final items = snap.data ?? const <HatPurchaseItem>[];
        final purchasePaid = items.fold<int>(0, (a, r) => a + r.paidPaisa);
        return StreamBuilder<List<Expense>>(
          stream: (dbRef.select(dbRef.expenses)
                ..where((t) => t.deletedAt.isNull() & t.sessionId.equals(session.id)))
              .watch(),
          builder: (c2, snap2) {
            final sessionExpense = (snap2.data ?? const <Expense>[]).fold<int>(0, (a, r) => a + r.amountPaisa);
            final expected = SessionCalc.expectedCash(
              openingCashPaisa: session.openingCashPaisa,
              ownerCashReceivedPaisa: session.ownerCashReceivedPaisa,
              purchasePaidPaisa: purchasePaid,
              sessionExpensePaisa: sessionExpense,
              chotaPaisa: session.chotaPaisa,
              slipChargePaisa: session.slipChargePaisa,
              memoChargePaisa: session.memoChargePaisa,
              returnedToOwnerPaisa: session.returnedToOwnerPaisa,
            );
            return Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.primaryLight,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'প্রত্যাশিত ক্যাশ (অটো)',
                    style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 12.5, color: AppColors.primary),
                  ),
                  const SizedBox(height: 4),
                  MoneyText(expected, color: AppColors.primary, fontSize: 24, fontWeight: FontWeight.w700),
                  const SizedBox(height: 6),
                  Text(
                    '= শুরুর ${MoneyFmt.takaShort(session.openingCashPaisa)} + মালিকের ${MoneyFmt.takaShort(session.ownerCashReceivedPaisa)} − ক্রয় ${MoneyFmt.takaShort(purchasePaid)} − খরচ ${MoneyFmt.takaShort(sessionExpense)} − ছোতা ${MoneyFmt.takaShort(session.chotaPaisa)} − স্লিপ ${MoneyFmt.takaShort(session.slipChargePaisa)} − মেমো ${MoneyFmt.takaShort(session.memoChargePaisa)} − ফেরত ${MoneyFmt.takaShort(session.returnedToOwnerPaisa)}',
                    softWrap: true,
                    style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 11, height: 1.4, color: AppColors.onSurfaceVariant),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}
