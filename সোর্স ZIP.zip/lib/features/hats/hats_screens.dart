import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/providers/app_providers.dart';
import '../../core/theme/app_colors.dart';
import '../../core/widgets/common.dart';
import '../../data/local/app_database.dart';

const List<String> _dayLabels = ['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র', 'শনি'];

/// হাট তালিকা
class HatsScreen extends ConsumerWidget {
  const HatsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // F-02 (v1.4.1): আগে `.asData?.value ?? []` ছিল — প্রোভাইডার loading
    // থাকলেও খালি ধরে EmptyState দেখাত। এখন state অনুযায়ী আলাদা:
    // loading → spinner, error → আবার-চেষ্টা, data খালি হলেই EmptyState।
    final hatsAsync = ref.watch(_hatsListProvider);
    final sessions = ref.watch(_allSessionsProvider).asData?.value ?? const <HatSession>[];
    return Scaffold(
      appBar: AppBar(title: const Text('হাট')),
      body: hatsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => EmptyState(
          icon: Icons.error_outline,
          title: 'হাটের তালিকা লোড হয়নি',
          subtitle: 'কিছু একটা সমস্যা হয়েছে — আবার চেষ্টা করুন',
          actionLabel: 'আবার চেষ্টা',
          onAction: () => ref.invalidate(_hatsListProvider),
        ),
        data: (hats) => hats.isEmpty
            ? EmptyState(
                icon: Icons.storefront,
                title: 'এখনো কোনো হাট নেই',
                subtitle: 'আপনি যে হাটে পেঁয়াজ বিক্রি করেন সেটি যোগ করুন',
                actionLabel: 'হাট যোগ করুন',
                onAction: () => context.push('/hats/new'),
              )
            : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
              itemCount: hats.length,
              itemBuilder: (c, i) {
                final h = hats[i];
                final mine = sessions.where((s) => s.hatId == h.id).toList();
                final hatDays = _daysOf(h.hatDays);
                return Card(
                  margin: const EdgeInsets.only(bottom: 10),
                  child: ListTile(
                    onTap: () => context.push('/hats/${h.id}'),
                    leading: CircleAvatar(
                      backgroundColor: _hexToColor(h.colorHex).withAlpha(36),
                      child: Icon(Icons.storefront, color: _hexToColor(h.colorHex)),
                    ),
                    title: Text(
                      h.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    subtitle: Text(
                      '${hatDays.isEmpty ? 'দিন নেই' : hatDays.map((d) => _dayLabels[d]).join(', ')}'
                      ' • ${mine.length} সেশন',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    trailing: PopupMenuButton<String>(
                      onSelected: (v) async {
                        if (v == 'edit') context.push('/hats/${h.id}/edit');
                        if (v == 'delete') {
                          final ok = await _confirmDelete(context);
                          if (ok == true) {
                            await repo.softDelete('hats', h.id);
                          }
                        }
                      },
                      itemBuilder: (_) => const [
                        PopupMenuItem(value: 'edit', child: Text('এডিট')),
                        PopupMenuItem(value: 'delete', child: Text('ডিলিট')),
                      ],
                    ),
                  ),
                );
              },
            ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        heroTag: 'hat_add',
        onPressed: () => context.push('/hats/new'),
        backgroundColor: AppColors.primary,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('নতুন হাট', style: TextStyle(color: Colors.white)),
      ),
    );
  }

  List<int> _daysOf(String json) {
    try {
      final body = json.trim();
      final inner = body.startsWith('[') ? body.substring(1, body.length - 1) : body;
      if (inner.isEmpty) return [];
      return inner.split(',').map((e) => int.tryParse(e.trim()) ?? -1).where((e) => e >= 0).toList();
    } catch (_) {
      return [];
    }
  }

  Color _hexToColor(String hex) {
    try {
      return Color(int.parse(hex.replaceFirst('#', '0xFF')));
    } catch (_) {
      return AppColors.primary;
    }
  }

  Future<bool?> _confirmDelete(BuildContext context) {
    return showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('হাট মুছে ফেলবেন?'),
        content: const Text('মুছে ফেললে হাটটি আবর্জনায় যাবে — ৩০ দিনের মধ্যে ফিরিয়ে আনা যাবে।'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('বাতিল')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.expense),
            onPressed: () => Navigator.pop(c, true),
            child: const Text('মুছে ফেলুন'),
          ),
        ],
      ),
    );
  }
}

/// F-02 (v1.4.1) মূল কারণ: repo.watchHats()-এর Drift query স্ট্রিম তৈরির
/// মুহূর্তে `uid` (Supa.uidOrDefault) ক্যাপচার করে — গেস্ট অবস্থায় তৈরি
/// স্ট্রিম 'local' uid দিয়ে ফিল্টার করত। লগইনের পর migrate-এ সব হাটের
/// user_id নতুন uid হয়ে গেলেও পুরনো স্ট্রিম 'local' খুঁজত, ফলে হাট
/// থাকা সত্ত্বেও তালিকা খালি ("কোনো হাট নেই") দেখাত — অথচ সেশন
/// ড্রপডাউন তাজা query করায় সেখানে হাট ঠিকই আসত।
/// ফিক্স: (১) authStateProvider watch — auth বদলালেই প্রোভাইডার নতুন
/// স্ট্রিম বানায় (নতুন uid দিয়ে), (২) autoDispose বাদ — shell-এ
/// স্ক্রিন বেঁচে থাকতে স্ট্রিম অকারণে ভাঙবে না।
final _hatsListProvider = StreamProvider<List<Hat>>((ref) {
  ref.watch(authStateProvider);
  return repo.watchHats();
});
final _allSessionsProvider = StreamProvider<List<HatSession>>((ref) {
  ref.watch(authStateProvider);
  return repo.watchSessions();
});

/// হাট ফর্ম
class HatFormScreen extends ConsumerStatefulWidget {
  final String? hatId;
  const HatFormScreen({super.key, this.hatId});

  @override
  ConsumerState<HatFormScreen> createState() => _HatFormScreenState();
}

class _HatFormScreenState extends ConsumerState<HatFormScreen> {
  final _name = TextEditingController();
  final _location = TextEditingController();
  final _owner = TextEditingController();
  final Set<int> _days = {5}; // শুক্র (FIX L-2: _dayLabels[4]=বৃহঃ ছিল)
  Color _color = AppColors.primary;
  Hat? _existing;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (widget.hatId != null) {
      final h = await repo.getHat(widget.hatId!);
      if (h != null && mounted) {
        setState(() {
          _existing = h;
          _name.text = h.name;
          _location.text = h.location ?? '';
          _owner.text = h.defaultOwnerName ?? '';
          _days.addAll(_parseDays(h.hatDays));
          _color = _hex(h.colorHex);
          _loaded = true;
        });
        return;
      }
    }
    setState(() => _loaded = true);
  }

  Set<int> _parseDays(String json) {
    try {
      final inner = json.trim().startsWith('[')
          ? json.trim().substring(1, json.trim().length - 1)
          : json;
      if (inner.isEmpty) return {};
      return inner.split(',').map((e) => int.tryParse(e.trim()) ?? -1).where((e) => e >= 0).toSet();
    } catch (_) {
      return {};
    }
  }

  Color _hex(String hex) {
    try {
      return Color(int.parse(hex.replaceFirst('#', '0xFF')));
    } catch (_) {
      return AppColors.primary;
    }
  }

  Future<void> _save() async {
    if (_name.text.trim().isEmpty) {
      // F-14: floating স্ন্যাকবার (ফর্মে ছোট মার্জিন)
      showFloatingSnackBar(context, 'হাটের নাম দিন', bottomMargin: 24);
      return;
    }
    final daysJson = '[${_days.join(',')}]';
    if (_existing == null) {
      await repo.insert(dbRef.hats, HatsCompanion.insert(
        id: '', userId: '',
        name: _name.text.trim(),
        location: Value(_location.text.trim().isEmpty ? null : _location.text.trim()),
        hatDays: Value(daysJson),
        colorHex: Value('#${_color.value.toRadixString(16).padLeft(8, '0').substring(2)}'),
        defaultOwnerName: Value(_owner.text.trim().isEmpty ? null : _owner.text.trim()),
      ));
    } else {
      await repo.update(dbRef.hats, _existing!.id, HatsCompanion(
        name: Value(_name.text.trim()),
        location: Value(_location.text.trim().isEmpty ? null : _location.text.trim()),
        hatDays: Value(daysJson),
        colorHex: Value('#${_color.value.toRadixString(16).padLeft(8, '0').substring(2)}'),
        defaultOwnerName: Value(_owner.text.trim().isEmpty ? null : _owner.text.trim()),
      ));
    }
    if (mounted) {
      showFloatingSnackBar(context, 'সেভ হয়েছে ✓', bottomMargin: 24);
      context.pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) {
      return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
    }
    return Scaffold(
      appBar: AppBar(title: Text(_existing == null ? 'নতুন হাট' : 'হাট এডিট')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          AppTextField(controller: _name, label: 'হাটের নাম', hint: 'যেমন: কালুখালী হাট'),
          const SizedBox(height: 12),
          AppTextField(controller: _location, label: 'জায়গা (ঐচ্ছিক)', hint: 'থানা/জেলা'),
          const SizedBox(height: 12),
          AppTextField(controller: _owner, label: 'মালিক/মহাজনের নাম (ঐচ্ছিক)'),
          const SizedBox(height: 16),
          Text('হাটের দিন', style: Theme.of(context).textTheme.titleSmall),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (var i = 0; i < 7; i++)
                FilterChip(
                  selected: _days.contains(i),
                  label: Text(_dayLabels[i]),
                  onSelected: (v) => setState(() => v ? _days.add(i) : _days.remove(i)),
                ),
            ],
          ),
          const SizedBox(height: 16),
          Text('রং', style: Theme.of(context).textTheme.titleSmall),
          const SizedBox(height: 8),
          Wrap(
            spacing: 10,
            children: [
              for (final c in AppColors.hatPalette)
                GestureDetector(
                  onTap: () => setState(() => _color = c),
                  child: CircleAvatar(
                    radius: 18,
                    backgroundColor: c,
                    child: _color == c ? const Icon(Icons.check, color: Colors.white, size: 18) : null,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 24),
          FilledButton(onPressed: _save, child: const Text('সেভ করুন')),
        ],
      ),
    );
  }
}
