import 'package:drift/drift.dart' hide Column;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/calculations/busy_calc.dart';
import '../../core/calculations/session_calc.dart';
import '../../core/providers/app_providers.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/bangla_digits.dart';
import '../../core/utils/date_utils_bn.dart';
import '../../core/utils/money_format.dart';
import '../../core/widgets/common.dart';
import '../../data/local/app_database.dart';

/// V1.3 (ফিচার ১): হাটের বিস্তারিত — ইতিহাস, মোট কেনাবেচা, গড় পার্থক্য,
/// প্রতি সেশনের ব্যস্ততা স্কোর (ফিচার ৩) ও বড় পার্থক্য হাইলাইট (ফিচার ৬)।
class _SessionRow {
  final HatSession session;
  final int lines;
  final double totalKg;
  final int totalPaisa;
  const _SessionRow(this.session, this.lines, this.totalKg, this.totalPaisa);
}

class _HatDetail {
  final Hat hat;
  final List<_SessionRow> rows; // নতুন আগে
  final int totalPaisa;
  final double totalKg;
  final int closedCount;
  final int? avgDiffPaisa;
  final int wageTotalPaisa;
  final double avgLines;
  final double avgKg;
  const _HatDetail({
    required this.hat,
    required this.rows,
    required this.totalPaisa,
    required this.totalKg,
    required this.closedCount,
    required this.avgDiffPaisa,
    required this.wageTotalPaisa,
    required this.avgLines,
    required this.avgKg,
  });
}

// V1.3.1 FIX: আগে FutureProvider ছিল — প্রথমবারের ফল ক্যাশ হয়ে থাকত,
// তাই সেশন বন্ধ করে ফিরলেও "এখনো সেশন হয়নি" + সব হিসাব ০ দেখাত
// (হাট-তালিকায় ঠিকই ১ সেশন গোনা হতো)। এখন sessions স্ট্রিমের ওপর
// ভিত্তি করে লাইভ হিসাব হয়।
final _hatDetailProvider = StreamProvider.family<_HatDetail?, String>((ref, hatId) {
  ref.watch(authStateProvider); // V1.4.1: uid বদলালে নতুন uid দিয়ে স্ট্রিম (F-02 প্যাটার্ন)
  return repo.watchSessions(hatId: hatId).asyncMap((sessions) async {
    final hat = await repo.getHat(hatId);
    if (hat == null) return null;
    final rows = <_SessionRow>[];
    var totalPaisa = 0;
    var totalKg = 0.0;
    var closedCount = 0;
    var diffSum = 0;
    var linesSum = 0;
    var kgSumClosed = 0.0;
    for (final s in sessions) {
      final items = await repo.getPurchaseItems(s.id);
      final kg = items.fold<double>(0, (a, r) => a + r.kg);
      final tk = items.fold<int>(0, (a, r) => a + r.totalPaisa);
      rows.add(_SessionRow(s, items.length, kg, tk));
      if (s.status == 'closed') {
        closedCount++;
        totalPaisa += tk;
        totalKg += kg;
        linesSum += items.length;
        kgSumClosed += kg;
        diffSum += s.cashDifferencePaisa ?? 0;
      }
    }
    rows.sort((a, b) => b.session.txnDate.compareTo(a.session.txnDate));
    final wages = await (dbRef.select(dbRef.incomeHat)
          ..where((t) => t.deletedAt.isNull() & t.hatId.equals(hatId)))
        .get();
    return _HatDetail(
      hat: hat,
      rows: rows,
      totalPaisa: totalPaisa,
      totalKg: totalKg,
      closedCount: closedCount,
      avgDiffPaisa: closedCount == 0 ? null : (diffSum / closedCount).round(),
      wageTotalPaisa: wages.fold<int>(0, (a, r) => a + r.amountPaisa),
      avgLines: closedCount == 0 ? 0 : linesSum / closedCount,
      avgKg: closedCount == 0 ? 0 : kgSumClosed / closedCount,
    );
  });
});

class HatDetailScreen extends ConsumerWidget {
  final String hatId;
  const HatDetailScreen({super.key, required this.hatId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(_hatDetailProvider(hatId));
    return Scaffold(
      appBar: AppBar(
        title: Text(async.asData?.value?.hat.name ?? 'হাটের বিবরণ'),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit_outlined),
            tooltip: 'হাট এডিট',
            onPressed: () => context.push('/hats/$hatId/edit'),
          ),
        ],
      ),
      body: async.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('তথ্য লোড হয়নি: $e')),
        data: (d) {
          if (d == null) {
            return const EmptyState(
              icon: Icons.storefront_outlined,
              title: 'হাট পাওয়া যায়নি',
              subtitle: 'হয়তো মুছে ফেলা হয়েছে',
            );
          }
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 96),
            children: [
              IntrinsicHeight(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Expanded(
                      child: StatCard(
                        label: 'মোট কেনা (বন্ধ সেশন)',
                        paisa: d.totalPaisa,
                        color: AppColors.primary,
                        icon: Icons.shopping_basket,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: StatCard(
                        label: 'মোট পারিশ্রমিক',
                        paisa: d.wageTotalPaisa,
                        color: AppColors.income,
                        icon: Icons.badge_outlined,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              IntrinsicHeight(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Expanded(
                      child: _infoCard(
                        'মোট ওজন',
                        ['${MoneyFmt.kg(d.totalKg, suffix: '')} কেজি'],
                        Icons.scale_outlined,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _infoCard(
                        'বন্ধ সেশন',
                        [
                          '${toBanglaDigits('${d.closedCount}')}টি',
                          'গড় পার্থক্য: '
                              '${d.avgDiffPaisa == null ? '—' : MoneyFmt.taka(d.avgDiffPaisa!)}',
                        ],
                        Icons.fact_check_outlined,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              Text('সেশনের ইতিহাস', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              if (d.rows.isEmpty)
                const EmptyState(
                  icon: Icons.history,
                  title: 'এই হাটে এখনো সেশন হয়নি',
                  subtitle: 'নতুন সেশন শুরু করুন',
                )
              else
                ...d.rows.map((r) => _sessionTile(context, d, r)),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        heroTag: 'hat_detail_new_session',
        onPressed: () => context.push('/sessions/new?hatId=$hatId'),
        backgroundColor: AppColors.primary,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('নতুন সেশন', style: TextStyle(color: Colors.white)),
      ),
    );
  }

  /// v1.5.0: মান এখন আলাদা লাইনের তালিকা — প্রতিটা লাইন FittedBox-এ
  /// থাকে, তাই লম্বা মান (যেমন গড় পার্থক্য) কার্ডের বাইরে ছিটকে বা
  /// মাঝখানে ভেঙে ক্লিপ হয় না। IntrinsicHeight-row-তে দুই কার্ডের
  /// উচ্চতা সমান থাকে, লেখা মাঝখানে (vertically centered) বসে।
  Widget _infoCard(String label, List<String> values, IconData icon) {
    return Container(
      constraints: const BoxConstraints(minHeight: 96),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: AppColors.primaryLight,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 16, color: AppColors.primary),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 11.5, color: AppColors.onSurfaceVariant, fontFamily: 'HindSiliguri'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          for (var i = 0; i < values.length; i++) ...[
            if (i > 0) const SizedBox(height: 2),
            FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerLeft,
              child: Text(
                values[i],
                maxLines: 1,
                style: TextStyle(
                  fontSize: i == 0 ? 15 : 12.5,
                  fontWeight: i == 0 ? FontWeight.w700 : FontWeight.w600,
                  fontFamily: 'HindSiliguri',
                  color: AppColors.primary,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _sessionTile(BuildContext context, _HatDetail d, _SessionRow r) {
    final s = r.session;
    final closed = s.status == 'closed';
    final diff = s.cashDifferencePaisa;
    final bigDiff = closed && diff != null && diff.abs() > SessionCalc.differenceAlertThresholdPaisa;
    final score = closed
        ? BusyScore.score(lines: r.lines, totalKg: r.totalKg, avgLines: d.avgLines, avgKg: d.avgKg)
        : null;
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      color: bigDiff ? AppColors.expense.withOpacity(0.07) : null,
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        title: Text(formatDateBn(s.txnDate)),
        // v1.5.0 FIX: আগে '\\n' (escaped backslash) লেখা ছিল — Dart-এ
        // '\\n' মানে আসল newline নয়, হুবহু "\n" অক্ষর দুটো; তাই
        // স্ক্রিনে "\nDifference: ..." ছাপা হতো। এখন লাইনগুলো তালিকা
        // বানিয়ে আসল '\n' দিয়ে জোড়া হয় এবং শব্দটা বাংলায়।
        subtitle: Text(
          [
            '${closed ? 'বন্ধ' : 'খসড়া'} · ${r.lines} লাইন · ${MoneyFmt.kg(r.totalKg)} · ${MoneyFmt.taka(r.totalPaisa)}'
                '${bigDiff ? ' · ⚠️ বড় পার্থক্য' : ''}',
            if (closed && diff != null)
              'পার্থক্য: ${diff == 0 ? 'মিলে গেছে ✓' : MoneyFmt.taka(diff)}',
            if ((s.differenceNote ?? '').isNotEmpty) 'কারণ: ${s.differenceNote}',
          ].join('\n'),
          maxLines: 4,
          overflow: TextOverflow.ellipsis,
        ),
        trailing: score == null
            ? const Icon(Icons.chevron_right)
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('$score',
                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: AppColors.primary, fontFamily: 'HindSiliguri')),
                  Text(BusyScore.label(score),
                      style: const TextStyle(fontSize: 10, color: AppColors.onSurfaceVariant, fontFamily: 'HindSiliguri')),
                ],
              ),
        onTap: () => context.push('/sessions/${s.id}'),
      ),
    );
  }
}
