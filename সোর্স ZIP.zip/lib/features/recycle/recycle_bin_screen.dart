import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers/app_providers.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/date_utils_bn.dart';

/// আবর্জনা — সফট-ডিলিট করা সারি, ফেরানো/পুরোপুরি মুছা
class RecycleBinScreen extends ConsumerStatefulWidget {
  const RecycleBinScreen({super.key});

  @override
  ConsumerState<RecycleBinScreen> createState() => _RecycleBinScreenState();
}

class _BinItem {
  final String table;
  final String id;
  final String label;
  final String date;
  const _BinItem(this.table, this.id, this.label, this.date);
}

class _RecycleBinScreenState extends ConsumerState<RecycleBinScreen> {
  bool _loading = true;
  List<_BinItem> _items = [];

  static const Map<String, String> _tables = {
    'hats': 'name',
    'hat_sessions': 'txn_date',
    'hat_purchase_items': 'product_name',
    'income_hat': 'txn_date',
    'income_personal': 'title',
    'expenses': 'txn_date',
    'mother_payments': 'txn_date',
    'dps_accounts': 'institution_name',
    'dps_transactions': 'txn_date',
    'loan_persons': 'name',
    'loans': 'txn_date',
    'loan_payments': 'txn_date',
    'fuel_logs': 'txn_date',
    'bike_maintenance': 'item_name',
  };

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final db = dbRef;
    final out = <_BinItem>[];
    for (final entry in _tables.entries) {
      try {
        final rows = await db.customSelect(
          "SELECT id, IFNULL(${entry.value},'') label, deleted_at FROM ${entry.key} WHERE deleted_at IS NOT NULL LIMIT 50",
        ).get();
        for (final r in rows) {
          final da = r.read<String>('deleted_at');
          out.add(_BinItem(entry.key, r.read<String>('id'), r.read<String>('label'), da.substring(0, 10)));
        }
      } catch (_) {}
    }
    if (!mounted) return;
    setState(() {
      _items = out;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('আবর্জনা')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _items.isEmpty
              ? const Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.delete_outline, size: 52, color: AppColors.onSurfaceVariant),
                      SizedBox(height: 8),
                      Text(
                        'আবর্জনা ফাঁকা — মুছে ফেলা এন্ট্রি এখানে আসবে\n(৩০ দিন পর সম্পূর্ণ মুছে যাবে)',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 13, height: 1.5),
                      ),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _items.length,
                    itemBuilder: (c, i) {
                      final it = _items[i];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 8),
                        child: ListTile(
                          title: Text(
                            it.label.isEmpty ? it.table : it.label,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          subtitle: Text(
                            '${it.table} • মোছা হয়েছে ${formatDateShortBn(it.date)}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 11.5),
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.restore, color: AppColors.income),
                                tooltip: 'ফিরিয়ে আনুন',
                                onPressed: () async {
                                  await repo.restore(it.table, it.id);
                                  await _load();
                                },
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete_forever, color: AppColors.expense),
                                tooltip: 'সম্পূর্ণ মুছুন',
                                onPressed: () async {
                                  await repo.purge(it.table, it.id);
                                  await _load();
                                },
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
    );
  }
}
