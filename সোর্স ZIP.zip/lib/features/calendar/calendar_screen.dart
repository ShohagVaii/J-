import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers/app_providers.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/bangla_digits.dart';
import '../../core/utils/date_utils_bn.dart';
import '../../core/utils/money_format.dart';
import '../../core/widgets/common.dart';
import '../../data/local/app_database.dart';

/// ক্যালেন্ডার — মাসের গ্রিড + দিনের মার্কার + দিনের বিস্তারিত
///
/// V1.5 রিডিজাইন: আগের সংস্করণে তারিখের সংখ্যায় LIGHT-থিমের টোকেন
/// (AppColors.onSurface = #1A1F1C, প্রায় কালো) সরাসরি বসানো ছিল —
/// ডার্ক থিমের গাঢ় ব্যাকগ্রাউন্ডে মার্ক-বিহীন দিনগুলো প্রায় অদৃশ্য
/// হয়ে যেত (শুধু হালকা সেল-ব্যাকগ্রাউন্ডওয়ালা দিনগুলো দেখা যেত)।
/// এখন সব রঙ Theme-এর ColorScheme থেকে (থিম-অওয়্যার)।
///
/// হাতে-দেওয়া চিহ্ন (Task 2): তারিখ চেপে ধরলে / নির্বাচিত তারিখে
/// আবার চাপ দিলে বটম শিট — 'daymark:<yyyy-mm-dd>' → 'hat'|'money'|'both'
/// syncMeta-তে থাকে (repo.getMeta/setMeta), লোকাল-অনলি (সিঙ্ক হয় না)।
/// হাতের চিহ্ন থাকলে অটো ডটের বদলে সেটাই দেখায় (বড় 8px ডট + রিং)।
class CalendarScreen extends ConsumerStatefulWidget {
  const CalendarScreen({super.key});

  @override
  ConsumerState<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends ConsumerState<CalendarScreen> {
  DateTime _month = DateTime(DateTime.now().year, DateTime.now().month, 1);
  DateTime _selected = DateTime.now();

  /// হাতে-দেওয়া চিহ্ন: ymd → 'hat' | 'money' | 'both'
  final Map<String, String> _manualMarks = {};

  static String _markKey(String ymd) => 'daymark:$ymd';

  @override
  void initState() {
    super.initState();
    _loadGridMarks();
  }

  /// দৃশ্যমান গ্রিডের (স্পিল ডেসহ) সব দিনের হাতের চিহ্ন লোড
  Future<void> _loadGridMarks() async {
    final (start, end) = _gridRange(_month);
    var d = start;
    while (!d.isAfter(end)) {
      final ymd = ymdOf(d);
      final v = await repo.getMeta(_markKey(ymd));
      if (v != null && v.isNotEmpty) _manualMarks[ymd] = v;
      d = d.add(const Duration(days: 1));
    }
    if (mounted) setState(() {});
  }

  /// গ্রিডের প্রথম ও শেষ সেলের তারিখ (রবিবার থেকে সপ্তাহ শুরু)
  (DateTime, DateTime) _gridRange(DateTime month) {
    final first = DateTime(month.year, month.month, 1);
    final start = first.subtract(Duration(days: first.weekday % 7));
    final lastDay = DateTime(month.year, month.month + 1, 0);
    final end = lastDay.add(Duration(days: 6 - (lastDay.weekday % 7)));
    return (start, end);
  }

  void _shiftMonth(int delta) {
    setState(() {
      _month = DateTime(_month.year, _month.month + delta, 1);
      // নির্বাচন নতুন মাসের ১ তারিখে — পুরোনো মাসের দিন ধরে রাখলে
      // বিবরণ কার্ড অদৃশ্য মাসের হয়ে থাকত
      _selected = _month;
    });
    _loadGridMarks();
  }

  Future<void> _openMarkSheet(DateTime day) async {
    final ymd = ymdOf(day);
    final current = _manualMarks[ymd];
    final picked = await showModalBottomSheet<String>(
      context: context,
      useRootNavigator: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      builder: (c) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(8, 10, 8, 12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 4, 12, 2),
                child: Text(
                  'দিন চিহ্নিত করুন',
                  style: Theme.of(c).textTheme.titleMedium,
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
                child: Text(
                  '${formatDateBn(ymd)} — ${weekdayNameBn(day)}',
                  style: Theme.of(c).textTheme.bodySmall,
                ),
              ),
              _MarkOption(
                dotColor: AppColors.primary,
                label: 'হাট',
                subtitle: 'সবুজ ডট বসবে',
                selected: current == 'hat',
                onTap: () => Navigator.pop(c, 'hat'),
              ),
              _MarkOption(
                dotColor: AppColors.error,
                label: 'টাকা/খরচ',
                subtitle: 'লাল ডট বসবে',
                selected: current == 'money',
                onTap: () => Navigator.pop(c, 'money'),
              ),
              _MarkOption(
                dotColor: null,
                label: 'দুটোই',
                subtitle: 'সবুজ ও লাল — দুটো ডটই বসবে',
                selected: current == 'both',
                onTap: () => Navigator.pop(c, 'both'),
              ),
              if (current != null)
                ListTile(
                  leading: const Icon(Icons.clear, size: 22),
                  title: const Text('চিহ্ন সরান', style: TextStyle(fontFamily: 'HindSiliguri')),
                  subtitle: const Text(
                    'অটো ডট আবার দেখা যাবে',
                    style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 12),
                  ),
                  onTap: () => Navigator.pop(c, ''),
                ),
            ],
          ),
        ),
      ),
    );
    if (picked == null) return;
    if (picked.isEmpty) {
      _manualMarks.remove(ymd);
      await repo.setMeta(_markKey(ymd), '');
    } else {
      _manualMarks[ymd] = picked;
      await repo.setMeta(_markKey(ymd), picked);
    }
    if (!mounted) return;
    setState(() {});
    showFloatingSnackBar(
      context,
      picked.isEmpty ? 'চিহ্ন সরানো হয়েছে' : 'দিন চিহ্নিত হয়েছে ✓',
      bottomMargin: 24,
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final incomeHat = ref.watch(_incHatCal).asData?.value ?? const <IncomeHatData>[];
    final incomePersonal = ref.watch(_incPerCal).asData?.value ?? const <IncomePersonalData>[];
    final expenses = ref.watch(_expCal).asData?.value ?? const <Expense>[];
    final mother = ref.watch(_motherCal).asData?.value ?? const <MotherPayment>[];
    final closings = ref.watch(_closingsCal).asData?.value ?? const <DailyClosing>[];
    final sessions = ref.watch(_sessionsCal).asData?.value ?? const <HatSession>[];

    final markers = <String, _DayMarks>{};
    void add(String d, void Function(_DayMarks) f) {
      final m = markers.putIfAbsent(d, () => _DayMarks());
      f(m);
    }

    for (final e in incomeHat) {
      add(e.txnDate, (m) => m.income += e.amountPaisa);
    }
    for (final e in incomePersonal) {
      add(e.txnDate, (m) => m.income += e.amountPaisa);
    }
    for (final e in expenses) {
      add(e.txnDate, (m) => m.expense += e.amountPaisa);
    }
    for (final e in mother) {
      add(e.txnDate, (m) => m.expense += e.amountPaisa);
    }
    for (final s in sessions) {
      add(s.txnDate, (m) => m.hat = true);
    }
    final closingSet = closings.map((c) => c.txnDate).toSet();

    final (gridStart, gridEnd) = _gridRange(_month);
    final cellCount = gridEnd.difference(gridStart).inDays + 1;
    final selectedYmd = ymdOf(_selected);

    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: const Icon(Icons.chevron_left),
              onPressed: () => _shiftMonth(-1),
            ),
            Text(monthYearBn(_month.year, _month.month)),
            IconButton(
              icon: const Icon(Icons.chevron_right),
              onPressed: () => _shiftMonth(1),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 0),
            child: Row(
              children: [
                for (final d in ['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র', 'শনি'])
                  Expanded(
                    child: Center(
                      child: Text(
                        d,
                        style: TextStyle(
                          fontFamily: 'HindSiliguri',
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: cs.onSurfaceVariant,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          GridView.count(
            crossAxisCount: 7,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            childAspectRatio: 0.92,
            mainAxisSpacing: 2,
            crossAxisSpacing: 2,
            padding: const EdgeInsets.fromLTRB(12, 6, 12, 2),
            children: [
              for (var i = 0; i < cellCount; i++)
                _dayCell(gridStart.add(Duration(days: i)), markers, closingSet),
            ],
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Wrap(
              spacing: 14,
              runSpacing: 4,
              children: [
                _Legend(color: cs.primary, label: 'হাট'),
                _Legend(color: cs.primary, label: 'আয়'),
                _Legend(color: cs.error, label: 'খরচ'),
                _Legend(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? AppColors.dInfo
                      : AppColors.info,
                  label: 'দিন বন্ধ',
                ),
                _Legend(color: cs.onSurfaceVariant, label: 'হাতের চিহ্ন (বড় ডট)'),
              ],
            ),
          ),
          const SizedBox(height: 8),
          _SelectedDayCard(
            ymd: selectedYmd,
            marks: markers[selectedYmd],
            closed: closingSet.contains(selectedYmd),
            manual: _manualMarks[selectedYmd],
          ),
          Expanded(
            child: _DayDetail(
              month: _month,
              markers: markers,
              incomeHat: incomeHat,
              incomePersonal: incomePersonal,
              expenses: expenses,
              mother: mother,
            ),
          ),
        ],
      ),
    );
  }

  Widget _dayCell(DateTime date, Map<String, _DayMarks> markers, Set<String> closings) {
    final cs = Theme.of(context).colorScheme;
    final ymd = ymdOf(date);
    final m = markers[ymd];
    final manual = _manualMarks[ymd];
    final inMonth = date.month == _month.month;
    final today = ymdOf(DateTime.now()) == ymd;
    final selected = ymdOf(_selected) == ymd;
    final infoColor = Theme.of(context).brightness == Brightness.dark
        ? AppColors.dInfo
        : AppColors.info;

    // হাতের চিহ্ন থাকলে অটো হাট/আয়/খরচ ডটের বদলে সেটাই (ব্যবহারকারীর
    // স্পষ্ট সত্য); দিন-বন্ধ ডট সবসময় তথ্য হিসেবে থাকে।
    final dots = <Widget>[];
    if (manual != null) {
      if (manual == 'hat' || manual == 'both') dots.add(_dot(cs.primary, manual: true));
      if (manual == 'money' || manual == 'both') dots.add(_dot(cs.error, manual: true));
    } else {
      if (m?.hat == true) dots.add(_dot(cs.primary));
      if ((m?.income ?? 0) > 0) dots.add(_dot(cs.primary));
      if ((m?.expense ?? 0) > 0) dots.add(_dot(cs.error));
    }
    if (closings.contains(ymd)) dots.add(_dot(infoColor));

    final numeralColor = today
        ? Colors.white
        : inMonth
            ? cs.onSurface
            : cs.onSurface.withAlpha(89);

    return InkWell(
      borderRadius: BorderRadius.circular(10),
      onTap: () {
        if (selected) {
          _openMarkSheet(date);
        } else {
          setState(() => _selected = date);
        }
      },
      onLongPress: () {
        setState(() => _selected = date);
        _openMarkSheet(date);
      },
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: m != null && manual == null
              ? cs.surfaceContainerHighest.withAlpha(115)
              : null,
          border: selected && !today
              ? Border.all(color: cs.primary, width: 1.4)
              : null,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 34,
              height: 34,
              alignment: Alignment.center,
              decoration: today
                  ? BoxDecoration(color: cs.primary, shape: BoxShape.circle)
                  : null,
              child: Text(
                toBanglaDigits('${date.day}'),
                style: TextStyle(
                  fontFamily: 'HindSiliguri',
                  fontSize: 15,
                  fontWeight: today || selected ? FontWeight.w700 : FontWeight.w500,
                  color: numeralColor,
                ),
              ),
            ),
            const SizedBox(height: 3),
            SizedBox(
              height: 10,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: dots,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _dot(Color c, {bool manual = false}) => Container(
        width: manual ? 8 : 6,
        height: manual ? 8 : 6,
        margin: const EdgeInsets.symmetric(horizontal: 1.2),
        decoration: BoxDecoration(
          color: c,
          shape: BoxShape.circle,
          // হাতের চিহ্ন আলাদা চেনার জন্য হালকা রিং
          border: manual ? Border.all(color: c.withAlpha(89), width: 1.4) : null,
        ),
      );
}

/// বটম শিটের একটি চিহ্ন-অপশন
class _MarkOption extends StatelessWidget {
  final Color? dotColor;
  final String label;
  final String subtitle;
  final bool selected;
  final VoidCallback onTap;
  const _MarkOption({
    required this.dotColor,
    required this.label,
    required this.subtitle,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: dotColor != null
          ? Container(
              width: 14,
              height: 14,
              decoration: BoxDecoration(color: dotColor, shape: BoxShape.circle),
            )
          : const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                _MiniDot(color: AppColors.primary),
                SizedBox(width: 3),
                _MiniDot(color: AppColors.error),
              ],
            ),
      title: Text(label, style: const TextStyle(fontFamily: 'HindSiliguri')),
      subtitle: Text(subtitle, style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 12)),
      trailing: selected ? const Icon(Icons.check_circle, size: 20) : null,
      onTap: onTap,
    );
  }
}

class _MiniDot extends StatelessWidget {
  final Color color;
  const _MiniDot({required this.color});

  @override
  Widget build(BuildContext context) => Container(
        width: 11,
        height: 11,
        decoration: BoxDecoration(color: color, shape: BoxShape.circle),
      );
}

/// নির্বাচিত দিনের সারাংশ কার্ড — গ্রিডের ঠিক নিচে
class _SelectedDayCard extends StatelessWidget {
  final String ymd;
  final _DayMarks? marks;
  final bool closed;
  final String? manual;
  const _SelectedDayCard({
    required this.ymd,
    required this.marks,
    required this.closed,
    required this.manual,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final hasAny = marks != null || closed || manual != null;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 4),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      '${formatDateBn(ymd)} — ${weekdayNameBn(dateOf(ymd))}',
                      style: const TextStyle(
                        fontFamily: 'HindSiliguri',
                        fontSize: 13.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  if (manual != null)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: cs.surfaceContainerHighest,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        manual == 'hat'
                            ? 'হাতে চিহ্ন: হাট'
                            : manual == 'money'
                                ? 'হাতে চিহ্ন: টাকা/খরচ'
                                : 'হাতে চিহ্ন: দুটোই',
                        style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 11),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 4),
              if (!hasAny)
                Text(
                  'এই দিনে কোনো এন্ট্রি নেই',
                  style: TextStyle(
                    fontFamily: 'HindSiliguri',
                    fontSize: 12.5,
                    color: cs.onSurfaceVariant,
                  ),
                )
              else
                Wrap(
                  spacing: 12,
                  runSpacing: 2,
                  children: [
                    if (marks?.hat == true)
                      Text('হাট', style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 12.5, color: cs.primary)),
                    if ((marks?.income ?? 0) > 0)
                      Text(
                        'আয় +${MoneyFmt.compact(marks!.income)}',
                        style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 12.5, color: cs.primary),
                      ),
                    if ((marks?.expense ?? 0) > 0)
                      Text(
                        'খরচ -${MoneyFmt.compact(marks!.expense)}',
                        style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 12.5, color: cs.error),
                      ),
                    if (closed)
                      Text(
                        'দিন বন্ধ',
                        style: TextStyle(
                          fontFamily: 'HindSiliguri',
                          fontSize: 12.5,
                          color: Theme.of(context).brightness == Brightness.dark
                              ? AppColors.dInfo
                              : AppColors.info,
                        ),
                      ),
                  ],
                ),
              const SizedBox(height: 2),
              Text(
                'দিনে আবার চাপ দিলে বা চেপে ধরলে হাতে চিহ্ন দেওয়া যায়',
                style: TextStyle(
                  fontFamily: 'HindSiliguri',
                  fontSize: 11,
                  color: cs.onSurfaceVariant.withAlpha(204),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DayMarks {
  int income = 0;
  int expense = 0;
  bool hat = false;
}

class _Legend extends StatelessWidget {
  final Color color;
  final String label;
  const _Legend({required this.color, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(width: 8, height: 8, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
        const SizedBox(width: 4),
        Text(label, style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 11.5)),
      ],
    );
  }
}

/// নিচের অংশ: মাসের দিনগুলোর সারাংশ লিস্ট
class _DayDetail extends StatelessWidget {
  final DateTime month;
  final Map<String, _DayMarks> markers;
  final List<IncomeHatData> incomeHat;
  final List<IncomePersonalData> incomePersonal;
  final List<Expense> expenses;
  final List<MotherPayment> mother;
  const _DayDetail({
    required this.month,
    required this.markers,
    required this.incomeHat,
    required this.incomePersonal,
    required this.expenses,
    required this.mother,
  });

  @override
  Widget build(BuildContext context) {
    final prefix =
        '${month.year.toString().padLeft(4, '0')}-${month.month.toString().padLeft(2, '0')}';
    final days = markers.keys.where((d) => d.startsWith(prefix)).toList()
      ..sort((a, b) => b.compareTo(a));
    if (days.isEmpty) {
      return const EmptyState(
        icon: Icons.calendar_month_outlined,
        title: 'এই মাসে কোনো এন্ট্রি নেই',
        subtitle: 'হাট, আয়-খরচ করলে এখানে দেখা যাবে',
      );
    }
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      children: [
        for (final d in days)
          ListTile(
            contentPadding: EdgeInsets.zero,
            dense: true,
            leading: SizedBox(
              width: 56,
              child: Text(
                formatDateShortBn(d),
                style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 12),
              ),
            ),
            title: Wrap(
              spacing: 8,
              children: [
                if (markers[d]!.hat)
                  const Text('হাট', style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 12, color: AppColors.primary)),
                if (markers[d]!.income > 0)
                  Text(
                    '+${MoneyFmt.compact(markers[d]!.income)}',
                    style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 12, color: AppColors.income),
                  ),
                if (markers[d]!.expense > 0)
                  Text(
                    '-${MoneyFmt.compact(markers[d]!.expense)}',
                    style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 12, color: AppColors.expense),
                  ),
              ],
            ),
          ),
      ],
    );
  }
}

final _incHatCal = StreamProvider.autoDispose((ref) { ref.watch(authStateProvider); return repo.watchIncomeHat(); });
final _incPerCal = StreamProvider.autoDispose((ref) { ref.watch(authStateProvider); return repo.watchIncomePersonal(); });
final _expCal = StreamProvider.autoDispose((ref) { ref.watch(authStateProvider); return repo.watchExpenses(); });
final _motherCal = StreamProvider.autoDispose((ref) { ref.watch(authStateProvider); return repo.watchMotherPayments(); });
final _closingsCal = StreamProvider.autoDispose((ref) { ref.watch(authStateProvider); return repo.watchDailyClosings(); });
final _sessionsCal = StreamProvider.autoDispose((ref) { ref.watch(authStateProvider); return repo.watchSessions(); });
