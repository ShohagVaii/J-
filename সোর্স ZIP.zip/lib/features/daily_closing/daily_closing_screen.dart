import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers/app_providers.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/date_utils_bn.dart';
import '../../core/utils/money_format.dart';
import '../../core/widgets/common.dart';
import '../../data/local/app_database.dart';

/// হিসাব মেলানো (দৈনিক বন্ধ) —
/// হাতে থাকার কথা = শুরুর ক্যাশ + আজকের নগদ আয় − আজকের কেনা (পরিশোধ)
///                − আজকের খরচ ± অন্যান্য সমন্বয়
/// হাতে গোনা টাকার সাথে মিলিয়ে বাড়তি/ঘাটতি দেখায়, তারপর দিন বন্ধ।
///
/// v1.5.0 পরিবর্তন:
/// (ক) অটো হিসাব এখন **সব নগদ (cash) লেনদেন** থেকে — আয়: income_hat +
///     income_personal; কেনা: সেশনের paid; খরচ: expenses + আম্মু +
///     DPS জমা + বাইক তেল + বাইক মেইনটেন্যান্স। payment_method থাকলে
///     শুধু 'cash' (NULL-ও cash ধরা হয়) — বিকাশ/বাকি ক্যাশ মেলানোয় আসে না।
///     (fuel_logs / bike_maintenance-এ payment_method কলামই নেই — পুরোটাই
///     নগদ খরচ ধরা হয়।) আগে শুধু expenses আসত বলে আম্মুর ৳৫০০-এর মতো
///     বহির্গমন বাদ পড়ে সব ৳০/কম দেখাত।
/// (খ) হিসাব এখন **লাইভ স্ট্রিম** — অন্য স্ক্রিনে এন্ট্রি যোগ হলেই
///     এখানে তখনই বদলায়, অ্যাপ রিস্টার্ট লাগে না।
/// (গ) যেকোনো অটো সারিতে চাপ দিলে ওই দিনের জন্য **ম্যানুয়াল ওভাররাইড**
///     দেওয়া যায় + "অন্যান্য সমন্বয়" (±) সারি। ওভাররাইড app_settings-এ
///     থাকে (স্কিমা বদল ছাড়াই): closing_override:<তারিখ>:<income|purchase|expense>,
///     closing_adj:<তারিখ> (সাইনসহ পয়সা), closing_adj_note:<তারিখ>।
class DailyClosingScreen extends ConsumerStatefulWidget {
  const DailyClosingScreen({super.key});

  @override
  ConsumerState<DailyClosingScreen> createState() => _DailyClosingScreenState();
}

/// এক দিনের মেলানো-ডাটা: অটো মান + ঐচ্ছিক ম্যানুয়াল ওভাররাইড + সমন্বয়
class ClosingDayData {
  final int autoIncome;
  final int autoPurchase;
  final int autoExpense;
  final int? ovIncome;
  final int? ovPurchase;
  final int? ovExpense;

  /// সাইনসহ সমন্বয় (পয়সা) — হাতে থাকার কথায় যোগ হয়
  final int adjPaisa;
  final String? adjNote;

  const ClosingDayData({
    required this.autoIncome,
    required this.autoPurchase,
    required this.autoExpense,
    this.ovIncome,
    this.ovPurchase,
    this.ovExpense,
    this.adjPaisa = 0,
    this.adjNote,
  });

  int get income => ovIncome ?? autoIncome;
  int get purchase => ovPurchase ?? autoPurchase;
  int get expense => ovExpense ?? autoExpense;

  int? overrideOf(String rowKey) => switch (rowKey) {
        'income' => ovIncome,
        'purchase' => ovPurchase,
        _ => ovExpense,
      };

  int autoOf(String rowKey) => switch (rowKey) {
        'income' => autoIncome,
        'purchase' => autoPurchase,
        _ => autoExpense,
      };
}

/// লাইভ প্রোভাইডার — সংশ্লিষ্ট যেকোনো টেবিল বদলালেই নতুন মান আসে।
/// ওভাররাইড/সমন্বয় app_settings থেকে একই কোয়েরিতে পড়া হয়, তাই
/// সেগুলো বদলালেও স্ট্রিম নিজে থেকেই আপডেট হয়।
final _closingDayProvider =
    StreamProvider.autoDispose.family<ClosingDayData, String>((ref, ymd) {
  ref.watch(authStateProvider); // uid বদলালে নতুন স্ট্রিম (F-02 প্যাটার্ন)
  final db = dbRef;
  const cash = "(payment_method = 'cash' OR payment_method IS NULL)";
  return db.customSelect(
    'SELECT '
    '(SELECT IFNULL(SUM(amount_paisa),0) FROM income_hat WHERE deleted_at IS NULL AND txn_date = ? AND $cash) + '
    '(SELECT IFNULL(SUM(amount_paisa),0) FROM income_personal WHERE deleted_at IS NULL AND txn_date = ? AND $cash) AS income, '
    '(SELECT IFNULL(SUM(p.paid_paisa),0) FROM hat_purchase_items p JOIN hat_sessions s2 ON p.session_id = s2.id '
    'WHERE p.deleted_at IS NULL AND s2.deleted_at IS NULL AND s2.txn_date = ?) AS purchase, '
    '(SELECT IFNULL(SUM(amount_paisa),0) FROM expenses WHERE deleted_at IS NULL AND txn_date = ? AND $cash) + '
    '(SELECT IFNULL(SUM(amount_paisa),0) FROM mother_payments WHERE deleted_at IS NULL AND txn_date = ? AND $cash) + '
    '(SELECT IFNULL(SUM(amount_paisa),0) FROM dps_transactions WHERE deleted_at IS NULL AND txn_date = ? AND $cash) + '
    '(SELECT IFNULL(SUM(amount_paisa),0) FROM fuel_logs WHERE deleted_at IS NULL AND txn_date = ?) + '
    '(SELECT IFNULL(SUM(cost_paisa),0) FROM bike_maintenance WHERE deleted_at IS NULL AND txn_date = ?) AS expense, '
    "(SELECT value FROM app_settings WHERE key = ?) AS ov_income, "
    "(SELECT value FROM app_settings WHERE key = ?) AS ov_purchase, "
    "(SELECT value FROM app_settings WHERE key = ?) AS ov_expense, "
    "(SELECT value FROM app_settings WHERE key = ?) AS adj, "
    "(SELECT value FROM app_settings WHERE key = ?) AS adj_note",
    variables: [
      for (var i = 0; i < 8; i++) Variable.withString(ymd),
      Variable.withString('closing_override:$ymd:income'),
      Variable.withString('closing_override:$ymd:purchase'),
      Variable.withString('closing_override:$ymd:expense'),
      Variable.withString('closing_adj:$ymd'),
      Variable.withString('closing_adj_note:$ymd'),
    ],
    readsFrom: {
      db.incomeHat,
      db.incomePersonal,
      db.hatPurchaseItems,
      db.hatSessions,
      db.expenses,
      db.motherPayments,
      db.dpsTransactions,
      db.fuelLogs,
      db.bikeMaintenance,
      db.appSettings,
    },
  ).watchSingle().map((row) {
    int? parseOv(String col) {
      final v = row.readNullable<String>(col);
      if (v == null || v.isEmpty) return null;
      return int.tryParse(v);
    }

    return ClosingDayData(
      autoIncome: row.read<int>('income'),
      autoPurchase: row.read<int>('purchase'),
      autoExpense: row.read<int>('expense'),
      ovIncome: parseOv('ov_income'),
      ovPurchase: parseOv('ov_purchase'),
      ovExpense: parseOv('ov_expense'),
      adjPaisa: int.tryParse(row.readNullable<String>('adj') ?? '') ?? 0,
      adjNote: row.readNullable<String>('adj_note'),
    );
  });
});

class _DailyClosingScreenState extends ConsumerState<DailyClosingScreen> {
  final _opening = TextEditingController();
  final _counted = TextEditingController();
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _loadOpening();
  }

  Future<void> _loadOpening() async {
    final v = int.tryParse(await repo.getSetting('last_opening_cash') ?? '0') ?? 0;
    if (!mounted) return;
    setState(() {
      if (v > 0) _opening.text = (v ~/ 100).toString();
    });
  }

  @override
  void dispose() {
    _opening.dispose();
    _counted.dispose();
    super.dispose();
  }

  String _takaText(int paisa) {
    final t = paisa / 100;
    return t == t.roundToDouble()
        ? '${t.round()}'
        : t.toStringAsFixed(2);
  }

  /// অটো সারিতে চাপ → ওই দিনের জন্য ম্যানুয়াল মান বসানো/তুলে নেওয়া
  Future<void> _editOverride(
      String ymd, String rowKey, String label, ClosingDayData day) async {
    final ctrl = TextEditingController(
        text: _takaText(day.overrideOf(rowKey) ?? day.autoOf(rowKey)));
    final hasOverride = day.overrideOf(rowKey) != null;
    final action = await showDialog<String>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text('$label — ম্যানুয়াল মান'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'অটো হিসাব: ${MoneyFmt.taka(day.autoOf(rowKey))}। নিজে মান বসালে আজকের জন্য সেটাই ব্যবহার হবে — অটো এন্ট্রিগুলো বদলাবে না।',
              style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 13),
            ),
            const SizedBox(height: 12),
            AmountInput(controller: ctrl, label: 'মান (৳)', suffixText: '৳'),
          ],
        ),
        actions: [
          if (hasOverride)
            TextButton(
              onPressed: () => Navigator.pop(c, 'reset'),
              child: const Text('অটোতে ফেরত'),
            ),
          TextButton(
              onPressed: () => Navigator.pop(c), child: const Text('বাতিল')),
          FilledButton(
              onPressed: () => Navigator.pop(c, 'save'),
              child: const Text('সেভ করুন')),
        ],
      ),
    );
    if (action == null) {
      ctrl.dispose();
      return;
    }
    final key = 'closing_override:$ymd:$rowKey';
    if (action == 'reset') {
      await repo.setSetting(key, '');
    } else {
      final paisa = AmountInput.readPaisa(ctrl);
      if (paisa == null) return;
      await repo.setSetting(key, '$paisa');
    }
    ctrl.dispose();
  }

  /// অন্যান্য সমন্বয় (±) — অটো হিসাবে ধরা পড়ে না এমন ক্যাশ চলাচল
  Future<void> _editAdjustment(String ymd, ClosingDayData day) async {
    final amountCtrl =
        TextEditingController(text: day.adjPaisa == 0 ? '' : _takaText(day.adjPaisa.abs()));
    final noteCtrl = TextEditingController(text: day.adjNote ?? '');
    var isPlus = day.adjPaisa >= 0;
    final saved = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, setLocal) => AlertDialog(
          title: const Text('অন্যান্য সমন্বয়'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'অটো হিসাবে আসে না এমন ক্যাশ — যেমন কাউকে হাতে ধার দেওয়া বা ফেরত পাওয়া।',
                  style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 13),
                ),
                const SizedBox(height: 12),
                SegmentedButton<bool>(
                  segments: const [
                    ButtonSegment(value: true, label: Text('যোগ +')),
                    ButtonSegment(value: false, label: Text('বিয়োগ −')),
                  ],
                  selected: {isPlus},
                  onSelectionChanged: (v) => setLocal(() => isPlus = v.first),
                ),
                const SizedBox(height: 12),
                AmountInput(controller: amountCtrl, label: 'পরিমাণ (৳)', suffixText: '৳'),
                const SizedBox(height: 12),
                TextField(
                  controller: noteCtrl,
                  decoration: const InputDecoration(
                    labelText: 'নোট (ঐচ্ছিক)',
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            if (day.adjPaisa != 0)
              TextButton(
                onPressed: () => Navigator.pop(c, false),
                child: const Text('মুছে ফেলুন'),
              ),
            TextButton(
                onPressed: () => Navigator.pop(c, null),
                child: const Text('বাতিল')),
            FilledButton(
                onPressed: () => Navigator.pop(c, true),
                child: const Text('সেভ করুন')),
          ],
        ),
      ),
    );
    if (saved == null) {
      amountCtrl.dispose();
      noteCtrl.dispose();
      return;
    }
    if (saved == false) {
      // মুছে ফেলা
      await repo.setSetting('closing_adj:$ymd', '');
      await repo.setSetting('closing_adj_note:$ymd', '');
    } else {
      final paisa = AmountInput.readPaisa(amountCtrl) ?? 0;
      await repo.setSetting(
          'closing_adj:$ymd', '${isPlus ? paisa : -paisa}');
      await repo.setSetting('closing_adj_note:$ymd', noteCtrl.text.trim());
    }
    amountCtrl.dispose();
    noteCtrl.dispose();
  }

  Future<void> _close(String today, ClosingDayData day) async {
    if (_saving) return;
    setState(() => _saving = true);
    try {
      final opening = AmountInput.readPaisa(_opening) ?? 0;
      final expected =
          opening + day.income - day.purchase - day.expense + day.adjPaisa;
      final counted = AmountInput.readPaisa(_counted);
      await repo.setSetting('last_opening_cash', '$opening');
      final existing = await repo.getDailyClosing(today);
      final comp = DailyClosingsCompanion(
        txnDate: Value(today),
        expectedCashPaisa: Value(expected),
        countedCashPaisa: Value(counted),
        differencePaisa: Value(counted == null ? null : counted - expected),
        closedAt: Value(DateTime.now().millisecondsSinceEpoch),
      );
      if (existing == null) {
        await repo.insert(dbRef.dailyClosings, comp);
      } else {
        await repo.update(dbRef.dailyClosings, existing.id, comp);
      }
      if (!mounted) return;
      final diff = counted == null ? null : counted - expected;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(diff == null
            ? 'দিন বন্ধ হয়েছে ✓'
            : diff == 0
                ? 'হিসাব মিলেছে — নিখুঁত! ✓'
                : diff > 0
                    ? 'দিন বন্ধ — বাড়তি ${MoneyFmt.taka(diff)}'
                    : 'দিন বন্ধ — ঘাটতি ${MoneyFmt.taka(-diff)}'),
      ));
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('বন্ধ করা যায়নি — আবার চেষ্টা করুন'),
          backgroundColor: AppColors.expense,
        ));
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Widget _line(String label, int paisa,
      {bool income = false,
      bool cost = false,
      bool manual = false,
      bool editable = false}) {
    final color = income ? AppColors.income : (cost ? AppColors.expense : AppColors.onSurface);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Expanded(
            child: Row(
              children: [
                Flexible(
                  child: Text(label,
                      style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 13.5, color: color)),
                ),
                if (manual) ...[
                  const SizedBox(width: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                    decoration: BoxDecoration(
                      color: AppColors.warning.withAlpha(40),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text('ম্যানুয়াল',
                        style: TextStyle(
                            fontFamily: 'HindSiliguri',
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                            color: AppColors.warning)),
                  ),
                ],
              ],
            ),
          ),
          Text(MoneyFmt.taka(paisa),
              style: TextStyle(fontFamily: 'HindSiliguri', fontSize: 14.5, fontWeight: FontWeight.w600, color: color)),
          if (editable) ...[
            const SizedBox(width: 4),
            const Icon(Icons.edit_outlined, size: 14, color: AppColors.onSurfaceVariant),
          ],
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final today = ymdOf(DateTime.now());
    final dayAsync = ref.watch(_closingDayProvider(today));
    final day = dayAsync.asData?.value ??
        const ClosingDayData(autoIncome: 0, autoPurchase: 0, autoExpense: 0);
    final opening = AmountInput.readPaisa(_opening) ?? 0;
    final expected =
        opening + day.income - day.purchase - day.expense + day.adjPaisa;
    final counted = AmountInput.readPaisa(_counted);
    final diff = counted == null ? null : counted - expected;
    return Scaffold(
      appBar: AppBar(title: const Text('হিসাব মেলানো')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('আজ — ${formatDateBn(today)}', style: Theme.of(context).textTheme.titleSmall),
          const SizedBox(height: 10),
          AmountInput(
            controller: _opening,
            label: 'সকালে হাতে কত ক্যাশ নিয়ে বসেছিলেন',
            suffixText: '৳',
            onChangedPaisa: (_) => setState(() {}),
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppColors.primaryLight,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _line('শুরুর ক্যাশ', opening),
                InkWell(
                  onTap: () => _editOverride(today, 'income', '+ আজকের নগদ আয়', day),
                  child: _line('+ আজকের নগদ আয় (হাট + পার্সোনাল)', day.income,
                      income: true, manual: day.ovIncome != null, editable: true),
                ),
                InkWell(
                  onTap: () => _editOverride(today, 'purchase', '− আজকের কেনা (পরিশোধ)', day),
                  child: _line('− আজকের কেনা (পরিশোধ)', day.purchase,
                      cost: true, manual: day.ovPurchase != null, editable: true),
                ),
                InkWell(
                  onTap: () => _editOverride(today, 'expense', '− আজকের খরচ', day),
                  child: _line('− আজকের খরচ', day.expense,
                      cost: true, manual: day.ovExpense != null, editable: true),
                ),
                InkWell(
                  onTap: () => _editAdjustment(today, day),
                  child: _line(
                    '± অন্যান্য সমন্বয়${day.adjNote != null && day.adjNote!.isNotEmpty ? ' — ${day.adjNote}' : ''}',
                    day.adjPaisa,
                    income: day.adjPaisa > 0,
                    cost: day.adjPaisa < 0,
                    manual: day.adjPaisa != 0,
                    editable: true,
                  ),
                ),
                const Divider(height: 14),
                _line('= হাতে থাকার কথা', expected),
                if (diff != null) ...[
                  const SizedBox(height: 4),
                  Text(
                    diff == 0
                        ? 'গুনে দেখলেন ${MoneyFmt.taka(counted!)} — মিলে গেছে 🎯'
                        : diff > 0
                            ? 'বাড়তি: ${MoneyFmt.taka(diff)}'
                            : 'ঘাটতি: ${MoneyFmt.taka(-diff)}',
                    style: TextStyle(
                      fontFamily: 'HindSiliguri',
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: diff == 0
                          ? AppColors.primary
                          : (diff > 0 ? AppColors.income : AppColors.expense),
                    ),
                  ),
                ],
                const SizedBox(height: 4),
                const Text(
                  'যেকোনো সারিতে চাপ দিলে ওই দিনের জন্য ম্যানুয়াল মান বসানো যায়।',
                  style: TextStyle(
                      fontFamily: 'HindSiliguri',
                      fontSize: 11,
                      color: AppColors.onSurfaceVariant),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          AmountInput(
            controller: _counted,
            label: 'হাতে গোনা টাকা (ঐচ্ছিক)',
            suffixText: '৳',
            onChangedPaisa: (_) => setState(() {}),
          ),
          const SizedBox(height: 18),
          FilledButton(
            onPressed: _saving ? null : () => _close(today, day),
            child: Text(_saving ? 'বন্ধ হচ্ছে…' : 'আজকের দিন বন্ধ করুন'),
          ),
        ],
      ),
    );
  }
}
