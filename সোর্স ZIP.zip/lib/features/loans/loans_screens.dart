import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/calculations/loan_calc.dart';
import '../../core/providers/app_providers.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/date_utils_bn.dart';
import '../../core/utils/money_format.dart';
import '../../core/widgets/common.dart';
import '../../data/local/app_database.dart';

/// ধার — ব্যক্তি-প্রথম দৃশ্য (05_Schema §3.13)
class LoansScreen extends ConsumerWidget {
  const LoansScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final persons = ref.watch(_personsProvider).asData?.value ?? const <LoanPerson>[];
    final loans = ref.watch(_loansProvider).asData?.value ?? const <Loan>[];
    final payments = ref.watch(_paymentsProvider).asData?.value ?? const <LoanPayment>[];

    int paidOf(String loanId) =>
        payments.where((p) => p.loanId == loanId && p.deletedAt == null).fold(0, (a, p) => a + p.amountPaisa);
    int givenTotal = 0, takenTotal = 0;
    for (final l in loans) {
      final net = l.principalPaisa - paidOf(l.id);
      if (l.type == 'given') {
        givenTotal += net > 0 ? net : 0;
      } else {
        takenTotal += net > 0 ? net : 0;
      }
    }

    return Scaffold(
      appBar: AppBar(title: const Text('ধার-দেনা')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            child: Row(
              children: [
                Expanded(
                  child: StatCard(
                      label: 'আমার পাওনা (দেওয়া)',
                      paisa: givenTotal,
                      color: AppColors.loan,
                      icon: Icons.arrow_outward,
                      compact: true),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: StatCard(
                      label: 'আমি দেনা (নেওয়া)',
                      paisa: takenTotal,
                      color: AppColors.expense,
                      icon: Icons.south_west,
                      compact: true),
                ),
              ],
            ),
          ),
          Expanded(
            child: persons.isEmpty
                ? EmptyState(
                    icon: Icons.handshake_outlined,
                    title: 'কোনো ধারের ব্যক্তি নেই',
                    subtitle: 'যাকে টাকা দিয়েছেন বা যার কাছে নিয়েছেন — তাকে যোগ করুন',
                    actionLabel: 'ব্যক্তি যোগ করুন',
                    onAction: () => _personDialog(context),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
                    itemCount: persons.length,
                    itemBuilder: (c, i) {
                      final p = persons[i];
                      final myLoans = loans.where((l) => l.personId == p.id && l.deletedAt == null);
                      var net = 0;
                      for (final l in myLoans) {
                        final paid = paidOf(l.id);
                        net += l.type == 'given' ? (l.principalPaisa - paid) : -(l.principalPaisa - paid);
                      }
                      return Card(
                        margin: const EdgeInsets.only(bottom: 10),
                        child: ListTile(
                          onTap: () => context.push('/loans/person/${p.id}'),
                          leading: CircleAvatar(
                            backgroundColor: AppColors.loan.withAlpha(net > 0 ? 30 : net < 0 ? 20 : 10),
                            child: Text(
                              p.name.isEmpty ? '?' : p.name.characters.first,
                              style: TextStyle(
                                color: net > 0 ? AppColors.loan : AppColors.onSurfaceVariant,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                          title: Text(
                            p.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          subtitle: Text(
                            net > 0
                                ? 'পাবেন ${MoneyFmt.taka(net)}'
                                : net < 0
                                    ? 'দেবেন ${MoneyFmt.taka(-net)}'
                                    : 'হিসাব মিলে গেছে',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontFamily: 'HindSiliguri',
                              fontSize: 12.5,
                              color: net > 0 ? AppColors.loan : net < 0 ? AppColors.expense : AppColors.onSurfaceVariant,
                            ),
                          ),
                          trailing: const Icon(Icons.chevron_right),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        heroTag: 'loan_add',
        onPressed: () => context.push('/loans/new'),
        backgroundColor: AppColors.loan,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('ধার যোগ', style: TextStyle(color: Colors.white)),
      ),
    );
  }

  void _personDialog(BuildContext context) {
    final name = TextEditingController();
    final phone = TextEditingController();
    showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('নতুন ব্যক্তি'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AppTextField(controller: name, label: 'নাম'),
            const SizedBox(height: 10),
            AppTextField(controller: phone, label: 'ফোন (ঐচ্ছিক)'),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('বাতিল')),
          FilledButton(
            onPressed: () async {
              if (name.text.trim().isEmpty) return;
              await repo.insert(dbRef.loanPersons, LoanPersonsCompanion.insert(
        id: '', userId: '',
                name: name.text.trim(),
                phone: Value(phone.text.trim().isEmpty ? null : phone.text.trim()),
              ));
              if (c.mounted) Navigator.pop(c);
            },
            child: const Text('যোগ করুন'),
          ),
        ],
      ),
    );
  }
}

final _personsProvider = StreamProvider.autoDispose((ref) { ref.watch(authStateProvider); return repo.watchLoanPersons(); });
final _loansProvider = StreamProvider.autoDispose((ref) { ref.watch(authStateProvider); return repo.watchLoans(); });
final _paymentsProvider = StreamProvider.autoDispose((ref) { ref.watch(authStateProvider); return repo.watchLoanPayments(); });

/// ব্যক্তির লেজার
class LoanPersonScreen extends ConsumerWidget {
  final String personId;
  const LoanPersonScreen({super.key, required this.personId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final personSnap = ref.watch(_personProvider(personId));
    final loansSnap = ref.watch(_personLoansProvider(personId));
    final paymentsSnap = ref.watch(_allPaymentsProvider);
    final person = personSnap.asData?.value;
    if (person == null) {
      return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
    }
    final loans = (loansSnap.asData?.value ?? const <Loan>[]);
    final allPayments = paymentsSnap.asData?.value ?? const <LoanPayment>[];
    return Scaffold(
      appBar: AppBar(
        title: Text(person.name, maxLines: 1, overflow: TextOverflow.ellipsis),
      ),
      body: loans.isEmpty
          ? const EmptyState(
              icon: Icons.handshake_outlined,
              title: 'এই ব্যক্তির কোনো ধার নেই',
              subtitle: 'নিচের + দিয়ে ধার দেওয়া/নেওয়া যোগ করুন',
            )
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
              itemCount: loans.length,
              itemBuilder: (c, i) {
                final l = loans[i];
                final paid = allPayments
                    .where((p) => p.loanId == l.id && p.deletedAt == null)
                    .fold<int>(0, (a, p) => a + p.amountPaisa);
                final status = deriveLoanStatus(
                  paidPaisa: paid,
                  principalPaisa: l.principalPaisa,
                  dueDateYmd: l.dueDate,
                );
                return Card(
                  margin: const EdgeInsets.only(bottom: 10),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                '${l.type == 'given' ? 'দিয়েছি' : 'নিয়েছি'} ${MoneyFmt.taka(l.principalPaisa)}',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontWeight: FontWeight.w700, fontFamily: 'HindSiliguri'),
                              ),
                            ),
                            Chip(
                              label: Text(
                                loanStatusLabel(status),
                                maxLines: 1,
                                style: TextStyle(
                                  fontFamily: 'HindSiliguri',
                                  fontSize: 11,
                                  color: status == LoanStatus.settled
                                      ? AppColors.income
                                      : status == LoanStatus.overdue
                                          ? AppColors.expense
                                          : AppColors.warning,
                                ),
                              ),
                              backgroundColor: status == LoanStatus.settled
                                  ? AppColors.primaryLight
                                  : status == LoanStatus.overdue
                                      ? AppColors.errorLight
                                      : AppColors.secondaryLight,
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '${formatDateShortBn(l.txnDate)} • শোধ হয়েছে ${MoneyFmt.taka(paid)} / ${MoneyFmt.taka(l.principalPaisa)}',
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          softWrap: true,
                          style: const TextStyle(fontFamily: 'HindSiliguri', fontSize: 12.5),
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            if (status != LoanStatus.settled)
                              OutlinedButton(
                                onPressed: () => _paymentDialog(context, l, paid),
                                child: const Text('শোধ এন্ট্রি'),
                              ),
                            const SizedBox(width: 8),
                            TextButton(
                              onPressed: () async {
                                if (await confirmDialog(context, 'ধার মুছবেন?', 'আবর্জনায় যাবে')) {
                                  await repo.softDelete('loans', l.id);
                                }
                              },
                              child: const Text('মুছুন'),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton.extended(
        heroTag: 'loan_person_add',
        onPressed: () => context.push('/loans/new?personId=$personId'),
        backgroundColor: AppColors.loan,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('ধার যোগ', style: TextStyle(color: Colors.white)),
      ),
    );
  }

  void _paymentDialog(BuildContext context, Loan loan, int paidSoFar) {
    final amount = TextEditingController();
    final date = TextEditingController(text: ymdOf(DateTime.now()));
    showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('শোধের এন্ট্রি'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'বাকি আছে: ${MoneyFmt.taka(loan.principalPaisa - paidSoFar)}',
              style: const TextStyle(fontFamily: 'HindSiliguri'),
            ),
            const SizedBox(height: 10),
            AmountInput(
              controller: amount,
              label: 'শোধের পরিমাণ',
              validator: (v) {
                final p = AmountInput.readPaisa(amount) ?? 0;
                if (p <= 0) return 'টাকা দিন';
                if (!canAddLoanPayment(currentPaidPaisa: paidSoFar, principalPaisa: loan.principalPaisa, newAmountPaisa: p)) {
                  return 'মূলের বেশি হতে পারে না';
                }
                return null;
              },
            ),
            const SizedBox(height: 10),
            DateField(controller: date, label: 'তারিখ'),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('বাতিল')),
          FilledButton(
            onPressed: () async {
              final p = AmountInput.readPaisa(amount) ?? 0;
              if (p <= 0) return;
              if (!canAddLoanPayment(currentPaidPaisa: paidSoFar, principalPaisa: loan.principalPaisa, newAmountPaisa: p)) return;
              await repo.insert(dbRef.loanPayments, LoanPaymentsCompanion.insert(
        id: '', userId: '',
                loanId: loan.id,
                txnDate: date.text,
                amountPaisa: p,
              ));
              if (c.mounted) Navigator.pop(c);
            },
            child: const Text('সেভ'),
          ),
        ],
      ),
    );
  }
}

final _personProvider = StreamProvider.autoDispose.family<LoanPerson?, String>((ref, id) {
  ref.watch(authStateProvider); // V1.4.1: uid বদলালে নতুন uid দিয়ে স্ট্রিম (F-02 প্যাটার্ন)
  return (dbRef.select(dbRef.loanPersons)..where((t) => t.id.equals(id))).watchSingleOrNull();
});
final _personLoansProvider = StreamProvider.autoDispose.family<List<Loan>, String>((ref, id) async* {
  ref.watch(authStateProvider); // V1.4.1: uid বদলালে নতুন uid দিয়ে স্ট্রিম (F-02 প্যাটার্ন)
  yield await repo.getLoansOfPerson(id);
  await for (final _ in repo.watchLoans()) {
    yield await repo.getLoansOfPerson(id);
  }
});
final _allPaymentsProvider = StreamProvider.autoDispose((ref) { ref.watch(authStateProvider); return repo.watchLoanPayments(); });

/// ধার ফর্ম
class LoansFormScreen extends ConsumerStatefulWidget {
  final String? personId;
  const LoansFormScreen({super.key, this.personId});

  @override
  ConsumerState<LoansFormScreen> createState() => _LoansFormScreenState();
}

class _LoansFormScreenState extends ConsumerState<LoansFormScreen> {
  final _amount = TextEditingController();
  final _note = TextEditingController();
  final _date = TextEditingController(text: ymdOf(DateTime.now()));
  final _dueDate = TextEditingController();
  String _type = 'given';
  String? _personId;
  List<LoanPerson> _persons = [];
  bool _creating = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final persons = await repo.watchLoanPersons().first;
    if (!mounted) return;
    setState(() {
      _persons = persons;
      _personId = widget.personId ?? (persons.isNotEmpty ? persons.first.id : null);
    });
  }

  Future<void> _save() async {
    final amount = AmountInput.readPaisa(_amount) ?? 0;
    if (amount <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('টাকার পরিমাণ দিন')));
      return;
    }
    if (_personId == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ব্যক্তি বাছুন বা নতুন যোগ করুন')));
      return;
    }
    setState(() => _creating = true);
    await repo.insert(dbRef.loans, LoansCompanion.insert(
        id: '', userId: '',
      personId: _personId!,
      type: Value(_type),
      principalPaisa: amount,
      txnDate: _date.text,
      dueDate: Value(_dueDate.text.isEmpty ? null : _dueDate.text),
      note: Value(_note.text.trim().isEmpty ? null : _note.text.trim()),
    ));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('সেভ হয়েছে ✓')));
      context.pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('নতুন ধার')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'given', label: Text('ধার দিয়েছি')),
              ButtonSegment(value: 'taken', label: Text('ধার নিয়েছি')),
            ],
            selected: {_type},
            // F-05: ট্যাব/সেগমেন্ট বদলে কীবোর্ড বন্ধ রাখা
            onSelectionChanged: (v) {
              FocusManager.instance.primaryFocus?.unfocus();
              setState(() => _type = v.first);
            },
          ),
          const SizedBox(height: 12),
          if (_persons.isEmpty)
            Card(
              child: ListTile(
                title: const Text('আগে ব্যক্তি যোগ করুন'),
                subtitle: const Text('ধার তালিকা পেজ থেকে "ব্যক্তি যোগ করুন"'),
                onTap: () => context.pop(),
              ),
            )
          else
            DropdownButtonFormField<String>(
              value: _personId,
              decoration: const InputDecoration(labelText: 'ব্যক্তি', border: OutlineInputBorder()),
              items: [
                for (final p in _persons)
                  DropdownMenuItem(value: p.id, child: Text(p.name, maxLines: 1, overflow: TextOverflow.ellipsis)),
              ],
              onChanged: (v) => setState(() => _personId = v),
            ),
          const SizedBox(height: 12),
          AmountInput(controller: _amount, label: 'টাকার পরিমাণ'),
          const SizedBox(height: 12),
          DateField(controller: _date, label: 'তারিখ'),
          const SizedBox(height: 12),
          DateField(controller: _dueDate, label: 'ফেরতের তারিখ (ঐচ্ছিক)'),
          const SizedBox(height: 12),
          AppTextField(controller: _note, label: 'নোট (ঐচ্ছিক)'),
          const SizedBox(height: 20),
          FilledButton(onPressed: _creating ? null : _save, child: const Text('সেভ করুন')),
        ],
      ),
    );
  }
}
