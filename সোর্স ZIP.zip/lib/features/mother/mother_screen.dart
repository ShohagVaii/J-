import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/providers/app_providers.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/bangla_digits.dart';
import '../../core/utils/date_utils_bn.dart';
import '../../core/widgets/common.dart';
import '../../data/local/app_database.dart';

/// আম্মুকে দেওয়া টাকা — আলাদা সেকশন (v1.1 ফিক্স ১১):
/// কবে কত টাকা দেওয়া হয়েছে — পূর্ণ লিস্ট, অ্যাড/এডিট/ডিলিট।
class MotherScreen extends ConsumerStatefulWidget {
  const MotherScreen({super.key});

  @override
  ConsumerState<MotherScreen> createState() => _MotherScreenState();
}

class _MotherScreenState extends ConsumerState<MotherScreen> {
  bool _autoAddDone = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_autoAddDone || !mounted) return;
      _autoAddDone = true;
      final args = GoRouterState.of(context).uri.queryParameters;
      final paisa = int.tryParse(args['add'] ?? '');
      if (paisa != null && paisa > 0) {
        _openForm(context, ref, prefillPaisa: paisa);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final items = ref.watch(_motherProvider).asData?.value ?? const <MotherPayment>[];
    final now = DateTime.now();
    final prefix = '${now.year}-${now.month.toString().padLeft(2, '0')}';
    final monthTotal = items.where((e) => e.txnDate.startsWith(prefix)).fold<int>(0, (a, r) => a + r.amountPaisa);
    final total = items.fold<int>(0, (a, r) => a + r.amountPaisa);

    // মাস-ভিত্তিক গ্রুপ
    final grouped = <String, List<MotherPayment>>{};
    for (final it in items) {
      grouped.putIfAbsent(it.txnDate.substring(0, 7), () => []).add(it);
    }
    final months = grouped.keys.toList()..sort((a, b) => b.compareTo(a));

    return Scaffold(
      appBar: AppBar(title: const Text('আম্মুকে দেওয়া')),
      body: items.isEmpty
          ? EmptyState(
              icon: Icons.favorite,
              title: 'এখনো কিছু দেওয়া হয়নি',
              subtitle: 'আম্মুকে টাকা দিলে এখানে এন্ট্রি করুন — কবে কত দিলেন সব থাকবে',
              actionLabel: '+ দেওয়া যোগ করুন',
              onAction: () => _openForm(context, ref),
            )
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
              children: [
                Row(
                  children: [
                    Expanded(
                      child: StatCard(
                          label: 'এই মাসে দেওয়া',
                          paisa: monthTotal,
                          color: AppColors.mother,
                          icon: Icons.calendar_month),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: StatCard(
                          label: 'সব মিলিয়ে',
                          paisa: total,
                          color: AppColors.mother,
                          icon: Icons.favorite),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                for (final m in months) ...[
                  SectionHeader(title: monthYearBn(int.parse(m.split('-')[0]), int.parse(m.split('-')[1]))),
                  for (final it in grouped[m]!)
                    EntryTile(
                      icon: Icons.favorite,
                      iconColor: AppColors.mother,
                      title: relativeDayBn(it.txnDate),
                      subtitle: it.note == null || it.note!.isEmpty ? null : it.note,
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          AmountTrailing(it.amountPaisa, color: AppColors.mother),
                          PopupMenuButton<String>(
                            onSelected: (v) async {
                              if (v == 'edit') _openForm(context, ref, edit: it);
                              if (v == 'del') {
                                if (await confirmDialog(context, 'মুছে ফেলবেন?', 'এই এন্ট্রি আবর্জনায় যাবে')) {
                                  await repo.softDelete('mother_payments', it.id);
                                }
                              }
                            },
                            itemBuilder: (_) => const [
                              PopupMenuItem(value: 'edit', child: Text('এডিট')),
                              PopupMenuItem(value: 'del', child: Text('ডিলিট')),
                            ],
                          ),
                        ],
                      ),
                    ),
                ],
              ],
            ),
      floatingActionButton: FloatingActionButton.extended(
        heroTag: 'mother_add',
        onPressed: () => _openForm(context, ref),
        backgroundColor: AppColors.mother,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('দেওয়া যোগ', style: TextStyle(color: Colors.white)),
      ),
    );
  }

  void _openForm(BuildContext context, WidgetRef ref, {MotherPayment? edit, int? prefillPaisa}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => _MotherForm(edit: edit, prefillPaisa: prefillPaisa),
    );
  }
}

final _motherProvider = StreamProvider.autoDispose((ref) { ref.watch(authStateProvider); return repo.watchMotherPayments(); });

class _MotherForm extends ConsumerStatefulWidget {
  final MotherPayment? edit;
  final int? prefillPaisa;
  const _MotherForm({this.edit, this.prefillPaisa});

  @override
  ConsumerState<_MotherForm> createState() => _MotherFormState();
}

class _MotherFormState extends ConsumerState<_MotherForm> {
  final _amount = TextEditingController();
  final _note = TextEditingController();
  final _date = TextEditingController(text: ymdOf(DateTime.now()));
  String? _walletId;
  List<Wallet> _wallets = [];
  int _quick = 500;

  @override
  void initState() {
    super.initState();
    if (widget.edit != null) {
      _amount.text = toBanglaDigits((widget.edit!.amountPaisa / 100).toString());
      _date.text = widget.edit!.txnDate;
      _note.text = widget.edit!.note ?? '';
      _walletId = widget.edit!.walletId;
    } else if (widget.prefillPaisa != null) {
      _amount.text = toBanglaDigits((widget.prefillPaisa! / 100).toString());
    } else {
      _amount.text = toBanglaDigits('500');
    }
    _init();
  }

  Future<void> _init() async {
    final wallets = await repo.getWallets();
    if (!mounted) return;
    setState(() {
      _wallets = wallets;
      _walletId ??= wallets.isNotEmpty ? wallets.first.id : null;
    });
  }

  Future<void> _save() async {
    final amount = AmountInput.readPaisa(_amount) ?? 0;
    if (amount <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('টাকার পরিমাণ দিন')));
      return;
    }
    if (widget.edit != null) {
      await repo.update(dbRef.motherPayments, widget.edit!.id, MotherPaymentsCompanion(
        txnDate: Value(_date.text),
        amountPaisa: Value(amount),
        walletId: Value(_walletId),
        note: Value(_note.text.trim().isEmpty ? null : _note.text.trim()),
      ));
    } else {
      await repo.insert(dbRef.motherPayments, MotherPaymentsCompanion.insert(
        id: '', userId: '',
        txnDate: _date.text,
        amountPaisa: amount,
        walletId: Value(_walletId),
        note: Value(_note.text.trim().isEmpty ? null : _note.text.trim()),
      ));
    }
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(widget.edit != null ? 'এন্ট্রি এডিট' : 'আম্মুকে দেওয়া যোগ করুন',
                  style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 12),
              // F-16 (v1.4.1): আগে Wrap-এ ৩টা চিপ এক সারিতে, ৪র্থটা একা
              // নিচের সারিতে ঝুলত — এখন ৪টাই সমান ভাগে এক সারিতে
              Row(
                children: [
                  for (final v in [500, 1000, 2000, 5000])
                    Expanded(
                      child: Center(
                        child: ChoiceChip(
                          label: Text('৳${toBanglaDigits('$v')}'),
                          selected: _quick == v,
                          onSelected: (_) => setState(() {
                            _quick = v;
                            _amount.text = toBanglaDigits('$v');
                          }),
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 12),
              AmountInput(controller: _amount, label: 'টাকার পরিমাণ'),
              const SizedBox(height: 12),
              DateField(controller: _date, label: 'তারিখ'),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _walletId,
                decoration: const InputDecoration(labelText: 'কোন ওয়ালেট থেকে', border: OutlineInputBorder()),
                items: [
                  for (final w in _wallets)
                    DropdownMenuItem(value: w.id, child: Text(w.name, maxLines: 1, overflow: TextOverflow.ellipsis)),
                ],
                onChanged: (v) => setState(() => _walletId = v),
              ),
              const SizedBox(height: 12),
              AppTextField(controller: _note, label: 'নোট (ঐচ্ছিক)'),
              const SizedBox(height: 16),
              FilledButton(onPressed: _save, child: const Text('সেভ করুন')),
            ],
          ),
        ),
      ),
    );
  }
}
