import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/notifications/notification_service.dart';
import 'core/notifications/reminder_scheduler.dart';
import 'core/security/lock_controller.dart';
import 'core/providers/app_providers.dart';
import 'core/router.dart';
import 'core/theme/app_colors.dart';
import 'core/theme/app_theme.dart';
import 'core/widgets/floating_calculator.dart';
import 'data/remote/supabase_client.dart';
import 'features/settings/update_dialog.dart';

class HatHisabApp extends ConsumerStatefulWidget {
  const HatHisabApp({super.key});

  @override
  ConsumerState<HatHisabApp> createState() => _HatHisabAppState();
}

class _HatHisabAppState extends ConsumerState<HatHisabApp> with WidgetsBindingObserver {
  DateTime? _pausedAt;

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // FIX H-1: background-এ ২ মিনিটের বেশি থাকলে পুনরায় লক (02_AppFlow §3.3)
    if (state == AppLifecycleState.paused) {
      _pausedAt = DateTime.now();
    } else if (state == AppLifecycleState.resumed && _pausedAt != null) {
      if (DateTime.now().difference(_pausedAt!) > const Duration(minutes: 2)) {
        LockController.instance.lock();
      }
      _pausedAt = null;
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    // লগইন স্টেট পরিবর্তন → প্রোভাইডার রিফ্রেশ + সিঙ্ক চালু
    // (auth লিসেনার Supa.init()-এর ভেতরে জুড়ে দেওয়া হয় — লঞ্চ ব্লক না করতে)
    SupaAuthWatcher.instance.onChange = () {
      ref.read(authStateProvider).refresh();
      syncEngine.start();
      syncEngine.runSync();
    };
    // অ্যাপ শুরুর কিছুক্ষণ পরে নীরব আপডেট চেক (ব্যাকগ্রাউন্ড ডাউনলোড সহ)
    Future.delayed(const Duration(seconds: 4), () {
      updateService.backgroundCheck();
    });
    updateService.onReadyToInstall = (readyState) {
      final ctx = rootNavigatorKey.currentContext;
      if (ctx != null && ctx.mounted) {
        showUpdateReadyDialog(ctx, updateService);
      }
    };
    NotificationService.instance.onTapRoute = (route) {
      ref.read(goRouterProvider).go(route);
    };
    // V1.3: DPS চেইন + বাইক সার্ভিস রিমাইন্ডার (দেরিতে, নীরবে)
    Future.delayed(const Duration(seconds: 3), () {
      ReminderScheduler.scheduleAll();
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'FinTrack হাট হিসাব',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: ThemeMode.system,
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [Locale('bn'), Locale('en')],
      locale: const Locale('bn'),
      routerConfig: ref.watch(goRouterProvider),
      builder: (context, child) {
        // সব স্ক্রিনের উপরে ভাসমান ক্যালকুলেটর বাটন
        return FloatingCalculatorButton(child: child ?? const SizedBox.shrink());
      },
    );
  }
}

Color statusColorFor(bool ok) => ok ? AppColors.income : AppColors.expense;
