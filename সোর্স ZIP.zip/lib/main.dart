import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:shared_preferences/shared_preferences.dart';

import 'app.dart';
import 'core/app_flags.dart' as flags;
import 'core/notifications/notification_service.dart';
import 'core/security/lock_controller.dart';
import 'core/providers/app_providers.dart';
import 'data/local/app_database.dart';
import 'data/remote/supabase_client.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(statusBarColor: Colors.transparent),
  );

  try {
    final prefs = await SharedPreferences.getInstance();
    flags.appOnboarded = prefs.getBool('onboarded') ?? false;
  } catch (_) {
    flags.appOnboarded = true; // পড়তে না পারলে onboarding-এ আটকাব না
  }

  // লাইটওয়েট সিঙ্ক্রোনাস বুট (ডিস্ক ছোঁয় না — ড্রিফট লেজি) → runApp সাথে সাথে
  final db = AppDatabase();
  bootstrapServices(db);

  runZonedGuarded(() {
    runApp(const ProviderScope(child: HatHisabApp()));
  }, (e, st) {
    debugPrint('আনকট এরর: $e\n$st');
  });

  // UI চালু হওয়ার পরে ভারী সব ইনিশিয়ালাইজেশন — কোনোটাই লঞ্চ আটকাবে না
  unawaited(_postLaunchInit());
}

Future<void> _postLaunchInit() async {
  // প্রতিটা ধাপ আলাদা ট্রাই-ক্যাচ + টাইমআউট — একটা আটকালেও বাকি সব চলবে
  try {
    await Supa.init().timeout(const Duration(seconds: 15));
  } catch (e) {
    debugPrint('Supa init skipped: $e');
  }
  try {
    // V1.4.1 (G-05): আগের লগআউট-করা uid — ওই ডাটা লগআউট-অবস্থায়ও দেখাতে
    await Supa.loadLastUid().timeout(const Duration(seconds: 5));
  } catch (e) {
    debugPrint('LastUid load skipped: $e');
  }
  try {
    await LockController.instance.load().timeout(const Duration(seconds: 5));
  } catch (e) {
    debugPrint('Lock load skipped: $e');
  }
  try {
    await NotificationService.instance.init().timeout(const Duration(seconds: 8));
  } catch (e) {
    debugPrint('Notification init skipped: $e');
  }
  try {
    await repo.seedIfNeeded().timeout(const Duration(seconds: 10));
  } catch (e) {
    debugPrint('Seed skipped: $e');
  }
  try {
    // V1.5.0 (D): পুরনো seed-ডুপ্লিকেট (wallet/category) একীভূত করা —
    // idempotent, ডুপ্লিকেট না থাকলে কিছুই করে না। seed-এর পর, sync
    // শুরুর আগে চলা চাই যাতে tombstone গুলো প্রথম সিঙ্কেই ওঠে।
    await repo.mergeDuplicateSeeds().timeout(const Duration(seconds: 10));
  } catch (e) {
    debugPrint('Seed merge skipped: $e');
  }
  try {
    await updateService.loadCurrentVersion();
  } catch (e) {
    debugPrint('Version load skipped: $e');
  }
  try {
    syncEngine.start();
  } catch (e) {
    debugPrint('Sync start skipped: $e');
  }
  try {
    // V1.5.0 (Agent E) — [COMPOSITION-ROOT EDIT: এই ফাইলে Agent E-র
    // একমাত্র পরিবর্তন, ঠিক syncEngine.start()-এর পরের এই ব্লকটা]
    // onLocalChange চেইন: SyncEngine.start() ভেতরে repo.onLocalChange-এ
    // সেট হওয়া সিঙ্ক-ট্রিগার callback আগের মতোই চলবে; তার সঙ্গে
    // DataRevision-ও bump হবে, যাতে FutureProvider-গুলো প্রতিটা লোকাল
    // write-এর পর ইনস্ট্যান্ট রি-কম্পিউট করে। start() আবার ডাকলেও
    // (auth পরিবর্তনে) onLocalChange পুনরায় সেট হয় না, তাই এই
    // চেইনটা টিকে থাকে।
    final prevOnLocalChange = repo.onLocalChange;
    repo.onLocalChange = () {
      prevOnLocalChange?.call();
      DataRevision.instance.bump();
    };
  } catch (e) {
    debugPrint('DataRevision chain skipped: $e');
  }
}
