// V1.4.1 regression — F-01 (সিঙ্ক pull-এর NoSuchMethodError)।
// v1.4.0-তে applyServerRow-র pending-চেকে dynamic `&` (extension operator)
// থাকায় লোকালে আগে থেকে row থাকলেই প্রতিটা টেবিলের pull ভাঙত; খালি DB-র
// টেস্টে ওই শাখায় ঢোকা হতো না বলে ধরা পড়েনি। এই টেস্টগুলো আগে থেকে
// লোকাল row বসিয়ে তারপর applyServerRow চালায়।
import 'package:drift/drift.dart' hide isNull, isNotNull, Column;
import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:hat_hisab/data/local/app_database.dart';
import 'package:hat_hisab/data/local/dao/app_repository.dart';

void main() {
  late AppDatabase db;
  late AppRepository repo;

  setUp(() {
    db = AppDatabase.withExecutor(NativeDatabase.memory());
    repo = AppRepository(db);
  });
  tearDown(() async => db.close());

  Map<String, dynamic> serverWallet(String id, String name) => {
        'id': id,
        'user_id': 'local',
        'name': name,
        'type': 'cash',
        'opening_balance_paisa': 0,
        'is_archived': false,
        'created_at': '2026-11-01T00:00:00.000Z',
        'updated_at': '2026-11-01T01:00:00.000Z',
        'deleted_at': null,
        'version': 1,
      };

  test(
      'F-01 (a): লোকালে pending row থাকলে applyServerRow throw করে না — conflict জমে',
      () async {
    final id = await repo.insert(
      db.wallets,
      WalletsCompanion.insert(id: '', userId: '', name: 'লোকাল নাম'),
    );
    // repo.insert sync_status='pending' বসায় — pending-চেকের শাখাই F-01-এর উৎস
    await repo.applyServerRow('wallets', serverWallet(id, 'সার্ভারের নাম'));

    final conflict = await repo.getMeta('conflict:wallets:$id');
    expect(conflict, isNotNull, reason: 'pending লোকাল row থাকলে conflict রেকর্ড হওয়ার কথা');
    final local = await (db.select(db.wallets)..where((t) => t.id.equals(id)))
        .getSingle();
    expect(local.name, 'লোকাল নাম', reason: 'pending লোকাল row বদলানো যাবে না');
  });

  test('F-01 (b): লোকালে synced row থাকলে applyServerRow replace করে — throw নয়',
      () async {
    final id = await repo.insert(
      db.wallets,
      WalletsCompanion.insert(id: '', userId: '', name: 'আগের নাম'),
    );
    await (db.update(db.wallets)..where((t) => t.id.equals(id)))
        .write(WalletsCompanion(syncStatus: const Value('synced')));

    await repo.applyServerRow('wallets', serverWallet(id, 'সার্ভারের নতুন নাম'));

    final local = await (db.select(db.wallets)..where((t) => t.id.equals(id)))
        .getSingle();
    expect(local.name, 'সার্ভারের নতুন নাম');
    expect(local.syncStatus, 'synced');
  });

  test('countLocalGuestData: গেস্ট এন্ট্রি সংখ্যা ও টাকার সারাংশ', () async {
    await repo.insert(
      db.incomePersonal,
      IncomePersonalCompanion.insert(
        id: '',
        userId: '',
        title: 'বেতন',
        txnDate: '2026-11-01',
        amountPaisa: 300000,
      ),
    );
    await repo.insert(
      db.expenses,
      ExpensesCompanion.insert(
        id: '',
        userId: '',
        txnDate: '2026-11-01',
        amountPaisa: 45000,
      ),
    );

    final s = await repo.countLocalGuestData();
    expect(s.incomePaisa, 300000);
    expect(s.expensePaisa, 45000);
    expect(s.loanPaisa, 0);
    expect(s.perTable['income_personal'], 1);
    expect(s.perTable['expenses'], 1);
    expect(s.totalCount, 2);
  });
}
