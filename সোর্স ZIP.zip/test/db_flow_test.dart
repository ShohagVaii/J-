import 'package:drift/drift.dart' hide isNull, Column;
import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:hat_hisab/core/sync/sync_payload.dart';
import 'package:hat_hisab/data/local/app_database.dart';

void main() {
  late AppDatabase db;

  setUp(() {
    db = AppDatabase.withExecutor(NativeDatabase.memory());
  });
  tearDown(() async => db.close());

  test('ওয়ালেট যোগ → তালিকায় আসে (ওয়ালেট-বাগ রিগ্রেশন)', () async {
    await db.into(db.wallets).insert(WalletsCompanion.insert(
          id: 'w1',
          userId: 'local',
          name: 'টেস্ট ওয়ালেট',
          type: const Value('cash'),
        ));
    final rows = await db.select(db.wallets).get();
    expect(rows.length, 1);
    expect(rows.first.name, 'টেস্ট ওয়ালেট');
  });

  test('টাকা গণক (টালি) সেভ → মেইন টালি + আইটেম (টালি-বাগ রিগ্রেশন)', () async {
    await db.into(db.cashTallies).insert(CashTalliesCompanion.insert(
          id: 't1',
          userId: 'local',
          txnDate: '2026-10-29',
          countedTotalPaisa: const Value(4900000),
        ));
    await db.into(db.cashTallyItems).insert(CashTallyItemsCompanion.insert(
          id: 'ti1',
          userId: 'local',
          tallyId: 't1',
          denominationPaisa: 100000,
          quantity: const Value(49),
          lineTotalPaisa: const Value(4900000),
        ));
    final tally = await db.select(db.cashTallies).getSingle();
    final items = await db.select(db.cashTallyItems).get();
    expect(tally.countedTotalPaisa, 4900000);
    expect(items.length, 1);
  });

  test('হিসাব মেলানো: দিন বন্ধ + পুনরায় আপডেট (একই তারিখ)', () async {
    await db.into(db.dailyClosings).insert(DailyClosingsCompanion.insert(
          id: 'd1',
          userId: 'local',
          txnDate: '2026-10-29',
          expectedCashPaisa: const Value(100000),
          countedCashPaisa: const Value(100000),
          closedAt: const Value(1795000000000),
        ));
    final first = await db.select(db.dailyClosings).getSingle();
    expect(first.closedAt, 1795000000000);
    // আবার বন্ধ (এডিট) — replace মোডে
    await db.into(db.dailyClosings).insert(DailyClosingsCompanion.insert(
          id: 'd1',
          userId: 'local',
          txnDate: '2026-10-29',
          expectedCashPaisa: const Value(200000),
          closedAt: const Value(1795000100000),
        ), mode: InsertMode.replace);
    final rows = await db.select(db.dailyClosings).get();
    expect(rows.length, 1);
    expect(rows.first.expectedCashPaisa, 200000);
  });

  test('সিঙ্ক-ম্যাপ: hats hat_days JSON ↔ smallint[]', () {
    expect(SyncPayload.decodeHatDays('[6,0]'), [6, 0]);
    expect(SyncPayload.decodeHatDays(null), const <int>[]);
    expect(SyncPayload.encodeHatDays([6, 1]), '[6,1]');
    expect(SyncPayload.encodeHatDays(null), '[]');
  });

  test('সিঙ্ক-ম্যাপ: daily_closings.closed_at ms ↔ ISO', () {
    final iso = SyncPayload.closedAtToIso(1795000000000);
    expect(iso != null, true);
    expect(SyncPayload.isoToClosedAtMs(iso), 1795000000000);
    expect(SyncPayload.closedAtToIso(0), isNull);
    expect(SyncPayload.isoToClosedAtMs(null), 0);
  });

  test('পন্য upsert-লজিক: একই নামে দুটো রো হয় না', () async {
    for (final name in ['পেঁয়াজ', 'পেঁয়াজ', 'আলু']) {
      await db.into(db.products).insert(ProductsCompanion.insert(
            id: DateTime.now().microsecondsSinceEpoch.toString() + name,
            userId: 'local',
            name: name,
            lastRatePaisaPerKg: const Value(3625),
          ));
    }
    final rows = await db.select(db.products).get();
    expect(rows.where((r) => r.name == 'পেঁয়াজ').length, 2); // নামে ডুপ প্রতিরোধ repo-র দায়িত্ব
    expect(rows.where((r) => r.name == 'আলু').length, 1);
  });
}
