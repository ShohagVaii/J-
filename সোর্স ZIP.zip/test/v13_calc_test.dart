import 'package:flutter_test/flutter_test.dart';
import 'package:hat_hisab/core/calculations/busy_calc.dart';
import 'package:hat_hisab/core/calculations/mileage_calc.dart';
import 'package:hat_hisab/core/calculations/session_calc.dart';
import 'package:hat_hisab/core/calculations/streak_calc.dart';

/// V1.3 রিগ্রেশন টেস্ট — docs/07 (ব্যবহারকারীর নিজের হিসাবের নিয়ম)
void main() {
  group('লাইন-মোট পূর্ণ টাকায় (docs/07)', () {
    test('ব্যবহারকারীর উদাহরণ: ৯৪ কেজি × ৳১৪৫০/মন = ৳৩,৪০৭', () {
      // 1450÷40×94 = 3407.50 → পূর্ণ টাকায় নামিয়ে 3407
      expect(SessionCalc.lineTotalMaund(kg: 94, ratePaisaPerMaund: 145000), 340700);
    });
    test('ভগ্নাংশ সবসময় নিচে নামে', () {
      // ১০ কেজি × ৳১০০/মন = ২৫.০০ → ২৫.০০ (ভগ্নাংশ নেই)
      expect(SessionCalc.lineTotalMaund(kg: 10, ratePaisaPerMaund: 10000), 2500);
      // ৩ কেজি × ৳১০০/মন = ৭.৫০ → ৭
      expect(SessionCalc.lineTotalMaund(kg: 3, ratePaisaPerMaund: 10000), 700);
      // ১ কেজি × ৳৩৯/মন = ০.৯৭৫ → ০
      expect(SessionCalc.lineTotalMaund(kg: 1, ratePaisaPerMaund: 3900), 0);
    });
    test('পড়তা সরাসরি প্রতি-মণ: মোট ÷ কেজি × ৪০', () {
      // মোট ৳৩,৪০৭ (340700 পয়সা), ৯৪ কেজি → 340700×40÷94 = 144978.7 ≈ 144979
      expect(
        SessionCalc.weightedAvgRateMaundPaisa(totalKg: 94, totalPaisa: 340700),
        144979,
      );
      expect(SessionCalc.weightedAvgRateMaundPaisa(totalKg: 0, totalPaisa: 100), 0);
    });
  });

  group('আম্মু streak', () {
    test('পরপর হাটে দিলে streak বাড়ে, ফাঁক পড়লে থামে', () {
      expect(
        motherStreak(
          closedSessionDatesYmd: ['2026-10-28', '2026-10-25', '2026-10-22', '2026-10-19'],
          motherPaymentDatesYmd: {'2026-10-28', '2026-10-25', '2026-10-19'},
        ),
        2, // ২৮ ও ২৫ আছে, ২২ নেই → সেখানেই থামে
      );
    });
    test('সবশেষ হাটে না দিলে streak ০', () {
      expect(
        motherStreak(
          closedSessionDatesYmd: ['2026-10-28'],
          motherPaymentDatesYmd: {'2026-10-25'},
        ),
        0,
      );
    });
    test('একই দিনে দুই সেশন থাকলে দিন একবারই গোনে', () {
      expect(
        motherStreak(
          closedSessionDatesYmd: ['2026-10-28', '2026-10-28', '2026-10-25'],
          motherPaymentDatesYmd: {'2026-10-28', '2026-10-25'},
        ),
        2,
      );
    });
  });

  group('ব্যস্ততা স্কোর', () {
    test('গড় দিন = ৫০, দ্বিগুণ = ১০০', () {
      expect(BusyScore.score(lines: 10, totalKg: 400, avgLines: 10, avgKg: 400), 50);
      expect(BusyScore.score(lines: 20, totalKg: 800, avgLines: 10, avgKg: 400), 100);
    });
    test('ভিত্তি না থাকলে null', () {
      expect(BusyScore.score(lines: 5, totalKg: 100, avgLines: 0, avgKg: 0), isNull);
    });
  });

  group('বাইক সার্ভিস পূর্বাভাস', () {
    test('বাকি কিমি ও আনুমানিক তারিখ', () {
      final est = estimateNextService(
        nextServiceKm: 12000,
        currentOdometerKm: 11500,
        avgKmPerDay: 50,
        today: DateTime(2026, 10, 30),
      );
      expect(est!.remainingKm, 500);
      expect(est.estimatedDate, DateTime(2026, 11, 9)); // ৫০০÷৫০ = ১০ দিন
    });
    test('গড় চলাচল না জানলে তারিখ null, বাকি কিমি থাকে', () {
      final est = estimateNextService(
        nextServiceKm: 12000,
        currentOdometerKm: 11500,
        avgKmPerDay: null,
        today: DateTime(2026, 10, 30),
      );
      expect(est!.remainingKm, 500);
      expect(est.estimatedDate, isNull);
    });
    test('দৈনিক গড়: ৭ দিনের কম ব্যবধানে null', () {
      final entries = [
        const FuelEntryView(id: '1', txnDate: '2026-10-01', odometerKm: 1000, amountPaisa: 1, isFullTank: true),
        const FuelEntryView(id: '2', txnDate: '2026-10-05', odometerKm: 1200, amountPaisa: 1, isFullTank: true),
      ];
      expect(avgKmPerDayFromFuel(entries), isNull);
      final entries2 = [
        const FuelEntryView(id: '1', txnDate: '2026-10-01', odometerKm: 1000, amountPaisa: 1, isFullTank: true),
        const FuelEntryView(id: '2', txnDate: '2026-10-11', odometerKm: 1500, amountPaisa: 1, isFullTank: true),
      ];
      expect(avgKmPerDayFromFuel(entries2), 50.0); // ৫০০ কিমি ÷ ১০ দিন
    });
  });
}
