// V1.3.1 sync diagnosis: replay the user's REAL server rows (dumped
// 2026-10-31 from the production Supabase project) through the exact
// applyServerRow path the pull phase uses, and find which row throws.
import 'dart:convert';
import 'dart:io';

import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:hat_hisab/data/local/app_database.dart';
import 'package:hat_hisab/data/local/dao/app_repository.dart';

void main() {
  late AppDatabase db;
  late AppRepository repo;

  setUp(() {
    db = AppDatabase.withExecutor(NativeDatabase.memory());
    repo = AppRepository(db);
  });
  tearDown(() async => db.close());

  test('pull replay: every real server row applies without throwing', () async {
    final fixture =
        jsonDecode(File('test/fixtures_server_rows.json').readAsStringSync())
            as Map<String, dynamic>;
    final failures = <String>[];
    for (final entry in fixture.entries) {
      final table = entry.key;
      final rows = (entry.value as List).cast<Map<String, dynamic>>();
      for (final row in rows) {
        try {
          await repo.applyServerRow(table, row);
        } catch (e) {
          failures.add('$table id=${row['id']}: $e');
        }
      }
    }
    for (final f in failures) {
      // ignore: avoid_print
      print('PULL FAILURE -> $f');
    }
    expect(failures, isEmpty, reason: failures.join('\n'));
  });
}
