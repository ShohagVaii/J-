import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:hat_hisab/core/calculations/finance_calc.dart';
import 'package:hat_hisab/data/local/app_database.dart';
import 'package:hat_hisab/data/local/dao/finance_repository.dart';

void main() {
  group('বাজেট হিসাব (FinTracks BudgetView লজিক)', () {
    test('used percent + status: <80 ok, 80–100 warn, >100 over', () {
      expect(budgetUsedPercent(spentPaisa: 40000, limitPaisa: 100000), 40);
      expect(budgetStatus(spentPaisa: 40000, limitPaisa: 100000), BudgetStatus.ok);
      expect(budgetStatus(spentPaisa: 85000, limitPaisa: 100000), BudgetStatus.warn);
      expect(budgetStatus(spentPaisa: 100000, limitPaisa: 100000), BudgetStatus.warn);
      expect(budgetStatus(spentPaisa: 120000, limitPaisa: 100000), BudgetStatus.over);
    });

    test('remaining কখনো ঋণাত্মক নয়; limit 0 হলে noLimit', () {
      expect(budgetRemaining(spentPaisa: 30000, limitPaisa: 100000), 70000);
      expect(budgetRemaining(spentPaisa: 150000, limitPaisa: 100000), 0);
      expect(budgetStatus(spentPaisa: 5000, limitPaisa: 0), BudgetStatus.noLimit);
      expect(budgetUsedPercent(spentPaisa: 0, limitPaisa: 0), 0);
      expect(budgetUsedPercent(spentPaisa: 5000, limitPaisa: 0), 100);
    });
  });

  group('সেভিংস গোল হিসাব', () {
    test('progress percent 0–100-এ সীমাবদ্ধ, reached চেক', () {
      expect(goalProgressPercent(currentPaisa: 25000, targetPaisa: 100000), 25);
      expect(goalProgressPercent(currentPaisa: 150000, targetPaisa: 100000), 100);
      expect(goalProgressPercent(currentPaisa: 5000, targetPaisa: 0), 0);
      expect(goalReached(currentPaisa: 100000, targetPaisa: 100000), isTrue);
      expect(goalReached(currentPaisa: 99999, targetPaisa: 100000), isFalse);
    });
  });

  group('ক্যাটাগরি খরচ + পেমেন্ট মোড', () {
    test('spentByCategory একই ক্যাটাগরির খরচ যোগ করে', () {
      final m = spentByCategory(const [
        CategorySpend(category: 'খাবার', amountPaisa: 10000),
        CategorySpend(category: 'খাবার', amountPaisa: 25050),
        CategorySpend(category: 'যাতায়াত', amountPaisa: 5000),
      ]);
      expect(m['খাবার'], 35050);
      expect(m['যাতায়াত'], 5000);
      expect(m.length, 2);
    });

    test('monthKey ও FinTracks payment mode লেবেল', () {
      expect(monthKeyOf(DateTime(2026, 11, 1)), '2026-11');
      expect(monthKeyOf(DateTime(2026, 1, 5)), '2026-01');
      expect(paymentModeLabel('bkash'), 'বিকাশ');
      expect(paymentModeLabel('rocket'), 'রকেট');
      expect(paymentModeLabel('card'), 'কার্ড');
      expect(finPaymentModes.map((m) => m.$1),
          ['cash', 'bkash', 'nagad', 'rocket', 'bank', 'card']);
    });
  });

  group('FinanceRepository (লোকাল-অনলি টেবিল)', () {
    late AppDatabase db;
    late FinanceRepository fin;

    setUp(() {
      db = AppDatabase.withExecutor(NativeDatabase.memory());
      fin = FinanceRepository(db);
    });
    tearDown(() async => db.close());

    test('schema version 6 — নতুন টেবিলসহ DB তৈরি হয়', () {
      expect(db.schemaVersion, 6);
    });

    test('setBudget: একই category+month আপডেট হয়, অন্য মাস আলাদা রো', () async {
      await fin.setBudget(category: 'খাবার', month: '2026-11', limitPaisa: 1500000);
      await fin.setBudget(category: 'খাবার', month: '2026-11', limitPaisa: 2000000);
      await fin.setBudget(category: 'খাবার', month: '2026-12', limitPaisa: 1800000);
      final nov = await fin.getBudgets('2026-11');
      expect(nov.length, 1);
      expect(nov.first.limitPaisa, 2000000);
      final dec = await fin.getBudgets('2026-12');
      expect(dec.length, 1);
      expect(dec.first.limitPaisa, 1800000);
    });

    test('গোল: addGoal → addToGoal জমা বাড়ায়; বেশি তুললে 0-র নিচে যায় না', () async {
      final id = await fin.addGoal(name: 'নতুন ল্যাপটপ', targetPaisa: 8000000);
      await fin.addToGoal(id, 1500000);
      await fin.addToGoal(id, 500000);
      var goals = await fin.getGoals();
      expect(goals.length, 1);
      expect(goals.first.currentPaisa, 2000000);
      await fin.addToGoal(id, -99999999);
      goals = await fin.getGoals();
      expect(goals.first.currentPaisa, 0);
    });

    test('গোল soft-delete হলে তালিকা থেকে অদৃশ্য হয়', () async {
      final id = await fin.addGoal(name: 'বাইক', targetPaisa: 15000000);
      await fin.deleteGoal(id);
      expect(await fin.getGoals(), isEmpty);
    });

    test('লেনদেন UNION: income_personal + expenses একসাথে আসে; মাসের খরচে ক্যাটাগরি নাম থাকে', () async {
      await db.into(db.categories).insert(CategoriesCompanion.insert(
            id: 'cat-food',
            userId: 'local',
            name: 'খাবার',
          ));
      await db.into(db.incomePersonal).insert(IncomePersonalCompanion.insert(
            id: 'inc1',
            userId: 'local',
            title: 'বেতন',
            txnDate: '2026-11-01',
            amountPaisa: 3000000,
            paymentMethod: const Value('bkash'),
          ));
      await db.into(db.expenses).insert(ExpensesCompanion.insert(
            id: 'exp1',
            userId: 'local',
            categoryId: const Value('cat-food'),
            txnDate: '2026-11-01',
            amountPaisa: 45000,
            paymentMethod: const Value('rocket'),
          ));
      final txns = await fin.watchRecentTransactions().first;
      expect(txns.length, 2);
      final expRow = txns.firstWhere((r) => r.read<String>('src') == 'expense');
      expect(expRow.read<String>('category_name'), 'খাবার');
      expect(expRow.read<String>('payment_method'), 'rocket');
      final month = await fin.monthExpensesWithCategory('2026-11');
      expect(month.length, 1);
      expect(month.first.read<int>('amount_paisa'), 45000);
      expect(month.first.read<String>('category_name'), 'খাবার');
    });
  });
}
