// V1.5.0 — স্থায়ী সিঙ্ক-ফিক্সের regression টেস্ট:
// (C) SyncCompare normalized তুলনা (ভুয়া conflict-এর উৎস ছিল raw string
//     তুলনা — timestamp ফরম্যাটের তফাত),
// (B) adoptServerVersion (profiles version-divergence-এর স্থায়ী block),
// (D) natural-key pull dedupe, mergeDuplicateSeeds, deterministic seed id।
import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:hat_hisab/core/sync/sync_payload.dart';
import 'package:hat_hisab/data/local/app_database.dart';
import 'package:hat_hisab/data/local/dao/app_repository.dart';

void main() {
  late AppDatabase db;
  late AppRepository repo;

  setUp(() {
    db = AppDatabase.withExecutor(NativeDatabase.memory());
    repo = AppRepository(db);
  });
  tearDown(() async => db.close());

  group('SyncCompare (C)', () {
    test('profiles দৃশ্য: version আলাদা + timestamp শুধু ফরম্যাটে আলাদা → সমান', () {
      // সার্ভার: version 6, Z-ফরম্যাট, trailing-zero fraction
      final server = <String, dynamic>{
        'id': 'uid-1',
        'display_name': 'SHOHAG VAII',
        'number_style': 'bn',
        'theme_mode': 'system',
        'daily_closing_time': '21:30',
        'default_mother_amount_paisa': 50000,
        'created_at': '2026-11-01T17:49:37.392380Z',
        'updated_at': '2026-11-01T17:58:30.310011Z',
        'deleted_at': null,
        'version': 6,
      };
      // লোকাল payload: version 2, +00:00 ফরম্যাট, fraction-এ trailing zero নেই
      final local = <String, dynamic>{
        'id': 'uid-1',
        'display_name': 'SHOHAG VAII',
        'number_style': 'bn',
        'theme_mode': 'system',
        'daily_closing_time': '21:30',
        'default_mother_amount_paisa': 50000,
        'created_at': '2026-11-01T17:49:37.39238+00:00',
        'updated_at': '2026-11-01T17:58:30.310011+00:00',
        'deleted_at': null,
        'version': 2,
      };
      expect(SyncCompare.rowsEqual(server, local), isTrue);
    });

    test('Z বনাম +00:00 একই instant; আলাদা instant → আলাদা', () {
      expect(
        SyncCompare.valuesEqual(
            '2026-11-01T17:58:30.310011Z', '2026-11-01T17:58:30.310011+00:00'),
        isTrue,
      );
      expect(
        SyncCompare.valuesEqual(
            '2026-11-01T17:58:30.310011Z', '2026-11-01T17:58:31.310011+00:00'),
        isFalse,
      );
    });

    test('int বনাম double মান দিয়ে সমান (kg 4 বনাম 4.0)', () {
      expect(SyncCompare.valuesEqual(4, 4.0), isTrue);
      expect(SyncCompare.valuesEqual(4, 4.5), isFalse);
      expect(
        SyncCompare.rowsEqual(
          {'kg': 4, 'id': 'x'},
          {'kg': 4.0, 'id': 'x'},
        ),
        isTrue,
      );
    });

    test('আসল পার্থক্য ধরতে পারে: নাম বদল, deleted_at, user_id case', () {
      expect(
        SyncCompare.rowsEqual({'name': 'নগদ'}, {'name': 'বিকাশ'}),
        isFalse,
      );
      expect(
        SyncCompare.rowsEqual(
          {'deleted_at': '2026-11-01T00:00:00.000Z'},
          {'deleted_at': null},
        ),
        isFalse,
      );
      expect(
        SyncCompare.rowsEqual(
          {'user_id': 'ABC-123'},
          {'user_id': 'abc-123'},
        ),
        isTrue,
      );
      // missing key = null
      expect(
        SyncCompare.rowsEqual(<String, dynamic>{}, {'note': null}),
        isTrue,
      );
      expect(
        SyncCompare.rowsEqual(<String, dynamic>{}, {'note': 'কিছু'}),
        isFalse,
      );
      // hat_days list
      expect(SyncCompare.valuesEqual([6, 0], [6, 0]), isTrue);
      expect(SyncCompare.valuesEqual([6], [5]), isFalse);
      // date-only string instant হিসেবে নয়, plain string হিসেবে
      expect(SyncCompare.valuesEqual('2026-11-01', '2026-11-01'), isTrue);
    });
  });

  test('adopt (B): version 2 → সার্ভারের 6, synced, content অক্ষত', () async {
    final id = await repo.insert(
      db.wallets,
      WalletsCompanion.insert(id: '', userId: '', name: 'নগদ'),
    );
    await (db.update(db.wallets)..where((t) => t.id.equals(id)))
        .write(const WalletsCompanion(version: Value(2)));
    var w = await (db.select(db.wallets)..where((t) => t.id.equals(id))).getSingle();
    expect(w.version, 2);
    expect(w.syncStatus, 'pending');

    await repo.adoptServerVersion('wallets', id, 6);

    w = await (db.select(db.wallets)..where((t) => t.id.equals(id))).getSingle();
    expect(w.version, 6);
    expect(w.syncStatus, 'synced');
    expect(w.name, 'নগদ', reason: 'adopt-এ content বদলায় না');
  });

  test('pull dedupe (D): সার্ভার seed wallet (ভিন্ন id) লোকাল seed-এর উপরেই বসে',
      () async {
    // লোকাল seed wallet id 'A' (synced অবস্থা)
    await repo.insert(
      db.wallets,
      WalletsCompanion.insert(
        id: '',
        userId: '',
        name: 'নগদ',
        type: const Value('cash'),
      ),
      id: 'A',
    );
    await (db.update(db.wallets)..where((t) => t.id.equals('A')))
        .write(const WalletsCompanion(syncStatus: Value('synced')));

    // সার্ভার থেকে একই (নগদ, cash) কিন্তু id 'B' ও নতুন মান
    await repo.applyServerRow('wallets', {
      'id': 'B',
      'user_id': 'local',
      'name': 'নগদ',
      'type': 'cash',
      'opening_balance_paisa': 50000,
      'is_archived': false,
      'created_at': '2026-11-01T00:00:00.000Z',
      'updated_at': '2026-11-01T02:00:00.000Z',
      'deleted_at': null,
      'version': 3,
    });

    final all = await db.select(db.wallets).get();
    expect(all.length, 1, reason: 'ডুপ্লিকেট row তৈরি হওয়া যাবে না');
    expect(all.first.id, 'A', reason: 'লোকাল id-ই থাকবে');
    expect(all.first.openingBalancePaisa, 50000,
        reason: 'সার্ভার content লোকাল row-তে প্রযুক্ত হয়েছে');
    expect(all.first.version, 3);
    expect(all.first.syncStatus, 'synced');
  });

  test('pull dedupe (D): user-তৈরি একই type-এর wallet জোর করে মেলে না', () async {
    // লোকাল wallet (নগদ, cash) নয় — নাম আলাদা, শুধু type এক
    await repo.insert(
      db.wallets,
      WalletsCompanion.insert(
        id: '',
        userId: '',
        name: 'আমার ক্যাশ',
        type: const Value('cash'),
      ),
      id: 'U1',
    );
    await (db.update(db.wallets)..where((t) => t.id.equals('U1')))
        .write(const WalletsCompanion(syncStatus: Value('synced')));

    await repo.applyServerRow('wallets', {
      'id': 'B',
      'user_id': 'local',
      'name': 'নগদ',
      'type': 'cash',
      'opening_balance_paisa': 0,
      'is_archived': false,
      'created_at': '2026-11-01T00:00:00.000Z',
      'updated_at': '2026-11-01T02:00:00.000Z',
      'deleted_at': null,
      'version': 1,
    });

    final all = await db.select(db.wallets).get();
    expect(all.length, 2,
        reason: 'seed pair না হলে natural-key merge নয় — সার্ভার row আলাদা ঢুকবে');
  });

  test('mergeDuplicateSeeds (D): রেফারেন্স repoint + dupe soft-delete + idempotent',
      () async {
    // দুটো (নগদ, cash) seed wallet — W1 আগে তৈরি, W2 পরে
    await db.into(db.wallets).insert(WalletsCompanion.insert(
          id: 'W1',
          userId: 'local',
          name: 'নগদ',
          type: const Value('cash'),
          createdAt: const Value('2026-10-30T10:00:00.000Z'),
          updatedAt: const Value('2026-10-30T10:00:00.000Z'),
          syncStatus: const Value('synced'),
        ));
    await db.into(db.wallets).insert(WalletsCompanion.insert(
          id: 'W2',
          userId: 'local',
          name: 'নগদ',
          type: const Value('cash'),
          createdAt: const Value('2026-11-01T10:00:00.000Z'),
          updatedAt: const Value('2026-11-01T10:00:00.000Z'),
          syncStatus: const Value('synced'),
        ));
    // দুটোতেই ১টা করে খরচের রেফারেন্স (tie) → keeper = earliest created = W1
    await repo.insert(
      db.expenses,
      ExpensesCompanion.insert(
        id: '',
        userId: '',
        txnDate: '2026-11-01',
        amountPaisa: 10000,
        walletId: const Value('W1'),
      ),
    );
    await repo.insert(
      db.expenses,
      ExpensesCompanion.insert(
        id: '',
        userId: '',
        txnDate: '2026-11-01',
        amountPaisa: 20000,
        walletId: const Value('W2'),
      ),
    );

    final merged = await repo.mergeDuplicateSeeds();
    expect(merged, 1);

    final live = await (db.select(db.wallets)
          ..where((t) => t.deletedAt.isNull()))
        .get();
    expect(live.length, 1);
    expect(live.first.id, 'W1');

    final w2 = await (db.select(db.wallets)..where((t) => t.id.equals('W2')))
        .getSingle();
    expect(w2.deletedAt, isNotNull, reason: 'dupe soft-deleted হবে');

    final exps = await db.select(db.expenses).get();
    expect(exps.every((e) => e.walletId == 'W1'), isTrue,
        reason: 'সব রেফারেন্স keeper-এ repoint হবে');

    // idempotent — আবার চালালে কিছুই merge হবে না
    expect(await repo.mergeDuplicateSeeds(), 0);
    final live2 = await (db.select(db.wallets)
          ..where((t) => t.deletedAt.isNull()))
        .get();
    expect(live2.length, 1);
  });

  test('deterministic seed id (D): একই input → একই id, scope বদলালে আলাদা',
      () {
    final a = SyncPayload.deterministicSeedId('local', 'wallets', 'cash');
    final b = SyncPayload.deterministicSeedId('local', 'wallets', 'cash');
    final c = SyncPayload.deterministicSeedId('uid-9', 'wallets', 'cash');
    final d = SyncPayload.deterministicSeedId('local', 'wallets', 'bkash');
    expect(a, b);
    expect(a, isNot(c));
    expect(a, isNot(d));
    // UUIDv5 ফরম্যাট: version nibble 5, variant 8/9/a/b
    expect(a.length, 36);
    expect(a[14], '5');
    expect('89ab'.contains(a[19]), isTrue);
  });

  test('seed (D): fresh DB-তে deterministic id-তেই seed হয়, পুনঃseed হয় না',
      () async {
    await repo.seedIfNeeded();
    final wallets = await db.select(db.wallets).get();
    expect(wallets.length, 4);
    final cash = wallets.firstWhere((w) => w.type == 'cash');
    expect(
      cash.id,
      SyncPayload.deterministicSeedId('local', 'wallets', 'cash'),
    );
    final cats = await db.select(db.categories).get();
    expect(cats.length, 21); // ৫ income + ৭ session + ৯ both
    final food = cats.firstWhere((c) => c.name == 'খাবার');
    expect(
      food.id,
      SyncPayload.deterministicSeedId('local', 'categories', 'খাবার|both'),
    );
    // দ্বিতীয়বার — সংখ্যা বাড়বে না
    await repo.seedIfNeeded();
    expect((await db.select(db.wallets).get()).length, 4);
    expect((await db.select(db.categories).get()).length, 21);
  });
}
