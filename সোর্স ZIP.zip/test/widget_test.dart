import 'package:flutter_test/flutter_test.dart';

import 'package:hat_hisab/core/calculations/dps_calc.dart';
import 'package:hat_hisab/core/calculations/loan_calc.dart';
import 'package:hat_hisab/core/calculations/mileage_calc.dart';
import 'package:hat_hisab/core/calculations/session_calc.dart';
import 'package:hat_hisab/core/calculations/update_version.dart';
import 'package:hat_hisab/core/utils/bangla_digits.dart';
import 'package:hat_hisab/core/utils/money_format.dart';

void main() {
  group('বাংলা সংখ্যা ও টাকা', () {
    test('toBanglaDigits / fromBanglaDigits round trip', () {
      expect(toBanglaDigits('1234.5'), '১২৩৪.৫');
      expect(fromBanglaDigits('১২৩৪.৫'), '1234.5');
      expect(fromBanglaDigits(toBanglaDigits('987654')), '987654');
    });

    test('parseTakaToPaisa — বাংলা ও ইংরেজি', () {
      expect(parseTakaToPaisa('১২৩৪'), 123400);
      expect(parseTakaToPaisa('1234.50'), 123450);
      expect(parseTakaToPaisa('৳ 2,500'), 250000);
      expect(parseTakaToPaisa(''), isNull);
    });

    test('MoneyFmt.taka বাংলা ফরম্যাট', () {
      expect(MoneyFmt.taka(123450), '৳১,২৩৪.৫০');
      expect(MoneyFmt.taka(-5000), '-৳৫০.০০');
      expect(MoneyFmt.takaShort(25000000), '৳২,৫০,০০০');
    });

    test('weighted average 4333 case', () {
      // ২ কেজি × ৩০ + ৩ কেজি × ৫০ → মোট ২১০ ÷ ৫ = ৪২০০ পয়সা/কেজি = ৳৪২
      final avg = SessionCalc.weightedAvgRate(totalKg: 5, totalPaisa: 21000);
      expect(avg, 4200);
    });
  });

  group('সেশন সূত্র', () {
    test('expected cash — পারিশ্রমিক বাদ', () {
      final expected = SessionCalc.expectedCash(
        openingCashPaisa: 50000,
        ownerCashReceivedPaisa: 1000000,
        purchasePaidPaisa: 800000,
        sessionExpensePaisa: 50000,
        chotaPaisa: 10000,
        slipChargePaisa: 5000,
        memoChargePaisa: 5000,
        returnedToOwnerPaisa: 200000,
      );
      // ৳500 + ৳10000 − ৳8000 − ৳500 − ৳100 − ৳50 − ৳50 − ৳2000 = ৳−২০০ (ফেরত বেশি)
      expect(expected, -20000);
    });

    test('difference', () {
      expect(SessionCalc.difference(countedPaisa: 500000, expectedPaisa: 480000), 20000);
      expect(SessionCalc.difference(countedPaisa: 400000, expectedPaisa: 480000), -80000);
    });

    test('line total rounding', () {
      expect(SessionCalc.lineTotal(kg: 12.345, ratePaisaPerKg: 4500), 55553); // 12.345×4500=55552.5→round
      expect(SessionCalc.lineTotal(kg: 0, ratePaisaPerKg: 4500), 0);
    });

    test('মন হিসাব — ১ মন = ৪০ কেজি', () {
      expect(SessionCalc.kgPerMaund, 40);
      // ৳১৪৫০/মন → ৳৩৬.২৫/কেজি (145000/40 = 3625 পয়সা)
      expect(SessionCalc.paisaPerKgFromMaund(145000), 3625);
      // V1.3 (docs/07): লাইন-মোট পূর্ণ টাকায় নামিয়ে — ৪৫ কেজি × ৳১৪৫০/মন
      // = ৳১৬৩১.২৫ → ৳১,৬৩১ = ১৬৩১০০ পয়সা
      expect(SessionCalc.lineTotalMaund(kg: 45, ratePaisaPerMaund: 145000), 163100);
      expect(MoneyFmt.taka(163100), '৳১,৬৩১.০০');
      expect(MoneyFmt.rate(3625), '৳৩৬.২৫/কেজি');
      expect(MoneyFmt.rateMaund(3625), '৳১,৪৫০/মন');
      expect(MoneyFmt.rateMaund(116667), '৳৪৬,৬৬৬.৮০/মন');
    });
  });

  group('মাইলেজ', () {
    List<FuelEntryView> entries() => [
          const FuelEntryView(id: '1', txnDate: '2026-01-01', odometerKm: 1000, amountPaisa: 100000, litre: 5, isFullTank: true),
          const FuelEntryView(id: '2', txnDate: '2026-01-02', odometerKm: 1100, amountPaisa: 20000, litre: 1, isFullTank: false),
          const FuelEntryView(id: '3', txnDate: '2026-01-03', odometerKm: 1241, amountPaisa: 300000, litre: 5, isFullTank: true),
        ];

    test('ফুল-ট্যাংক মাইলেজ: (1241-1000)/(1+5) = 40.2', () {
      final r = computeMileage(entries());
      expect(r[0].kmPerLitre, isNull);
      expect(r[1].approximate, isTrue);
      expect(r[2].kmPerLitre!.toStringAsFixed(1), '40.2');
    });

    test('average — এক জোড়া', () {
      final avg = averageMileage(entries());
      expect(avg!.toStringAsFixed(1), '40.2');
    });

    test('একটি এন্ট্রি হলে মাইলেজ নেই', () {
      final r = computeMileage([
        const FuelEntryView(id: 'x', txnDate: '2026-01-01', odometerKm: 500, amountPaisa: 100000, litre: 4, isFullTank: true),
      ]);
      expect(r.single.kmPerLitre, isNull);
    });

    test('আনুমানিক মোড', () {
      final r = computeMileage([
        const FuelEntryView(id: 'a', txnDate: '2026-01-01', odometerKm: 100, amountPaisa: 100000, litre: 2, isFullTank: false),
      ]);
      expect(r.single.approximate, isTrue);
    });
  });

  group('ধার', () {
    test('স্টেটাস নির্ধারণ', () {
      expect(deriveLoanStatus(paidPaisa: 0, principalPaisa: 100000), LoanStatus.ongoing);
      expect(deriveLoanStatus(paidPaisa: 50000, principalPaisa: 100000), LoanStatus.partial);
      expect(deriveLoanStatus(paidPaisa: 100000, principalPaisa: 100000), LoanStatus.settled);
      expect(
        deriveLoanStatus(paidPaisa: 0, principalPaisa: 100000, dueDateYmd: '2026-01-01', today: DateTime(2026, 1, 15)),
        LoanStatus.overdue,
      );
    });

    test('ওভারপে ব্লক', () {
      expect(canAddLoanPayment(currentPaidPaisa: 80000, principalPaisa: 100000, newAmountPaisa: 20000), isTrue);
      expect(canAddLoanPayment(currentPaidPaisa: 80000, principalPaisa: 100000, newAmountPaisa: 30000), isFalse);
    });
  });

  group('DPS', () {
    test('মাসিক next due', () {
      final next = nextDueDate(
        frequency: DpsFrequency.monthly,
        dueDay: 5,
        startDateYmd: '2026-01-05',
        lastDepositDateYmd: '2026-01-05',
        today: DateTime(2026, 1, 20),
      );
      expect(next, '2026-02-05');
    });

    test('সাপ্তাহিক next due — পরের শুক্রবার', () {
      final next = nextDueDate(
        frequency: DpsFrequency.weekly,
        dueDay: 5, // শুক্র
        startDateYmd: '2026-10-23', // শুক্র
        lastDepositDateYmd: '2026-10-23',
        today: DateTime(2026, 10, 23),
      );
      expect(next, '2026-10-30');
    });

    test('দৈনিক next due', () {
      final next = nextDueDate(
        frequency: DpsFrequency.daily,
        dueDay: 1,
        startDateYmd: '2026-10-28',
        lastDepositDateYmd: '2026-10-28',
        today: DateTime(2026, 10, 28),
      );
      expect(next, '2026-10-29');
    });

    test('মোট জমা ও streak', () {
      expect(totalDeposited([50000, 50000, 30000]), 130000);
      final streak = streakCount(
        frequency: DpsFrequency.weekly,
        depositDatesAsc: ['2026-10-09', '2026-10-16', '2026-10-23'],
      );
      expect(streak, 3);
    });

    test('expected deposits count — মাসিক', () {
      final n = expectedDepositsCount(
        frequency: DpsFrequency.monthly,
        startDateYmd: '2026-01-01',
        today: DateTime(2026, 3, 15),
      );
      expect(n, 3);
    });
  });

  group('ভার্সন তুলনা', () {
    test('compareVersions', () {
      expect(compareVersions('1.1.0', '1.0.9'), 1);
      expect(compareVersions('1.1.0', '1.1.0'), 0);
      expect(compareVersions('1.0.0', '2.0.0'), -1);
      expect(compareVersions('1.10.0', '1.9.0'), 1);
    });
  });
}
