// Audit 2026-10-29 — FIX রিগ্রেশন টেস্ট (T-1/T-2)
// আগের suite সরাসরি db.into(...) ব্যবহার করত, তাই AppRepository-র
// ভাঙা generic write path (C-1) কোনোদিন ধরা পড়েনি। এই ফাইলটি
// repository দিয়েই লেখে/পড়ে।
import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:hat_hisab/core/calculations/dps_calc.dart';
import 'package:hat_hisab/core/calculations/loan_calc.dart';
import 'package:hat_hisab/core/calculations/mileage_calc.dart';
import 'package:hat_hisab/core/utils/bangla_digits.dart';
import 'package:hat_hisab/data/local/app_database.dart';
import 'package:hat_hisab/data/local/dao/app_repository.dart';

void main() {
  late AppDatabase db;
  late AppRepository repo;

  setUp(() {
    db = AppDatabase.withExecutor(NativeDatabase.memory());
    repo = AppRepository(db);
  });
  tearDown(() async => db.close());

  group('Repository generic write path (FIX C-1)', () {
    test('insert → watch-এ আসে; update → বদলায়; softDelete → লুকায়; restore → ফেরে', () async {
      final id = await repo.insert(
        db.wallets,
        WalletsCompanion.insert(id: '', userId: '', name: 'নগদ টেস্ট'),
      );
      var wallets = await repo.watchWallets().first;
      expect(wallets.length, 1);
      expect(wallets.first.id, id);
      expect(wallets.first.userId, 'local');

      await repo.update(db.wallets, id, WalletsCompanion(name: const Value('বদলানো নাম')));
      wallets = await repo.watchWallets().first;
      expect(wallets.first.name, 'বদলানো নাম');
      expect(wallets.first.version, 2);

      await repo.softDelete('wallets', id);
      expect(await repo.watchWallets().first, isEmpty);

      await repo.restore('wallets', id);
      expect((await repo.watchWallets().first).length, 1);
    });

    test('update-এ nullable ফিল্ড মোছা যায় (FIX M-4)', () async {
      final id = await repo.insert(
        db.hats,
        HatsCompanion.insert(id: '', userId: '', name: 'হাট', location: const Value('কালুখালী')),
      );
      await repo.update(db.hats, id, HatsCompanion(location: const Value(null)));
      final rows = await db.select(db.hats).get();
      expect(rows.single.location, isNull);
    });

    test('profiles insert — user_id কলাম ছাড়াই কাজ করে (FIX M-5)', () async {
      await repo.saveProfileFields(displayName: 'সোহাগ');
      final p = await repo.watchProfile().first;
      expect(p?.displayName, 'সোহাগ');
    });
  });

  group('Wallet balance (FIX C-2)', () {
    test('bike_maintenance-এর cost_paisa হিসাবে balance আসে', () async {
      final wid = await repo.insert(
        db.wallets,
        WalletsCompanion.insert(id: '', userId: '', name: 'নগদ', openingBalancePaisa: const Value(100000)),
      );
      await repo.insert(
        db.bikeMaintenance,
        BikeMaintenanceCompanion.insert(
          id: '', userId: '',
          txnDate: '2026-10-29',
          type: const Value('mobil'),
          itemName: 'মোবিল',
          costPaisa: 45000,
          walletId: Value(wid),
        ),
      );
      final balances = await repo.watchWalletBalances().first;
      expect(balances.length, 1);
      expect(balances.first.read<int>('balance_paisa'), 100000 - 45000);
      expect(await repo.cashInHand(), 55000);
    });
  });

  group('Settings/Meta upsert (FIX C-4)', () {
    test('একই key দুবার লিখলে crash নয়, নতুন মান থাকে', () async {
      await repo.setSetting('k', '1');
      await repo.setSetting('k', '2');
      expect(await repo.getSetting('k'), '2');
      await repo.setMeta('m', 'a');
      await repo.setMeta('m', 'b');
      expect(await repo.getMeta('m'), 'b');
    });
  });

  group('Migration (FIX C-3)', () {
    test('profiles সহ migrate crash করে না', () async {
      await repo.insert(db.wallets, WalletsCompanion.insert(id: '', userId: '', name: 'নগদ'));
      await repo.saveProfileFields(displayName: 'গেস্ট');
      final n = await repo.migrateLocalDataToUser('user-123');
      // Supa লগইন নেই → কিউ হয় না, তবে transaction অংশ শেষ হয়
      expect(n, 0);
      final rows = await db.select(db.wallets).get();
      expect(rows.single.userId, 'user-123');
    });
  });

  group('Daily closing double-close (FIX H-1)', () {
    test('একই দিন দুবার insert হলে unique index আটকায়', () async {
      await repo.insert(
        db.dailyClosings,
        DailyClosingsCompanion.insert(id: '', userId: '', txnDate: '2026-10-29'),
      );
      expect(
        () => repo.insert(
          db.dailyClosings,
          DailyClosingsCompanion.insert(id: '', userId: '', txnDate: '2026-10-29'),
        ),
        throwsA(anything),
      );
    });
  });

  group('Calc edge cases (FIX H-2/H-3/H-8, M-2, M-9)', () {
    test('ওডোমিটার কমে গেলে মাইলেজ null', () {
      final r = computeMileage(const [
        FuelEntryView(id: '1', txnDate: '2026-01-01', odometerKm: 5000, amountPaisa: 100000, litre: 5, isFullTank: true),
        FuelEntryView(id: '2', txnDate: '2026-01-02', odometerKm: 4900, amountPaisa: 100000, litre: 5, isFullTank: true),
      ]);
      expect(r[1].kmPerLitre, isNull);
      expect(averageMileage(const [
        FuelEntryView(id: '1', txnDate: '2026-01-01', odometerKm: 5000, amountPaisa: 100000, litre: 5, isFullTank: true),
        FuelEntryView(id: '2', txnDate: '2026-01-02', odometerKm: 4900, amountPaisa: 100000, litre: 5, isFullTank: true),
      ]), isNull);
    });

    test('ফুল বেসলাইনের পরে আংশিক ভরায় মাইলেজ null (আনুমানিক পতাকাসহ)', () {
      final r = computeMileage(const [
        FuelEntryView(id: '1', txnDate: '2026-01-01', odometerKm: 1000, amountPaisa: 100000, litre: 5, isFullTank: true),
        FuelEntryView(id: '2', txnDate: '2026-01-02', odometerKm: 1100, amountPaisa: 20000, litre: 1, isFullTank: false),
      ]);
      expect(r[1].kmPerLitre, isNull);
      expect(r[1].approximate, isTrue);
    });

    test('DPS পুরনো last deposit — next due অতীতে নয়', () {
      final next = nextDueDate(
        frequency: DpsFrequency.monthly,
        dueDay: 5,
        startDateYmd: '2026-01-05',
        lastDepositDateYmd: '2026-01-05',
        today: DateTime(2026, 4, 20),
      );
      expect(next, '2026-05-05');
    });

    test('DPS জমা নেই — প্রথম কিস্তি বাদ যায় না', () {
      final next = nextDueDate(
        frequency: DpsFrequency.monthly,
        dueDay: 5,
        startDateYmd: '2026-01-05',
        today: DateTime(2026, 1, 3),
      );
      expect(next, '2026-01-05');
    });

    test('parseTakaToPaisa আবর্জনা প্রত্যাখ্যান করে', () {
      expect(parseTakaToPaisa('abc'), isNull);
      expect(parseTakaToPaisa('1.2.3'), isNull);
      expect(parseTakaToPaisa('10.999'), isNull);
      expect(parseTakaToPaisa('1234.50'), 123450);
    });

    test('ঋণাত্মক/শূন্য লোন পরিশোধ ব্লক', () {
      expect(canAddLoanPayment(currentPaidPaisa: 0, principalPaisa: 1000, newAmountPaisa: 0), isFalse);
      expect(canAddLoanPayment(currentPaidPaisa: 0, principalPaisa: 1000, newAmountPaisa: -500), isFalse);
      expect(loanRemainingPaisa(principalPaisa: 1000, paidPaisa: 1500), 0);
    });
  });
}
